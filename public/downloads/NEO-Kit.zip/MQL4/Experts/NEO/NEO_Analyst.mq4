﻿//+------------------------------------------------------------------+
//|                                                  NEO_Analyst.mq4 |
//|  NEO analyst: reads W1 / D1 / H4 with the NEO rules (NeoCore.mqh,|
//|  the same formulas as NC / NS / NE) and reports.                 |
//|                                                                  |
//|  Messages (Telegram, MT4 push, Alert):                           |
//|    daily   one analysis on the first start of each server day:   |
//|            state of every timeframe and the zones to watch       |
//|            within InpWatchPips above and below price             |
//|    LP      new LP, GLP / RLP, cleared, new Main (H4, D1, W1)     |
//|    struct  BOS, CHoCH, confirmation, failed turn (H4, D1)        |
//|    touch   price reaches a watched zone or level                 |
//|    EP      potential entry by the NE rule: H4 trend, price at a  |
//|            watch zone (RT / PR / LP), reaction on M15            |
//|                                                                  |
//|  Orders: the EA never opens or closes an order. For market       |
//|  orders of this symbol (manual ones by default) it sets a        |
//|  missing stop and target and moves the stop to break-even.       |
//|                                                                  |
//|  EP messages are textbook setups for review. The research behind |
//|  NEO found no robust edge in them; they are not tested signals.  |
//|                                                                  |
//|  Required: Tools > Options > Expert Advisors > Allow WebRequest  |
//|  for https://api.telegram.org                                    |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "NEO analyst: daily analysis, LP / structure / touch / EP messages, stop, target and break-even for manual orders."
#property description "Allow WebRequest for https://api.telegram.org in Tools > Options > Expert Advisors."

#include "NeoCore.mqh"

enum ENUM_NEO_BE
  {
   NEO_BE_OFF  = 0,  // Off
   NEO_BE_PIPS = 1,  // After InpBePips in profit
   NEO_BE_RISK = 2   // After 1R (the stop distance) in profit
  };

input string InpTelegramToken   = "";      // Telegram bot token, empty = off
input string InpTelegramChatId  = "";      // Telegram chat id
input bool   InpPush            = true;    // Also send an MT4 push notification (needs MetaQuotes ID)
input bool   InpAlert           = true;    // Also show an Alert on this terminal
input int    InpQuietFrom       = -1;      // Quiet hours start (server hour 0-23, -1 = off)
input int    InpQuietTo         = -1;      // Quiet hours end (server hour)

input bool   InpDailyReport     = true;    // Send the analysis once per day at the first start
input double InpWatchPips       = 100;     // Analysis lists zones within this many pips above and below price
input bool   InpSendLp          = true;    // Message on LP events (H4, D1, W1)
input bool   InpSendStructure   = true;    // Message on structure events (H4, D1)
input bool   InpSendTouch       = true;    // Message when price reaches a watched zone
input double InpTouchPips       = 3;       // Price this close to a zone counts as a touch
input double InpRearmPips       = 15;      // A zone can alert again after price moved this far away
input int    InpSwingsPerSide   = 3;       // Nearest unbroken swings watched above and below, per timeframe

input bool   InpSendEp          = true;    // Message on potential entries (NE rule)
input bool   InpZoneRetest      = true;    // EP zone: retest of the level broken by the last H4 break (RT)
input bool   InpZoneProtect     = true;    // EP zone: the H4 protected level (PR)
input bool   InpZoneLp          = true;    // EP zone: live H4 LP on the trend side (LP)
input bool   InpTrigSweep       = true;    // EP reaction: sweep
input bool   InpTrigReject      = false;   // EP reaction: rejection
input bool   InpTrigThrust      = true;    // EP reaction: thrust
input double InpBandRangeMult   = 0.5;     // Half width of the RT / PR band, in median H4 candle ranges
input double InpBandMinPips     = 8;       // ... but never less than this many pips
input int    InpConfirmBars     = 32;      // M15 candles after the first touch in which a reaction is looked for
input int    InpZoneLifeBars    = 480;     // An EP zone is dropped this many M15 candles after it appeared
input double InpBigRange        = 1.75;    // Rejection / thrust: range >= this x the median of the 20 candles before
input double InpRiskPercent     = 1.0;     // Lot suggestion: risk per trade in % of the balance

input bool   InpManageOrders    = true;    // Manage stop, target and break-even of open orders
input bool   InpManualOnly      = true;    // Only orders opened by hand (magic number 0)
input bool   InpSetStop         = true;    // Set a stop when the order has none
input bool   InpSetTarget       = true;    // Set a target when the order has none
input double InpStopPadPips     = 3;       // Stop this far beyond the M15 extreme
input double InpMaxStopPips     = 40;      // Largest stop distance the EA will set
input double InpMinTargetPips   = 30;      // Target must be at least this far from the entry
input ENUM_NEO_BE InpBeMode     = NEO_BE_PIPS; // Break-even rule
input double InpBePips          = 10;      // Break-even: profit in pips that triggers it
input double InpBeLockPips      = 1;       // Break-even: stop goes to the entry plus this many pips

input bool   InpShowPanel       = true;    // Status panel on the chart

#define PREFIX        "NEOA_"
#define ZONE_RETEST   1
#define ZONE_PROTECT  2
#define ZONE_LP       3
#define PANEL_LINES   9

CNeoFrame gH4, gD1, gW1, gEp, gM15;
datetime  gLastBar[3], gLastM15 = 0;
bool      gReady = false;
double    gPip = 0;
string    gLastMessage = "";
string    gWarning = "";
datetime  gDailyRetry = 0, gPanelTime = 0;

// Watch list: zones and levels of H4 / D1 / W1
string    wName[], wKey[];
double    wLow[], wHigh[];
bool      wArmed[];
int       wCount = 0;

// EP zones (NE rule), rebuilt on every closed M15 candle
int       zType[], zDirection[], zBornBar[], zTouchBar[];
double    zTop[], zBottom[], zLevel[], zExtreme[];
bool      zDone[];
int       zCount = 0;

// M15 candles as series (index = shift)
double    mOpen[], mHigh[], mLow[], mClose[];
datetime  mTime[];
int       mCount = 0;

// Orders whose modification failed: retry later
int       tTicket[];
datetime  tTime[];

//+------------------------------------------------------------------+
int OnInit()
  {
   gPip = NeoPip(Symbol());
   ArrayInitialize(gLastBar, 0);
   gLastM15 = 0;
   gReady = false;
   wCount = 0;
   EventSetTimer(2);
   if(InpTelegramToken == "" || InpTelegramChatId == "")
      Print("NEO_Analyst: Telegram token or chat id is empty, messages go to push / Alert / the Experts log only");
   Process();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   ObjectsDeleteAll(0, PREFIX);
  }

void OnTick()  { Process(); }
void OnTimer() { Process(); }

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id != CHARTEVENT_OBJECT_CLICK || sparam != PREFIX + "button")
      return;
   ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
   if(gReady)
      Send(Analysis(), true);
  }

//+------------------------------------------------------------------+
void Process()
  {
   RefreshRates();
   if(!Refresh())
     {
      gWarning = "Đang tải dữ liệu W1 / D1 / H4 / M15...";
      UpdatePanel(true);
      return;
     }
   ManageOrders();
   CheckTouches();
   DailyReport();
   UpdatePanel(false);
  }

//+------------------------------------------------------------------+
//| Recomputes a timeframe when it has a new closed candle and       |
//| reports what that candle did.                                    |
//+------------------------------------------------------------------+
bool Refresh()
  {
   int  timeframes[3] = {PERIOD_H4, PERIOD_D1, PERIOD_W1};
   bool changed = false;
   for(int k = 0; k < 3; k++)
     {
      datetime bar = iTime(Symbol(), timeframes[k], 0);
      if(bar == 0)
         return(false);
      if(bar == gLastBar[k])
         continue;
      if(!FrameOf(k).Load(Symbol(), timeframes[k], 2500))
         return(false);
      FrameOf(k).Run();
      if(gLastBar[k] != 0)
         ReportFrameEvents(FrameOf(k));
      gLastBar[k] = bar;
      changed = true;
     }
   datetime m15 = iTime(Symbol(), PERIOD_M15, 0);
   if(m15 == 0)
      return(false);
   if(m15 != gLastM15)
     {
      if(!RunEp(gLastM15 != 0))
         return(false);
      gLastM15 = m15;
     }
   if(changed)
      BuildWatchList();
   gReady = true;
   if(gWarning == "Đang tải dữ liệu W1 / D1 / H4 / M15...")
      gWarning = "";
   return(true);
  }

CNeoFrame *FrameOf(int k)
  {
   if(k == 0)
      return(GetPointer(gH4));
   if(k == 1)
      return(GetPointer(gD1));
   return(GetPointer(gW1));
  }

//+------------------------------------------------------------------+
string P(double price)
  {
   return(DoubleToString(price, Digits));
  }

string Pips(double distance)
  {
   return(DoubleToString(MathAbs(distance) / gPip, 0) + " pip");
  }

string StateName(int state)
  {
   switch(state)
     {
      case NEO_UP:        return("xu hướng TĂNG");
      case NEO_DOWN:      return("xu hướng GIẢM");
      case NEO_TURN_DOWN: return("đang đảo chiều giảm (CHoCH, chưa xác nhận)");
      case NEO_TURN_UP:   return("đang đảo chiều tăng (CHoCH, chưa xác nhận)");
     }
   return("chưa rõ xu hướng");
  }

//+------------------------------------------------------------------+
//| NC colour of the last closed candle: M = EMA50 - EMA200.         |
//+------------------------------------------------------------------+
string CandleColour(int timeframe)
  {
   double now = iMA(Symbol(), timeframe, 50, 0, MODE_EMA, PRICE_CLOSE, 1) - iMA(Symbol(), timeframe, 200, 0, MODE_EMA, PRICE_CLOSE, 1);
   double previous = iMA(Symbol(), timeframe, 50, 0, MODE_EMA, PRICE_CLOSE, 2) - iMA(Symbol(), timeframe, 200, 0, MODE_EMA, PRICE_CLOSE, 2);
   if(now > 0)
      return(now > previous ? "xanh lá (M > 0, đang mạnh lên)" : "xanh dương (M > 0, đang yếu đi)");
   return(now > previous ? "hồng (M < 0, đang hồi)" : "đỏ (M < 0, đang giảm)");
  }

//+------------------------------------------------------------------+
void ReportFrameEvents(CNeoFrame *frame)
  {
   string tf = NeoTfName(frame.timeframe);
   string text = "";
   if(InpSendStructure && frame.timeframe != PERIOD_W1 && frame.evKind != NEO_EV_NONE)
     {
      string side = (frame.evDirection == 1) ? "lên" : "xuống";
      switch(frame.evKind)
        {
         case NEO_EV_BOS:
            text += "• BOS " + side + ": nến đóng qua " + P(frame.evLevel) + ". Mức bảo vệ mới " + P(frame.guard) + ".\n";
            break;
         case NEO_EV_CHOCH:
            text += "• CHoCH " + side + ": nến đóng qua mức bảo vệ " + P(frame.evLevel) + ". Cấu trúc " + StateName(frame.state) + ".\n";
            break;
         case NEO_EV_CONFIRM:
            text += "• Xác nhận đảo chiều " + side + ": đóng qua " + P(frame.evLevel) + ". Mức bảo vệ mới " + P(frame.guard) + ".\n";
            break;
         case NEO_EV_FAILED:
            text += "• Đảo chiều thất bại, quay lại xu hướng " + side + ": đóng qua " + P(frame.evLevel) + ". Mức bảo vệ " + P(frame.guard) + ".\n";
            break;
         case NEO_EV_START:
            text += "• Bắt đầu xu hướng " + side + ": đóng qua " + P(frame.evLevel) + ".\n";
            break;
        }
     }
   if(InpSendLp)
     {
      if(frame.evLpNew >= 0)
         text += "• LP mới " + tf + " [" + P(frame.lpLow[frame.evLpNew]) + " – " + P(frame.lpHigh[frame.evLpNew]) + "], chưa bị phá.\n";
      for(int k = 0; k < ArraySize(frame.evLpSided); k++)
        {
         int z = frame.evLpSided[k];
         text += "• LP " + tf + " [" + P(frame.lpLow[z]) + " – " + P(frame.lpHigh[z]) + "] bị phá " +
                 (frame.lpDirection[z] == 1 ? "lên → GLP (hỗ trợ)" : "xuống → RLP (kháng cự)") + ".\n";
        }
      for(int k = 0; k < ArraySize(frame.evLpDead); k++)
        {
         int z = frame.evLpDead[k];
         text += "• " + (frame.lpDirection[z] == 1 ? "GLP " : "RLP ") + tf + " [" + P(frame.lpLow[z]) + " – " + P(frame.lpHigh[z]) +
                 "] bị xoá: giá đóng qua cạnh xa.\n";
        }
      if(frame.evLpMain >= 0)
        {
         int z = frame.evLpMain;
         text += "• Main mới: " + frame.LpName(z) + " [" + P(frame.lpLow[z]) + " – " + P(frame.lpHigh[z]) + "].\n";
        }
     }
   if(text != "")
      Send("🔔 " + Symbol() + " · sự kiện " + tf + " (nến vừa đóng)\n" + text + "Giá " + P(Bid), false);
  }

//+------------------------------------------------------------------+
//| Watch list                                                       |
//+------------------------------------------------------------------+
void AddWatch(string name, string key, double low, double high, string &oldKey[], bool &oldArmed[])
  {
   int size = wCount + 1;
   ArrayResize(wName, size, 32);
   ArrayResize(wKey, size, 32);
   ArrayResize(wLow, size, 32);
   ArrayResize(wHigh, size, 32);
   ArrayResize(wArmed, size, 32);
   wName[wCount] = name;
   wKey[wCount] = key;
   wLow[wCount] = low;
   wHigh[wCount] = high;
   // A zone that price already sits in does not alert until price has left it
   double touch = InpTouchPips * gPip;
   wArmed[wCount] = !(Bid >= low - touch && Bid <= high + touch);
   for(int k = 0; k < ArraySize(oldKey); k++)
      if(oldKey[k] == key)
        {
         wArmed[wCount] = oldArmed[k];
         break;
        }
   wCount++;
  }

void BuildWatchList()
  {
   string oldKey[];
   bool   oldArmed[];
   ArrayResize(oldKey, wCount);
   ArrayResize(oldArmed, wCount);
   for(int k = 0; k < wCount; k++)
     {
      oldKey[k] = wKey[k];
      oldArmed[k] = wArmed[k];
     }
   wCount = 0;
   int ages[3] = {360, 250, 300};
   for(int f = 0; f < 3; f++)
     {
      CNeoFrame *frame = FrameOf(f);
      string tf = NeoTfName(frame.timeframe);
      for(int z = 0; z < frame.lpCount; z++)
         if(!frame.lpDead[z] && frame.lpFrom[z] >= frame.count - ages[f])
            AddWatch(frame.LpName(z), "LP" + tf + IntegerToString(frame.T[frame.lpFrom[z]]), frame.lpLow[z], frame.lpHigh[z], oldKey, oldArmed);
      if(frame.timeframe != PERIOD_W1)
        {
         if(frame.state != NEO_NONE)
            AddWatch("Mức bảo vệ " + tf, "PR" + tf + P(frame.guard), frame.guard, frame.guard, oldKey, oldArmed);
         if(frame.rangeOn)
           {
            AddWatch("Cạnh trên range " + tf, "RH" + tf + P(frame.rangeHigh), frame.rangeHigh, frame.rangeHigh, oldKey, oldArmed);
            AddWatch("Cạnh dưới range " + tf, "RL" + tf + P(frame.rangeLow), frame.rangeLow, frame.rangeLow, oldKey, oldArmed);
           }
        }
      for(int kind = 1; kind >= -1; kind -= 2)
        {
         double   prices[];
         datetime times[];
         int      found = frame.Swings(kind, ages[f], prices, times);
         // Nearest InpSwingsPerSide on the far side of price
         for(int pick = 0; pick < InpSwingsPerSide; pick++)
           {
            int best = -1;
            for(int s = 0; s < found; s++)
              {
               if(prices[s] == 0 || (prices[s] - Bid) * kind <= 0)
                  continue;
               if(best < 0 || MathAbs(prices[s] - Bid) < MathAbs(prices[best] - Bid))
                  best = s;
              }
            if(best < 0)
               break;
            AddWatch((kind == 1 ? "Đỉnh swing " : "Đáy swing ") + tf, "SW" + tf + P(prices[best]), prices[best], prices[best], oldKey, oldArmed);
            prices[best] = 0;
           }
        }
     }
  }

string WatchText(int k)
  {
   if(wLow[k] == wHigh[k])
      return(wName[k] + " " + P(wLow[k]));
   return(wName[k] + " [" + P(wLow[k]) + " – " + P(wHigh[k]) + "]");
  }

void CheckTouches()
  {
   double touch = InpTouchPips * gPip, rearm = InpRearmPips * gPip;
   string text = "";
   for(int k = 0; k < wCount; k++)
     {
      double distance = (Bid < wLow[k]) ? wLow[k] - Bid : (Bid > wHigh[k]) ? Bid - wHigh[k] : 0;
      if(distance > rearm)
         wArmed[k] = true;
      else if(distance <= touch && wArmed[k])
        {
         wArmed[k] = false;
         text += "• " + WatchText(k) + "\n";
        }
     }
   if(text != "" && InpSendTouch)
      Send("📍 " + Symbol() + " · giá " + P(Bid) + " chạm vùng cần quan sát\n" + text + "Xem phản ứng trên M15 trước khi làm gì.", false);
  }

//+------------------------------------------------------------------+
//| Lists the watch items on one side of price, nearest first.       |
//| side: 1 above, -1 below, 0 holding price.                        |
//+------------------------------------------------------------------+
string WatchSide(int side, double limit)
  {
   int    order[];
   double gaps[];
   int    found = 0;
   for(int k = 0; k < wCount; k++)
     {
      double gap;
      if(side == 1 && wLow[k] > Bid)
         gap = wLow[k] - Bid;
      else if(side == -1 && wHigh[k] < Bid)
         gap = Bid - wHigh[k];
      else if(side == 0 && wLow[k] <= Bid && Bid <= wHigh[k])
         gap = 0;
      else
         continue;
      if(gap > limit)
         continue;
      ArrayResize(order, found + 1);
      ArrayResize(gaps, found + 1);
      int at = found;
      while(at > 0 && gaps[at - 1] > gap)
        {
         order[at] = order[at - 1];
         gaps[at] = gaps[at - 1];
         at--;
        }
      order[at] = k;
      gaps[at] = gap;
      found++;
     }
   string text = "";
   for(int k = 0; k < found; k++)
      text += "• " + WatchText(order[k]) + (side == 0 ? "" : " · cách " + Pips(gaps[k])) + "\n";
   return(text);
  }

string FrameLine(CNeoFrame *frame)
  {
   string text = NeoTfName(frame.timeframe) + ": " + StateName(frame.state);
   if(frame.state != NEO_NONE)
      text += ", mức bảo vệ " + P(frame.guard);
   if(frame.rangeOn)
      text += ", đang trong range [" + P(frame.rangeLow) + " – " + P(frame.rangeHigh) + "]";
   return(text + ". Nến NC " + CandleColour(frame.timeframe) + ".\n");
  }

string EpZoneName(int type)
  {
   switch(type)
     {
      case ZONE_RETEST:  return("RT (retest mức vừa phá)");
      case ZONE_PROTECT: return("PR (mức bảo vệ)");
      case ZONE_LP:      return("LP cùng phía xu hướng");
     }
   return("?");
  }

string Analysis()
  {
   double limit = InpWatchPips * gPip;
   string text = "📊 NEO · " + Symbol() + " · " + TimeToString(TimeCurrent(), TIME_DATE | TIME_MINUTES) + " (giờ server)\n";
   text += "Giá " + P(Bid) + "\n\n";
   text += FrameLine(GetPointer(gW1)) + FrameLine(GetPointer(gD1)) + FrameLine(GetPointer(gH4));
   if(gM15.Load(Symbol(), PERIOD_M15, 1500))
     {
      gM15.Run();
      text += FrameLine(GetPointer(gM15));
     }

   string holding = WatchSide(0, limit), above = WatchSide(1, limit), below = WatchSide(-1, limit);
   string range = DoubleToString(InpWatchPips, 0) + " pip";
   if(holding != "")
      text += "\nGiá đang nằm trong:\n" + holding;
   text += "\nPhía trên (trong " + range + "):\n" + (above != "" ? above : "• Không có vùng nào\n");
   text += "\nPhía dưới (trong " + range + "):\n" + (below != "" ? below : "• Không có vùng nào\n");

   int    trend = (gH4.state == NEO_UP) ? 1 : (gH4.state == NEO_DOWN) ? -1 : 0;
   string waiting = "";
   for(int z = 0; z < zCount; z++)
      if(!zDone[z] && zDirection[z] == trend)
         waiting += "• " + (trend == 1 ? "BUY" : "SELL") + " tại " + EpZoneName(zType[z]) + " [" + P(zBottom[z]) + " – " + P(zTop[z]) + "]" +
                    (zTouchBar[z] >= 0 ? " · đã chạm, đang chờ phản ứng M15" : "") + "\n";
   text += "\nVùng chờ EP (thuận xu hướng H4):\n";
   if(trend == 0)
      text += "• H4 chưa có xu hướng rõ: không chờ EP\n";
   else
      text += (waiting != "" ? waiting : "• Không có vùng nào đang chờ\n");
   text += "\nLưu ý: đây là mô tả theo quy tắc NEO để quan sát, không phải tín hiệu đã kiểm chứng lợi thế.";
   return(text);
  }

void DailyReport()
  {
   if(!InpDailyReport || TimeCurrent() < gDailyRetry || InQuietHours())
      return;
   string name = "NEO_Analyst.daily." + Symbol();
   MqlDateTime now;
   TimeToStruct(TimeCurrent(), now);
   double today = now.year * 10000 + now.mon * 100 + now.day;
   if(GlobalVariableCheck(name) && GlobalVariableGet(name) == today)
      return;
   if(Send(Analysis(), false))
      GlobalVariableSet(name, today);
   else
      gDailyRetry = TimeCurrent() + 120;
  }

//+------------------------------------------------------------------+
//| Potential entries: the NE rule replayed over the recent M15      |
//| candles; only the candle that just closed is announced.          |
//+------------------------------------------------------------------+
void AddZone(int type, int direction, double top, double bottom, double level, int chartBar)
  {
   int size = zCount + 1;
   ArrayResize(zType, size, 32);
   ArrayResize(zDirection, size, 32);
   ArrayResize(zTop, size, 32);
   ArrayResize(zBottom, size, 32);
   ArrayResize(zLevel, size, 32);
   ArrayResize(zExtreme, size, 32);
   ArrayResize(zBornBar, size, 32);
   ArrayResize(zTouchBar, size, 32);
   ArrayResize(zDone, size, 32);
   zType[zCount] = type;
   zDirection[zCount] = direction;
   zTop[zCount] = top;
   zBottom[zCount] = bottom;
   zLevel[zCount] = level;
   zExtreme[zCount] = 0;
   zBornBar[zCount] = chartBar;
   zTouchBar[zCount] = -1;
   zDone[zCount] = false;
   zCount++;
  }

void EndStructureZones()
  {
   for(int z = 0; z < zCount; z++)
      if(zType[z] != ZONE_LP)
         zDone[z] = true;
  }

bool RunEp(bool announce)
  {
   int wanted = MathMin(iBars(Symbol(), PERIOD_M15) - 1, InpZoneLifeBars + InpConfirmBars + 120);
   if(wanted < 200)
      return(false);
   ArraySetAsSeries(mOpen, true);
   ArraySetAsSeries(mHigh, true);
   ArraySetAsSeries(mLow, true);
   ArraySetAsSeries(mClose, true);
   ArraySetAsSeries(mTime, true);
   if(CopyOpen(Symbol(), PERIOD_M15, 0, wanted, mOpen) != wanted || CopyHigh(Symbol(), PERIOD_M15, 0, wanted, mHigh) != wanted ||
      CopyLow(Symbol(), PERIOD_M15, 0, wanted, mLow) != wanted || CopyClose(Symbol(), PERIOD_M15, 0, wanted, mClose) != wanted ||
      CopyTime(Symbol(), PERIOD_M15, 0, wanted, mTime) != wanted)
      return(false);
   mCount = wanted;
   if(!gEp.Load(Symbol(), PERIOD_H4, 2500))
      return(false);
   gEp.Reset();
   zCount = 0;
   int next = 0;
   for(int i = mCount - 60; i >= 1; i--)
     {
      // Feed every H4 candle that was complete when this M15 candle opened
      while(next < gEp.count && gEp.CloseTime(next) <= mTime[i])
        {
         gEp.Step(next);
         if(gEp.evNewTrendZones)
           {
            EndStructureZones();
            double band = MathMax(InpBandRangeMult * gEp.MedianRange(next, 20), InpBandMinPips * gPip);
            if(InpZoneRetest)
               AddZone(ZONE_RETEST, gEp.evDirection, gEp.evLevel + band, gEp.evLevel - band, gEp.evLevel, i);
            if(InpZoneProtect)
               AddZone(ZONE_PROTECT, gEp.evDirection, gEp.guard + band, gEp.guard - band, gEp.guard, i);
           }
         if(gEp.evTrendLost)
            EndStructureZones();
         for(int k = 0; k < ArraySize(gEp.evLpSided) && InpZoneLp; k++)
           {
            int lp = gEp.evLpSided[k];
            AddZone(ZONE_LP, gEp.lpDirection[lp], gEp.lpHigh[lp], gEp.lpLow[lp],
                    gEp.lpDirection[lp] == 1 ? gEp.lpHigh[lp] : gEp.lpLow[lp], i);
           }
         for(int k = 0; k < ArraySize(gEp.evLpDead); k++)
           {
            int lp = gEp.evLpDead[k];
            for(int z = 0; z < zCount; z++)
               if(zType[z] == ZONE_LP && zTop[z] == gEp.lpHigh[lp] && zBottom[z] == gEp.lpLow[lp])
                  zDone[z] = true;
           }
         next++;
        }
      ProcessEpBar(i, announce && i == 1 && InpSendEp);
     }
   return(true);
  }

void ProcessEpBar(int i, bool announce)
  {
   int    trend = (gEp.state == NEO_UP) ? 1 : (gEp.state == NEO_DOWN) ? -1 : 0;
   double pad = InpStopPadPips * gPip;
   for(int z = 0; z < zCount; z++)
     {
      if(zDone[z] || zBornBar[z] <= i)
         continue;
      if(zBornBar[z] - i > InpZoneLifeBars)
        {
         zDone[z] = true;
         continue;
        }
      int d = zDirection[z];
      if(d != trend)
         continue;
      if((d == 1 && mClose[i] < zBottom[z] - pad) || (d == -1 && mClose[i] > zTop[z] + pad))
        {
         if(announce && zTouchBar[z] >= 0)
            Send("✖️ " + Symbol() + " · vùng chờ EP " + EpZoneName(zType[z]) + " " + P(zLevel[z]) + " thất bại: M15 đóng xuyên qua vùng.", false);
         zDone[z] = true;
         continue;
        }
      bool inside = (d == 1) ? (mLow[i] <= zTop[z]) : (mHigh[i] >= zBottom[z]);
      if(zTouchBar[z] < 0)
        {
         if(!inside)
            continue;
         zTouchBar[z] = i;
         zExtreme[z] = (d == 1) ? mLow[i] : mHigh[i];
         if(announce)
            Send("👀 " + Symbol() + " · EP tiềm năng " + (d == 1 ? "BUY" : "SELL") + "\nGiá vừa chạm vùng chờ " + EpZoneName(zType[z]) +
                 " [" + P(zBottom[z]) + " – " + P(zTop[z]) + "], H4 " + StateName(gEp.state) + ".\nChưa vào: chờ phản ứng M15 (quét / bứt phá) trong " +
                 IntegerToString(InpConfirmBars) + " nến.", false);
        }
      else
         zExtreme[z] = (d == 1) ? MathMin(zExtreme[z], mLow[i]) : MathMax(zExtreme[z], mHigh[i]);

      if(zTouchBar[z] - i > InpConfirmBars)
        {
         zDone[z] = true;
         continue;
        }
      string trigger = Reaction(i, d);
      if(trigger == "")
         continue;
      zDone[z] = true;
      if(!announce)
         continue;
      double entry = mClose[i];
      double stop = (d == 1) ? zExtreme[z] - pad : zExtreme[z] + pad;
      double risk = MathAbs(entry - stop);
      string basis = "";
      double target = ComputeTarget(d, entry, risk, basis);
      string text = "🎯 " + Symbol() + " · EP " + (d == 1 ? "BUY" : "SELL") + " (quy tắc NE)\n";
      text += "H4 " + StateName(gEp.state) + " · vùng " + EpZoneName(zType[z]) + " " + P(zLevel[z]) + "\n";
      text += "Phản ứng M15: " + trigger + "\n";
      text += "Vào quanh " + P(entry) + " · SL " + P(stop) + " (" + Pips(risk) + ")\n";
      if(target > 0)
         text += "TP " + P(target) + " (" + Pips(target - entry) + ", " + DoubleToString(MathAbs(target - entry) / risk, 1) + "R) · " + basis + "\n";
      else
         text += "TP: không có mốc H4 nào cách từ " + DoubleToString(InpMinTargetPips, 0) + " pip\n";
      text += "Lot gợi ý cho rủi ro " + DoubleToString(InpRiskPercent, 1) + "%: " + DoubleToString(LotFor(risk), 2) + "\n";
      text += "Setup sách vở để tham khảo, chưa được kiểm chứng lợi thế. EA không tự vào lệnh.";
      Send(text, false);
     }
  }

double HighOf(int start, int bars)
  {
   double value = mHigh[start];
   for(int k = start + 1; k < start + bars; k++)
      value = MathMax(value, mHigh[k]);
   return(value);
  }

double LowOf(int start, int bars)
  {
   double value = mLow[start];
   for(int k = start + 1; k < start + bars; k++)
      value = MathMin(value, mLow[k]);
   return(value);
  }

//+------------------------------------------------------------------+
//| Reaction in direction d on the last 1-3 M15 candles taken        |
//| together, sized against the 20 candles before them (as NE).      |
//+------------------------------------------------------------------+
string Reaction(int i, int d)
  {
   if(i + 30 >= mCount)
      return("");
   for(int size = 1; size <= 3; size++)
     {
      int    first = i + size - 1;
      double open = mOpen[first], close = mClose[i];
      double high = HighOf(i, size), low = LowOf(i, size);
      double range = high - low;
      double ranges[20];
      for(int k = 1; k <= 20; k++)
         ranges[k - 1] = mHigh[first + k] - mLow[first + k];
      ArraySort(ranges);
      double median = (ranges[9] + ranges[10]) / 2.0;
      if(median <= 0 || range <= 0)
         continue;
      if(size > 1 && ((d == 1 && mClose[i] <= mOpen[i]) || (d == -1 && mClose[i] >= mOpen[i])))
         continue;
      double back = (d == 1) ? close - low : high - close;
      double excursion = (d == 1) ? LowOf(first + 1, 20) - low : high - HighOf(first + 1, 20);
      double body = MathAbs(close - open);
      bool   beyond4 = (d == 1) ? close > HighOf(first + 1, 4) : close < LowOf(first + 1, 4);
      string cluster = IntegerToString(size) + " nến, biên độ " + DoubleToString(range / median, 1) + " lần trung vị";

      if(InpTrigSweep && excursion > 0 && back >= 0.75 * excursion && range >= 1.25 * median && back >= 0.5 * median && back >= 0.4 * range)
         return("quét " + (d == 1 ? "đáy" : "đỉnh") + " 20 nến rồi đóng ngược lại (" + cluster + ")");
      if(InpTrigReject && range >= InpBigRange * median && back >= 0.6 * range)
         return("từ chối: trả lại " + DoubleToString(100 * back / range, 0) + "% biên độ (" + cluster + ")");
      if(InpTrigThrust && range >= InpBigRange * median && body >= 0.6 * range && ((d == 1 && close > open) || (d == -1 && close < open)) && beyond4)
         return("bứt phá qua 4 nến trước đó (" + cluster + ")");
     }
   return("");
  }

//+------------------------------------------------------------------+
//| Target: the near edge of the nearest opposite H4 LP or the       |
//| nearest unbroken H4 swing, at least InpMinTargetPips away;       |
//| otherwise 2R when the risk is known.                             |
//+------------------------------------------------------------------+
double ComputeTarget(int d, double entry, double risk, string &basis)
  {
   double least = InpMinTargetPips * gPip;
   double best = 0;
   for(int z = 0; z < gH4.lpCount; z++)
     {
      if(gH4.lpDead[z] || gH4.lpDirection[z] != -d || gH4.lpFrom[z] < gH4.count - 360)
         continue;
      double edge = (d == 1) ? gH4.lpLow[z] : gH4.lpHigh[z];
      if((edge - entry) * d >= least && (best == 0 || (edge - best) * d < 0))
        {
         best = edge;
         basis = "cạnh gần của " + gH4.LpName(z) + " đối diện";
        }
     }
   double   prices[];
   datetime times[];
   int      found = gH4.Swings(d, 360, prices, times);
   for(int s = 0; s < found; s++)
      if((prices[s] - entry) * d >= least && (best == 0 || (prices[s] - best) * d < 0))
        {
         best = prices[s];
         basis = (d == 1) ? "đỉnh swing H4" : "đáy swing H4";
        }
   if(best == 0 && risk > 0 && 2 * risk >= least)
     {
      best = entry + d * 2 * risk;
      basis = "2R (không có mốc H4 phù hợp)";
     }
   return(best);
  }

double LotFor(double stopDistance)
  {
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE), tickSize = MarketInfo(Symbol(), MODE_TICKSIZE);
   double step = MarketInfo(Symbol(), MODE_LOTSTEP), least = MarketInfo(Symbol(), MODE_MINLOT);
   if(stopDistance <= 0 || tickValue <= 0 || tickSize <= 0 || step <= 0)
      return(least);
   double lossPerLot = stopDistance / tickSize * tickValue;
   double lot = MathFloor(AccountBalance() * InpRiskPercent / 100.0 / lossPerLot / step) * step;
   return(MathMax(lot, least));
  }

//+------------------------------------------------------------------+
//| Open orders: missing stop / target, break-even. Never opens or   |
//| closes anything.                                                 |
//+------------------------------------------------------------------+
bool CanTry(int ticket)
  {
   for(int k = 0; k < ArraySize(tTicket); k++)
      if(tTicket[k] == ticket)
         return(TimeCurrent() >= tTime[k]);
   return(true);
  }

void Postpone(int ticket)
  {
   int size = ArraySize(tTicket);
   for(int k = 0; k < size; k++)
      if(tTicket[k] == ticket)
        {
         tTime[k] = TimeCurrent() + 30;
         return;
        }
   ArrayResize(tTicket, size + 1);
   ArrayResize(tTime, size + 1);
   tTicket[size] = ticket;
   tTime[size] = TimeCurrent() + 30;
  }

void ManageOrders()
  {
   if(!InpManageOrders)
      return;
   if(!IsTradeAllowed())
     {
      if(CountManaged() > 0)
         gWarning = "AutoTrading đang tắt: EA không đặt được SL / TP / BE";
      return;
     }
   if(gWarning == "AutoTrading đang tắt: EA không đặt được SL / TP / BE")
      gWarning = "";
   double level = MarketInfo(Symbol(), MODE_STOPLEVEL) * Point;
   double spread = Ask - Bid;
   for(int k = OrdersTotal() - 1; k >= 0; k--)
     {
      if(!OrderSelect(k, SELECT_BY_POS, MODE_TRADES) || !IsManaged())
         continue;
      int    ticket = OrderTicket();
      int    d = (OrderType() == OP_BUY) ? 1 : -1;
      double open = OrderOpenPrice(), stop = OrderStopLoss(), target = OrderTakeProfit();
      double price = (d == 1) ? Bid : Ask;                 // price at which the order would close
      double newStop = stop, newTarget = target;
      string done = "";

      if(stop == 0 && InpSetStop)
        {
         double extreme = (d == 1) ? iLow(Symbol(), PERIOD_M15, iLowest(Symbol(), PERIOD_M15, MODE_LOW, 21, 0))
                                   : iHigh(Symbol(), PERIOD_M15, iHighest(Symbol(), PERIOD_M15, MODE_HIGH, 21, 0)) + spread;
         double wanted = extreme - d * InpStopPadPips * gPip;
         if((open - wanted) * d > InpMaxStopPips * gPip)
            wanted = open - d * InpMaxStopPips * gPip;
         if((price - wanted) * d > level)
           {
            newStop = NormalizeDouble(wanted, Digits);
            done += "SL " + P(newStop) + " (" + Pips(open - newStop) + ", sau đỉnh / đáy 20 nến M15)\n";
           }
        }
      if(target == 0 && InpSetTarget)
        {
         string basis = "";
         double wanted = ComputeTarget(d, open, newStop != 0 ? MathAbs(open - newStop) : 0, basis);
         if(wanted != 0 && (wanted - price) * d > level)
           {
            newTarget = NormalizeDouble(wanted, Digits);
            done += "TP " + P(newTarget) + " (" + Pips(newTarget - open) + ", " + basis + ")\n";
           }
        }
      // Break-even, once: skipped when the stop is already at or beyond the entry
      bool safe = (newStop != 0 && (newStop - open) * d >= 0);
      if(InpBeMode != NEO_BE_OFF && !safe)
        {
         double need = (InpBeMode == NEO_BE_RISK && newStop != 0) ? MathAbs(open - newStop) : InpBePips * gPip;
         double even = NormalizeDouble(open + d * InpBeLockPips * gPip, Digits);
         if((price - open) * d >= need && (price - even) * d > level)
           {
            newStop = even;
            done += "Kéo SL về hoà vốn " + P(even) + " (giá đã đi " + Pips(price - open) + ")\n";
           }
        }

      if(done == "" || !CanTry(ticket))
         continue;
      ResetLastError();
      if(OrderModify(ticket, open, newStop, newTarget, 0))
         Send("🛡 " + Symbol() + " · lệnh #" + IntegerToString(ticket) + " " + (d == 1 ? "BUY" : "SELL") + " " +
              DoubleToString(OrderLots(), 2) + " @ " + P(open) + "\n" + done, true);
      else
        {
         PrintFormat("NEO_Analyst: OrderModify #%d failed, error %d", ticket, GetLastError());
         Postpone(ticket);
        }
     }
  }

bool IsManaged()
  {
   if(OrderSymbol() != Symbol() || (OrderType() != OP_BUY && OrderType() != OP_SELL))
      return(false);
   return(!InpManualOnly || OrderMagicNumber() == 0);
  }

int CountManaged()
  {
   int found = 0;
   for(int k = OrdersTotal() - 1; k >= 0; k--)
      if(OrderSelect(k, SELECT_BY_POS, MODE_TRADES) && IsManaged())
         found++;
   return(found);
  }

//+------------------------------------------------------------------+
//| Sending                                                          |
//+------------------------------------------------------------------+
bool InQuietHours()
  {
   if(InpQuietFrom < 0 || InpQuietTo < 0 || InpQuietFrom == InpQuietTo)
      return(false);
   int hour = TimeHour(TimeCurrent());
   if(InpQuietFrom < InpQuietTo)
      return(hour >= InpQuietFrom && hour < InpQuietTo);
   return(hour >= InpQuietFrom || hour < InpQuietTo);
  }

//+------------------------------------------------------------------+
//| always = true: sent even in quiet hours (order changes, the      |
//| "analyse now" button).                                           |
//+------------------------------------------------------------------+
bool Send(string text, bool always)
  {
   if(!always && InQuietHours())
     {
      Print("NEO_Analyst (quiet hours, not sent): ", text);
      return(true);
     }
   if(StringLen(text) > 4000)             // Telegram limit is 4096 characters
      text = StringSubstr(text, 0, 3990) + "\n…";
   bool ok = true;
   if(InpTelegramToken != "" && InpTelegramChatId != "")
      ok = SendTelegram(text);
   else
      Print(text);
   string head = text;
   int    lineEnd = StringFind(text, "\n");
   if(lineEnd > 0)
      head = StringSubstr(text, 0, lineEnd);
   if(InpPush && TerminalInfoInteger(TERMINAL_NOTIFICATIONS_ENABLED))
      SendNotification(StringSubstr(text, 0, 250));
   if(InpAlert)
      Alert(head);
   gLastMessage = TimeToString(TimeCurrent(), TIME_MINUTES) + " " + head;
   return(ok);
  }

bool SendTelegram(string text)
  {
   string url = "https://api.telegram.org/bot" + InpTelegramToken + "/sendMessage";
   string body = "chat_id=" + UrlEncode(InpTelegramChatId) + "&text=" + UrlEncode(text);
   char   data[], result[];
   string resultHeaders;
   int    length = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(length > 0)
      ArrayResize(data, length - 1);
   ResetLastError();
   int status = WebRequest("POST", url, "Content-Type: application/x-www-form-urlencoded\r\n", 5000, data, result, resultHeaders);
   if(status == -1)
     {
      int error = GetLastError();
      PrintFormat("NEO_Analyst: WebRequest failed, error %d%s", error,
                  error == 4060 ? " - allow https://api.telegram.org in Tools > Options > Expert Advisors" : "");
      gWarning = "Không gửi được Telegram (lỗi " + IntegerToString(error) + "): kiểm tra Allow WebRequest";
      return(false);
     }
   if(status < 200 || status >= 300)
     {
      PrintFormat("NEO_Analyst: Telegram HTTP %d %s", status, CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8));
      gWarning = "Telegram trả về lỗi HTTP " + IntegerToString(status) + ": kiểm tra token và chat id";
      return(false);
     }
   if(StringFind(gWarning, "Telegram") >= 0)
      gWarning = "";
   return(true);
  }

string UrlEncode(string text)
  {
   uchar bytes[];
   int   size = StringToCharArray(text, bytes, 0, WHOLE_ARRAY, CP_UTF8) - 1;
   string out = "";
   for(int k = 0; k < size; k++)
     {
      uchar b = bytes[k];
      if((b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '-' || b == '_' || b == '.' || b == '~')
         out += CharToString(b);
      else
         out += StringFormat("%%%02X", b);
     }
   return(out);
  }

//+------------------------------------------------------------------+
//| Status panel                                                     |
//+------------------------------------------------------------------+
void PanelLine(int row, string text, color textColor)
  {
   string name = PREFIX + "line" + IntegerToString(row);
   if(ObjectFind(0, name) < 0)
     {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      // Bottom-left corner: the top-left one belongs to the NS panel
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_LOWER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, 10);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, 44 + 16 * (PANEL_LINES - row));
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 9);
      ObjectSetString(0, name, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
     }
   ObjectSetString(0, name, OBJPROP_TEXT, text == "" ? " " : text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
  }

string Nearest(int side)
  {
   int    best = -1;
   double gap = 0;
   for(int k = 0; k < wCount; k++)
     {
      double distance;
      if(side == 1 && wLow[k] > Bid)
         distance = wLow[k] - Bid;
      else if(side == -1 && wHigh[k] < Bid)
         distance = Bid - wHigh[k];
      else
         continue;
      if(best < 0 || distance < gap)
        {
         best = k;
         gap = distance;
        }
     }
   if(best < 0 || gap > InpWatchPips * gPip)
      return("không có trong " + DoubleToString(InpWatchPips, 0) + " pip");
   return(WatchText(best) + " · " + Pips(gap));
  }

void UpdatePanel(bool force)
  {
   if(!InpShowPanel || (!force && TimeLocal() - gPanelTime < 2))
      return;
   gPanelTime = TimeLocal();
   string button = PREFIX + "button";
   if(ObjectFind(0, button) < 0)
     {
      ObjectCreate(0, button, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(0, button, OBJPROP_CORNER, CORNER_LEFT_LOWER);
      ObjectSetInteger(0, button, OBJPROP_XDISTANCE, 10);
      ObjectSetInteger(0, button, OBJPROP_YDISTANCE, 34);
      ObjectSetInteger(0, button, OBJPROP_XSIZE, 150);
      ObjectSetInteger(0, button, OBJPROP_YSIZE, 24);
      ObjectSetInteger(0, button, OBJPROP_FONTSIZE, 9);
      ObjectSetString(0, button, OBJPROP_TEXT, "NEO: phân tích ngay");
      ObjectSetInteger(0, button, OBJPROP_COLOR, clrBlack);
      ObjectSetInteger(0, button, OBJPROP_BGCOLOR, clrGold);
     }
   int row = 0;
   if(!gReady)
     {
      PanelLine(row++, gWarning, clrSilver);
      for(; row < PANEL_LINES; row++)
         PanelLine(row, "", clrSilver);
      return;
     }
   for(int f = 2; f >= 0; f--)
     {
      CNeoFrame *frame = FrameOf(f);
      color tone = (frame.state == NEO_UP) ? clrLimeGreen : (frame.state == NEO_DOWN) ? clrTomato : clrSilver;
      PanelLine(row++, NeoTfName(frame.timeframe) + ": " + StateName(frame.state) +
                (frame.state != NEO_NONE ? " · bảo vệ " + P(frame.guard) : ""), tone);
     }
   PanelLine(row++, "Trên: " + Nearest(1), clrSilver);
   PanelLine(row++, "Dưới: " + Nearest(-1), clrSilver);
   int waiting = 0, trend = (gH4.state == NEO_UP) ? 1 : (gH4.state == NEO_DOWN) ? -1 : 0;
   for(int z = 0; z < zCount; z++)
      if(!zDone[z] && zDirection[z] == trend)
         waiting++;
   PanelLine(row++, "Vùng chờ EP: " + IntegerToString(waiting) + " · lệnh đang quản lý: " + IntegerToString(InpManageOrders ? CountManaged() : 0), clrSilver);
   PanelLine(row++, "Tin gần nhất: " + (gLastMessage == "" ? "chưa có" : gLastMessage), clrSilver);
   PanelLine(row++, (InpTelegramToken == "" || InpTelegramChatId == "") ? "Telegram: chưa nhập token / chat id" : "", clrGold);
   PanelLine(row++, gWarning, clrGold);
   for(; row < PANEL_LINES; row++)
      PanelLine(row, "", clrSilver);
  }
//+------------------------------------------------------------------+

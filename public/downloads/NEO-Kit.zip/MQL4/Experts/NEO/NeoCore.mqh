//+------------------------------------------------------------------+
//|                                                      NeoCore.mqh |
//|  NEO engine for one timeframe, fed closed candle by closed       |
//|  candle in time order. Same rules as NS.mq4 / NE.mq4:            |
//|                                                                  |
//|  structure : pivot = InpPivotSide candles each side; BOS = close |
//|              beyond the leg extreme; protected level = extreme   |
//|              of the pullback; CHoCH = close through the          |
//|              protected level (state TURN_*); confirmation /      |
//|              failed turn end the turn.                           |
//|  range     : on once two pivot highs and two pivot lows formed   |
//|              between the two deciding levels of the state.       |
//|  LP        : starts on a Build candle with a wick on both ends   |
//|              of the smoothed candle; a later Build candle        |
//|              reaching its High / Low extends it; a smoothed      |
//|              close outside makes it GLP / RLP; a smoothed close  |
//|              beyond the far edge clears it. Main = the latest    |
//|              live LP of the side that cleared an opposite LP.    |
//|  swings    : pivots not exceeded by any later candle.            |
//|                                                                  |
//|  After Step(t) the ev* members describe what happened on candle  |
//|  t, so a caller can react to the newest candle only.             |
//+------------------------------------------------------------------+
#property strict

#define NEO_NONE        0
#define NEO_UP          1
#define NEO_DOWN       -1
#define NEO_TURN_DOWN   2
#define NEO_TURN_UP    -2

#define NEO_EV_NONE     0
#define NEO_EV_START    1
#define NEO_EV_BOS      2
#define NEO_EV_CHOCH    3
#define NEO_EV_CONFIRM  4
#define NEO_EV_FAILED   5

double NeoPip(string symbol)
  {
   int    digits = (int)MarketInfo(symbol, MODE_DIGITS);
   double point = MarketInfo(symbol, MODE_POINT);
   return((digits == 3 || digits == 5) ? 10 * point : point);
  }

string NeoTfName(int timeframe)
  {
   switch(timeframe)
     {
      case PERIOD_M15: return("M15");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
     }
   return("TF" + IntegerToString(timeframe));
  }

class CNeoFrame
  {
public:
   string            symbol;
   int               timeframe;
   int               pivotSide;
   int               buildBars;
   int               rangeTouches;
   double            wick;

   // Closed candles, oldest first
   double            O[], H[], L[], C[];
   long              V[];
   datetime          T[];
   int               count;

   // Structure
   int               state;
   double            guard;            // protected level (in a turn: the old top / bottom)
   double            legExtreme;       // furthest price of the current trend leg
   bool              rangeOn;
   double            rangeLow, rangeHigh;

   // What candle t did (set by Step)
   int               evKind, evDirection;
   double            evLevel;          // level that was broken
   bool              evNewTrendZones;  // a break that defines a new retest level and protected level
   bool              evTrendLost;      // the state left UP / DOWN on this candle
   int               evLpNew;          // index of an LP created on this candle, or -1
   int               evLpSided[];      // LPs that became GLP / RLP on this candle
   int               evLpDead[];       // LPs cleared on this candle
   int               evLpMain;         // LP that became Main on this candle, or -1

   // Liquidity zones
   double            lpHigh[], lpLow[];
   int               lpDirection[], lpFrom[];
   bool              lpDead[], lpMain[];
   int               lpCount;

                     CNeoFrame(void) { pivotSide = 2; buildBars = 5; rangeTouches = 2; wick = 0; count = 0; lpCount = 0; state = NEO_NONE; }

   bool              Load(string sym, int tf, int maxBars);
   void              Reset(void);
   void              Step(int t);
   void              Run(void) { Reset(); for(int t = 0; t < count; t++) Step(t); }
   double            MedianRange(int t, int bars);
   datetime          CloseTime(int t) { return((t + 1 < count) ? T[t + 1] : T[t] + timeframe * 60); }
   bool              IsBuild(int t);
   int               Swings(int kind, int maxAge, double &prices[], datetime &times[]);
   string            LpName(int z);

private:
   int               pivotIndex[], pivotKind[];
   double            pivotPrice[];
   int               pivotCount;
   int               pivotHighIndex, pivotLowIndex, legIndex, counterIndex, sinceBreak, turnStart;
   bool              hasPivotHigh, hasPivotLow, hasLeg, hasCounter;
   double            pivotHighPrice, pivotLowPrice, legPrice, turnLimit, counterBreak;
   double            candleOpen, candleClose;

   double            Highest(int from, int to);
   double            Lowest(int from, int to);
   int               ArgHighest(int from, int to);
   int               ArgLowest(int from, int to);
   void              AddPivot(int index, double price, int kind);
   void              StartTrend(int t, int direction, int origin, int kind, double broken);
   void              StepStructure(int t);
   void              StepRange(void);
   void              StepLp(int t);
  };

//+------------------------------------------------------------------+
//| Copies up to maxBars closed candles (the forming one is skipped).|
//+------------------------------------------------------------------+
bool CNeoFrame::Load(string sym, int tf, int maxBars)
  {
   symbol = sym;
   timeframe = tf;
   if(wick <= 0)
      wick = NeoPip(sym);
   int total = iBars(sym, tf);
   int wanted = MathMin(total - 1, maxBars);
   if(wanted < 30)
      return(false);
   ArraySetAsSeries(O, false);
   ArraySetAsSeries(H, false);
   ArraySetAsSeries(L, false);
   ArraySetAsSeries(C, false);
   ArraySetAsSeries(V, false);
   ArraySetAsSeries(T, false);
   if(CopyOpen(sym, tf, 1, wanted, O) != wanted || CopyHigh(sym, tf, 1, wanted, H) != wanted ||
      CopyLow(sym, tf, 1, wanted, L) != wanted || CopyClose(sym, tf, 1, wanted, C) != wanted ||
      CopyTickVolume(sym, tf, 1, wanted, V) != wanted || CopyTime(sym, tf, 1, wanted, T) != wanted)
      return(false);
   count = wanted;
   return(true);
  }

void CNeoFrame::Reset(void)
  {
   state = NEO_NONE;
   hasPivotHigh = false; hasPivotLow = false; hasLeg = false; hasCounter = false;
   sinceBreak = 0; turnStart = 0; guard = 0; legExtreme = 0;
   turnLimit = 0; counterBreak = 0; legPrice = 0; legIndex = 0; counterIndex = 0;
   rangeOn = false; rangeLow = 0; rangeHigh = 0;
   pivotCount = 0;
   lpCount = 0;
   candleOpen = 0; candleClose = 0;
   evKind = NEO_EV_NONE; evDirection = 0; evLevel = 0; evNewTrendZones = false; evTrendLost = false;
   evLpNew = -1; evLpMain = -1;
   ArrayResize(evLpSided, 0);
   ArrayResize(evLpDead, 0);
  }

double CNeoFrame::Highest(int from, int to)
  {
   double value = H[from];
   for(int k = from + 1; k <= to; k++)
      if(H[k] > value)
         value = H[k];
   return(value);
  }

double CNeoFrame::Lowest(int from, int to)
  {
   double value = L[from];
   for(int k = from + 1; k <= to; k++)
      if(L[k] < value)
         value = L[k];
   return(value);
  }

int CNeoFrame::ArgHighest(int from, int to)
  {
   int best = from;
   for(int k = from + 1; k <= to; k++)
      if(H[k] > H[best])
         best = k;
   return(best);
  }

int CNeoFrame::ArgLowest(int from, int to)
  {
   int best = from;
   for(int k = from + 1; k <= to; k++)
      if(L[k] < L[best])
         best = k;
   return(best);
  }

//+------------------------------------------------------------------+
//| Median candle range of the `bars` candles ending at t.           |
//+------------------------------------------------------------------+
double CNeoFrame::MedianRange(int t, int bars)
  {
   double ranges[];
   ArrayResize(ranges, bars);
   ArrayInitialize(ranges, H[t] - L[t]);
   int used = 0;
   for(int k = t; k > t - bars && k >= 0; k--)
      ranges[used++] = H[k] - L[k];
   ArraySort(ranges);
   return((ranges[(bars - 1) / 2] + ranges[bars / 2]) / 2.0);
  }

void CNeoFrame::AddPivot(int index, double price, int kind)
  {
   int size = pivotCount + 1;
   ArrayResize(pivotIndex, size, 256);
   ArrayResize(pivotPrice, size, 256);
   ArrayResize(pivotKind, size, 256);
   pivotIndex[pivotCount] = index;
   pivotPrice[pivotCount] = price;
   pivotKind[pivotCount] = kind;
   pivotCount++;
  }

void CNeoFrame::StartTrend(int t, int direction, int origin, int kind, double broken)
  {
   state = (direction == 1) ? NEO_UP : NEO_DOWN;
   guard = (direction == 1) ? L[ArgLowest(origin, t)] : H[ArgHighest(origin, t)];
   sinceBreak = t;
   hasLeg = false;
   evKind = kind; evDirection = direction; evLevel = broken; evNewTrendZones = true;
  }

void CNeoFrame::Step(int t)
  {
   evKind = NEO_EV_NONE; evDirection = 0; evLevel = 0; evNewTrendZones = false; evTrendLost = false;
   evLpNew = -1; evLpMain = -1;
   ArrayResize(evLpSided, 0);
   ArrayResize(evLpDead, 0);
   StepStructure(t);
   StepRange();
   StepLp(t);
  }

void CNeoFrame::StepStructure(int t)
  {
   int side = pivotSide;
   int p = t - side;
   if(p >= side)
     {
      if(H[p] > Highest(p - side, p - 1) && H[p] >= Highest(p + 1, p + side))
        {
         AddPivot(p, H[p], 1);
         hasPivotHigh = true; pivotHighIndex = p; pivotHighPrice = H[p];
         if(state == NEO_UP && H[p] >= Highest(sinceBreak, t))
           { hasLeg = true; legIndex = p; legPrice = H[p]; }
         if(state == NEO_TURN_DOWN && p > turnStart && H[p] < turnLimit)
           { hasCounter = true; counterIndex = p; counterBreak = Lowest(turnStart, p); }
        }
      if(L[p] < Lowest(p - side, p - 1) && L[p] <= Lowest(p + 1, p + side))
        {
         AddPivot(p, L[p], -1);
         hasPivotLow = true; pivotLowIndex = p; pivotLowPrice = L[p];
         if(state == NEO_DOWN && L[p] <= Lowest(sinceBreak, t))
           { hasLeg = true; legIndex = p; legPrice = L[p]; }
         if(state == NEO_TURN_UP && p > turnStart && L[p] > turnLimit)
           { hasCounter = true; counterIndex = p; counterBreak = Highest(turnStart, p); }
        }
     }

   double price = C[t];
   int    before = state;

   if(state == NEO_NONE)
     {
      if(hasPivotHigh && price > pivotHighPrice)
         StartTrend(t, 1, pivotHighIndex, NEO_EV_START, pivotHighPrice);
      else if(hasPivotLow && price < pivotLowPrice)
         StartTrend(t, -1, pivotLowIndex, NEO_EV_START, pivotLowPrice);
     }
   else if(state == NEO_UP)
     {
      if(price < guard)
        {
         int top = ArgHighest(sinceBreak, t);
         evKind = NEO_EV_CHOCH; evDirection = -1; evLevel = guard;
         turnLimit = H[top]; turnStart = top; state = NEO_TURN_DOWN; hasCounter = false; guard = turnLimit;
        }
      else if(hasLeg && price > legPrice)
        {
         evKind = NEO_EV_BOS; evDirection = 1; evLevel = legPrice; evNewTrendZones = true;
         guard = L[ArgLowest(legIndex, t)];
         sinceBreak = t; hasLeg = false;
        }
     }
   else if(state == NEO_DOWN)
     {
      if(price > guard)
        {
         int bottom = ArgLowest(sinceBreak, t);
         evKind = NEO_EV_CHOCH; evDirection = 1; evLevel = guard;
         turnLimit = L[bottom]; turnStart = bottom; state = NEO_TURN_UP; hasCounter = false; guard = turnLimit;
        }
      else if(hasLeg && price < legPrice)
        {
         evKind = NEO_EV_BOS; evDirection = -1; evLevel = legPrice; evNewTrendZones = true;
         guard = H[ArgHighest(legIndex, t)];
         sinceBreak = t; hasLeg = false;
        }
     }
   else if(state == NEO_TURN_DOWN)
     {
      if(price > turnLimit)
         StartTrend(t, 1, turnStart, NEO_EV_FAILED, turnLimit);
      else if(hasCounter && price < counterBreak)
         StartTrend(t, -1, counterIndex, NEO_EV_CONFIRM, counterBreak);
     }
   else if(state == NEO_TURN_UP)
     {
      if(price < turnLimit)
         StartTrend(t, -1, turnStart, NEO_EV_FAILED, turnLimit);
      else if(hasCounter && price > counterBreak)
         StartTrend(t, 1, counterIndex, NEO_EV_CONFIRM, counterBreak);
     }

   evTrendLost = (state != before && state != NEO_UP && state != NEO_DOWN);
   if(state == NEO_UP)
      legExtreme = Highest(sinceBreak, t);
   else if(state == NEO_DOWN)
      legExtreme = Lowest(sinceBreak, t);
  }

//+------------------------------------------------------------------+
//| Range between the two levels that decide what happens next.      |
//+------------------------------------------------------------------+
void CNeoFrame::StepRange(void)
  {
   double lower = 0, upper = 0;
   int    anchor = -1;
   if(state == NEO_UP && hasLeg)                  { lower = guard;        upper = legPrice;     anchor = legIndex; }
   else if(state == NEO_DOWN && hasLeg)           { lower = legPrice;     upper = guard;        anchor = legIndex; }
   else if(state == NEO_TURN_DOWN && hasCounter)  { lower = counterBreak; upper = turnLimit;    anchor = turnStart; }
   else if(state == NEO_TURN_UP && hasCounter)    { lower = turnLimit;    upper = counterBreak; anchor = turnStart; }
   rangeOn = false;
   if(anchor < 0)
      return;
   int highs = 0, lows = 0;
   for(int k = pivotCount - 1; k >= 0 && k >= pivotCount - 60; k--)
     {
      if(pivotIndex[k] < anchor || pivotPrice[k] < lower || pivotPrice[k] > upper)
         continue;
      if(pivotKind[k] == 1)
         highs++;
      else
         lows++;
     }
   if(highs >= rangeTouches && lows >= rangeTouches)
     { rangeOn = true; rangeLow = lower; rangeHigh = upper; }
  }

bool CNeoFrame::IsBuild(int t)
  {
   if(t < buildBars + 1)
      return(false);
   bool up = C[t] > O[t], down = C[t] < O[t];
   bool previousUp = C[t - 1] > O[t - 1], previousDown = C[t - 1] < O[t - 1];
   if(!((up && previousDown) || (down && previousUp)))
      return(false);
   double activity = (double)V[t] * (H[t] - L[t]);
   for(int k = t - buildBars; k < t; k++)
      if((double)V[k] * (H[k] - L[k]) >= activity)
         return(false);
   return(true);
  }

void CNeoFrame::StepLp(int t)
  {
   if(t == 0)
     {
      candleOpen = (O[0] + C[0]) / 2.0;
      candleClose = candleOpen;
      return;
     }
   double sum = 0;
   int    used = 0;
   for(int k = t; k > t - 3 && k >= 0; k--)
     {
      sum += (O[k] + H[k] + L[k] + C[k]) / 4.0;
      used++;
     }
   candleOpen = (candleOpen + candleClose) / 2.0;
   candleClose = sum / used;
   if(t < buildBars + 8)
      return;

   double top = MathMax(H[t], MathMax(candleOpen, candleClose));
   double bottom = MathMin(L[t], MathMin(candleOpen, candleClose));
   bool   build = IsBuild(t), extended = false;

   for(int z = 0; z < lpCount; z++)
     {
      if(lpDead[z])
         continue;
      if(lpDirection[z] == 0)
        {
         if(candleClose > lpHigh[z])
            lpDirection[z] = 1;
         else if(candleClose < lpLow[z])
            lpDirection[z] = -1;
         else if(build && ((bottom <= lpHigh[z] && lpHigh[z] <= top) || (bottom <= lpLow[z] && lpLow[z] <= top)))
           {
            lpHigh[z] = MathMax(lpHigh[z], top);
            lpLow[z] = MathMin(lpLow[z], bottom);
            extended = true;
           }
         if(lpDirection[z] != 0)
           {
            int size = ArraySize(evLpSided);
            ArrayResize(evLpSided, size + 1);
            evLpSided[size] = z;
           }
        }
      else if((lpDirection[z] == 1 && candleClose < lpLow[z]) || (lpDirection[z] == -1 && candleClose > lpHigh[z]))
        {
         lpDead[z] = true;
         int size = ArraySize(evLpDead);
         ArrayResize(evLpDead, size + 1);
         evLpDead[size] = z;
         // The latest live LP of the side that did the clearing becomes the Main of that side
         int winner = -lpDirection[z], best = -1;
         for(int m = 0; m < lpCount; m++)
            if(!lpDead[m] && lpDirection[m] == winner && (best < 0 || lpFrom[m] > lpFrom[best]))
               best = m;
         if(best >= 0)
           {
            for(int m = 0; m < lpCount; m++)
               if(lpDirection[m] == winner)
                  lpMain[m] = false;
            lpMain[best] = true;
            evLpMain = best;
           }
        }
     }

   if(build && !extended && top - MathMax(candleOpen, candleClose) >= wick && MathMin(candleOpen, candleClose) - bottom >= wick)
     {
      int size = lpCount + 1;
      ArrayResize(lpHigh, size, 64);
      ArrayResize(lpLow, size, 64);
      ArrayResize(lpDirection, size, 64);
      ArrayResize(lpFrom, size, 64);
      ArrayResize(lpDead, size, 64);
      ArrayResize(lpMain, size, 64);
      lpHigh[lpCount] = top;
      lpLow[lpCount] = bottom;
      lpDirection[lpCount] = 0;
      lpFrom[lpCount] = t;
      lpDead[lpCount] = false;
      lpMain[lpCount] = false;
      evLpNew = lpCount;
      lpCount++;
     }
  }

//+------------------------------------------------------------------+
//| Unbroken swing highs (kind 1) or lows (kind -1) no older than    |
//| maxAge candles, newest first. Returns how many were found.       |
//+------------------------------------------------------------------+
int CNeoFrame::Swings(int kind, int maxAge, double &prices[], datetime &times[])
  {
   int found = 0;
   ArrayResize(prices, 0);
   ArrayResize(times, 0);
   if(count < 2 * pivotSide + 1)
      return(0);
   double beyond = (kind == 1) ? Highest(count - pivotSide, count - 1) : Lowest(count - pivotSide, count - 1);
   for(int p = count - 1 - pivotSide; p >= pivotSide && p >= count - maxAge; p--)
     {
      bool pivot, unbroken;
      if(kind == 1)
        {
         pivot = H[p] > Highest(p - pivotSide, p - 1) && H[p] >= Highest(p + 1, p + pivotSide);
         unbroken = H[p] >= beyond;
         beyond = MathMax(beyond, H[p]);
        }
      else
        {
         pivot = L[p] < Lowest(p - pivotSide, p - 1) && L[p] <= Lowest(p + 1, p + pivotSide);
         unbroken = L[p] <= beyond;
         beyond = MathMin(beyond, L[p]);
        }
      if(!pivot || !unbroken)
         continue;
      ArrayResize(prices, found + 1);
      ArrayResize(times, found + 1);
      prices[found] = (kind == 1) ? H[p] : L[p];
      times[found] = T[p];
      found++;
     }
   return(found);
  }

string CNeoFrame::LpName(int z)
  {
   string kind = (lpDirection[z] == 1) ? "GLP" : (lpDirection[z] == -1) ? "RLP" : "LP";
   return((lpMain[z] ? "M" : "") + kind + " " + NeoTfName(timeframe));
  }
//+------------------------------------------------------------------+

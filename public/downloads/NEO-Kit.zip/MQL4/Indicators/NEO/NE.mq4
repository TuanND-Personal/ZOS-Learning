//+------------------------------------------------------------------+
//|                                                           NE.mq4 |
//|  NEO entries: marks where to WATCH and where the textbook entry  |
//|  would be, for review by eye. It is a reading aid built from the |
//|  theory, not a tested signal.                                    |
//|                                                                  |
//|  Idea (Wyckoff / Villahermosa "simplified strategy", ZO retest): |
//|  trade only with the H4 structure trend, wait at a zone, and act |
//|  only when the entry timeframe shows a reaction there.           |
//|                                                                  |
//|  Watch zones, all from H4 closed candles:                        |
//|    RT  retest of the level broken by the last H4 BOS, as a band  |
//|        of +- half a median H4 candle range (min 8 pips)          |
//|    PR  the H4 protected low / high (a sweep here = spring /      |
//|        upthrust)                                                 |
//|    LP  a live H4 liquidity zone on the trend side (GLP in an     |
//|        uptrend, RLP in a downtrend)                              |
//|                                                                  |
//|  On the chart timeframe (M15):                                   |
//|    x      first touch of a watch zone                            |
//|    arrow  reaction inside the zone within InpConfirmBars candles,|
//|           in the trend direction, by 1-3 candles taken together  |
//|           and sized against the 20 candles before them: a sweep, |
//|           a rejection or a thrust (see Reaction)                 |
//|    lines  stop (beyond the extreme made since the touch) and     |
//|           first target (the H4 leg extreme)                      |
//|  Defaults = the one combination that stayed above break-even on  |
//|  all three data parts when tuned on the earliest one (PR zone,   |
//|  sweep or thrust). RT, LP and the rejection trigger are switches.|
//|  The arrow text gives zone, trigger, stop in pips and reward:risk|
//|  to the target; the tooltip holds the full reasoning.            |
//|                                                                  |
//|  The H4 structure and LP rules mirror NS.mq4; everything is fed  |
//|  candle by candle in time order, so each mark only uses what was |
//|  known when its candle closed.                                   |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window

input int    InpBars         = 3000;   // Chart candles scanned back from the last one
input int    InpStructureTf  = PERIOD_H4; // Timeframe of the structure and the zones
input int    InpPivotSide    = 2;      // Structure: candles on each side of a pivot
input bool   InpZoneRetest   = false;  // Watch the retest of the last broken level (RT)
input bool   InpZoneProtect  = true;   // Watch the protected low / high (PR)
input bool   InpZoneLp       = false;  // Watch live liquidity zones on the trend side (LP)
input bool   InpTrigSweep    = true;   // Reaction: sweep
input bool   InpTrigReject   = false;  // Reaction: rejection (big candle that poked and gave back)
input bool   InpTrigThrust   = true;   // Reaction: thrust
input double InpBandRangeMult = 0.5;   // Half width of the RT / PR band, in median H4 candle ranges (20 candles)
input double InpBandMinPips  = 8.0;    // ... but never less than this many pips
input int    InpConfirmBars  = 32;     // Candles after the first touch in which a reaction is looked for
input int    InpZoneLifeBars = 480;    // A zone is dropped this many chart candles after it appeared
input double InpStopPadPips  = 3.0;    // Stop distance beyond the extreme made since the touch
input double InpBigRange     = 1.75;   // Rejection / thrust: cluster range >= this x the median range of the 20 candles before
input bool   InpShowText     = true;   // Short text next to each arrow
input bool   InpShowLevels   = true;   // Stop and target lines of each entry
input int    InpLpBuildBars  = 5;      // LP: Build candle lookback (as NS / NC)
input double InpLpWickPips   = 1.0;    // LP: wick needed on both ends of its first candle
input color  InpBuyColor     = clrLimeGreen;
input color  InpSellColor    = clrTomato;
input color  InpWatchColor   = clrSilver;

#define STATE_NONE       0
#define STATE_UP         1
#define STATE_DOWN      -1
#define STATE_TURN_DOWN  2
#define STATE_TURN_UP   -2

#define ZONE_RETEST  1
#define ZONE_PROTECT 2
#define ZONE_LP      3

string   Prefix = "NE_";
datetime LastBarTime = 0;

// Structure timeframe candles (chronological, closed only)
double   HOpen[], HHigh[], HLow[], HClose[];
long     HVolume[];
datetime HTime[];
int      HCount = 0;

// Structure state machine (same rules as NS)
int      sState, sPivotHighIndex, sPivotLowIndex, sLegIndex, sCounterIndex, sSinceBreak, sTurnStart;
bool     sHasPivotHigh, sHasPivotLow, sHasLeg, sHasCounter;
double   sPivotHighPrice, sPivotLowPrice, sLegPrice, sGuard, sTurnLimit, sCounterBreak;
double   sLegExtreme;                  // furthest price of the current leg (first target)

// Liquidity zones of the structure timeframe
double   lpHigh[], lpLow[];
int      lpDirection[];
bool     lpDead[];
datetime lpBorn[];
int      lpCount = 0;
double   lpCandleOpen, lpCandleClose;

// Watch zones
int      zType[], zDirection[];
double   zTop[], zBottom[], zLevel[];
datetime zBorn[], zTouched[];
bool     zDone[];
double   zExtreme[];
int      zBornBar[], zTouchBar[];
int      zCount = 0;
int      Marks = 0;

//+------------------------------------------------------------------+
int OnInit()
  {
   IndicatorShortName("NE");
   LastBarTime = 0;
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0, Prefix);
  }

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(Time[0] == LastBarTime && prev_calculated > 0)
      return(rates_total);
   if(Period() >= InpStructureTf)
     {
      Comment("NE: attach to a chart below the structure timeframe (for example M15)");
      return(rates_total);
     }
   if(Render())
      LastBarTime = Time[0];
   return(rates_total);
  }

//+------------------------------------------------------------------+
bool Render()
  {
   ObjectsDeleteAll(0, Prefix);
   Marks = 0;
   int total = iBars(Symbol(), InpStructureTf);
   if(total < 300)
      return(false);
   HCount = MathMin(total - 1, 2500);
   ArraySetAsSeries(HOpen, false);
   ArraySetAsSeries(HHigh, false);
   ArraySetAsSeries(HLow, false);
   ArraySetAsSeries(HClose, false);
   ArraySetAsSeries(HVolume, false);
   ArraySetAsSeries(HTime, false);
   if(CopyOpen(Symbol(), InpStructureTf, 1, HCount, HOpen) != HCount || CopyHigh(Symbol(), InpStructureTf, 1, HCount, HHigh) != HCount ||
      CopyLow(Symbol(), InpStructureTf, 1, HCount, HLow) != HCount || CopyClose(Symbol(), InpStructureTf, 1, HCount, HClose) != HCount ||
      CopyTickVolume(Symbol(), InpStructureTf, 1, HCount, HVolume) != HCount || CopyTime(Symbol(), InpStructureTf, 1, HCount, HTime) != HCount)
      return(false);

   ResetEngines();
   int first = MathMin(InpBars, Bars - 60);
   int next = 0;                                   // next structure candle to feed
   int seconds = InpStructureTf * 60;

   for(int i = first; i >= 1; i--)
     {
      // Feed every structure candle that was complete when this chart candle opened
      while(next < HCount)
        {
         datetime closeTime = (next + 1 < HCount) ? HTime[next + 1] : HTime[next] + seconds;
         if(closeTime > Time[i])
            break;
         StepStructure(next, i);
         StepLp(next, i);
         next++;
        }
      ProcessChartBar(i);
     }
   Comment("");
   return(true);
  }

//+------------------------------------------------------------------+
void ResetEngines()
  {
   sState = STATE_NONE;
   sHasPivotHigh = false; sHasPivotLow = false; sHasLeg = false; sHasCounter = false;
   sSinceBreak = 0; sTurnStart = 0; sGuard = 0; sLegExtreme = 0;
   lpCount = 0;
   lpCandleOpen = 0; lpCandleClose = 0;
   zCount = 0;
  }

//+------------------------------------------------------------------+
double HMax(int from, int to)
  {
   double value = HHigh[from];
   for(int k = from + 1; k <= to; k++)
      if(HHigh[k] > value)
         value = HHigh[k];
   return(value);
  }

double HMin(int from, int to)
  {
   double value = HLow[from];
   for(int k = from + 1; k <= to; k++)
      if(HLow[k] < value)
         value = HLow[k];
   return(value);
  }

int HArgMax(int from, int to)
  {
   int best = from;
   for(int k = from + 1; k <= to; k++)
      if(HHigh[k] > HHigh[best])
         best = k;
   return(best);
  }

int HArgMin(int from, int to)
  {
   int best = from;
   for(int k = from + 1; k <= to; k++)
      if(HLow[k] < HLow[best])
         best = k;
   return(best);
  }

//+------------------------------------------------------------------+
//| One closed structure candle t. chartBar is the chart candle at   |
//| which this becomes known (used to stamp new watch zones).        |
//+------------------------------------------------------------------+
void StepStructure(int t, int chartBar)
  {
   int side = InpPivotSide;
   int p = t - side;
   if(p >= side)
     {
      if(HHigh[p] > HMax(p - side, p - 1) && HHigh[p] >= HMax(p + 1, p + side))
        {
         sHasPivotHigh = true; sPivotHighIndex = p; sPivotHighPrice = HHigh[p];
         if(sState == STATE_UP && HHigh[p] >= HMax(sSinceBreak, t))
           { sHasLeg = true; sLegIndex = p; sLegPrice = HHigh[p]; }
         if(sState == STATE_TURN_DOWN && p > sTurnStart && HHigh[p] < sTurnLimit)
           { sHasCounter = true; sCounterIndex = p; sCounterBreak = HMin(sTurnStart, p); }
        }
      if(HLow[p] < HMin(p - side, p - 1) && HLow[p] <= HMin(p + 1, p + side))
        {
         sHasPivotLow = true; sPivotLowIndex = p; sPivotLowPrice = HLow[p];
         if(sState == STATE_DOWN && HLow[p] <= HMin(sSinceBreak, t))
           { sHasLeg = true; sLegIndex = p; sLegPrice = HLow[p]; }
         if(sState == STATE_TURN_UP && p > sTurnStart && HLow[p] > sTurnLimit)
           { sHasCounter = true; sCounterIndex = p; sCounterBreak = HMax(sTurnStart, p); }
        }
     }

   double price = HClose[t];
   int    startDirection = 0, startOrigin = 0;
   double brokenLevel = 0;
   int    before = sState;

   if(sState == STATE_NONE)
     {
      if(sHasPivotHigh && price > sPivotHighPrice)      { startDirection = 1;  startOrigin = sPivotHighIndex; brokenLevel = sPivotHighPrice; }
      else if(sHasPivotLow && price < sPivotLowPrice)   { startDirection = -1; startOrigin = sPivotLowIndex;  brokenLevel = sPivotLowPrice; }
     }
   else if(sState == STATE_UP)
     {
      if(price < sGuard)
        {
         int top = HArgMax(sSinceBreak, t);
         sTurnLimit = HHigh[top]; sTurnStart = top; sState = STATE_TURN_DOWN; sHasCounter = false; sGuard = sTurnLimit;
        }
      else if(sHasLeg && price > sLegPrice)
        {
         brokenLevel = sLegPrice;
         sGuard = HLow[HArgMin(sLegIndex, t)];
         sSinceBreak = t; sHasLeg = false;
         NewStructureZones(1, brokenLevel, chartBar, t);
        }
     }
   else if(sState == STATE_DOWN)
     {
      if(price > sGuard)
        {
         int bottom = HArgMin(sSinceBreak, t);
         sTurnLimit = HLow[bottom]; sTurnStart = bottom; sState = STATE_TURN_UP; sHasCounter = false; sGuard = sTurnLimit;
        }
      else if(sHasLeg && price < sLegPrice)
        {
         brokenLevel = sLegPrice;
         sGuard = HHigh[HArgMax(sLegIndex, t)];
         sSinceBreak = t; sHasLeg = false;
         NewStructureZones(-1, brokenLevel, chartBar, t);
        }
     }
   else if(sState == STATE_TURN_DOWN)
     {
      if(price > sTurnLimit)                            { startDirection = 1;  startOrigin = sTurnStart;    brokenLevel = sTurnLimit; }
      else if(sHasCounter && price < sCounterBreak)     { startDirection = -1; startOrigin = sCounterIndex; brokenLevel = sCounterBreak; }
     }
   else if(sState == STATE_TURN_UP)
     {
      if(price < sTurnLimit)                            { startDirection = -1; startOrigin = sTurnStart;    brokenLevel = sTurnLimit; }
      else if(sHasCounter && price > sCounterBreak)     { startDirection = 1;  startOrigin = sCounterIndex; brokenLevel = sCounterBreak; }
     }

   if(startDirection != 0)
     {
      sState = (startDirection == 1) ? STATE_UP : STATE_DOWN;
      sGuard = (startDirection == 1) ? HLow[HArgMin(startOrigin, t)] : HHigh[HArgMax(startOrigin, t)];
      sSinceBreak = t; sHasLeg = false;
      NewStructureZones(startDirection, brokenLevel, chartBar, t);
     }

   // A trend that stopped being a trend takes its structure zones with it
   if(sState != before && sState != STATE_UP && sState != STATE_DOWN)
      for(int z = 0; z < zCount; z++)
         if(zType[z] != ZONE_LP)
            zDone[z] = true;

   if(sState == STATE_UP)
      sLegExtreme = HMax(sSinceBreak, t);
   else if(sState == STATE_DOWN)
      sLegExtreme = HMin(sSinceBreak, t);
  }

//+------------------------------------------------------------------+
//| After a break of structure: the broken level becomes the retest  |
//| zone and the new protected level the spring / upthrust zone.     |
//+------------------------------------------------------------------+
void NewStructureZones(int direction, double brokenLevel, int chartBar, int t)
  {
   for(int z = 0; z < zCount; z++)
      if(zType[z] != ZONE_LP)
         zDone[z] = true;
   // Band sized to the structure timeframe: a share of its median candle range over the last 20 candles
   double ranges[20];
   ArrayInitialize(ranges, HHigh[t] - HLow[t]);
   int    used = 0;
   for(int k = t; k > t - 20 && k >= 0; k--)
      ranges[used++] = HHigh[k] - HLow[k];
   ArraySort(ranges);
   double band = MathMax(InpBandRangeMult * (ranges[9] + ranges[10]) / 2.0, InpBandMinPips * PipSize());
   if(InpZoneRetest)
      AddZone(ZONE_RETEST, direction, brokenLevel + band, brokenLevel - band, brokenLevel, chartBar);
   if(InpZoneProtect)
      AddZone(ZONE_PROTECT, direction, sGuard + band, sGuard - band, sGuard, chartBar);
  }

//+------------------------------------------------------------------+
//| Liquidity zones, same rules as NS: Build candle with a wick on   |
//| both ends of the smoothed candle starts a zone; a smoothed close |
//| outside sets its side; a close beyond the far edge clears it.    |
//+------------------------------------------------------------------+
void StepLp(int t, int chartBar)
  {
   if(t == 0)
     {
      lpCandleOpen = (HOpen[0] + HClose[0]) / 2.0;
      lpCandleClose = lpCandleOpen;
      return;
     }
   double sum = 0;
   int    used = 0;
   for(int k = t; k > t - 3 && k >= 0; k--)
     {
      sum += (HOpen[k] + HHigh[k] + HLow[k] + HClose[k]) / 4.0;
      used++;
     }
   lpCandleOpen = (lpCandleOpen + lpCandleClose) / 2.0;
   lpCandleClose = sum / used;
   if(t < InpLpBuildBars + 5)
      return;

   double top = MathMax(HHigh[t], MathMax(lpCandleOpen, lpCandleClose));
   double bottom = MathMin(HLow[t], MathMin(lpCandleOpen, lpCandleClose));
   bool   build = IsBuild(t), extended = false;

   for(int z = 0; z < lpCount; z++)
     {
      if(lpDead[z])
         continue;
      if(lpDirection[z] == 0)
        {
         if(lpCandleClose > lpHigh[z])       lpDirection[z] = 1;
         else if(lpCandleClose < lpLow[z])   lpDirection[z] = -1;
         else if(build && ((bottom <= lpHigh[z] && lpHigh[z] <= top) || (bottom <= lpLow[z] && lpLow[z] <= top)))
           {
            lpHigh[z] = MathMax(lpHigh[z], top);
            lpLow[z] = MathMin(lpLow[z], bottom);
            extended = true;
           }
         if(lpDirection[z] != 0 && InpZoneLp)
            AddZone(ZONE_LP, lpDirection[z], lpHigh[z], lpLow[z], (lpDirection[z] == 1) ? lpHigh[z] : lpLow[z], chartBar);
        }
      else if((lpDirection[z] == 1 && lpCandleClose < lpLow[z]) || (lpDirection[z] == -1 && lpCandleClose > lpHigh[z]))
        {
         lpDead[z] = true;
         for(int w = 0; w < zCount; w++)
            if(zType[w] == ZONE_LP && zTop[w] == lpHigh[z] && zBottom[w] == lpLow[z])
               zDone[w] = true;
        }
     }

   double wick = InpLpWickPips * PipSize();
   if(build && !extended && top - MathMax(lpCandleOpen, lpCandleClose) >= wick && MathMin(lpCandleOpen, lpCandleClose) - bottom >= wick)
     {
      int size = lpCount + 1;
      ArrayResize(lpHigh, size);
      ArrayResize(lpLow, size);
      ArrayResize(lpDirection, size);
      ArrayResize(lpDead, size);
      ArrayResize(lpBorn, size);
      lpHigh[lpCount] = top;
      lpLow[lpCount] = bottom;
      lpDirection[lpCount] = 0;
      lpDead[lpCount] = false;
      lpBorn[lpCount] = HTime[t];
      lpCount++;
     }
  }

bool IsBuild(int t)
  {
   bool up = HClose[t] > HOpen[t], down = HClose[t] < HOpen[t];
   bool previousUp = HClose[t - 1] > HOpen[t - 1], previousDown = HClose[t - 1] < HOpen[t - 1];
   if(!((up && previousDown) || (down && previousUp)))
      return(false);
   double activity = (double)HVolume[t] * (HHigh[t] - HLow[t]);
   for(int k = t - InpLpBuildBars; k < t; k++)
      if((double)HVolume[k] * (HHigh[k] - HLow[k]) >= activity)
         return(false);
   return(true);
  }

//+------------------------------------------------------------------+
void AddZone(int type, int direction, double top, double bottom, double level, int chartBar)
  {
   int size = zCount + 1;
   ArrayResize(zType, size);
   ArrayResize(zDirection, size);
   ArrayResize(zTop, size);
   ArrayResize(zBottom, size);
   ArrayResize(zLevel, size);
   ArrayResize(zBorn, size);
   ArrayResize(zTouched, size);
   ArrayResize(zDone, size);
   ArrayResize(zExtreme, size);
   ArrayResize(zBornBar, size);
   ArrayResize(zTouchBar, size);
   zType[zCount] = type;
   zDirection[zCount] = direction;
   zTop[zCount] = top;
   zBottom[zCount] = bottom;
   zLevel[zCount] = level;
   zBorn[zCount] = Time[chartBar];
   zBornBar[zCount] = chartBar;
   zTouched[zCount] = 0;
   zTouchBar[zCount] = -1;
   zDone[zCount] = false;
   zExtreme[zCount] = 0;
   zCount++;
  }

//+------------------------------------------------------------------+
//| One closed chart candle: first touches and reactions.            |
//+------------------------------------------------------------------+
void ProcessChartBar(int i)
  {
   int trend = (sState == STATE_UP) ? 1 : (sState == STATE_DOWN) ? -1 : 0;
   double pad = InpStopPadPips * PipSize();

   for(int z = 0; z < zCount; z++)
     {
      if(zDone[z] || zBornBar[z] <= i)             // not usable on the candle that revealed it
         continue;
      if(zBornBar[z] - i > InpZoneLifeBars)
        {
         zDone[z] = true;
         continue;
        }
      int d = zDirection[z];
      if(d != trend)
         continue;

      // A close beyond the far side of the zone kills it
      if((d == 1 && Close[i] < zBottom[z] - pad) || (d == -1 && Close[i] > zTop[z] + pad))
        {
         if(zTouchBar[z] >= 0)
            MarkText(i, "o", d == 1, InpWatchColor, ZoneName(zType[z]) + " zone failed: close beyond it");
         zDone[z] = true;
         continue;
        }

      bool inside = (d == 1) ? (Low[i] <= zTop[z]) : (High[i] >= zBottom[z]);
      if(zTouchBar[z] < 0)
        {
         if(!inside)
            continue;
         zTouchBar[z] = i;
         zTouched[z] = Time[i];
         zExtreme[z] = (d == 1) ? Low[i] : High[i];
         MarkText(i, "x", d != 1, InpWatchColor,
                  "WATCH " + ZoneName(zType[z]) + " " + DoubleToString(zLevel[z], Digits) + " (" + TrendName(d) + ")");
        }
      else
         zExtreme[z] = (d == 1) ? MathMin(zExtreme[z], Low[i]) : MathMax(zExtreme[z], High[i]);

      if(zTouchBar[z] - i > InpConfirmBars)
        {
         zDone[z] = true;
         continue;
        }

      string trigger = Reaction(i, d);
      if(trigger == "")
         continue;

      double entry = Close[i];
      double stop = (d == 1) ? zExtreme[z] - pad : zExtreme[z] + pad;
      double risk = MathAbs(entry - stop);
      double target = sLegExtreme;
      double reward = (d == 1) ? target - entry : entry - target;
      string ratio = (risk > 0 && reward > 0) ? DoubleToString(reward / risk, 1) + "R" : "no room";
      string reason = StringFormat("%s %s | %s trend %s | zone %s %s | trigger: %s | stop %s (%.0f pip) | target %s = %s",
                                   d == 1 ? "BUY" : "SELL", Symbol(), TfName(InpStructureTf), TrendName(d),
                                   ZoneName(zType[z]), DoubleToString(zLevel[z], Digits), trigger,
                                   DoubleToString(stop, Digits), risk / PipSize(), DoubleToString(target, Digits), ratio);
      MarkEntry(i, d, entry, stop, target, ZoneShort(zType[z]) + " " + ratio, reason);
      zDone[z] = true;
     }
  }

//+------------------------------------------------------------------+
//| Reaction in direction d, judged on the last 1, 2 or 3 chart      |
//| candles merged into one (open of the first, close of the last,   |
//| highest high, lowest low) and always measured against the median |
//| range of the 20 candles before that cluster:                     |
//|   sweep     - beyond the low (high) of those 20 candles, >= 75%  |
//|               of that excursion given back, range >= 1.25 x the  |
//|               median, give-back >= 0.5 x median and >= 40% of    |
//|               the range                                          |
//|   rejection - range >= InpBigRange x median and the give-back    |
//|               from the extreme to the close >= 60% of the range  |
//|               (a big candle that poked and did not follow)       |
//|   thrust    - range >= InpBigRange x median, body >= 60% of it,  |
//|               close beyond the 4 candles before the cluster      |
//+------------------------------------------------------------------+
string Reaction(int i, int d)
  {
   if(i + 30 >= Bars)
      return("");
   for(int size = 1; size <= 3; size++)
     {
      int    first = i + size - 1;                 // oldest candle of the cluster
      double open = Open[first], close = Close[i];
      double high = High[iHighest(NULL, 0, MODE_HIGH, size, i)];
      double low = Low[iLowest(NULL, 0, MODE_LOW, size, i)];
      double range = high - low;
      double ranges[20];
      for(int k = 1; k <= 20; k++)
         ranges[k - 1] = High[first + k] - Low[first + k];
      ArraySort(ranges);
      double median = (ranges[9] + ranges[10]) / 2.0;
      if(median <= 0 || range <= 0)
         continue;
      // A cluster only counts when its last candle closes the right way
      if((d == 1 && Close[i] <= Open[i]) || (d == -1 && Close[i] >= Open[i]))
         if(size > 1)
            continue;

      double back = (d == 1) ? close - low : high - close;
      double excursion = (d == 1) ? Low[iLowest(NULL, 0, MODE_LOW, 20, first + 1)] - low
                                  : high - High[iHighest(NULL, 0, MODE_HIGH, 20, first + 1)];
      double body = MathAbs(close - open);
      bool   beyond4 = (d == 1) ? close > High[iHighest(NULL, 0, MODE_HIGH, 4, first + 1)]
                                : close < Low[iLowest(NULL, 0, MODE_LOW, 4, first + 1)];
      string cluster = (size == 1) ? "1 candle" : IntegerToString(size) + " candles";
      string ratio = DoubleToString(range / median, 1) + "x the median range";

      if(InpTrigSweep && excursion > 0 && back >= 0.75 * excursion && range >= 1.25 * median && back >= 0.5 * median && back >= 0.4 * range)
         return("sweep of the 20-candle " + (d == 1 ? "low" : "high") + ", closed back (" + cluster + ", " + ratio + ")");
      if(InpTrigReject && range >= InpBigRange * median && back >= 0.6 * range)
         return("rejection: poked and gave back " + DoubleToString(100 * back / range, 0) + "% (" + cluster + ", " + ratio + ")");
      if(InpTrigThrust && range >= InpBigRange * median && body >= 0.6 * range && ((d == 1 && close > open) || (d == -1 && close < open)) && beyond4)
         return("thrust beyond the previous 4 candles (" + cluster + ", " + ratio + ")");
     }
   return("");
  }

//+------------------------------------------------------------------+
void MarkText(int shift, string text, bool above, color textColor, string tooltip)
  {
   double offset = 8 * Point * MathMax(1, Period() / 15);
   string name = Prefix + "t" + IntegerToString(Marks++);
   ObjectCreate(0, name, OBJ_TEXT, 0, Time[shift], above ? High[shift] + offset : Low[shift] - offset);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, above ? ANCHOR_LOWER : ANCHOR_UPPER);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tooltip);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
  }

//+------------------------------------------------------------------+
void MarkEntry(int shift, int d, double entry, double stop, double target, string text, string reason)
  {
   color  arrowColor = (d == 1) ? InpBuyColor : InpSellColor;
   string base = Prefix + "e" + IntegerToString(Marks++);
   ObjectCreate(0, base, (d == 1) ? OBJ_ARROW_BUY : OBJ_ARROW_SELL, 0, Time[shift], entry);
   ObjectSetInteger(0, base, OBJPROP_COLOR, arrowColor);
   ObjectSetInteger(0, base, OBJPROP_WIDTH, 2);
   ObjectSetString(0, base, OBJPROP_TOOLTIP, reason);
   ObjectSetInteger(0, base, OBJPROP_SELECTABLE, false);

   if(InpShowText)
     {
      double offset = 14 * Point * MathMax(1, Period() / 15);
      string label = base + "_txt";
      ObjectCreate(0, label, OBJ_TEXT, 0, Time[shift], (d == 1) ? Low[shift] - offset : High[shift] + offset);
      ObjectSetString(0, label, OBJPROP_TEXT, text);
      ObjectSetString(0, label, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, label, OBJPROP_FONTSIZE, 7);
      ObjectSetInteger(0, label, OBJPROP_COLOR, arrowColor);
      ObjectSetInteger(0, label, OBJPROP_ANCHOR, (d == 1) ? ANCHOR_UPPER : ANCHOR_LOWER);
      ObjectSetString(0, label, OBJPROP_TOOLTIP, reason);
      ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
     }

   if(!InpShowLevels)
      return;
   datetime until = Time[MathMax(shift - 16, 0)];
   for(int part = 0; part < 2; part++)
     {
      double price = (part == 0) ? stop : target;
      string line = base + (part == 0 ? "_sl" : "_tp");
      ObjectCreate(0, line, OBJ_TREND, 0, Time[shift], price, until, price);
      ObjectSetInteger(0, line, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, line, OBJPROP_COLOR, (part == 0) ? InpSellColor : InpBuyColor);
      ObjectSetInteger(0, line, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetInteger(0, line, OBJPROP_SELECTABLE, false);
      ObjectSetString(0, line, OBJPROP_TOOLTIP, (part == 0 ? "stop " : "target ") + DoubleToString(price, Digits));
     }
  }

//+------------------------------------------------------------------+
string ZoneName(int type)
  {
   switch(type)
     {
      case ZONE_RETEST:  return("retest of the broken level");
      case ZONE_PROTECT: return("protected level");
      case ZONE_LP:      return("liquidity zone");
     }
   return("?");
  }

string ZoneShort(int type)
  {
   switch(type)
     {
      case ZONE_RETEST:  return("RT");
      case ZONE_PROTECT: return("PR");
      case ZONE_LP:      return("LP");
     }
   return("?");
  }

string TrendName(int d)
  {
   return(d == 1 ? "UP" : "DOWN");
  }

string TfName(int timeframe)
  {
   switch(timeframe)
     {
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
     }
   return("TF" + IntegerToString(timeframe));
  }

double PipSize()
  {
   return((Digits == 3 || Digits == 5) ? 10 * Point : Point);
  }
//+------------------------------------------------------------------+

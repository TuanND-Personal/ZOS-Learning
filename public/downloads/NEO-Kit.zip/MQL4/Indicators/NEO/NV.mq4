//+------------------------------------------------------------------+
//|                                                           NV.mq4 |
//|  NEO volume: tick volume coloured by the PVSRA tiers.            |
//|                                                                  |
//|  normal   : everything else                                      |
//|  rising   : volume >= InpRisingMult * average of the previous    |
//|             InpLookback candles                                  |
//|  climax   : volume >= InpClimaxMult * that average, or the       |
//|             highest spread * volume of those candles             |
//|  build    : the yellow candle of NC (activity above each of the  |
//|             previous InpBuildBars candles and a close against    |
//|             the previous candle)                                 |
//|  stopping : raised volume on a narrow candle at a                |
//|             InpExtremeBars-candle high or low (effort without    |
//|             result)                                              |
//|  The line is the average volume the tiers are measured against.  |
//|                                                                  |
//|  Wave mode (InpWaveMode = true, attach NV a second time for it): |
//|  volume added up over each price wave, to compare the effort of  |
//|  pushes and pullbacks. A wave turns when the close moves against |
//|  it by InpWaveAtr x ATR from its best close; the new wave starts |
//|  on that candle, so nothing is redrawn afterwards.               |
//+------------------------------------------------------------------+
#property strict
#property indicator_separate_window
#property indicator_minimum 0
#property indicator_buffers 8
#property indicator_color1 C'90,90,100'
#property indicator_color2 C'70,115,160'
#property indicator_color3 clrDeepSkyBlue
#property indicator_color4 clrWhite
#property indicator_color5 C'150,150,165'
#property indicator_width1 2
#property indicator_width2 2
#property indicator_width3 2
#property indicator_width4 2
#property indicator_width5 1
#property indicator_color6 clrYellow
#property indicator_width6 2
#property indicator_color7 clrLimeGreen
#property indicator_width7 2
#property indicator_color8 clrTomato
#property indicator_width8 2

input int    InpLookback    = 10;    // Candles used for the average volume
input double InpRisingMult  = 1.5;   // Rising volume threshold
input double InpClimaxMult  = 2.0;   // Climax volume threshold
input bool   InpUseProduct  = true;  // Climax also when spread * volume is the highest
input int    InpExtremeBars = 20;    // Stopping volume: candles that define the high / low extreme
input int    InpBuildBars   = 5;     // Build: activity must exceed each of this many previous candles
input bool   InpWaveMode    = false; // Show volume added up per price wave instead of per candle
input double InpWaveAtr     = 1.0;   // Wave: reversal needed, in ATR
input int    InpWaveAtrBars = 20;    // Wave: ATR period

double NormalVolume[], RisingVolume[], ClimaxVolume[], StoppingVolume[], AverageVolume[], BuildVolume[];
double WaveUp[], WaveDown[];
int    WaveDirection = 0;
double WaveBest = 0, WaveSum = 0;

//+------------------------------------------------------------------+
int OnInit()
  {
   SetIndexBuffer(0, NormalVolume);
   SetIndexBuffer(1, RisingVolume);
   SetIndexBuffer(2, ClimaxVolume);
   SetIndexBuffer(3, StoppingVolume);
   SetIndexBuffer(4, AverageVolume);
   SetIndexBuffer(5, BuildVolume);
   SetIndexStyle(5, DRAW_HISTOGRAM);
   SetIndexEmptyValue(5, 0.0);
   SetIndexLabel(5, "Build");
   for(int b = 0; b < 4; b++)
     {
      SetIndexStyle(b, DRAW_HISTOGRAM);
      SetIndexEmptyValue(b, 0.0);
     }
   SetIndexStyle(4, DRAW_LINE);
   SetIndexLabel(0, "Normal");
   SetIndexLabel(1, "Rising");
   SetIndexLabel(2, "Climax");
   SetIndexLabel(3, "Stopping");
   SetIndexLabel(4, "Average");
   SetIndexBuffer(6, WaveUp);
   SetIndexBuffer(7, WaveDown);
   SetIndexStyle(6, DRAW_HISTOGRAM);
   SetIndexStyle(7, DRAW_HISTOGRAM);
   SetIndexEmptyValue(6, 0.0);
   SetIndexEmptyValue(7, 0.0);
   SetIndexLabel(6, "Up wave volume");
   SetIndexLabel(7, "Down wave volume");
   IndicatorShortName(InpWaveMode ? "NV waves" : "NV");
   IndicatorDigits(0);
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int warmup = MathMax(MathMax(InpLookback, InpExtremeBars), InpBuildBars + 1) + 1;
   if(rates_total <= warmup)
      return(0);
   if(InpWaveMode)
      return(CalculateWaves(rates_total, prev_calculated, warmup));
   int start = (prev_calculated == 0) ? rates_total - 1 - warmup : rates_total - prev_calculated;

   for(int i = start; i >= 0; i--)
     {
      double current = (double)Volume[i];
      double range = High[i] - Low[i];
      double sum = 0, highestProduct = 0;
      for(int k = i + 1; k <= i + InpLookback; k++)
        {
         sum += (double)Volume[k];
         highestProduct = MathMax(highestProduct, (double)Volume[k] * (High[k] - Low[k]));
        }
      double average = sum / InpLookback;
      bool climax = (average > 0 && current >= InpClimaxMult * average) || (InpUseProduct && current * range > highestProduct);
      bool rising = (average > 0 && current >= InpRisingMult * average);

      // Stopping volume: raised volume, candle narrower than the median of the previous ones, at an extreme
      bool stopping = false;
      if(climax || rising)
        {
         double ranges[];
         ArrayResize(ranges, InpExtremeBars);
         double highest = High[i], lowest = Low[i];
         for(int k = 1; k <= InpExtremeBars; k++)
            ranges[k - 1] = High[i + k] - Low[i + k];
         for(int k = 1; k < InpExtremeBars; k++)
           {
            highest = MathMax(highest, High[i + k]);
            lowest = MathMin(lowest, Low[i + k]);
           }
         ArraySort(ranges);
         double median = (ranges[InpExtremeBars / 2 - 1] + ranges[InpExtremeBars / 2]) / 2.0;
         bool atHigh = High[i] >= highest, atLow = Low[i] <= lowest;
         stopping = range < median && (atHigh != atLow);
        }

      NormalVolume[i] = 0;
      RisingVolume[i] = 0;
      ClimaxVolume[i] = 0;
      StoppingVolume[i] = 0;
      BuildVolume[i] = 0;
      if(IsBuild(i))
         BuildVolume[i] = current;
      else if(stopping)
         StoppingVolume[i] = current;
      else if(climax)
         ClimaxVolume[i] = current;
      else if(rising)
         RisingVolume[i] = current;
      else
         NormalVolume[i] = current;
      AverageVolume[i] = average;
     }
   return(rates_total);
  }

//+------------------------------------------------------------------+
//| Volume per wave. Only closed candles change the wave state; the  |
//| forming candle is shown on top of it and recomputed each tick.   |
//+------------------------------------------------------------------+
int CalculateWaves(int rates_total, int prev_calculated, int warmup)
  {
   static datetime lastClosed = 0;
   int start;
   if(prev_calculated == 0)
     {
      start = rates_total - 1 - MathMax(warmup, InpWaveAtrBars + 1);
      WaveDirection = 0;
      WaveBest = Close[start + 1];
      WaveSum = 0;
      lastClosed = 0;
      ArrayInitialize(WaveUp, 0.0);
      ArrayInitialize(WaveDown, 0.0);
     }
   else
      start = rates_total - prev_calculated;

   for(int i = MathMax(start, 1); i >= 1; i--)
     {
      if(Time[i] <= lastClosed)
         continue;
      lastClosed = Time[i];
      double threshold = InpWaveAtr * iATR(NULL, 0, InpWaveAtrBars, i);
      if(WaveDirection >= 0 && Close[i] < WaveBest - threshold)
        { WaveDirection = -1; WaveBest = Close[i]; WaveSum = 0; }
      else if(WaveDirection <= 0 && Close[i] > WaveBest + threshold)
        { WaveDirection = 1; WaveBest = Close[i]; WaveSum = 0; }
      else if(WaveDirection > 0)
         WaveBest = MathMax(WaveBest, Close[i]);
      else if(WaveDirection < 0)
         WaveBest = MathMin(WaveBest, Close[i]);
      WaveSum += (double)Volume[i];
      WaveUp[i] = (WaveDirection > 0) ? WaveSum : 0;
      WaveDown[i] = (WaveDirection < 0) ? WaveSum : 0;
     }
   WaveUp[0] = (WaveDirection > 0) ? WaveSum + (double)Volume[0] : 0;
   WaveDown[0] = (WaveDirection < 0) ? WaveSum + (double)Volume[0] : 0;
   return(rates_total);
  }

//+------------------------------------------------------------------+
bool IsBuild(int shift)
  {
   if(shift + InpBuildBars + 1 >= Bars)
      return(false);
   bool up = Close[shift] > Open[shift], down = Close[shift] < Open[shift];
   bool previousUp = Close[shift + 1] > Open[shift + 1], previousDown = Close[shift + 1] < Open[shift + 1];
   if(!((up && previousDown) || (down && previousUp)))
      return(false);
   double activity = (double)Volume[shift] * (High[shift] - Low[shift]);
   for(int k = shift + 1; k <= shift + InpBuildBars; k++)
      if((double)Volume[k] * (High[k] - Low[k]) >= activity)
         return(false);
   return(true);
  }
//+------------------------------------------------------------------+

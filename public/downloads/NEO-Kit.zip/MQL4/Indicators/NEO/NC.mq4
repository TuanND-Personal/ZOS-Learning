//+------------------------------------------------------------------+
//|                                                           NC.mq4 |
//|  Smoothed candles coloured by trend state, modelled on ZOS.      |
//|                                                                  |
//|  Candle (matches the ZOS export to 6 decimals):                  |
//|    close = average of the last InpSmoothBars Heiken Ashi closes  |
//|            ((O + H + L + C) / 4)                                 |
//|    open  = midpoint of the previous smoothed candle body         |
//|    wick  = real high / low of the bar                            |
//|                                                                  |
//|  Colour family (matches ZOS on 100% of exported candles):        |
//|    M = EMA(close, InpFastEma) - EMA(close, InpSlowEma)           |
//|    M > 0 and rising  -> green  (strong uptrend)                  |
//|    M > 0 and falling -> blue   (pullback in / fading uptrend)    |
//|    M < 0 and falling -> red    (strong downtrend)                |
//|    M < 0 and rising  -> pink   (recovery in / fading downtrend)  |
//|  Inside a family the light shade is a rising candle, the dark    |
//|  shade a falling candle.                                         |
//|                                                                  |
//|  Yellow = Build candle: tick volume * range above each of the    |
//|  previous InpBuildBars candles and a close against the previous  |
//|  candle's direction (never marks a candle ZOS does not; finds    |
//|  83-91% of the ZOS Build candles).                               |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 13

input int    InpSmoothBars      = 3;             // Heiken Ashi closes averaged for the candle close
input int    InpFastEma         = 50;            // Fast EMA of the trend measure M
input int    InpSlowEma         = 200;           // Slow EMA of the trend measure M
input bool   InpShowBuild       = true;          // Paint Build candles yellow
input int    InpBuildBars       = 5;             // Build: activity must exceed each of this many previous candles
input bool   InpAutoWidth       = true;          // Fit the body width to the chart zoom
input int    InpBodyWidth       = 3;             // Candle body width when auto width is off
input int    InpWickWidth       = 1;             // Candle wick width
input bool   InpHideChart       = true;          // Hide the native price chart while attached
input color  InpGreenUp         = clrLime;       // Strong uptrend, rising candle
input color  InpGreenDown       = clrGreen;      // Strong uptrend, falling candle
input color  InpBlueUp          = clrDeepSkyBlue; // Weak uptrend, rising candle
input color  InpBlueDown        = clrRoyalBlue;  // Weak uptrend, falling candle
input color  InpRedUp           = C'250,128,114'; // Strong downtrend, rising candle
input color  InpRedDown         = C'253,38,0';   // Strong downtrend, falling candle
input color  InpPinkUp          = C'242,159,242'; // Weak downtrend, rising candle
input color  InpPinkDown        = C'137,18,137'; // Weak downtrend, falling candle
input color  InpBuildColor      = clrYellow;     // High-activity candle
input color  InpWickColor       = C'106,106,117';

#define FAMILY_GREEN  0
#define FAMILY_BLUE   1
#define FAMILY_RED    2
#define FAMILY_PINK   3
#define FAMILY_BUILD  4

// Each body pair holds the candle close in the first buffer and the open in the second one. MT4 paints a
// two-buffer histogram with the colour of the buffer holding the higher value, so the first colour shows
// on rising candles and the second on falling candles.
double WickHigh[], WickLow[];
double GreenClose[], GreenOpen[];
double BlueClose[],  BlueOpen[];
double RedClose[],   RedOpen[];
double PinkClose[],  PinkOpen[];
double BuildClose[], BuildOpen[];
double Matrix[];
double CandleOpen[], CandleClose[];

long PrevChartMode       = CHART_CANDLES;
long PrevChartLineColor  = clrNONE;
long PrevChartForeground = 0;
bool ChartHidden         = false;
int  AppliedWidth        = -1;

//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSmoothBars < 1 || InpBuildBars < 1 || InpFastEma < 1 || InpSlowEma <= InpFastEma)
     {
      Print("NC: need InpSmoothBars >= 1, InpBuildBars >= 1 and InpSlowEma > InpFastEma >= 1");
      return(INIT_PARAMETERS_INCORRECT);
     }

   IndicatorBuffers(15);

   // Wicks are bound first so the bodies are painted on top of them
   int width = BodyWidth();
   AppliedWidth = width;
   BindPair(0, WickHigh,   WickLow,   InpWickWidth, InpWickColor, InpWickColor);
   BindPair(2, GreenClose, GreenOpen, width, InpGreenUp,   InpGreenDown);
   BindPair(4, BlueClose,  BlueOpen,  width, InpBlueUp,    InpBlueDown);
   BindPair(6, RedClose,   RedOpen,   width, InpRedUp,     InpRedDown);
   BindPair(8, PinkClose,  PinkOpen,  width, InpPinkUp,    InpPinkDown);
   BindPair(10, BuildClose, BuildOpen, width, InpBuildColor, InpBuildColor);

   SetIndexBuffer(12, Matrix);
   SetIndexStyle(12, DRAW_NONE);
   SetIndexLabel(12, "Matrix (pips)");

   SetIndexBuffer(13, CandleOpen);
   SetIndexBuffer(14, CandleClose);
   SetIndexStyle(13, DRAW_NONE);
   SetIndexStyle(14, DRAW_NONE);

   IndicatorShortName("NC");

   if(InpHideChart)
      HideNativeChart();

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   if(ChartHidden)
     {
      ChartSetInteger(0, CHART_MODE, PrevChartMode);
      ChartSetInteger(0, CHART_COLOR_CHART_LINE, PrevChartLineColor);
      ChartSetInteger(0, CHART_FOREGROUND, PrevChartForeground);
      ChartHidden = false;
     }
  }

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int warmup = MathMax(InpSmoothBars, InpBuildBars) + 2;
   if(rates_total <= warmup)
      return(0);

   int start;
   if(prev_calculated == 0)
     {
      start = rates_total - 1 - warmup;
      // Seed the recursion one bar before the first drawn candle
      CandleClose[start + 1] = SmoothedClose(start + 1);
      CandleOpen[start + 1]  = (Open[start + 1] + Close[start + 1]) / 2.0;
     }
   else
      start = rates_total - prev_calculated;

   double pip = (Digits == 3 || Digits == 5) ? 10 * Point : Point;

   for(int i = start; i >= 0; i--)
     {
      double candleClose = SmoothedClose(i);
      double candleOpen  = (CandleOpen[i + 1] + CandleClose[i + 1]) / 2.0;
      CandleOpen[i]  = candleOpen;
      CandleClose[i] = candleClose;

      double trendNow  = TrendMeasure(i);
      double trendPrev = TrendMeasure(i + 1);
      Matrix[i] = trendNow / pip;

      int family;
      if(InpShowBuild && IsBuildCandle(i))
         family = FAMILY_BUILD;
      else if(trendNow > 0)
         family = (trendNow > trendPrev) ? FAMILY_GREEN : FAMILY_BLUE;
      else
         family = (trendNow > trendPrev) ? FAMILY_PINK : FAMILY_RED;

      DrawCandle(i, family, candleOpen, candleClose);
     }

   return(rates_total);
  }

//+------------------------------------------------------------------+
//| Re-fits the body width when the chart is zoomed                  |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id != CHARTEVENT_CHART_CHANGE || !InpAutoWidth)
      return;
   int width = BodyWidth();
   if(width == AppliedWidth)
      return;
   AppliedWidth = width;
   for(int index = 2; index <= 11; index++)
      SetIndexStyle(index, DRAW_HISTOGRAM, STYLE_SOLID, width);
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Histogram width for the current zoom. MT4 spaces bars 1, 2, 4,   |
//| 8, 16, 32 pixels apart for scales 0-5, and a histogram of width  |
//| w is painted about 2w - 1 pixels wide.                           |
//+------------------------------------------------------------------+
int BodyWidth()
  {
   if(!InpAutoWidth)
      return(InpBodyWidth);
   switch((int)ChartGetInteger(0, CHART_SCALE))
     {
      case 0:
      case 1: return(1);
      case 2: return(2);
      case 3: return(3);
     }
   return(5);
  }

//+------------------------------------------------------------------+
void BindPair(int index, double &first[], double &second[], int width, color firstColor, color secondColor)
  {
   SetIndexBuffer(index, first);
   SetIndexBuffer(index + 1, second);
   SetIndexStyle(index, DRAW_HISTOGRAM, STYLE_SOLID, width, firstColor);
   SetIndexStyle(index + 1, DRAW_HISTOGRAM, STYLE_SOLID, width, secondColor);
   SetIndexLabel(index, NULL);
   SetIndexLabel(index + 1, NULL);
  }

//+------------------------------------------------------------------+
void HideNativeChart()
  {
   PrevChartMode       = ChartGetInteger(0, CHART_MODE);
   PrevChartLineColor  = ChartGetInteger(0, CHART_COLOR_CHART_LINE);
   PrevChartForeground = ChartGetInteger(0, CHART_FOREGROUND);
   ChartSetInteger(0, CHART_MODE, CHART_LINE);
   ChartSetInteger(0, CHART_COLOR_CHART_LINE, clrNONE);
   ChartSetInteger(0, CHART_FOREGROUND, false);
   ChartHidden = true;
  }

//+------------------------------------------------------------------+
//| Average of the last InpSmoothBars Heiken Ashi closes             |
//+------------------------------------------------------------------+
double SmoothedClose(int shift)
  {
   double sum = 0.0;
   int    count = 0;
   for(int k = shift; k < shift + InpSmoothBars && k < Bars; k++)
     {
      sum += (Open[k] + High[k] + Low[k] + Close[k]) / 4.0;
      count++;
     }
   return(count > 0 ? sum / count : Close[shift]);
  }

//+------------------------------------------------------------------+
double TrendMeasure(int shift)
  {
   return(iMA(NULL, 0, InpFastEma, 0, MODE_EMA, PRICE_CLOSE, shift) -
          iMA(NULL, 0, InpSlowEma, 0, MODE_EMA, PRICE_CLOSE, shift));
  }

//+------------------------------------------------------------------+
//| Build candle, the rule recovered from the ZOS export: activity   |
//| (tick volume * range) above each of the previous InpBuildBars    |
//| candles AND the candle closes against the direction of the       |
//| candle before it. On the export this marks no candle that ZOS    |
//| does not mark and finds 83-91% of the ZOS Build candles.         |
//+------------------------------------------------------------------+
bool IsBuildCandle(int shift)
  {
   if(shift + InpBuildBars + 1 >= Bars)
      return(false);
   bool up = Close[shift] > Open[shift], down = Close[shift] < Open[shift];
   bool previousUp = Close[shift + 1] > Open[shift + 1], previousDown = Close[shift + 1] < Open[shift + 1];
   if(!((up && previousDown) || (down && previousUp)))
      return(false);

   double activity = (double)Volume[shift] * (High[shift] - Low[shift]);
   for(int k = shift + 1; k <= shift + InpBuildBars; k++)
      if((double)Volume[k] * (High[k] - Low[k]) >= activity)
         return(false);
   return(true);
  }

//+------------------------------------------------------------------+
void DrawCandle(int shift, int family, double candleOpen, double candleClose)
  {
   WickHigh[shift] = MathMax(High[shift], MathMax(candleOpen, candleClose));
   WickLow[shift]  = MathMin(Low[shift], MathMin(candleOpen, candleClose));

   GreenClose[shift] = EMPTY_VALUE; GreenOpen[shift] = EMPTY_VALUE;
   BlueClose[shift]  = EMPTY_VALUE; BlueOpen[shift]  = EMPTY_VALUE;
   RedClose[shift]   = EMPTY_VALUE; RedOpen[shift]   = EMPTY_VALUE;
   PinkClose[shift]  = EMPTY_VALUE; PinkOpen[shift]  = EMPTY_VALUE;
   BuildClose[shift] = EMPTY_VALUE; BuildOpen[shift] = EMPTY_VALUE;

   switch(family)
     {
      case FAMILY_GREEN: GreenClose[shift] = candleClose; GreenOpen[shift] = candleOpen; break;
      case FAMILY_BLUE:  BlueClose[shift]  = candleClose; BlueOpen[shift]  = candleOpen; break;
      case FAMILY_RED:   RedClose[shift]   = candleClose; RedOpen[shift]   = candleOpen; break;
      case FAMILY_PINK:  PinkClose[shift]  = candleClose; PinkOpen[shift]  = candleOpen; break;
      case FAMILY_BUILD: BuildClose[shift] = candleClose; BuildOpen[shift] = candleOpen; break;
     }
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                           NS.mq4 |
//|  NEO map: market structure, ranges, liquidity zones and levels   |
//|  of W1 / D1 / H4 on one chart. Every layer has its own switch in |
//|  the panel (upper right); the header folds the panel to a line.  |
//|                                                                  |
//|  pivot      : candle beyond InpPivotSide candles on each side    |
//|  leg top    : pivot high that is the highest since the last BOS  |
//|  BOS up     : close above the leg top; the lowest low since that |
//|               top becomes the protected low                      |
//|  CHoCH down : close below the protected low (trend is turning)   |
//|  CONF       : after a CHoCH, a lower high forms and a close goes |
//|               below the low before it (new trend confirmed)      |
//|  FAIL       : after a CHoCH, a close back beyond the old extreme |
//|  Everything is mirrored for the down side. Only closed candles   |
//|  are used, so nothing drawn changes afterwards.                  |
//|                                                                  |
//|  range      : at least InpRangeTouches pivot highs and lows have |
//|               formed between the two levels that decide the next |
//|               event (e.g. protected low and leg top)             |
//|  LP         : liquidity zone in the ZO style. It starts on a     |
//|               Build candle (the yellow candle of NC: activity    |
//|               above the 5 candles before it and a close against  |
//|               the previous candle) with a wick on both           |
//|               ends of the smoothed candle; a later such candle   |
//|               reaching its High / Low extends it; a smoothed     |
//|               close outside makes it GLP / RLP; a smoothed close |
//|               beyond the far edge clears it. MAIN = the latest   |
//|               LP alive when an opposite LP was cleared; shield = |
//|               a later LP of the same side while the Main lives.  |
//|               H4 / D1 / W1 LPs are drawn as High / Low lines     |
//|               (solid GLP, dashed RLP, dotted unbroken), LPs of a |
//|               chart below H4 as boxes.                           |
//|  trend line : joins the last two protected lows (highs); the     |
//|               channel line is its parallel through the extreme   |
//|               between them; TL = a close beyond the trend line   |
//|                                                                  |
//|  Mirrors research/structure.py; the events of the chart          |
//|  timeframe are written to MQL4/Files for cross-checking.         |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 4
#property indicator_color1 clrLimeGreen
#property indicator_color2 clrTomato
#property indicator_color3 clrGold
#property indicator_color4 clrDeepSkyBlue
#property indicator_width1 2
#property indicator_width2 2
#property indicator_width3 2
#property indicator_width4 2

#define STATE_NONE       0
#define STATE_UP         1
#define STATE_DOWN      -1
#define STATE_TURN_DOWN  2
#define STATE_TURN_UP   -2

#define EV_START_UP          1
#define EV_START_DOWN        2
#define EV_BOS_UP            3
#define EV_BOS_DOWN          4
#define EV_CHOCH_DOWN        5
#define EV_CHOCH_UP          6
#define EV_CONFIRM_UP        7
#define EV_CONFIRM_DOWN      8
#define EV_FAILED_TURN_UP    9
#define EV_FAILED_TURN_DOWN 10
#define EV_TL_BREAK_UP      11
#define EV_TL_BREAK_DOWN    12

input int   InpPivotSide     = 2;       // Candles on each side of a pivot
input int   InpMaxBars       = 5000;    // Closed candles analysed per timeframe
input bool  InpShowW1        = true;    // Panel + level for W1
input bool  InpShowD1        = true;    // Panel + level for D1
input bool  InpShowH4        = true;    // Panel + level for H4
input int   InpRangeTouches  = 2;       // Pivot highs and lows needed inside a range
input bool  InpLayerTrend    = true;    // Layer on at first start: protected levels (stepped line + W1 / D1 / H4 lines)
input bool  InpLayerRange    = true;    // Layer: range boxes
input bool  InpLayerLp       = true;    // Layer: liquidity zones (LP)
input bool  InpLayerSwing    = true;    // Layer: unbroken swing highs / lows of H4 / D1 / W1
input bool  InpLayerRound    = false;   // Layer: round numbers (00 / 50)
input bool  InpLayerPrev     = false;   // Layer: previous day / week high and low
input bool  InpLayerLines    = false;   // Layer: trend lines and channels
input bool  InpLayerEvents   = false;   // Layer: BOS / CHoCH / CONF / FAIL / TL labels
input bool  InpLayerMarks    = false;   // Layer: candle behaviour marks (S sweep, I intent, t test)
input int   InpMarkBars      = 150;     // Candles marked back from the last one
input int   InpSweepBars     = 20;      // Sweep: the high / low of this many previous candles must be taken
input double InpSweepRangeMult = 1.25;  // Big sweep (S): candle range >= this x the median range of the 20 candles before
input double InpSweepRejectMult = 0.5;  // Big sweep (S): distance from the extreme back to the close >= this x that median
input double InpSweepWickShare = 0.4;   // Big sweep (S): that distance >= this share of the candle range
input double InpSweepRecover   = 0.75;  // Sweep: the close gives back at least this share of the move beyond the old extreme
input bool  InpShowSmallSweeps = false; // Also mark the other sweeps with a small grey "s"
input int   InpLabelCount    = 8;       // Labels drawn when that layer is on (most recent)
input int   InpMaxRanges     = 3;       // Range boxes drawn when that layer is on (most recent)
input int   InpMaxLines      = 2;       // Trend lines drawn when that layer is on (most recent)
input int   InpSwingsPerSide = 3;       // Nearest unbroken swings above and below price, per timeframe
input double InpConfluencePips = 5.0;   // A level this close to a level of another kind is drawn thick
input color InpSwingHighColor = C'205,95,95';
input color InpSwingLowColor  = C'95,175,115';
input color InpRoundColor     = C'95,95,110';
input color InpPrevColor      = C'90,140,200';
input bool  InpLpBoxes       = true;    // On charts below H4: LPs of the chart timeframe as boxes
input int   InpLpPerSide     = 3;       // Nearest live LPs drawn above and below price per timeframe (Mains always)
input int   InpLpSmoothBars  = 3;       // Heiken Ashi closes averaged for the smoothed candle (as NeoCandles)
input int   InpLpBuildBars   = 5;       // Build candle: activity must exceed each of this many previous candles
input double InpLpWickPips   = 1.0;     // Wick needed on both ends of the first candle of an LP
input int   InpLpAgeH4       = 360;     // Oldest candle that can still start a drawn LP
input int   InpLpAgeD1       = 250;
input int   InpLpAgeW1       = 300;
input int   InpLpAgeChart    = 960;     // Same for the chart timeframe boxes
input color InpLpColorH4     = clrDodgerBlue;
input color InpLpColorD1     = clrGold;
input color InpLpColorW1     = clrTomato;
input color InpLpBoxGlp      = C'0,95,0';
input color InpLpBoxRlp      = C'110,0,0';
input color InpLpBoxFresh    = clrGold;
input color InpRangeColor    = C'45,35,70';
input color InpLineColor     = clrKhaki;
input bool  InpShowHtfLevels = true;    // Protected levels of higher timeframes as lines
input bool  InpWriteFile     = true;    // Write the chart timeframe events to MQL4/Files
input bool  InpStartExpanded = true;    // Panel state when first attached (click its header to toggle)
input int   InpPanelX        = 8;       // Panel distance from the right edge
input int   InpPanelY        = 18;      // Panel distance from the top
input color InpPanelBack     = C'18,18,26';
input color InpPanelBorder   = C'70,70,95';
input color InpPanelText     = C'205,205,215';

double GuardUp[], GuardDown[], GuardTurnDown[], GuardTurnUp[];

string   Prefix = "NS_";
datetime LastBarTime = 0;

#define LAYER_TREND  0
#define LAYER_RANGE  1
#define LAYER_LP     2
#define LAYER_SWING  3
#define LAYER_ROUND  4
#define LAYER_PREV   5
#define LAYER_LINES  6
#define LAYER_EVENTS 7
#define LAYER_MARKS  8
#define LAYER_COUNT  9
string   LayerName[LAYER_COUNT] = {"Trend", "Range", "LP", "Swing", "Round", "Prev", "TLine", "Event", "Mark"};

#define FAMILY_SWING 1
#define FAMILY_ROUND 2
#define FAMILY_PREV  3
// Plain price levels chosen for drawing (swings, round numbers, previous highs / lows)
double   LvPrice[];
string   LvText[];
color    LvColor[];
datetime LvFrom[];
int      LvFamily[];
int      LvCount = 0;
// Liquidity zones chosen for drawing
int      LpTf[], LpDirection[];
double   LpHigh[], LpLow[];
datetime LpFrom[];
bool     LpMain[], LpShield[];
int      LpCount = 0;
// Working arrays of one LP scan (chronological)
double   QHigh[], QLow[], QOpen[], QClose[];
long     QVolume[];
datetime QTime[];
string   PanelText[];
color    PanelColor[];
int      PanelRows = 0;

// Working arrays of one analysis (chronological, index 0 = oldest closed candle)
double   WHigh[], WLow[], WClose[];
datetime WTime[];
int      WState[];
double   WGuard[];
int      EvIndex[], EvKind[], EvWeak[];
double   EvLevel[];
int      EvCount = 0;

// Confirmed pivots, trend lines and ranges of the last analysis
int      PvIndex[], PvKind[];
double   PvPrice[];
int      PvCount = 0;
int      LnFrom[], LnStart[], LnEnd[], LnDirection[];
double   LnPrice[], LnSlope[], LnOffset[];
bool     LnBroken[];
int      LnCount = 0;
int      RgStart[], RgEnd[];
double   RgLow[], RgHigh[];
int      RgCount = 0;
bool     LastRangeOn = false;
double   LastRangeLow = 0, LastRangeHigh = 0;
int      LastRangeBars = 0;
// Context of the last closed candle (step 3, descriptive only)
bool     LastBoxDefined = false;
double   LastPosition = 0;         // 0 = lower deciding level, 1 = upper deciding level
double   LastLegRatio = 0;         // current leg / median of earlier impulses (0 = unknown)
int      LastSweep = 0;            // +1 upper edge swept recently, -1 lower edge, 0 none
double   Impulses[];
int      ImpulseCount = 0;

//+------------------------------------------------------------------+
int OnInit()
  {
   SetIndexBuffer(0, GuardUp);
   SetIndexBuffer(1, GuardDown);
   SetIndexBuffer(2, GuardTurnDown);
   SetIndexBuffer(3, GuardTurnUp);
   for(int b = 0; b < 4; b++)
     {
      SetIndexStyle(b, DRAW_LINE);
      SetIndexEmptyValue(b, EMPTY_VALUE);
     }
   SetIndexLabel(0, "Protected low (UP)");
   SetIndexLabel(1, "Protected high (DOWN)");
   SetIndexLabel(2, "Old top (turning down)");
   SetIndexLabel(3, "Old bottom (turning up)");
   IndicatorShortName("NS");
   LastBarTime = 0;
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0, Prefix);
   Comment("");
  }

//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total < 4 * InpPivotSide + 10)
      return(0);
   if(Time[0] == LastBarTime && prev_calculated > 0)
      return(rates_total);
   if(Render())
      LastBarTime = Time[0];
   return(rates_total);
  }

//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id != CHARTEVENT_OBJECT_CLICK)
      return;
   if(sparam == Prefix + "toggle")
      GlobalVariableSet(ExpandedKey(), IsExpanded() ? 0 : 1);
   else if(StringFind(sparam, Prefix + "layer_") == 0)
     {
      int layer = (int)StringToInteger(StringSubstr(sparam, StringLen(Prefix + "layer_")));
      GlobalVariableSet(LayerKey(layer), LayerOn(layer) ? 0 : 1);
     }
   else
      return;
   Render();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Layer switches, remembered per chart                             |
//+------------------------------------------------------------------+
string LayerKey(int layer)
  {
   return(Prefix + "layer" + IntegerToString(layer) + "_" + IntegerToString(ChartID()));
  }

bool LayerOn(int layer)
  {
   if(GlobalVariableCheck(LayerKey(layer)))
      return(GlobalVariableGet(LayerKey(layer)) > 0);
   switch(layer)
     {
      case LAYER_TREND:  return(InpLayerTrend);
      case LAYER_RANGE:  return(InpLayerRange);
      case LAYER_LP:     return(InpLayerLp);
      case LAYER_SWING:  return(InpLayerSwing);
      case LAYER_ROUND:  return(InpLayerRound);
      case LAYER_PREV:   return(InpLayerPrev);
      case LAYER_LINES:  return(InpLayerLines);
      case LAYER_EVENTS: return(InpLayerEvents);
      case LAYER_MARKS:  return(InpLayerMarks);
     }
   return(false);
  }

//+------------------------------------------------------------------+
string ExpandedKey()
  {
   return(Prefix + "expanded_" + IntegerToString(ChartID()));
  }

bool IsExpanded()
  {
   if(!GlobalVariableCheck(ExpandedKey()))
      return(InpStartExpanded);
   return(GlobalVariableGet(ExpandedKey()) > 0);
  }

//+------------------------------------------------------------------+
//| Analyses every timeframe and redraws everything. Collapsing the  |
//| panel only folds it to one line; the drawings stay.              |
//+------------------------------------------------------------------+
bool Render()
  {
   bool ready = true;
   bool expanded = IsExpanded();
   string brief = "";
   PanelRows = 0;
   LvCount = 0;
   LpCount = 0;
   ObjectsDeleteAll(0, Prefix);
   int swingAge[3];
   swingAge[0] = InpLpAgeW1;
   swingAge[1] = InpLpAgeD1;
   swingAge[2] = InpLpAgeH4;

   int frames[3] = {PERIOD_W1, PERIOD_D1, PERIOD_H4};
   bool shown[3];
   shown[0] = InpShowW1;
   shown[1] = InpShowD1;
   shown[2] = InpShowH4;

   for(int f = 0; f < 3; f++)
     {
      if(!shown[f] || frames[f] == Period())
         continue;
      if(!Analyze(frames[f]))
        {
         AddPanelRow(TfName(frames[f]) + "  loading history...", InpPanelText);
         ready = false;
         continue;
        }
      AddPanelRow(Summary(frames[f]), StateColor(LastState()));
      brief += TfName(frames[f]) + ":" + StateShort(LastState()) + " ";
      if(LayerOn(LAYER_TREND) && InpShowHtfLevels && frames[f] > Period())
         DrawHtfLevel(frames[f]);
      if(LayerOn(LAYER_SWING) && frames[f] > Period())
         CollectSwings(frames[f], swingAge[f]);
     }

   // The chart timeframe is analysed last so the working arrays hold its result for drawing.
   if(Analyze(Period()))
     {
      AddPanelRow(Summary(Period()) + " *", StateColor(LastState()));
      brief += TfName(Period()) + ":" + StateShort(LastState());
      if(LayerOn(LAYER_SWING) && Period() >= PERIOD_H4)
         CollectSwings(Period(), Period() == PERIOD_H4 ? InpLpAgeH4 : Period() == PERIOD_D1 ? InpLpAgeD1 : InpLpAgeW1);
      DrawChartTimeframe();
      if(InpWriteFile)
         WriteEvents();
     }
   else
      ready = false;

   if(LayerOn(LAYER_ROUND))
      CollectRound();
   if(LayerOn(LAYER_PREV))
      CollectPrev();
   if(LayerOn(LAYER_LP))
     {
      LpCount = 0;
      int ages[3];
      ages[0] = InpLpAgeW1;
      ages[1] = InpLpAgeD1;
      ages[2] = InpLpAgeH4;
      for(int f = 0; f < 3; f++)
         if(shown[f] && frames[f] >= Period() && !BuildLps(frames[f], ages[f]))
            ready = false;
      if(InpLpBoxes && Period() < PERIOD_H4)
         BuildLps(Period(), InpLpAgeChart);
      DrawLps();
     }

   DrawLevels();
   if(LayerOn(LAYER_MARKS))
      DrawMarks();
   DrawPanel(expanded, brief);
   return(ready);
  }

//+------------------------------------------------------------------+
//| Structure state machine on the closed candles of one timeframe   |
//+------------------------------------------------------------------+
bool Analyze(int timeframe)
  {
   int total = iBars(Symbol(), timeframe);
   if(total < 4 * InpPivotSide + 10)
      return(false);
   int count = MathMin(total - 1, InpMaxBars);

   ArraySetAsSeries(WHigh, false);
   ArraySetAsSeries(WLow, false);
   ArraySetAsSeries(WClose, false);
   ArraySetAsSeries(WTime, false);
   if(CopyHigh(Symbol(), timeframe, 1, count, WHigh) != count ||
      CopyLow(Symbol(), timeframe, 1, count, WLow) != count ||
      CopyClose(Symbol(), timeframe, 1, count, WClose) != count ||
      CopyTime(Symbol(), timeframe, 1, count, WTime) != count)
      return(false);

   ArrayResize(WState, count);
   ArrayResize(WGuard, count);
   EvCount = 0;
   PvCount = 0;
   LnCount = 0;
   RgCount = 0;
   LastRangeOn = false;
   LastBoxDefined = false;
   LastLegRatio = 0;
   LastSweep = 0;
   ImpulseCount = 0;
   int activeLine = -1, openRange = -1, guardIndex = 0;

   int    side = InpPivotSide;
   int    current = STATE_NONE;
   bool   hasPivotHigh = false, hasPivotLow = false, hasLeg = false, hasCounter = false, hasPrevLeg = false;
   int    pivotHighIndex = 0, pivotLowIndex = 0, legIndex = 0, counterIndex = 0;
   double pivotHighPrice = 0, pivotLowPrice = 0, legPrice = 0;
   int    sinceBreak = 0, turnStart = 0;
   double guard = EMPTY_VALUE, turnLimit = 0, counterBreak = 0;
   double prevImpulse = 0, prevDepth = 0, prevSpeed = 0;

   for(int t = 0; t < count; t++)
     {
      // Pivots confirmed by candle t (the pivot candle is t - side)
      int p = t - side;
      if(p >= side)
        {
         if(WHigh[p] > MaxHigh(p - side, p - 1) && WHigh[p] >= MaxHigh(p + 1, p + side))
           {
            hasPivotHigh = true;
            pivotHighIndex = p;
            pivotHighPrice = WHigh[p];
            AddPivot(p, WHigh[p], 1);
            if(current == STATE_UP && WHigh[p] >= MaxHigh(sinceBreak, t))
              {
               hasLeg = true;
               legIndex = p;
               legPrice = WHigh[p];
              }
            if(current == STATE_TURN_DOWN && p > turnStart && WHigh[p] < turnLimit)
              {
               hasCounter = true;
               counterIndex = p;
               counterBreak = MinLow(turnStart, p);
              }
           }
         if(WLow[p] < MinLow(p - side, p - 1) && WLow[p] <= MinLow(p + 1, p + side))
           {
            hasPivotLow = true;
            pivotLowIndex = p;
            pivotLowPrice = WLow[p];
            AddPivot(p, WLow[p], -1);
            if(current == STATE_DOWN && WLow[p] <= MinLow(sinceBreak, t))
              {
               hasLeg = true;
               legIndex = p;
               legPrice = WLow[p];
              }
            if(current == STATE_TURN_UP && p > turnStart && WLow[p] > turnLimit)
              {
               hasCounter = true;
               counterIndex = p;
               counterBreak = MaxHigh(turnStart, p);
              }
           }
        }

      int    startDirection = 0, startOrigin = 0, startKind = 0;
      double closePrice = WClose[t];

      if(current == STATE_NONE)
        {
         if(hasPivotHigh && closePrice > pivotHighPrice)
           {
            startDirection = 1;
            startOrigin = pivotHighIndex;
            startKind = EV_START_UP;
           }
         else if(hasPivotLow && closePrice < pivotLowPrice)
           {
            startDirection = -1;
            startOrigin = pivotLowIndex;
            startKind = EV_START_DOWN;
           }
        }
      else if(current == STATE_UP)
        {
         if(closePrice < guard)
           {
            int topIndex = ArgMaxHigh(sinceBreak, t);
            turnLimit = WHigh[topIndex];
            turnStart = topIndex;
            current = STATE_TURN_DOWN;
            hasCounter = false;
            AddEvent(t, EV_CHOCH_DOWN, guard, -1);
            guard = turnLimit;
            CloseLine(activeLine, t);
           }
         else if(hasLeg && closePrice > legPrice)
           {
            int newIndex = ArgMinLow(legIndex, t);
            double newGuard = WLow[newIndex];
            int weak = LegWeakness(MathAbs(legPrice - guard), MathAbs(legPrice - newGuard),
                                   MathMax(legIndex - sinceBreak, 1), hasPrevLeg, prevImpulse, prevDepth, prevSpeed);
            hasPrevLeg = true;
            NewLine(activeLine, t, 1, guardIndex, guard, newIndex, newGuard);
            guard = newGuard;
            guardIndex = newIndex;
            sinceBreak = t;
            AddEvent(t, EV_BOS_UP, legPrice, weak);
            hasLeg = false;
           }
        }
      else if(current == STATE_DOWN)
        {
         if(closePrice > guard)
           {
            int bottomIndex = ArgMinLow(sinceBreak, t);
            turnLimit = WLow[bottomIndex];
            turnStart = bottomIndex;
            current = STATE_TURN_UP;
            hasCounter = false;
            AddEvent(t, EV_CHOCH_UP, guard, -1);
            guard = turnLimit;
            CloseLine(activeLine, t);
           }
         else if(hasLeg && closePrice < legPrice)
           {
            int newIndex = ArgMaxHigh(legIndex, t);
            double newGuard = WHigh[newIndex];
            int weak = LegWeakness(MathAbs(legPrice - guard), MathAbs(legPrice - newGuard),
                                   MathMax(legIndex - sinceBreak, 1), hasPrevLeg, prevImpulse, prevDepth, prevSpeed);
            hasPrevLeg = true;
            NewLine(activeLine, t, -1, guardIndex, guard, newIndex, newGuard);
            guard = newGuard;
            guardIndex = newIndex;
            sinceBreak = t;
            AddEvent(t, EV_BOS_DOWN, legPrice, weak);
            hasLeg = false;
           }
        }
      else if(current == STATE_TURN_DOWN)
        {
         if(closePrice > turnLimit)
           {
            startDirection = 1;
            startOrigin = turnStart;
            startKind = EV_FAILED_TURN_UP;
           }
         else if(hasCounter && closePrice < counterBreak)
           {
            startDirection = -1;
            startOrigin = counterIndex;
            startKind = EV_CONFIRM_DOWN;
           }
        }
      else if(current == STATE_TURN_UP)
        {
         if(closePrice < turnLimit)
           {
            startDirection = -1;
            startOrigin = turnStart;
            startKind = EV_FAILED_TURN_DOWN;
           }
         else if(hasCounter && closePrice > counterBreak)
           {
            startDirection = 1;
            startOrigin = counterIndex;
            startKind = EV_CONFIRM_UP;
           }
        }

      if(startDirection != 0)
        {
         current = (startDirection == 1) ? STATE_UP : STATE_DOWN;
         guardIndex = (startDirection == 1) ? ArgMinLow(startOrigin, t) : ArgMaxHigh(startOrigin, t);
         guard = (startDirection == 1) ? WLow[guardIndex] : WHigh[guardIndex];
         sinceBreak = t;
         hasLeg = false;
         hasPrevLeg = false;
         CloseLine(activeLine, t);
         AddEvent(t, startKind, guard, -1);
        }

      WState[t] = current;
      WGuard[t] = guard;

      // Trend line break: a close beyond the line, reported once per line
      if(activeLine >= 0 && !LnBroken[activeLine] && t > LnStart[activeLine])
        {
         double lineValue = LnPrice[activeLine] + LnSlope[activeLine] * (t - LnFrom[activeLine]);
         if((closePrice - lineValue) * LnDirection[activeLine] < 0)
           {
            LnBroken[activeLine] = true;
            AddEvent(t, LnDirection[activeLine] == 1 ? EV_TL_BREAK_DOWN : EV_TL_BREAK_UP, lineValue, -1);
           }
        }

      // Range between the two levels that decide the next structure event
      bool   boxDefined = true;
      double lower = 0, upper = 0;
      int    anchor = 0;
      if(current == STATE_UP && hasLeg)
        { lower = guard; upper = legPrice; anchor = legIndex; }
      else if(current == STATE_DOWN && hasLeg)
        { lower = legPrice; upper = guard; anchor = legIndex; }
      else if(current == STATE_TURN_DOWN && hasCounter)
        { lower = counterBreak; upper = turnLimit; anchor = turnStart; }
      else if(current == STATE_TURN_UP && hasCounter)
        { lower = turnLimit; upper = counterBreak; anchor = turnStart; }
      else
         boxDefined = false;

      bool rangeActive = false;
      if(boxDefined)
        {
         int highs = 0, lows = 0;
         for(int k = MathMax(0, PvCount - 60); k < PvCount; k++)
            if(PvIndex[k] >= anchor && PvPrice[k] >= lower && PvPrice[k] <= upper)
              {
               if(PvKind[k] == 1) highs++;
               else lows++;
              }
         rangeActive = (highs >= InpRangeTouches && lows >= InpRangeTouches);
        }
      if(rangeActive)
        {
         if(openRange < 0 || RgStart[openRange] != anchor || RgLow[openRange] != lower || RgHigh[openRange] != upper)
           {
            if(openRange >= 0)
               RgEnd[openRange] = t;
            openRange = AddRange(anchor, lower, upper);
           }
        }
      else if(openRange >= 0)
        {
         RgEnd[openRange] = t;
         openRange = -1;
        }
      if(t == count - 1)
        {
         LastRangeOn = rangeActive;
         LastRangeLow = lower;
         LastRangeHigh = upper;
         LastRangeBars = t - anchor;
         LastBoxDefined = boxDefined && upper > lower;
         if(LastBoxDefined)
           {
            LastPosition = (closePrice - lower) / (upper - lower);
            // Edge sweeps of the last 12 candles: a wick outside with the close back inside
            for(int k = MathMax(anchor, t - 11); k <= t; k++)
              {
               if(WHigh[k] > upper && WClose[k] <= upper) LastSweep = 1;
               if(WLow[k] < lower && WClose[k] >= lower)  LastSweep = -1;
              }
           }
         if(ImpulseCount >= 5 && (current == STATE_UP || current == STATE_DOWN))
           {
            double sorted[];
            ArrayResize(sorted, ImpulseCount);
            ArrayCopy(sorted, Impulses, 0, 0, ImpulseCount);
            ArraySort(sorted);
            double median = sorted[ImpulseCount / 2];
            double leg = (current == STATE_UP) ? MaxHigh(sinceBreak, t) - guard : guard - MinLow(sinceBreak, t);
            if(median > 0)
               LastLegRatio = leg / median;
           }
        }
     }
   return(true);
  }

//+------------------------------------------------------------------+
//| Trend health at a BOS: counts the weakness signs (0-3) against   |
//| the previous leg: shorter impulse, deeper correction, slower.    |
//| Returns -1 for the first leg of a trend.                         |
//+------------------------------------------------------------------+
int LegWeakness(double impulse, double correction, int bars, bool hasPrev,
                double &prevImpulse, double &prevDepth, double &prevSpeed)
  {
   if(ImpulseCount >= ArraySize(Impulses))
      ArrayResize(Impulses, ImpulseCount + 128);
   Impulses[ImpulseCount++] = impulse;
   double depth = (impulse > 0) ? correction / impulse : 0;
   double speed = impulse / bars;
   int weak = -1;
   if(hasPrev)
      weak = (impulse < prevImpulse ? 1 : 0) + (depth > prevDepth ? 1 : 0) + (speed < prevSpeed ? 1 : 0);
   prevImpulse = impulse;
   prevDepth = depth;
   prevSpeed = speed;
   return(weak);
  }

//+------------------------------------------------------------------+
void AddPivot(int index, double price, int kind)
  {
   if(PvCount >= ArraySize(PvIndex))
     {
      int newSize = PvCount + 512;
      ArrayResize(PvIndex, newSize);
      ArrayResize(PvKind, newSize);
      ArrayResize(PvPrice, newSize);
     }
   PvIndex[PvCount] = index;
   PvPrice[PvCount] = price;
   PvKind[PvCount] = kind;
   PvCount++;
  }

//+------------------------------------------------------------------+
int AddRange(int start, double lower, double upper)
  {
   if(RgCount >= ArraySize(RgStart))
     {
      int newSize = RgCount + 128;
      ArrayResize(RgStart, newSize);
      ArrayResize(RgEnd, newSize);
      ArrayResize(RgLow, newSize);
      ArrayResize(RgHigh, newSize);
     }
   RgStart[RgCount] = start;
   RgEnd[RgCount] = -1;
   RgLow[RgCount] = lower;
   RgHigh[RgCount] = upper;
   RgCount++;
   return(RgCount - 1);
  }

//+------------------------------------------------------------------+
void CloseLine(int &activeLine, int t)
  {
   if(activeLine >= 0 && LnEnd[activeLine] < 0)
      LnEnd[activeLine] = t;
   activeLine = -1;
  }

//+------------------------------------------------------------------+
//| Line through two protected points, kept only when it slopes with |
//| the trend. The channel offset is the largest excursion between.  |
//+------------------------------------------------------------------+
void NewLine(int &activeLine, int t, int direction, int fromIndex, double fromPrice, int toIndex, double toPrice)
  {
   CloseLine(activeLine, t);
   if(toIndex <= fromIndex || (toPrice - fromPrice) * direction <= 0)
      return;
   if(LnCount >= ArraySize(LnFrom))
     {
      int newSize = LnCount + 128;
      ArrayResize(LnFrom, newSize);
      ArrayResize(LnStart, newSize);
      ArrayResize(LnEnd, newSize);
      ArrayResize(LnDirection, newSize);
      ArrayResize(LnPrice, newSize);
      ArrayResize(LnSlope, newSize);
      ArrayResize(LnOffset, newSize);
      ArrayResize(LnBroken, newSize);
     }
   double slope = (toPrice - fromPrice) / (toIndex - fromIndex);
   double offset = 0;
   for(int i = fromIndex; i <= toIndex; i++)
     {
      double base = fromPrice + slope * (i - fromIndex);
      double distance = (direction == 1) ? WHigh[i] - base : WLow[i] - base;
      if(i == fromIndex || (direction == 1 && distance > offset) || (direction == -1 && distance < offset))
         offset = distance;
     }
   LnFrom[LnCount] = fromIndex;
   LnPrice[LnCount] = fromPrice;
   LnSlope[LnCount] = slope;
   LnOffset[LnCount] = offset;
   LnDirection[LnCount] = direction;
   LnStart[LnCount] = t;
   LnEnd[LnCount] = -1;
   LnBroken[LnCount] = false;
   activeLine = LnCount;
   LnCount++;
  }

//+------------------------------------------------------------------+
void AddEvent(int index, int kind, double level, int weak)
  {
   if(EvCount >= ArraySize(EvIndex))
     {
      int newSize = EvCount + 256;
      ArrayResize(EvIndex, newSize);
      ArrayResize(EvKind, newSize);
      ArrayResize(EvWeak, newSize);
      ArrayResize(EvLevel, newSize);
     }
   EvIndex[EvCount] = index;
   EvKind[EvCount] = kind;
   EvLevel[EvCount] = level;
   EvWeak[EvCount] = weak;
   EvCount++;
  }

//+------------------------------------------------------------------+
double MaxHigh(int from, int to)
  {
   double value = WHigh[from];
   for(int i = from + 1; i <= to; i++)
      if(WHigh[i] > value)
         value = WHigh[i];
   return(value);
  }

double MinLow(int from, int to)
  {
   double value = WLow[from];
   for(int i = from + 1; i <= to; i++)
      if(WLow[i] < value)
         value = WLow[i];
   return(value);
  }

// First index of the extreme, like numpy argmax / argmin
int ArgMaxHigh(int from, int to)
  {
   int best = from;
   for(int i = from + 1; i <= to; i++)
      if(WHigh[i] > WHigh[best])
         best = i;
   return(best);
  }

int ArgMinLow(int from, int to)
  {
   int best = from;
   for(int i = from + 1; i <= to; i++)
      if(WLow[i] < WLow[best])
         best = i;
   return(best);
  }

//+------------------------------------------------------------------+
int LastState()
  {
   int count = ArraySize(WState);
   return(count > 0 ? WState[count - 1] : STATE_NONE);
  }

//+------------------------------------------------------------------+
string Summary(int timeframe)
  {
   int count = ArraySize(WState);
   if(count == 0)
      return(TfName(timeframe) + "  no data");
   int    state = WState[count - 1];
   double guard = WGuard[count - 1];
   string text = StringFormat("%-3s %-9s", TfName(timeframe), StateName(state));
   if(state != STATE_NONE)
     {
      double pips = (WClose[count - 1] - guard) / PipSize();
      text += StringFormat(" %s %s %+5.0fp", GuardShort(state), DoubleToString(guard, Digits), pips);
     }
   for(int e = EvCount - 1; e >= 0; e--)
     {
      if(EvKind[e] == EV_TL_BREAK_UP || EvKind[e] == EV_TL_BREAK_DOWN)
         continue;
      text += "  " + EventLabel(EvKind[e], EvWeak[e]) + " " + StringSubstr(TimeToString(WTime[EvIndex[e]], TIME_DATE), 5);
      break;
     }
   text += "  " + MomentumName(timeframe);
   if(LastBoxDefined)
      text += StringFormat("  pos %3.0f%%", 100 * MathMax(0, MathMin(1, LastPosition)));
   if(LastLegRatio > 0)
      text += StringFormat("  leg %.1fx", LastLegRatio);
   if(LastRangeOn)
      text += StringFormat("  RANGE %db", LastRangeBars);
   if(LastSweep != 0)
      text += (LastSweep > 0) ? " swept-high" : " swept-low";
   return(text);
  }

//+------------------------------------------------------------------+
void DrawChartTimeframe()
  {
   int count = ArraySize(WState);
   ArrayInitialize(GuardUp, EMPTY_VALUE);
   ArrayInitialize(GuardDown, EMPTY_VALUE);
   ArrayInitialize(GuardTurnDown, EMPTY_VALUE);
   ArrayInitialize(GuardTurnUp, EMPTY_VALUE);

   // Chronological index j of the closed candles maps to chart shift count - j
   for(int j = 0; j < count && LayerOn(LAYER_TREND); j++)
     {
      int shift = count - j;
      if(shift >= Bars || WGuard[j] == EMPTY_VALUE)
         continue;
      switch(WState[j])
        {
         case STATE_UP:        GuardUp[shift] = WGuard[j];       break;
         case STATE_DOWN:      GuardDown[shift] = WGuard[j];     break;
         case STATE_TURN_DOWN: GuardTurnDown[shift] = WGuard[j]; break;
         case STATE_TURN_UP:   GuardTurnUp[shift] = WGuard[j];   break;
        }
     }

   if(InpMaxRanges > 0 && LayerOn(LAYER_RANGE))
      for(int r = MathMax(0, RgCount - InpMaxRanges); r < RgCount; r++)
        {
         int last = (RgEnd[r] >= 0) ? RgEnd[r] : count - 1;
         string name = Prefix + "rg_" + IntegerToString(r);
         ObjectCreate(0, name, OBJ_RECTANGLE, 0, WTime[RgStart[r]], RgHigh[r], WTime[last], RgLow[r]);
         ObjectSetInteger(0, name, OBJPROP_COLOR, InpRangeColor);
         ObjectSetInteger(0, name, OBJPROP_BACK, true);
         ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
        }

   if(InpMaxLines > 0 && LayerOn(LAYER_LINES))
      for(int n = MathMax(0, LnCount - InpMaxLines); n < LnCount; n++)
        {
         bool active = (LnEnd[n] < 0);
         int  last = active ? count - 1 : LnEnd[n];
         double startPrice = LnPrice[n];
         double endPrice = LnPrice[n] + LnSlope[n] * (last - LnFrom[n]);
         for(int part = 0; part < 2; part++)
           {
            double shiftPrice = (part == 0) ? 0 : LnOffset[n];
            string name = Prefix + (part == 0 ? "tl_" : "ch_") + IntegerToString(n);
            ObjectCreate(0, name, OBJ_TREND, 0, WTime[LnFrom[n]], startPrice + shiftPrice, WTime[last], endPrice + shiftPrice);
            ObjectSetInteger(0, name, OBJPROP_COLOR, InpLineColor);
            ObjectSetInteger(0, name, OBJPROP_STYLE, part == 0 ? STYLE_SOLID : STYLE_DOT);
            ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
            ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, active);
            ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
           }
        }

   if(InpLabelCount <= 0 || !LayerOn(LAYER_EVENTS))
      return;
   double offset = 12 * Point * MathMax(1, Period() / 15);
   for(int e = MathMax(0, EvCount - InpLabelCount); e < EvCount; e++)
     {
      int  j = EvIndex[e];
      bool up = EventIsUp(EvKind[e]);
      string name = Prefix + "ev_" + IntegerToString(e);
      double price = up ? WHigh[j] + offset : WLow[j] - offset;
      ObjectCreate(0, name, OBJ_TEXT, 0, WTime[j], price);
      ObjectSetString(0, name, OBJPROP_TEXT, EventLabel(EvKind[e], EvWeak[e]));
      ObjectSetString(0, name, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 8);
      ObjectSetInteger(0, name, OBJPROP_COLOR, up ? clrLimeGreen : clrTomato);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, up ? ANCHOR_LOWER : ANCHOR_UPPER);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
     }
  }

//+------------------------------------------------------------------+
void DrawHtfLevel(int timeframe)
  {
   int count = ArraySize(WState);
   if(count == 0 || WState[count - 1] == STATE_NONE)
      return;
   int    state = WState[count - 1];
   double guard = WGuard[count - 1];

   // The level starts where it took its current value
   int from = count - 1;
   while(from > 0 && WGuard[from - 1] == guard && WState[from - 1] == state)
      from--;

   color lineColor = (state == STATE_UP) ? clrLimeGreen : (state == STATE_DOWN) ? clrTomato :
                     (state == STATE_TURN_DOWN) ? clrGold : clrDeepSkyBlue;
   string name = Prefix + "htf_" + TfName(timeframe);
   ObjectCreate(0, name, OBJ_TREND, 0, WTime[from], guard, Time[0], guard);
   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DASH);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);

   string label = name + "_txt";
   ObjectCreate(0, label, OBJ_TEXT, 0, Time[0], guard);
   ObjectSetString(0, label, OBJPROP_TEXT, TfName(timeframe) + " " + GuardShort(state));
   ObjectSetString(0, label, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, label, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, label, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, label, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);
   ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
  }

//+------------------------------------------------------------------+
//| Liquidity zones of one timeframe; the live ones nearest to price |
//| are appended to the draw list.                                   |
//+------------------------------------------------------------------+
bool BuildLps(int timeframe, int maxAge)
  {
   int total = iBars(Symbol(), timeframe);
   int warmup = InpLpBuildBars + InpLpSmoothBars + 5;
   if(total < warmup + 5)
      return(false);
   int count = MathMin(total - 1, maxAge + warmup);
   ArraySetAsSeries(QHigh, false);
   ArraySetAsSeries(QLow, false);
   ArraySetAsSeries(QOpen, false);
   ArraySetAsSeries(QClose, false);
   ArraySetAsSeries(QVolume, false);
   ArraySetAsSeries(QTime, false);
   if(CopyHigh(Symbol(), timeframe, 1, count, QHigh) != count || CopyLow(Symbol(), timeframe, 1, count, QLow) != count ||
      CopyOpen(Symbol(), timeframe, 1, count, QOpen) != count || CopyClose(Symbol(), timeframe, 1, count, QClose) != count ||
      CopyTickVolume(Symbol(), timeframe, 1, count, QVolume) != count || CopyTime(Symbol(), timeframe, 1, count, QTime) != count)
      return(false);

   double zHigh[], zLow[];
   int    zFrom[], zDirection[], zBreak[];
   bool   zDead[], zMain[];
   int    zones = 0;
   double wick = InpLpWickPips * PipSize();
   double candleOpen = (QOpen[0] + QClose[0]) / 2.0, candleClose = candleOpen;

   for(int i = 1; i < count; i++)
     {
      // Smoothed candle, same formula as NeoCandles / ZOS
      double sum = 0;
      int    used = 0;
      for(int k = i; k > i - InpLpSmoothBars && k >= 0; k--)
        {
         sum += (QOpen[k] + QHigh[k] + QLow[k] + QClose[k]) / 4.0;
         used++;
        }
      candleOpen = (candleOpen + candleClose) / 2.0;
      candleClose = sum / used;
      if(i < warmup)
         continue;
      double top = MathMax(QHigh[i], MathMax(candleOpen, candleClose));
      double bottom = MathMin(QLow[i], MathMin(candleOpen, candleClose));
      bool   active = LpIsActive(i);
      bool   extended = false;

      for(int z = 0; z < zones; z++)
        {
         if(zDead[z])
            continue;
         if(zDirection[z] == 0)
           {
            if(candleClose > zHigh[z])
              { zDirection[z] = 1; zBreak[z] = i; }
            else if(candleClose < zLow[z])
              { zDirection[z] = -1; zBreak[z] = i; }
            else if(active && ((bottom <= zHigh[z] && zHigh[z] <= top) || (bottom <= zLow[z] && zLow[z] <= top)))
              {
               zHigh[z] = MathMax(zHigh[z], top);
               zLow[z] = MathMin(zLow[z], bottom);
               extended = true;
              }
           }
         else if((zDirection[z] == 1 && candleClose < zLow[z]) || (zDirection[z] == -1 && candleClose > zHigh[z]))
           {
            zDead[z] = true;
            // The latest live LP of the side that did the clearing becomes the Main of that side
            int winner = -zDirection[z], best = -1;
            for(int m = 0; m < zones; m++)
               if(!zDead[m] && zDirection[m] == winner && (best < 0 || zFrom[m] > zFrom[best]))
                  best = m;
            if(best >= 0)
              {
               for(int m = 0; m < zones; m++)
                  if(zDirection[m] == winner)
                     zMain[m] = false;
               zMain[best] = true;
              }
           }
        }

      if(active && !extended && top - MathMax(candleOpen, candleClose) >= wick && MathMin(candleOpen, candleClose) - bottom >= wick)
        {
         int size = zones + 1;
         ArrayResize(zHigh, size);
         ArrayResize(zLow, size);
         ArrayResize(zFrom, size);
         ArrayResize(zDirection, size);
         ArrayResize(zBreak, size);
         ArrayResize(zDead, size);
         ArrayResize(zMain, size);
         zHigh[zones] = top;
         zLow[zones] = bottom;
         zFrom[zones] = i;
         zDirection[zones] = 0;
         zBreak[zones] = -1;
         zDead[zones] = false;
         zMain[zones] = false;
         zones++;
        }
     }

   // Keep the Mains, the zones holding price and the nearest ones on each side
   double price = Close[0];
   bool   taken[];
   ArrayResize(taken, zones);
   ArrayInitialize(taken, false);
   int above = 0, below = 0;
   for(int pass = 0; pass < zones; pass++)
     {
      int best = -1;
      double bestDistance = 0;
      for(int z = 0; z < zones; z++)
        {
         if(taken[z] || zDead[z])
            continue;
         double distance = (price > zHigh[z]) ? price - zHigh[z] : (price < zLow[z]) ? zLow[z] - price : 0;
         if(best < 0 || distance < bestDistance)
           {
            best = z;
            bestDistance = distance;
           }
        }
      if(best < 0)
         break;
      taken[best] = true;
      if(!zMain[best])
        {
         if(price < zLow[best] && above++ >= InpLpPerSide) continue;
         if(price > zHigh[best] && below++ >= InpLpPerSide) continue;
        }
      bool shield = false;
      if(!zMain[best] && zDirection[best] != 0)
         for(int m = 0; m < zones; m++)
            if(!zDead[m] && zMain[m] && zDirection[m] == zDirection[best] && zFrom[m] < zFrom[best])
               shield = true;

      int size = LpCount + 1;
      ArrayResize(LpTf, size);
      ArrayResize(LpDirection, size);
      ArrayResize(LpHigh, size);
      ArrayResize(LpLow, size);
      ArrayResize(LpFrom, size);
      ArrayResize(LpMain, size);
      ArrayResize(LpShield, size);
      LpTf[LpCount] = timeframe;
      LpDirection[LpCount] = zDirection[best];
      LpHigh[LpCount] = zHigh[best];
      LpLow[LpCount] = zLow[best];
      LpFrom[LpCount] = QTime[zFrom[best]];
      LpMain[LpCount] = zMain[best];
      LpShield[LpCount] = shield;
      LpCount++;
     }
   return(true);
  }

//+------------------------------------------------------------------+
//| Build candle (same rule as NC): activity above each of the       |
//| previous InpLpBuildBars candles and a close against the          |
//| direction of the candle before it.                               |
//+------------------------------------------------------------------+
bool LpIsActive(int index)
  {
   bool up = QClose[index] > QOpen[index], down = QClose[index] < QOpen[index];
   bool previousUp = QClose[index - 1] > QOpen[index - 1], previousDown = QClose[index - 1] < QOpen[index - 1];
   if(!((up && previousDown) || (down && previousUp)))
      return(false);
   double activity = (double)QVolume[index] * (QHigh[index] - QLow[index]);
   for(int k = index - InpLpBuildBars; k < index; k++)
      if((double)QVolume[k] * (QHigh[k] - QLow[k]) >= activity)
         return(false);
   return(true);
  }

//+------------------------------------------------------------------+
//| H4 and above: two lines (High, Low) coloured by timeframe, solid |
//| for a GLP, dashed for an RLP, dotted while unbroken, thick for a |
//| Main. Below H4: a box, filled once the LP is broken.             |
//+------------------------------------------------------------------+
void DrawLps()
  {
   datetime rightEdge = Time[0] + PeriodSeconds() * 12;
   for(int i = 0; i < LpCount; i++)
     {
      int direction = LpDirection[i];
      string kind = (direction > 0) ? (LpMain[i] ? "MGLP" : "GLP") : (direction < 0) ? (LpMain[i] ? "MRLP" : "RLP") : "LP";
      string role = LpMain[i] ? "MAIN" : LpShield[i] ? "shield" : (direction == 0) ? "unbroken" : "";
      string label = kind + "-" + TfName(LpTf[i]) + " " + StringSubstr(TimeToString(LpFrom[i], TIME_DATE), 5) +
                     (role != "" ? " [" + role + "]" : "");
      datetime from = (LpFrom[i] > Time[Bars - 1]) ? LpFrom[i] : Time[Bars - 1];
      string base = Prefix + "lp_" + IntegerToString(LpTf[i]) + "_" + IntegerToString((long)LpFrom[i]);

      if(LpTf[i] < PERIOD_H4)
        {
         ObjectCreate(0, base, OBJ_RECTANGLE, 0, from, LpHigh[i], rightEdge, LpLow[i]);
         ObjectSetInteger(0, base, OBJPROP_COLOR, direction > 0 ? InpLpBoxGlp : direction < 0 ? InpLpBoxRlp : InpLpBoxFresh);
         ObjectSetInteger(0, base, OBJPROP_BACK, direction != 0);
         ObjectSetInteger(0, base, OBJPROP_WIDTH, LpMain[i] ? 3 : 1);
         ObjectSetInteger(0, base, OBJPROP_SELECTABLE, false);
         string text = base + "_t";
         ObjectCreate(0, text, OBJ_TEXT, 0, rightEdge, LpHigh[i]);
         ObjectSetString(0, text, OBJPROP_TEXT, label);
         ObjectSetString(0, text, OBJPROP_FONT, "Arial");
         ObjectSetInteger(0, text, OBJPROP_FONTSIZE, 7);
         ObjectSetInteger(0, text, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);
         ObjectSetInteger(0, text, OBJPROP_COLOR, LpMain[i] ? clrWhite : clrSilver);
         ObjectSetInteger(0, text, OBJPROP_SELECTABLE, false);
         continue;
        }

      color lineColor = (LpTf[i] == PERIOD_H4) ? InpLpColorH4 : (LpTf[i] == PERIOD_D1) ? InpLpColorD1 : InpLpColorW1;
      int style = (direction > 0) ? STYLE_SOLID : (direction < 0) ? STYLE_DASH : STYLE_DOT;
      for(int edge = 0; edge < 2; edge++)
        {
         double price = (edge == 0) ? LpHigh[i] : LpLow[i];
         string name = base + (edge == 0 ? "_h" : "_l");
         ObjectCreate(0, name, OBJ_TREND, 0, from, price, rightEdge, price);
         ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
         ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
         ObjectSetInteger(0, name, OBJPROP_STYLE, style);
         ObjectSetInteger(0, name, OBJPROP_WIDTH, (LpMain[i] && style == STYLE_SOLID) ? 2 : 1);
         ObjectSetInteger(0, name, OBJPROP_BACK, true);
         ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, name, OBJPROP_TOOLTIP, (edge == 0 ? "High " : "Low ") + label + " " + DoubleToString(price, Digits));
         string text = name + "t";
         ObjectCreate(0, text, OBJ_TEXT, 0, rightEdge, price);
         ObjectSetString(0, text, OBJPROP_TEXT, (edge == 0 ? "H " : "L ") + label);
         ObjectSetString(0, text, OBJPROP_FONT, "Arial");
         ObjectSetInteger(0, text, OBJPROP_FONTSIZE, 7);
         ObjectSetInteger(0, text, OBJPROP_ANCHOR, edge == 0 ? ANCHOR_RIGHT_LOWER : ANCHOR_RIGHT_UPPER);
         ObjectSetInteger(0, text, OBJPROP_COLOR, lineColor);
         ObjectSetInteger(0, text, OBJPROP_SELECTABLE, false);
        }
     }
  }

//+------------------------------------------------------------------+
//| Unbroken pivots of the timeframe just analysed: no later candle  |
//| (including the forming one) has traded beyond them, so highs sit |
//| above price and lows below. Nearest ones first.                  |
//+------------------------------------------------------------------+
void CollectSwings(int timeframe, int maxAge)
  {
   int count = ArraySize(WHigh), side = InpPivotSide;
   double runHigh = iHigh(Symbol(), timeframe, 0), runLow = iLow(Symbol(), timeframe, 0);
   int foundHigh = 0, foundLow = 0;
   for(int p = count - 1; p >= side && p >= count - maxAge; p--)
     {
      if(p <= count - 1 - side)
        {
         bool pivotHigh = true, pivotLow = true;
         for(int k = 1; k <= side; k++)
           {
            if(WHigh[p] <= WHigh[p - k] || WHigh[p] < WHigh[p + k]) pivotHigh = false;
            if(WLow[p] >= WLow[p - k] || WLow[p] > WLow[p + k])     pivotLow = false;
           }
         if(pivotHigh && runHigh <= WHigh[p] && foundHigh < InpSwingsPerSide)
           {
            AddLevel(WHigh[p], TfName(timeframe) + " high", InpSwingHighColor, WTime[p], FAMILY_SWING);
            foundHigh++;
           }
         if(pivotLow && runLow >= WLow[p] && foundLow < InpSwingsPerSide)
           {
            AddLevel(WLow[p], TfName(timeframe) + " low", InpSwingLowColor, WTime[p], FAMILY_SWING);
            foundLow++;
           }
        }
      runHigh = MathMax(runHigh, WHigh[p]);
      runLow = MathMin(runLow, WLow[p]);
      if(foundHigh >= InpSwingsPerSide && foundLow >= InpSwingsPerSide)
         break;
     }
  }

//+------------------------------------------------------------------+
void CollectRound()
  {
   double step = 50 * PipSize();
   double base = MathFloor(Close[0] / step) * step;
   for(int k = -1; k <= 2; k++)
     {
      double level = NormalizeDouble(base + k * step, Digits);
      bool whole = MathAbs(MathMod(level / PipSize() + 0.5, 100) - 0.5) < 0.01;
      AddLevel(level, whole ? "00" : "50", InpRoundColor, 0, FAMILY_ROUND);
     }
  }

//+------------------------------------------------------------------+
void CollectPrev()
  {
   AddLevel(iHigh(Symbol(), PERIOD_D1, 1), "PDH", InpPrevColor, iTime(Symbol(), PERIOD_D1, 1), FAMILY_PREV);
   AddLevel(iLow(Symbol(), PERIOD_D1, 1), "PDL", InpPrevColor, iTime(Symbol(), PERIOD_D1, 1), FAMILY_PREV);
   AddLevel(iHigh(Symbol(), PERIOD_W1, 1), "PWH", InpPrevColor, iTime(Symbol(), PERIOD_W1, 1), FAMILY_PREV);
   AddLevel(iLow(Symbol(), PERIOD_W1, 1), "PWL", InpPrevColor, iTime(Symbol(), PERIOD_W1, 1), FAMILY_PREV);
  }

//+------------------------------------------------------------------+
void AddLevel(double price, string text, color lineColor, datetime from, int family)
  {
   if(price <= 0)
      return;
   int size = LvCount + 1;
   ArrayResize(LvPrice, size);
   ArrayResize(LvText, size);
   ArrayResize(LvColor, size);
   ArrayResize(LvFrom, size);
   ArrayResize(LvFamily, size);
   LvPrice[LvCount] = price;
   LvText[LvCount] = text;
   LvColor[LvCount] = lineColor;
   LvFrom[LvCount] = from;
   LvFamily[LvCount] = family;
   LvCount++;
  }

//+------------------------------------------------------------------+
//| Thin lines for the plain levels; thick when a level of another   |
//| kind or the edge of a drawn LP lies within InpConfluencePips.    |
//+------------------------------------------------------------------+
void DrawLevels()
  {
   double tolerance = InpConfluencePips * PipSize();
   datetime leftEdge = Time[MathMin(Bars - 1, 60)];
   bool lpDrawn = LayerOn(LAYER_LP);
   for(int i = 0; i < LvCount; i++)
     {
      bool confluence = false;
      for(int j = 0; j < LvCount && !confluence; j++)
         if(j != i && LvFamily[j] != LvFamily[i] && MathAbs(LvPrice[j] - LvPrice[i]) <= tolerance)
            confluence = true;
      for(int z = 0; z < LpCount && lpDrawn && !confluence; z++)
         if(MathAbs(LpHigh[z] - LvPrice[i]) <= tolerance || MathAbs(LpLow[z] - LvPrice[i]) <= tolerance)
            confluence = true;

      datetime from = (LvFrom[i] > Time[Bars - 1]) ? LvFrom[i] : leftEdge;
      string name = Prefix + "lv_" + IntegerToString(i);
      ObjectCreate(0, name, OBJ_TREND, 0, from, LvPrice[i], Time[0], LvPrice[i]);
      ObjectSetInteger(0, name, OBJPROP_COLOR, LvColor[i]);
      ObjectSetInteger(0, name, OBJPROP_STYLE, (LvFamily[i] == FAMILY_ROUND && !confluence) ? STYLE_DOT : STYLE_SOLID);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, confluence ? 2 : 1);
      ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, true);
      ObjectSetInteger(0, name, OBJPROP_BACK, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);

      string label = name + "_txt";
      ObjectCreate(0, label, OBJ_TEXT, 0, Time[0] + 6 * PeriodSeconds(), LvPrice[i]);
      ObjectSetString(0, label, OBJPROP_TEXT, LvText[i]);
      ObjectSetString(0, label, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, label, OBJPROP_FONTSIZE, 7);
      ObjectSetInteger(0, label, OBJPROP_COLOR, LvColor[i]);
      ObjectSetInteger(0, label, OBJPROP_ANCHOR, ANCHOR_LEFT);
      ObjectSetInteger(0, label, OBJPROP_SELECTABLE, false);
     }
  }

//+------------------------------------------------------------------+
//| Momentum colour of the last closed candle of a timeframe, the    |
//| same measure NC paints: M = EMA50 - EMA200 and its direction.    |
//+------------------------------------------------------------------+
string MomentumName(int timeframe)
  {
   double now = iMA(Symbol(), timeframe, 50, 0, MODE_EMA, PRICE_CLOSE, 1) - iMA(Symbol(), timeframe, 200, 0, MODE_EMA, PRICE_CLOSE, 1);
   double before = iMA(Symbol(), timeframe, 50, 0, MODE_EMA, PRICE_CLOSE, 2) - iMA(Symbol(), timeframe, 200, 0, MODE_EMA, PRICE_CLOSE, 2);
   if(now > 0)
      return(now > before ? "green" : "blue ");
   return(now > before ? "pink " : "red  ");
  }

//+------------------------------------------------------------------+
//| Behaviour marks on the closed candles of the chart timeframe     |
//| (VSA / Wyckoff: false breakout, intent, test). Kept strict so    |
//| only a few candles in a hundred are marked:                      |
//|   S  sweep  - trades beyond the highest high (lowest low) of the |
//|               previous InpSweepBars candles and closes back (at  |
//|               least 75% of the excursion beyond the old extreme  |
//|               is given back); the candle stands out (range >= 1.25 x the |
//|               median) and gives back, from its extreme to its    |
//|               close, >= half a median candle and >= 40% of its   |
//|               own range                                          |
//|   I  intent - range >= 1.5 x the median, body >= 60% of it, close|
//|               beyond the previous 5 candles, volume >= 1.5 x the |
//|               10-candle average                                  |
//|   t  test   - the first quiet candle (narrow, volume below the   |
//|               two before it) that moves back towards a sweep     |
//|               within 12 candles without passing its extreme      |
//+------------------------------------------------------------------+
void DrawMarks()
  {
   int last = MathMin(InpMarkBars, Bars - InpSweepBars - 30);
   double offset = 10 * Point * MathMax(1, Period() / 15);
   int    sweepSide = 0, sweepAge = 0;        // +1 = a high was swept, -1 = a low
   double sweepExtreme = 0, sweepMiddle = 0;

   for(int i = last; i >= 1; i--)
     {
      double range = High[i] - Low[i];
      double ranges[20];
      double volumeSum = 0;
      for(int k = 1; k <= 20; k++)
         ranges[k - 1] = High[i + k] - Low[i + k];
      for(int k = 1; k <= 10; k++)
         volumeSum += (double)Volume[i + k];
      ArraySort(ranges);
      double median = (ranges[9] + ranges[10]) / 2.0;
      double average = volumeSum / 10.0;
      double body = MathAbs(Close[i] - Open[i]);

      int highest = iHighest(NULL, 0, MODE_HIGH, InpSweepBars, i + 1);
      int lowest = iLowest(NULL, 0, MODE_LOW, InpSweepBars, i + 1);
      // Sweep: beyond the extreme of the previous candles and a close back inside. It is a big one (S)
      // when the candle stands out and gives back a real distance from its extreme to its close.
      // "Closes back" = the close has given back at least InpSweepRecover of the excursion beyond the old
      // extreme, so a close a hair outside the level still counts.
      double overHigh = High[i] - High[highest], underLow = Low[lowest] - Low[i];
      bool   pokedHigh = overHigh > 0 && High[i] - Close[i] >= InpSweepRecover * overHigh;
      bool   pokedLow = underLow > 0 && Close[i] - Low[i] >= InpSweepRecover * underLow;
      double backFromHigh = High[i] - Close[i], backFromLow = Close[i] - Low[i];
      bool   wide = range >= InpSweepRangeMult * median;
      bool sweepHigh = pokedHigh && wide && backFromHigh >= InpSweepRejectMult * median && backFromHigh >= InpSweepWickShare * range;
      bool sweepLow = pokedLow && wide && backFromLow >= InpSweepRejectMult * median && backFromLow >= InpSweepWickShare * range;
      if(InpShowSmallSweeps && pokedHigh && !sweepHigh) Mark(i, "s", true, clrGray, offset);
      if(InpShowSmallSweeps && pokedLow && !sweepLow)   Mark(i, "s", false, clrGray, offset);

      bool strong = range >= 1.5 * median && body >= 0.6 * range && (double)Volume[i] >= 1.5 * average;
      bool intentUp = strong && Close[i] > Open[i] && Close[i] > High[iHighest(NULL, 0, MODE_HIGH, 5, i + 1)];
      bool intentDown = strong && Close[i] < Open[i] && Close[i] < Low[iLowest(NULL, 0, MODE_LOW, 5, i + 1)];

      // Test of the last sweep
      if(sweepSide != 0)
        {
         sweepAge++;
         bool passed = (sweepSide == 1) ? High[i] > sweepExtreme : Low[i] < sweepExtreme;
         bool quiet = range < median && Volume[i] < Volume[i + 1] && Volume[i] < Volume[i + 2];
         bool towards = (sweepSide == 1) ? (Close[i] > Open[i] && Close[i] >= sweepMiddle)
                                         : (Close[i] < Open[i] && Close[i] <= sweepMiddle);
         if(passed || sweepAge > 12)
            sweepSide = 0;
         else if(quiet && towards && !sweepHigh && !sweepLow)
           {
            Mark(i, "t", sweepSide == 1, clrSilver, offset);
            sweepSide = 0;
           }
        }

      if(sweepHigh)
        {
         Mark(i, "S", true, clrWhite, offset);
         sweepSide = 1; sweepAge = 0; sweepExtreme = High[i]; sweepMiddle = (High[i] + Low[i]) / 2.0;
        }
      if(sweepLow)
        {
         Mark(i, "S", false, clrWhite, offset);
         sweepSide = -1; sweepAge = 0; sweepExtreme = Low[i]; sweepMiddle = (High[i] + Low[i]) / 2.0;
        }
      if(intentUp)   Mark(i, "I", false, clrLime, offset);
      if(intentDown) Mark(i, "I", true, clrTomato, offset);
     }
  }

void Mark(int shift, string text, bool above, color textColor, double offset)
  {
   string name = Prefix + "mk_" + IntegerToString((long)Time[shift]) + text + (above ? "a" : "b");
   ObjectCreate(0, name, OBJ_TEXT, 0, Time[shift], above ? High[shift] + offset : Low[shift] - offset);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial");
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 7);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, above ? ANCHOR_LOWER : ANCHOR_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
  }

//+------------------------------------------------------------------+
void AddPanelRow(string text, color textColor)
  {
   if(PanelRows >= ArraySize(PanelText))
     {
      ArrayResize(PanelText, PanelRows + 8);
      ArrayResize(PanelColor, PanelRows + 8);
     }
   PanelText[PanelRows] = text;
   PanelColor[PanelRows] = textColor;
   PanelRows++;
  }

//+------------------------------------------------------------------+
//| Panel in the upper right corner. The header is a button: a click |
//| collapses the panel to one line and hides every drawing.         |
//+------------------------------------------------------------------+
void DrawPanel(bool expanded, string brief)
  {
   int charWidth = 7, rowHeight = 15, padding = 6;
   string header = expanded ? "[-] NEO " + Symbol() : "[+] " + brief;
   int longest = StringLen(header);
   if(expanded)
      for(int r = 0; r < PanelRows; r++)
         longest = MathMax(longest, StringLen(PanelText[r]));
   int buttonWidth = 44;
   int width = longest * charWidth + 2 * padding;
   if(expanded)
      width = MathMax(width, LAYER_COUNT * buttonWidth + 2 * padding);
   int layerRow = expanded ? rowHeight + 5 : 0;
   int height = rowHeight + 4 + layerRow + (expanded ? PanelRows * rowHeight + padding : 0);

   string back = Prefix + "panel_back";
   ObjectCreate(0, back, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, back, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
   ObjectSetInteger(0, back, OBJPROP_XDISTANCE, InpPanelX + width);
   ObjectSetInteger(0, back, OBJPROP_YDISTANCE, InpPanelY);
   ObjectSetInteger(0, back, OBJPROP_XSIZE, width);
   ObjectSetInteger(0, back, OBJPROP_YSIZE, height);
   ObjectSetInteger(0, back, OBJPROP_BGCOLOR, InpPanelBack);
   ObjectSetInteger(0, back, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, back, OBJPROP_COLOR, InpPanelBorder);
   ObjectSetInteger(0, back, OBJPROP_SELECTABLE, false);

   string toggle = Prefix + "toggle";
   ObjectCreate(0, toggle, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, toggle, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
   ObjectSetInteger(0, toggle, OBJPROP_XDISTANCE, InpPanelX + width - 1);
   ObjectSetInteger(0, toggle, OBJPROP_YDISTANCE, InpPanelY + 1);
   ObjectSetInteger(0, toggle, OBJPROP_XSIZE, width - 2);
   ObjectSetInteger(0, toggle, OBJPROP_YSIZE, rowHeight + 2);
   ObjectSetString(0, toggle, OBJPROP_TEXT, header);
   ObjectSetString(0, toggle, OBJPROP_FONT, "Courier New");
   ObjectSetInteger(0, toggle, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, toggle, OBJPROP_COLOR, InpPanelText);
   ObjectSetInteger(0, toggle, OBJPROP_BGCOLOR, C'38,38,54');
   ObjectSetInteger(0, toggle, OBJPROP_BORDER_COLOR, InpPanelBorder);
   ObjectSetInteger(0, toggle, OBJPROP_STATE, false);
   ObjectSetInteger(0, toggle, OBJPROP_SELECTABLE, false);

   if(!expanded)
      return;
   for(int layer = 0; layer < LAYER_COUNT; layer++)
     {
      bool on = LayerOn(layer);
      string button = Prefix + "layer_" + IntegerToString(layer);
      ObjectCreate(0, button, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(0, button, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
      ObjectSetInteger(0, button, OBJPROP_XDISTANCE, InpPanelX + width - padding - layer * buttonWidth);
      ObjectSetInteger(0, button, OBJPROP_YDISTANCE, InpPanelY + rowHeight + 5);
      ObjectSetInteger(0, button, OBJPROP_XSIZE, buttonWidth - 2);
      ObjectSetInteger(0, button, OBJPROP_YSIZE, rowHeight + 1);
      ObjectSetString(0, button, OBJPROP_TEXT, LayerName[layer]);
      ObjectSetString(0, button, OBJPROP_FONT, "Arial");
      ObjectSetInteger(0, button, OBJPROP_FONTSIZE, 7);
      ObjectSetInteger(0, button, OBJPROP_COLOR, on ? clrWhite : C'120,120,135');
      ObjectSetInteger(0, button, OBJPROP_BGCOLOR, on ? C'40,80,60' : C'28,28,38');
      ObjectSetInteger(0, button, OBJPROP_BORDER_COLOR, InpPanelBorder);
      ObjectSetInteger(0, button, OBJPROP_STATE, false);
      ObjectSetInteger(0, button, OBJPROP_SELECTABLE, false);
     }
   for(int r = 0; r < PanelRows; r++)
     {
      string name = Prefix + "panel_" + IntegerToString(r);
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, InpPanelX + width - padding);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, InpPanelY + rowHeight + 6 + layerRow + r * rowHeight);
      ObjectSetString(0, name, OBJPROP_TEXT, PanelText[r]);
      ObjectSetString(0, name, OBJPROP_FONT, "Courier New");
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 8);
      ObjectSetInteger(0, name, OBJPROP_COLOR, PanelColor[r]);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
     }
  }

//+------------------------------------------------------------------+
void WriteEvents()
  {
   string fileName = "NS_" + Symbol() + "_" + TfName(Period()) + ".csv";
   int handle = FileOpen(fileName, FILE_WRITE | FILE_TXT | FILE_ANSI);
   if(handle == INVALID_HANDLE)
      return;
   FileWriteString(handle, "time,event,level,weak\n");
   for(int e = 0; e < EvCount; e++)
      FileWriteString(handle, TimeToString(WTime[EvIndex[e]], TIME_DATE | TIME_MINUTES) + "," +
                      EventName(EvKind[e]) + "," + DoubleToString(EvLevel[e], Digits) + "," +
                      IntegerToString(EvWeak[e]) + "\n");
   FileClose(handle);
  }

//+------------------------------------------------------------------+
double PipSize()
  {
   return((Digits == 3 || Digits == 5) ? 10 * Point : Point);
  }

string TfName(int timeframe)
  {
   switch(timeframe)
     {
      case PERIOD_M1:  return("M1");
      case PERIOD_M5:  return("M5");
      case PERIOD_M15: return("M15");
      case PERIOD_M30: return("M30");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
      case PERIOD_MN1: return("MN1");
     }
   return("TF" + IntegerToString(timeframe));
  }

string StateName(int state)
  {
   switch(state)
     {
      case STATE_UP:        return("UP");
      case STATE_DOWN:      return("DOWN");
      case STATE_TURN_DOWN: return("TURN_DOWN");
      case STATE_TURN_UP:   return("TURN_UP");
     }
   return("NONE");
  }

color StateColor(int state)
  {
   switch(state)
     {
      case STATE_UP:        return(clrLimeGreen);
      case STATE_DOWN:      return(clrTomato);
      case STATE_TURN_DOWN: return(clrGold);
      case STATE_TURN_UP:   return(clrDeepSkyBlue);
     }
   return(InpPanelText);
  }

string StateShort(int state)
  {
   switch(state)
     {
      case STATE_UP:        return("UP");
      case STATE_DOWN:      return("DN");
      case STATE_TURN_DOWN: return("UP>dn?");
      case STATE_TURN_UP:   return("DN>up?");
     }
   return("-");
  }

string GuardShort(int state)
  {
   switch(state)
     {
      case STATE_UP:        return("low ");
      case STATE_DOWN:      return("high");
      case STATE_TURN_DOWN: return("top ");
      case STATE_TURN_UP:   return("bot ");
     }
   return("");
  }

string GuardName(int state)
  {
   switch(state)
     {
      case STATE_UP:        return("protected low");
      case STATE_DOWN:      return("protected high");
      case STATE_TURN_DOWN: return("old top");
      case STATE_TURN_UP:   return("old bottom");
     }
   return("");
  }

string EventName(int kind)
  {
   switch(kind)
     {
      case EV_START_UP:         return("START_UP");
      case EV_START_DOWN:       return("START_DOWN");
      case EV_BOS_UP:           return("BOS_UP");
      case EV_BOS_DOWN:         return("BOS_DOWN");
      case EV_CHOCH_DOWN:       return("CHOCH_DOWN");
      case EV_CHOCH_UP:         return("CHOCH_UP");
      case EV_CONFIRM_UP:       return("CONFIRM_UP");
      case EV_CONFIRM_DOWN:     return("CONFIRM_DOWN");
      case EV_FAILED_TURN_UP:   return("FAILED_TURN_UP");
      case EV_FAILED_TURN_DOWN: return("FAILED_TURN_DOWN");
      case EV_TL_BREAK_UP:      return("TL_BREAK_UP");
      case EV_TL_BREAK_DOWN:    return("TL_BREAK_DOWN");
     }
   return("?");
  }

string EventLabel(int kind, int weak)
  {
   string text = "";
   switch(kind)
     {
      case EV_START_UP:
      case EV_START_DOWN:       text = "START"; break;
      case EV_BOS_UP:
      case EV_BOS_DOWN:         text = "BOS";   break;
      case EV_CHOCH_DOWN:
      case EV_CHOCH_UP:         text = "CHoCH"; break;
      case EV_CONFIRM_UP:
      case EV_CONFIRM_DOWN:     text = "CONF";  break;
      case EV_FAILED_TURN_UP:
      case EV_FAILED_TURN_DOWN: text = "FAIL";  break;
      case EV_TL_BREAK_UP:
      case EV_TL_BREAK_DOWN:    text = "TL";    break;
     }
   if(weak >= 0)
      text += " w" + IntegerToString(weak);
   return(text);
  }

bool EventIsUp(int kind)
  {
   return(kind == EV_START_UP || kind == EV_BOS_UP || kind == EV_CHOCH_UP ||
          kind == EV_CONFIRM_UP || kind == EV_FAILED_TURN_UP || kind == EV_TL_BREAK_UP);
  }
//+------------------------------------------------------------------+

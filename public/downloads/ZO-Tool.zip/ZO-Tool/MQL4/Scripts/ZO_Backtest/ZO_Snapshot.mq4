﻿//+------------------------------------------------------------------+
//| ZO_Snapshot.mq4                                                  |
//| Verification tool: saves what is ON the chart and what the tools |
//| READ from it, at the same moment, so the two can be compared.    |
//|  - <name>.png : a screenshot of this chart (ZOS as the trader    |
//|    sees it, with whatever else is drawn on it);                  |
//|  - <name>.txt : the last closed candles as the tools read them   |
//|    (ZOS open / close, real high / low, colour, Build flag) and   |
//|    the LPs of this timeframe computed by ZoCore.mqh (kind, first |
//|    candle, High, Low, state, retests, Main / Shield), plus the   |
//|    live LPs of the other timeframes from the shared files.       |
//| Files go to MQL4\\Files\\zo_snap\\. Places no orders.             |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_Snapshot - Chup anh chart nay + ghi lai nhung gi tool DOC duoc tu chart (nen ZOS, LP) de doi chieu."
#property description "Chay tren chart co ZOS (M15, H4, D1 ...). File nam trong MQL4/Files/zo_snap."
#property script_show_inputs

#include <ZO/ZoCore.mqh>

input string InpZosName = "ZOS";   // ZOS indicator file name
input int    InpCandles = 60;      // Closed candles listed in the text file
input int    InpWidth   = 1800;    // Screenshot width, pixels
input int    InpHeight  = 900;     // Screenshot height, pixels

string StateEn(int st)
{
   switch(st)
   {
      case ZO_ST_FRESH:   return "not broken";
      case ZO_ST_BROKEN:  return "broken, waiting for retest";
      case ZO_ST_RETEST:  return "in retest";
      case ZO_ST_RUN:     return "retested and left";
      case ZO_ST_FAILED:  return "DEAD (end point cut)";
      case ZO_ST_CLEARED: return "DEAD (cleared)";
   }
   return "?";
}

string ColourEn(int c)
{
   return c == 1 ? "green" : c == 2 ? "blue" : c == -1 ? "red" : c == -2 ? "pink" : c == 9 ? "BUILD" : "none";
}

void OnStart()
{
   g_zoName = InpZosName;
   datetime now = TimeCurrent();
   string base = StringFormat("zo_snap\\%s_%d_%04d%02d%02d_%02d%02d", Symbol(), Period(), TimeYear(now), TimeMonth(now), TimeDay(now),
                              TimeHour(now), TimeMinute(now));
   FolderCreate("zo_snap");
   bool shot = ChartScreenShot(0, base + ".png", InpWidth, InpHeight, ALIGN_RIGHT);

   // The first iCustom call only starts ZOS; its values come a moment later (the first version of this script
   // read at once and got "no ZOS data" for every candle).
   bool ready = false;
   for(int tries = 0; tries < 100 && !ready && !IsStopped(); tries++)
   {
      double wh, wl, wo, wc;
      bool wb;
      ready = ZoReadChart(Period(), 1, wh, wl, wo, wc, wb) && ZoReadColorChart(Period(), 1) != 0;
      if(!ready)
         Sleep(200);
   }
   ZoZone zs[];
   ZoTf d;
   ArrayResize(zs, 0);
   ZoLoadTf(Period(), zs, d, true);
   int h = FileOpen(base + ".txt", FILE_WRITE | FILE_TXT | FILE_ANSI);
   if(h == INVALID_HANDLE)
   {
      Alert("ZO_Snapshot: cannot write ", base, ".txt (err ", GetLastError(), ")");
      return;
   }
   FileWrite(h, StringFormat("symbol %s  timeframe %s  server time %s  bid %s  screenshot %s", Symbol(), ZoTfName(Period()),
                             TimeToString(now, TIME_DATE | TIME_MINUTES), DoubleToString(Bid, Digits), shot ? "ok" : "FAILED"));
   FileWrite(h, ready ? "ZOS read: ok" : "ZOS read: FAILED after 20 s - is the indicator file really named " + InpZosName + "?");
   FileWrite(h, "colour = the ZOS state (green / blue = up regime strong / pull-back, red / pink = down regime strong / pull-back); each state is drawn in a bright shade when the ZOS body goes up and a dark shade when it goes down (see the body column)");
   int first = (int)ChartGetInteger(0, CHART_FIRST_VISIBLE_BAR), vis = (int)ChartGetInteger(0, CHART_VISIBLE_BARS);
   FileWrite(h, StringFormat("visible on the chart: %d candles, from %s to %s; price scale %s .. %s", vis,
                             TimeToString(iTime(Symbol(), Period(), first), TIME_DATE | TIME_MINUTES),
                             TimeToString(iTime(Symbol(), Period(), MathMax(0, first - vis + 1)), TIME_DATE | TIME_MINUTES),
                             DoubleToString(ChartGetDouble(0, CHART_PRICE_MIN), Digits), DoubleToString(ChartGetDouble(0, CHART_PRICE_MAX), Digits)));
   datetime since;
   int main = ZoMainTrend(zs, Period(), since);
   FileWrite(h, StringFormat("Main trend of this timeframe: %s (since %s)", main > 0 ? "UP" : main < 0 ? "DOWN" : "none",
                             since > 0 ? TimeToString(since, TIME_DATE | TIME_MINUTES) : "-"));
   FileWrite(h, "");
   FileWrite(h, "CANDLES (newest first; shift 1 = last closed)");
   FileWrite(h, "shift | time | colour | ZOS open | ZOS close | high | low | upper wick pip | lower wick pip | body pip");
   double pip = ZoPip();
   for(int s = 1; s <= InpCandles; s++)
   {
      double zh, zl, zo, zc;
      bool build;
      if(!ZoReadChart(Period(), s, zh, zl, zo, zc, build))
      {
         FileWrite(h, StringFormat("%d | %s | NO ZOS DATA", s, TimeToString(iTime(Symbol(), Period(), s), TIME_DATE | TIME_MINUTES)));
         continue;
      }
      int col = ZoReadColorChart(Period(), s);
      FileWrite(h, StringFormat("%d | %s | %s%s | %s | %s | %s | %s | %.1f | %.1f | %s%.1f", s,
                                TimeToString(iTime(Symbol(), Period(), s), TIME_DATE | TIME_MINUTES), ColourEn(col), build && col != 9 ? " +build" : "",
                                DoubleToString(zo, Digits), DoubleToString(zc, Digits), DoubleToString(zh, Digits), DoubleToString(zl, Digits),
                                (zh - MathMax(zo, zc)) / pip, (MathMin(zo, zc) - zl) / pip, zc >= zo ? "+" : "-", MathAbs(zc - zo) / pip));
   }
   FileWrite(h, "");
   FileWrite(h, "LPs OF THIS TIMEFRAME (live first, then the ones that died inside the visible part)");
   FileWrite(h, "kind | first candle | High | Low | height pip | state | retests | role | broke at | died at");
   datetime visFrom = iTime(Symbol(), Period(), first);
   for(int pass = 0; pass < 2; pass++)
      for(int i = ArraySize(zs) - 1; i >= 0; i--)
      {
         bool alive = ZoIsAlive(zs[i]);
         if((pass == 0) != alive || (!alive && zs[i].tDead < visFrom))
            continue;
         string role = zs[i].isMain ? "MAIN" : ZoIsShield(zs, i) ? "shield" : zs[i].dir == 0 ? "-" : "ordinary";
         FileWrite(h, StringFormat("%s | %s | %s | %s | %.1f | %s | %d | %s | %s | %s", zs[i].dir > 0 ? "GLP" : zs[i].dir < 0 ? "RLP" : "LP",
                                   TimeToString(zs[i].t0, TIME_DATE | TIME_MINUTES), DoubleToString(zs[i].hi, Digits), DoubleToString(zs[i].lo, Digits),
                                   (zs[i].hi - zs[i].lo) / pip, StateEn(zs[i].state), zs[i].retests, role,
                                   zs[i].tBreak > 0 ? TimeToString(zs[i].tBreak, TIME_DATE | TIME_MINUTES) : "-",
                                   zs[i].tDead > 0 ? TimeToString(zs[i].tDead, TIME_DATE | TIME_MINUTES) : "-"));
      }
   int tfs[] = {15, 240, 1440, 10080};
   for(int k = 0; k < 4; k++)
   {
      if(tfs[k] == Period())
         continue;
      ZoZone oz[];
      ZoTf od;
      ArrayResize(oz, 0);
      FileWrite(h, "");
      if(!ZoLoadTf(tfs[k], oz, od, false))
      {
         FileWrite(h, "OTHER TIMEFRAME " + ZoTfName(tfs[k]) + ": no shared file");
         continue;
      }
      FileWrite(h, StringFormat("OTHER TIMEFRAME %s (shared file, last candle %s%s) - live LPs", ZoTfName(tfs[k]),
                                TimeToString(od.lastBar, TIME_DATE | TIME_MINUTES), od.lastBar < iTime(Symbol(), tfs[k], 1) ? ", OLD" : ""));
      for(int i = ArraySize(oz) - 1; i >= 0; i--)
         if(ZoIsAlive(oz[i]))
            FileWrite(h, StringFormat("%s | %s | %s | %s | %s | %s", oz[i].dir > 0 ? "GLP" : oz[i].dir < 0 ? "RLP" : "LP",
                                      TimeToString(oz[i].t0, TIME_DATE | TIME_MINUTES), DoubleToString(oz[i].hi, Digits), DoubleToString(oz[i].lo, Digits),
                                      StateEn(oz[i].state), oz[i].isMain ? "MAIN" : ZoIsShield(oz, i) ? "shield" : oz[i].dir == 0 ? "-" : "ordinary"));
   }
   FileClose(h);
   Alert("ZO_Snapshot: da luu ", base, ".png va .txt (MQL4/Files)");
}

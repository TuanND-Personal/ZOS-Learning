//+------------------------------------------------------------------+
//| ZOS_Probe.mq4                                                    |
//| Read-only probe: dumps every buffer of the ZOS indicator to CSV. |
//| By default it dumps only the chart's own timeframe, because ZOS  |
//| read through iCustom() for another timeframe returns different   |
//| values than ZOS on that timeframe's chart. Run it once on each   |
//| chart (W1, D1, H4, H1, M15) to collect backtest data.            |
//| Places no orders.                                                |
//+------------------------------------------------------------------+
#property strict
#property script_show_inputs

input string InpIndicator  = "ZOS";   // Indicator file name (without .ex4)
input int    InpBars       = 20000;   // Bars to dump (bars ZOS did not compute are written as 0)
input int    InpMaxBuf     = 15;      // Buffer indexes to probe (0..N-1)
input string InpTimeframes = "";      // Empty = this chart only; or e.g. "240,60" (iCustom estimate)

// Ensure the indicator has computed on the given timeframe before dumping.
bool WarmUp(string sym, int tf)
{
   for(int i = 0; i < 50; i++)
   {
      ResetLastError();
      iCustom(sym, tf, InpIndicator, 0, 1);
      int err = GetLastError();
      if(err == 0 && iBars(sym, tf) > 0)
         return true;
      Sleep(200);
   }
   return false;
}

void DumpTimeframe(string sym, int tf)
{
   if(!WarmUp(sym, tf))
      PrintFormat("ZOS_Probe: warm-up failed %s tf=%d err=%d", sym, tf, GetLastError());

   int bars = MathMin(InpBars, iBars(sym, tf) - 1);
   // "chart" = read on its own chart (reliable); "x<chart tf>" = read from another chart (estimate).
   string source = (tf == Period()) ? "chart" : "x" + IntegerToString(Period());
   string name = StringFormat("zos_probe_%s_%d_%s.csv", sym, tf, source);
   int h = FileOpen(name, FILE_WRITE | FILE_CSV | FILE_ANSI, ',');
   if(h == INVALID_HANDLE)
   {
      PrintFormat("ZOS_Probe: cannot open %s err=%d", name, GetLastError());
      return;
   }

   string header = "time,open,high,low,close,tick_volume";
   for(int b = 0; b < InpMaxBuf; b++)
      header += ",b" + IntegerToString(b);
   FileWriteString(h, header + "\r\n");

   int valid = 0;
   for(int s = bars; s >= 1; s--)
   {
      string line = StringFormat("%s,%s,%s,%s,%s,%d",
                                 TimeToString(iTime(sym, tf, s), TIME_DATE | TIME_MINUTES),
                                 DoubleToString(iOpen(sym, tf, s), _Digits),
                                 DoubleToString(iHigh(sym, tf, s), _Digits),
                                 DoubleToString(iLow(sym, tf, s), _Digits),
                                 DoubleToString(iClose(sym, tf, s), _Digits),
                                 (int)iVolume(sym, tf, s));
      for(int b = 0; b < InpMaxBuf; b++)
      {
         double v = iCustom(sym, tf, InpIndicator, b, s);
         line += "," + (v == EMPTY_VALUE ? "E" : DoubleToString(v, 6));
         if(b == 1 && v != EMPTY_VALUE && v > 0.5)
            valid++;
      }
      FileWriteString(h, line + "\r\n");
   }
   FileClose(h);
   PrintFormat("ZOS_Probe: wrote %s (%d bars, %d with ZOS data)", name, bars, valid);
}

void OnStart()
{
   if(InpTimeframes == "")
   {
      DumpTimeframe(Symbol(), Period());
   }
   else
   {
      string parts[];
      int n = StringSplit(InpTimeframes, ',', parts);
      for(int i = 0; i < n; i++)
         DumpTimeframe(Symbol(), (int)StringToInteger(parts[i]));
   }
   Print("ZOS_Probe: done");
}

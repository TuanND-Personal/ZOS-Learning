﻿//+------------------------------------------------------------------+
//| ZO_ExportMarks.mq4                                               |
//| Exports the entries you marked by hand on the chart, so the      |
//| backtest can compare them with its own trades                    |
//| (backtest/bt_marks.py).                                          |
//|                                                                  |
//| How to mark (M15 chart recommended):                             |
//|  - BUY entry : Insert > Arrows > "Buy Sign" (or Arrow Up /        |
//|               Thumbs Up) on the candle where you would enter.    |
//|  - SELL entry: Insert > Arrows > "Sell Sign" (or Arrow Down /     |
//|               Thumbs Down).                                      |
//|  - Optional: double-click the arrow > Common > Description, e.g. |
//|    "sl=1.1650 tp=1.1720 retest G H4, nến 2 đầu" (free text).     |
//|  - A "Stop Sign" next to an arrow = "this trade should NOT be     |
//|    taken" (a trade of the system you think is wrong).            |
//| Objects drawn by the ZO tools (ZOBT_, ZOVIEW_, ZODRAW_, ZOLP_,  |
//| ZOREV_) are ignored. Writes MQL4\Files\zo_marks_<symbol>.csv     |
//| (all marks currently on the chart, overwritten on every run).    |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_ExportMarks - Xuat cac mui ten BAN TU DANH DAU tren chart ra file zo_marks_<cap>.csv."
#property description "Arrow Up / Buy Sign = mua; Arrow Down / Sell Sign = ban; Stop Sign = lenh khong nen vao."
#property description "File dung de so sanh voi backtest (backtest/bt_marks.py). Bo qua cac hinh do tool ZO ve."
#property show_inputs

#include <ZO/ZoCore.mqh>   // ZoUnaccent(): accents show as "?" on MT4 under Wine

input string InpFile = "";   // Output file (empty = zo_marks_<symbol>.csv)

bool IsToolObject(string name)
{
   return StringFind(name, "ZOBT_") == 0 || StringFind(name, "ZOVIEW_") == 0 || StringFind(name, "ZODRAW_") == 0 ||
          StringFind(name, "ZOLP_") == 0 || StringFind(name, "ZOREV_") == 0 ||
          StringFind(name, "ZOWICK_") == 0 || StringFind(name, "ZOAN_") == 0;
}

// +1 buy mark, -1 sell mark, 2 "do not take" mark, 0 not a mark.
int MarkKind(string name)
{
   int type = (int)ObjectGetInteger(0, name, OBJPROP_TYPE);
   if(type == OBJ_ARROW_BUY || type == OBJ_ARROW_UP || type == OBJ_ARROW_THUMB_UP)
      return 1;
   if(type == OBJ_ARROW_SELL || type == OBJ_ARROW_DOWN || type == OBJ_ARROW_THUMB_DOWN)
      return -1;
   if(type == OBJ_ARROW_STOP)
      return 2;
   if(type == OBJ_ARROW)
   {
      int code = (int)ObjectGetInteger(0, name, OBJPROP_ARROWCODE);
      if(code == 1 || code == 233 || code == 241 || code == 225)
         return 1;
      if(code == 2 || code == 234 || code == 242 || code == 226)
         return -1;
      if(code == 251)
         return 2;
   }
   return 0;
}

string Clean(string s)
{
   StringReplace(s, ",", ";");
   StringReplace(s, "\n", " ");
   StringReplace(s, "\r", " ");
   return s;
}

void OnStart()
{
   string file = InpFile != "" ? InpFile : "zo_marks_" + Symbol() + ".csv";
   int h = FileOpen(file, FILE_WRITE | FILE_CSV | FILE_UNICODE, ',');
   if(h == INVALID_HANDLE)
   {
      Alert(ZoUnaccent("ZO_ExportMarks: không mở được file " + file));
      return;
   }
   FileWrite(h, "kind", "time_server", "price", "chart_tf", "name", "description");
   int buys = 0, sells = 0, stops = 0;
   int total = ObjectsTotal(0, -1, -1);
   for(int i = 0; i < total; i++)
   {
      string name = ObjectName(0, i, -1, -1);
      if(IsToolObject(name))
         continue;
      int kind = MarkKind(name);
      if(kind == 0)
         continue;
      datetime t = (datetime)ObjectGetInteger(0, name, OBJPROP_TIME, 0);
      double p = ObjectGetDouble(0, name, OBJPROP_PRICE, 0);
      string k = kind == 1 ? "BUY" : kind == -1 ? "SELL" : "NO_TRADE";
      FileWrite(h, k, TimeToString(t, TIME_DATE | TIME_MINUTES), DoubleToString(p, Digits), Period(), Clean(name),
                Clean(ObjectGetString(0, name, OBJPROP_TEXT)));
      if(kind == 1) buys++; else if(kind == -1) sells++; else stops++;
   }
   FileClose(h);
   string msg = StringFormat("ZO_ExportMarks: %d BUY, %d SELL, %d không nên vào -> MQL4\\Files\\%s", buys, sells, stops, file);
   msg = ZoUnaccent(msg);
   Print(msg);
   Alert(msg);
}

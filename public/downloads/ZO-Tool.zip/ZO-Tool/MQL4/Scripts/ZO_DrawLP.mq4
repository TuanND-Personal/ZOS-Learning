﻿//+------------------------------------------------------------------+
//| ZO_DrawLP.mq4                                                    |
//| One-shot script: draws the important LPs of several timeframes   |
//| as labelled trendline pairs (High / Low of each LP), one colour  |
//| per timeframe, e.g. "H-RLP-W1 12/5" / "L-RLP-W1 12/5".           |
//| Main LPs get "MAIN" in the label, thicker lines and a star at    |
//| the candle whose clear of an opposite LP made them Main.         |
//| Data: the chart's own timeframe from ZOS, other timeframes from  |
//| ZO_LP's shared files (Common\Files\zo_lp\); without a file the   |
//| timeframe is estimated through iCustom and labelled "~".         |
//| Run again to refresh; set InpRemoveOnly to erase the drawing.    |
//+------------------------------------------------------------------+
#property strict
#property show_inputs

#include <ZO/ZoCore.mqh>

input string InpZosName     = "ZOS";              // ZOS indicator file name
input string InpTimeframes  = "10080,1440,240";   // Timeframes to draw (W1, D1, H4; add 60 for H1)
input int    InpPerSide     = 2;                  // LPs per timeframe above and below price (Mains always drawn)
input bool   InpShowFresh   = true;               // Draw LPs not broken yet (dotted)
input bool   InpShowRun     = true;               // Draw LPs already retested and left (dashed)
input bool   InpEstimate    = true;               // Estimate timeframes without a ZO_LP file (iCustom)
input bool   InpRayRight    = true;               // Extend lines to the right edge
input bool   InpRemoveOnly  = false;              // Only erase the previous drawing
input color  InpClrW1       = clrDarkViolet;      // W1 colour
input color  InpClrD1       = clrRed;             // D1 colour
input color  InpClrH4       = clrGold;            // H4 colour
input color  InpClrH1       = clrDeepSkyBlue;     // H1 colour
input color  InpClrOther    = clrSilver;          // Any other timeframe
input int    InpFontSize    = 8;

#define DRAW_PREFIX "ZODRAW_"

color TfColor(int tf)
{
   switch(tf)
   {
      case 10080: return InpClrW1;
      case 1440:  return InpClrD1;
      case 240:   return InpClrH4;
      case 60:    return InpClrH1;
   }
   return InpClrOther;
}

int TfWidth(int tf)
{
   if(tf >= 10080) return 3;
   if(tf >= 1440)  return 2;
   return 1;
}

void Line(string name, datetime t0, double price, color clr, int style, int width)
{
   datetime t1 = Time[0] + PeriodSeconds() * 5;
   ObjectCreate(0, name, OBJ_TREND, 0, t0, price, t1, price);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, InpRayRight);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, style == STYLE_SOLID ? width : 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, true);
}

void Text(string name, datetime t, double price, string txt, color clr, int anchor)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, price);
   ObjectSetString(0, name, OBJPROP_TEXT, txt);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpFontSize);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

void DrawZone(const ZoZone &z, bool shield, bool estimate)
{
   string base = DRAW_PREFIX + IntegerToString(z.tf) + "_" + IntegerToString((long)z.t0);
   color clr = TfColor(z.tf);
   int style = STYLE_SOLID;
   if(z.state == ZO_ST_FRESH) style = STYLE_DOT;
   else if(z.state == ZO_ST_RUN) style = STYLE_DASH;
   int width = TfWidth(z.tf) + (z.isMain ? 1 : 0);

   string kind = ZoKind(z);
   string tag = kind + "-" + ZoTfName(z.tf) + " " + ZoDate(z.t0);
   if(estimate) tag = "~" + tag;
   string extra = "";
   if(z.isMain)  extra += "  MAIN";
   if(shield)    extra += "  shield";
   if(z.state == ZO_ST_RETEST) extra += "  RETEST" + (z.retests > 1 ? " #" + IntegerToString(z.retests) : "");
   if(z.state == ZO_ST_FRESH)  extra += "  (chưa break)";

   Line(base + "_H", z.t0, z.hi, clr, style, width);
   Line(base + "_L", z.t0, z.lo, clr, style, width);
   // Labels sit at the right side of the visible chart, close to price.
   datetime tl = Time[0] + PeriodSeconds() * 2;
   Text(base + "_Ht", tl, z.hi, "H-" + tag + extra, clr, ANCHOR_LEFT_LOWER);
   Text(base + "_Lt", tl, z.lo, "L-" + tag, clr, ANCHOR_LEFT_UPPER);

   if(z.isMain && z.tMain > 0)
   {
      // Star at the candle that cleared the opposite LP, placed on the Main's key edge.
      double y = z.dir > 0 ? z.lo : z.hi;
      string star = base + "_M";
      Text(star, z.tMain, y, "★ MAIN " + (z.dir > 0 ? "G" : "R") + "-" + ZoTfName(z.tf) + " (clear LP ngược)",
           clr, z.dir > 0 ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER);
   }
}

void OnStart()
{
   ObjectsDeleteAll(0, DRAW_PREFIX);
   if(InpRemoveOnly)
   {
      ChartRedraw();
      return;
   }
   g_zoName = InpZosName;

   string parts[];
   int n = StringSplit(InpTimeframes, ',', parts);
   string report = "";
   int drawn = 0;
   for(int p = 0; p < n; p++)
   {
      int tf = (int)StringToInteger(parts[p]);
      if(tf <= 0)
         continue;
      ZoZone zs[];
      ArrayResize(zs, 0);
      ZoTf d;
      if(!ZoLoadTf(tf, zs, d, InpEstimate))
      {
         report += "\n" + ZoTfName(tf) + ": không có dữ liệu (chưa chạy ZO_LP trên chart " + ZoTfName(tf) + ")";
         continue;
      }
      int sel[];
      int k = ZoSelect(zs, tf, Bid, InpPerSide, InpShowFresh, sel);
      int shown = 0;
      for(int i = 0; i < k; i++)
      {
         ZoZone z = zs[sel[i]];
         if(z.state == ZO_ST_RUN && !InpShowRun && !z.isMain)
            continue;
         DrawZone(z, ZoIsShield(zs, sel[i]), d.source == ZO_SRC_ESTIMATE);
         shown++;
      }
      drawn += shown;
      report += StringFormat("\n%s: %d LP%s, xu thế %s", ZoTfName(tf), shown, ZoSourceNote(d), ZoTrendText(d.trend));
   }
   ChartRedraw();
   Print("ZO_DrawLP: đã vẽ ", drawn, " LP", report);
}

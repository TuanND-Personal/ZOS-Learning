﻿//+------------------------------------------------------------------+
//| ZO_DrawLP.mq4                                                    |
//| One-shot script: draws the important LPs of several timeframes   |
//| as labelled trendline pairs (High / Low of each LP), one colour  |
//| per timeframe (W1 red, D1 yellow, H4 blue), GLP solid, RLP       |
//| dashed, e.g. "High RLP-W1 12/5 1.08512" / "Low RLP-W1 12/5 ...". |
//| Labels sit at the left edge of the screen as it is when the      |
//| script runs (run it again after scrolling far).                  |
//| Main LPs get "MAIN" in the label and a star at the candle whose  |
//| clear of an opposite LP made them Main. Lines are 1 px wide.     |
//| Data: the chart's own timeframe from ZOS, other timeframes from  |
//| ZO_LP's shared files (Common\Files\zo_lp\); without a file the   |
//| timeframe is estimated through iCustom and labelled "~".         |
//| Run again to refresh; set InpRemoveOnly to erase the drawing.    |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_DrawLP - Ve 1 lan cac LP quan trong: W1 do, D1 vang, H4 xanh lam."
#property description "Moi LP = 2 duong High / Low co nhan va gia; GLP net lien, RLP net dut; Main co chu MAIN."
#property description "Chay lai de cap nhat. InpRemoveOnly = true de xoa hinh da ve."
#property description "CAN: ZO_LP chay tren chart cua tung khung."
#property show_inputs

#include <ZO/ZoCore.mqh>

input string InpZosName     = "ZOS";              // ZOS indicator file name
input string InpTimeframes  = "10080,1440,240";   // Timeframes to draw (W1, D1, H4; add 60 for H1)
input int    InpPerSide     = 2;                  // LPs per timeframe above and below price (Mains always drawn)
input bool   InpShowFresh   = true;               // Draw LPs not broken yet (dotted)
input bool   InpShowRun     = true;               // Draw LPs already retested and left (dashed)
input bool   InpEstimate    = true;               // Estimate timeframes without a ZO_LP file (iCustom)
input bool   InpRayRight    = true;               // Extend lines to the right edge
input bool   InpRemoveOnly  = false;              // Only erase the previous drawing
input color  InpClrW1       = clrRed;             // W1 colour
input color  InpClrD1       = clrGold;            // D1 colour
input color  InpClrH4       = clrDodgerBlue;      // H4 colour
input color  InpClrH1       = clrMediumPurple;    // H1 colour
input color  InpClrOther    = clrSilver;          // Any other timeframe
input int    InpFontSize    = 10;
input int    InpLineWidth   = 1;                  // Line width for every LP (1 = thinnest)
input double InpLabelGapPips = 6;                 // Labels closer than this (pips) are moved right to avoid overlap
input int    InpLabelShiftBars = 14;              // How far (bars) an overlapping label is moved

#define DRAW_PREFIX "ZODRAW_"

color TfColor(int tf)
{
   switch(tf)
   {
      case 10080: return InpClrW1;
      case 1440:  return InpClrD1;
      case 240:   return InpClrH4;
      case 60:    return InpClrH1;
   }
   return InpClrOther;
}

int TfWidth(int tf)
{
   return InpLineWidth;   // thinnest by default; Main LPs are told apart by their "MAIN" label
}

void Line(string name, datetime t0, double price, color clr, int style, int width)
{
   datetime t1 = Time[0] + PeriodSeconds() * 5;
   ObjectCreate(0, name, OBJ_TREND, 0, t0, price, t1, price);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, InpRayRight);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, style == STYLE_SOLID ? width : 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, true);
}

void Text(string name, datetime t, double price, string txt, color clr, int anchor)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, price);
   ObjectSetString(0, name, OBJPROP_TEXT, ZoUnaccent(txt));   // accents show as "?" on MT4 under Wine
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpFontSize);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

string   g_lblName[];
datetime g_lblTime[];
double   g_lblPrice[];
bool     g_lblUp[];
string   g_lblText[];
color    g_lblColor[];

void QueueLabel(string name, datetime t0, double price, bool up, string text, color clr)
{
   int k = ArraySize(g_lblName);
   ArrayResize(g_lblName, k + 1);
   ArrayResize(g_lblTime, k + 1);
   ArrayResize(g_lblPrice, k + 1);
   ArrayResize(g_lblUp, k + 1);
   ArrayResize(g_lblText, k + 1);
   ArrayResize(g_lblColor, k + 1);
   g_lblName[k] = name;
   g_lblTime[k] = t0;
   g_lblPrice[k] = price;
   g_lblUp[k] = up;
   g_lblText[k] = text;
   g_lblColor[k] = clr;
}

// Each label starts at its line's start, or at the left edge of the screen when the line starts off-screen
// (High labels above their line, Low labels below). A label closer than InpLabelGapPips to one already placed
// on the same side moves InpLabelShiftBars to the right.
void PlaceLabels()
{
   int first = WindowFirstVisibleBar();
   if(first < 0 || first >= Bars)
      first = Bars - 1;
   datetime leftT = Time[first];
   int n = ArraySize(g_lblName);
   double gap = InpLabelGapPips * ((Digits == 3 || Digits == 5) ? Point * 10 : Point);
   int step = InpLabelShiftBars * PeriodSeconds();
   datetime pt[];
   double pp[];
   bool pu[];
   ArrayResize(pt, n);
   ArrayResize(pp, n);
   ArrayResize(pu, n);
   for(int k = 0; k < n; k++)
   {
      datetime t = g_lblTime[k] > leftT ? g_lblTime[k] : leftT;
      for(int tries = 0; tries < 12; tries++)
      {
         bool clash = false;
         for(int j = 0; j < k && !clash; j++)
            clash = pu[j] == g_lblUp[k] && MathAbs((double)(pt[j] - t)) < step && MathAbs(pp[j] - g_lblPrice[k]) < gap;
         if(!clash)
            break;
         t += step;
      }
      pt[k] = t;
      pp[k] = g_lblPrice[k];
      pu[k] = g_lblUp[k];
      Text(g_lblName[k], t, g_lblPrice[k], " " + g_lblText[k], g_lblColor[k], g_lblUp[k] ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER);
   }
}

void DrawZone(const ZoZone &z, bool shield, bool estimate)
{
   string base = DRAW_PREFIX + IntegerToString(z.tf) + "_" + IntegerToString((long)z.t0);
   color clr = TfColor(z.tf);
   // Colour = timeframe, style = direction (GLP solid, RLP dashed, not broken yet dotted).
   int style = z.dir > 0 ? STYLE_SOLID : z.dir < 0 ? STYLE_DASH : STYLE_DOT;
   int width = TfWidth(z.tf);

   string kind = ZoKind(z);
   string tag = kind + "-" + ZoTfName(z.tf) + " " + ZoDate(z.t0);
   if(estimate) tag = "~" + tag;
   string extra = "";
   if(z.isMain)  extra += "  MAIN";
   if(shield)    extra += "  shield";
   if(z.state == ZO_ST_RETEST) extra += "  RETEST" + (z.retests > 1 ? " #" + IntegerToString(z.retests) : "");
   if(z.state == ZO_ST_RUN)    extra += "  run";
   if(z.state == ZO_ST_FRESH)  extra += "  (chưa break)";

   Line(base + "_H", z.t0, z.hi, clr, style, width);
   Line(base + "_L", z.t0, z.lo, clr, style, width);
   // One label per line, "High ..." above the High line and "Low ..." below the Low line, placed by PlaceLabels().
   QueueLabel(base + "_th", z.t0, z.hi, true, "High " + tag + extra + "  " + DoubleToString(z.hi, Digits), clr);
   QueueLabel(base + "_tl", z.t0, z.lo, false, "Low " + tag + extra + "  " + DoubleToString(z.lo, Digits), clr);

   if(z.isMain && z.tMain > 0)
   {
      // Star at the candle that cleared the opposite LP, placed on the Main's key edge.
      double y = z.dir > 0 ? z.lo : z.hi;
      string star = base + "_M";
      Text(star, z.tMain, y, "★ MAIN " + (z.dir > 0 ? "G" : "R") + "-" + ZoTfName(z.tf) + " (clear LP ngược)",
           clr, z.dir > 0 ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER);
   }
}

void OnStart()
{
   ObjectsDeleteAll(0, DRAW_PREFIX);
   if(InpRemoveOnly)
   {
      ChartRedraw();
      return;
   }
   g_zoName = InpZosName;

   string parts[];
   int n = StringSplit(InpTimeframes, ',', parts);
   string report = "";
   int drawn = 0;
   for(int p = 0; p < n; p++)
   {
      int tf = (int)StringToInteger(parts[p]);
      if(tf <= 0)
         continue;
      ZoZone zs[];
      ArrayResize(zs, 0);
      ZoTf d;
      if(!ZoLoadTf(tf, zs, d, InpEstimate))
      {
         report += "\n" + ZoTfName(tf) + ": không có dữ liệu (chưa chạy ZO_LP trên chart " + ZoTfName(tf) + ")";
         continue;
      }
      int sel[];
      int k = ZoSelect(zs, tf, Bid, InpPerSide, InpShowFresh, sel);
      int shown = 0;
      for(int i = 0; i < k; i++)
      {
         ZoZone z = zs[sel[i]];
         if(z.state == ZO_ST_RUN && !InpShowRun && !z.isMain)
            continue;
         DrawZone(z, ZoIsShield(zs, sel[i]), d.source == ZO_SRC_ESTIMATE);
         shown++;
      }
      drawn += shown;
      datetime since;
      report += StringFormat("\n%s: %d LP%s, xu the Main %s", ZoTfName(tf), shown, ZoSourceNote(d),
                             ZoUnaccent(ZoTrendText(ZoMainTrend(zs, tf, since))));
   }
   PlaceLabels();
   ChartRedraw();
   Print(ZoUnaccent("ZO_DrawLP: đã vẽ " + IntegerToString(drawn) + " LP" + report));
}

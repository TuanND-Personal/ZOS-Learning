﻿//+------------------------------------------------------------------+
//| ZO_Analyst.mq4                                                   |
//| Writes a ZO reading of the chart (W1 / D1 / H4 / H1 / M15 and    |
//| the H4 -> M15 plan) when attached and whenever the structure     |
//| changes, and sends it to Telegram / Discord.                     |
//|                                                                  |
//| System ZO-FLEX (backtest/bt_lab.py, code ZOFLEX) - the main      |
//| version; every earlier system is a testing version. Three entry  |
//| kinds, checked at every M15 close:                               |
//|  - LP-AB: a ZO A/B candle pair with its pull tip at any live H4  |
//|    LP of our side; announced as POTENTIAL EP at the first        |
//|    confirming candle, entered at the second (within 4 candles);  |
//|    break-even at 3R;                                             |
//|  - MAIN-AB: an A/B pair in the deep half of the Main / Shield H4,|
//|    Main H4 at least 48 h old;                                    |
//|  - PULLBACK: with the Main H4, price pulled >= 15 pip against it |
//|    into an LP, pull wick >= 5 pip then gone.                     |
//| Rounds 59-66 (2/10/2026), each with its own input:               |
//|  - "Main tre" block: no entry that follows the H4 Main while the |
//|    last closed day is on the other side of the close 10 days ago |
//|    (InpMainLagBlock);                                            |
//|  - no BUY while price sits inside a live D1 / W1 GLP             |
//|    (InpNoBuyInDwGlp);                                            |
//|  - stops widened by the spread above 1 pip (InpSlSpreadAdj);     |
//|  - risk per entry by confidence (InpRiskMode = 1): InpRiskBase,  |
//|    InpRiskHigh from InpRiskHighFactors of the 7 factors, minus   |
//|    InpRiskLossCut after InpRiskLossStreak straight losses.       |
//| Common rules: no entry while the last closed H4 ZOS candle is    |
//| the other side's strong colour (InpH4Veto); targets at the near  |
//| edge / middle / far end of the opposite H4 LP; a part that       |
//| reached its target is held until an M15 ZOS candle of the other  |
//| side's colour (InpHoldMode), stop locked at +0.5R once holding   |
//| starts (InpHoldLockR).                                           |
//| Auto trading (InpAutoTrade, on by default) runs on DEMO accounts |
//| only: the entries are sent as market orders, one order per       |
//| target, SL to the entry at 1R, closed on Friday night. On a real |
//| account the EA only sends signals unless InpAllowRealAccount is  |
//| set as well.                                                     |
//| Orders opened BY HAND on this symbol (magic 0, InpManualManage):  |
//| the EA reports them, sets the SL behind the last M15 swing and   |
//| the TP at the next H4 LP ahead (2R when that is too close), then |
//| moves the SL to the entry at InpManualBeR x risk and reports the |
//| result when the order closes. Real account: suggestion only,     |
//| unless InpAllowRealAccount. Defaults from backtest round 38.     |
//| Entries come with EP / SL / targets; open trades get BE and      |
//| ZO-hold hints. Trend of a timeframe = its latest Main LP. The    |
//| analysis message follows the "ZOS MARKET ANALYSIS" template.     |
//|                                                                  |
//| Message level (InpMsgLevel, round 50): 1 = Potential EP alerts,   |
//| entries, order messages and news only (default); 2 = also the    |
//| full analysis when the big structure changes; 0 = everything     |
//| below as well.                                                   |
//| Events watched (from ZO_LP's shared files, one chart per         |
//| timeframe):                                                      |
//|  - new LP, LP broken into GLP / RLP, LP cleared / failed         |
//|    (SHs sign when it dies right after its break),                |
//|  - new Main LP, LP-trend change of a timeframe,                  |
//|  - price touching an H4 / D1 / W1 LP (checked every few seconds).|
//| Major events (new Main, trend change on H4+, anything on D1/W1)  |
//| trigger a full analysis (at most once per InpFullGapMin); the    |
//| others are batched into short alerts (InpMinGapMin apart).       |
//|                                                                  |
//| Also forwards the alerts ZO_LP queues in Common\Files\zo_alerts\ |
//| (forwards the ZO_LP alert queue itself). Places orders only     |
//| when AutoOn() holds (demo account, or real one explicitly set).  |
//| Economic calendar: downloads this week's ForexFactory feed,      |
//| warns before red USD / EUR news, sends no entry signal within    |
//| +-InpNewsBlockMin minutes of one, draws them on the chart and    |
//| shares them with ZO_View (Common\Files\zo_lp\news.csv).          |
//| Required: Tools > Options > Expert Advisors > Allow WebRequest   |
//| for https://api.telegram.org, https://nfs.faireconomy.media      |
//| (and https://discord.com).                                       |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_Analyst - EA he ZO-FLEX (phan tich ZO, thoat lenh linh dong): bao Potential EP / ENTRY qua Telegram. DEMO: tu dat lenh. Lenh vao TAY: tu dat SL / TP + BE."
#property description "InpMsgLevel: 1 = chi EP + lenh + tin do; 2 = them ban phan tich; 0 = tat ca su kien LP."
#property description "CAN: chart W1, D1, H4, M15 co ZOS + ZO_LP. Luu template ten ZO_DATA (chart co ZOS + ZO_LP) de EA tu mo chart con thieu."
#property description "Tools > Options > Expert Advisors > Allow WebRequest: https://api.telegram.org va https://nfs.faireconomy.media"

#include <ZO/ZoCore.mqh>

#include <ZO/ZoSecrets.mqh>
// Defaults come from ZoSecrets.mqh (git-ignored; copy ZoSecrets.example.mqh): the owner's build carries its own bot.
input string InpTelegramToken   = ZO_TELEGRAM_TOKEN; // Telegram bot token, empty = off
input string InpTelegramChatId  = ZO_TELEGRAM_CHAT_ID;                                      // Telegram chat id
input string InpDiscordWebhook  = "";                     // Discord webhook URL, empty = off
input string InpZosName         = "ZOS";                  // ZOS indicator file name
input string InpTimeframes      = "10080,1440,240,60,15"; // Timeframes read (each needs ZO_LP on its own chart)
input bool   InpEstimate        = false;                  // Estimate timeframes without a ZO_LP file (iCustom, may be wrong)
input bool   InpAutoOpenCharts  = true;                   // Open the missing timeframe charts and apply the data template to them
input string InpDataTemplate    = "ZO_DATA";              // Template holding ZOS + ZO_LP (save it once: chart with both > Template > Save)
input int    InpAnalysisStyle   = 0;                      // Analysis message: 0 = "ZOS MARKET ANALYSIS" template, 1 = old per-timeframe text
input int    InpMsgLevel        = 1;                      // MESSAGES: 1 = Potential EP + entries + orders + news only, 2 = also the analysis when the big structure changes, 0 = everything (LP events, touches, ZO_LP alerts, cancelled EPs)
input bool   InpSignals         = true;                   // MAIN-AB / PULLBACK entry signals at every M15 close (needs H4 + M15 data)
input bool   InpEpSignals       = true;                   // LP-AB: Potential EP alerts (WATCH) and entries after 2 confirming ZO candles
input bool   InpEpAlertFade     = false;                  // Also alert "fading pull" Potential EPs (watch only; LP-AB enters on A/B pairs)
input bool   InpEpAnyH4Lp       = true;                   // LP-AB: accept any live H4 LP of our side at the pull tip, not only the Main / Shield (round 52: +70R over 3 years)
input bool   InpEpAlertOnly     = true;                   // ALERT-ONLY EPs: report an EP the rules block only for a soft reason (night / New York hours, stop 15-17 pip), with the reason and its backtest record. Never traded automatically
input double InpEpAlertSlMax    = 17;                     // ... widest stop of an alert-only EP (pip)
input int    InpEpConfWindow    = 4;                      // LP-AB: the confirming candles may come within N candles after the A/B pair (a candle that fails delays the entry); = InpEpConfirm for the old strict rule
input int    InpEpConfirm       = 2;                      // LP-AB: confirming ZO candles before the entry (2 = main system; 3 = fewer trades)
input int    InpEpMinQuality    = 80;                     // Send a Potential EP alert only from this quality (0-100). 80 = every check passes (~6 alerts a week in the 3-year backtest); 50 = any EP at an H4 LP (~47 a week)
input int    InpTpProfile       = 1;                      // Targets: 1 = near edge / middle / far end of the opposite H4 LP, SL from 8 pip (main system); 0 = 1R / middle / far end (testing)
input bool   InpDrawSignals     = true;                   // Draw signals (arrow, SL, targets) on this chart
input int    InpRiskMode        = 1;                      // RISK PER ENTRY: 1 = by confidence (InpRiskBase / InpRiskHigh below, round 65), 0 = always InpRiskPct
input double InpRiskPct         = 2;                      // Mode 0: % of balance risked per entry
input double InpRiskBase        = 2;                      // Mode 1: % risked on an ordinary entry
input double InpRiskHigh        = 5;                      // Mode 1: % risked when at least InpRiskHighFactors of the 7 confidence factors hold
input int    InpRiskHighFactors = 4;                      // ... factors needed for InpRiskHigh
input int    InpRiskLossStreak  = 2;                      // Mode 1: after this many straight losing entries ... (0 = off)
input double InpRiskLossCut     = 1;                      // ... the risk is cut by this many % (never below InpRiskMin)
input double InpRiskMin         = 1;                      // Mode 1: lowest risk per entry, %
input bool   InpMainLagBlock    = true;                   // BLOCK "Main tre": no entry with the H4 Main while the daily close is on the other side of the close InpMainLagDays ago (round 59: drawdown 32R -> 17R)
input int    InpMainLagDays     = 10;                     // ... days compared
input bool   InpNoBuyInDwGlp    = true;                   // BLOCK: no BUY while price is inside a live D1 / W1 GLP (round 60)
input bool   InpSlSpreadAdj     = true;                   // STOP: widen every stop (and the stop limits) by the spread above InpSlBaseSpread (round 66)
input double InpSlBaseSpread    = 1.0;                    // ... spread the rules were fitted on, pip
input bool   InpH4Veto          = true;                   // No entry while the last closed H4 ZOS candle is the other side's strong colour
input int    InpHoldMode        = 1;                      // Reached targets: 0 = close at the target, 1 = hold until an M15 ZOS candle of the other side's colour
input double InpHoldLockR       = 0.5;                    // Hold mode, LP targets: SL to +N x R when a part starts being held (0 = off)
input bool   InpManageHints     = true;                   // BE / ZO-hold hints for open trades of this symbol
input int    InpLossPause       = 2;                      // Straight losing signals in one direction before pausing it (0 = off)
input int    InpPauseHours      = 48;                     // Pause length (backtest round 23)
input bool   InpAutoTrade       = true;                   // AUTO TRADING: place the entries as market orders - demo accounts only (off = signals only)
input bool   InpAllowRealAccount = false;                 // Auto trading on a REAL account too (off = a real account only gets signals)
input int    InpMagic           = 20261001;               // Magic number of the EA's orders
input int    InpMaxOpenTrades   = 2;                      // Max open entries of this EA at once (an entry = up to 3 partial orders)
input double InpMaxSpreadPips   = 3.0;                    // No order when the spread is wider than this
input double InpMaxDriftPips    = 3.0;                    // No order when price already ran this far from the signal price
input int    InpSlippagePoints  = 20;                     // Max slippage of the market order (points)
input bool   InpAutoBE          = true;                   // Move SL to the entry price once price went 1R our way (LP-AB entries: InpLpAbBeR)
input double InpLpAbBeR          = 3.0;                    // LP-AB entries: break-even only after this many R (round 55: +275R against +217R at 1R, lower drawdown). 1 = old rule
input bool   InpAutoFridayClose = true;                   // Close the EA's orders on Friday 22:00 Hanoi time
input bool   InpManualManage    = true;                   // ORDERS OPENED BY HAND (magic 0): report on Telegram, set SL / TP, move to BE
input bool   InpManualKeepStops = true;                   // Keep an SL / TP already set by hand (only the missing one is filled in)
input int    InpManualSwingBars = 16;                     // SL behind the lowest low / highest high of the last N M15 candles
input double InpManualSlPadPips = 3;                      // ... plus this many pips
input double InpManualSlMinPips = 8;                      // Narrowest SL (a tighter one mostly pays the spread - round 38)
input double InpManualSlMaxPips = 20;                     // Widest SL
input double InpManualTpMinRR   = 1.5;                    // TP at the next H4 LP ahead when it is at least this many R away
input double InpManualTpFallbackR = 2.0;                  // ... otherwise TP at this many R
input double InpManualBeR       = 1.0;                    // SL to the entry price once price went this many R (0 = never)
input bool   InpNews            = true;                   // Economic calendar: download, warn, block signals around news
input string InpNewsUrl         = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"; // Calendar feed (allow in WebRequest)
input string InpNewsCurrencies  = "USD,EUR";              // Currencies watched
input int    InpNewsMinImpact   = 3;                      // 3 = red (high) news only, 2 = also orange (medium)
input int    InpNewsBlockMin    = 30;                     // No signals from N minutes before to N minutes after a news
input int    InpNewsWarnMin     = 30;                     // Telegram heads-up N minutes before a news (0 = off)
input int    InpNewsRefreshHours = 4;                     // Download the calendar again every N hours
input bool   InpNewsLines       = true;                   // Vertical lines on this chart at the watched news
input bool   InpAnalysisOnStart = true;                   // Send the analysis when attached
input int    InpStartThrottleMin = 10;                    // ... at most once per N minutes (timeframe switches re-attach)
input int    InpEventMinTf      = 60;                     // Events reported from this timeframe up
input int    InpTouchMinTf      = 240;                    // Price-touch alerts from this timeframe up
input double InpTouchPips       = 3;                      // "Touch" = price within N pips of the LP
input int    InpMinGapMin       = 10;                     // Min minutes between two short alert messages
input int    InpFullGapMin      = 60;                     // Min minutes between two change-driven full analyses
input int    InpQuietFrom       = 0;                      // Quiet hours (Hanoi): minor events dropped, major kept for later
input int    InpQuietTo         = 7;
input double InpSlBufferPips    = 2;                      // SL beyond the LP end point
input bool   InpForwardQueue    = true;                   // Forward ZO_LP alerts to Telegram
input int    InpMaxAgeMinutes   = 15;                     // Drop queued ZO_LP alerts older than this
input bool   InpWriteFile       = true;                   // Also write MQL4\Files\zo_analysis_<symbol>.txt

#define QUEUE_DIR "zo_alerts\\"

ZoZone   g_all[];
ZoTf     g_d[];
int      g_tfs[];
long     g_fileMod[];
datetime g_chartBar = 0;
bool     g_primed = false;

// Snapshot of the previous load, to detect changes.
string   g_snapKeys[];
int      g_snapState[];
int      g_snapDir[];
bool     g_snapMain[];
int      g_snapTrend[];
string   g_touched[];

string   g_minor = "";           // batched short alerts
bool     g_majorPending = false;
string   g_majorLines = "";      // major events, kept through quiet hours
datetime g_lastMinorSent = 0;
datetime g_lastFullSent = 0;
double   g_pip;
datetime g_lastSigBar = 0;       // M15 candle last checked for a MAIN-AB / PULLBACK signal
datetime g_lastMgmtBar = 0;
datetime g_newsFetched = 0;      // local time of the last calendar download attempt
datetime g_newsWarned = 0;       // GMT time of the last news already announced
// Signals sent and not resolved yet (loss = SL touched before 1R; reaching 1R = safe, BE from there).
int      g_sDir[];
double   g_sEp[];
double   g_sSl[];
datetime g_sBar[];

//+------------------------------------------------------------------+
int OnInit()
{
   g_zoName = InpZosName;
   g_pip = ZoPip();
   ArrayResize(g_tfs, 0);
   string parts[];
   int n = StringSplit(InpTimeframes, ',', parts);
   for(int i = 0; i < n; i++)
   {
      int tf = (int)StringToInteger(parts[i]);
      if(tf > 0)
      {
         int k = ArraySize(g_tfs);
         ArrayResize(g_tfs, k + 1);
         g_tfs[k] = tf;
      }
   }
   ArrayResize(g_d, ArraySize(g_tfs));
   ArrayResize(g_fileMod, ArraySize(g_tfs));
   ArrayInitialize(g_fileMod, -1);
   ArrayResize(g_snapTrend, ArraySize(g_tfs));
   ArrayInitialize(g_snapTrend, 0);
   g_primed = false;
   if(InpForwardQueue)
      FolderCreate(QUEUE_DIR, FILE_COMMON);
   if(InpAutoOpenCharts)
      OpenDataCharts();
   EventSetTimer(5);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

// ZOS is only right on the chart of its own timeframe, so every timeframe needs a chart with ZOS + ZO_LP (which
// writes the shared file this EA reads). Opens the charts that are missing and applies the data template.
void OpenDataCharts()
{
   for(int i = 0; i < ArraySize(g_tfs); i++)
   {
      int tf = g_tfs[i];
      if(tf == Period())
         continue;
      bool found = false;
      for(long id = ChartFirst(); id >= 0; id = ChartNext(id))
         if(ChartSymbol(id) == Symbol() && ChartPeriod(id) == tf)
         {
            found = true;
            break;
         }
      if(found)
         continue;
      long nid = ChartOpen(Symbol(), tf);
      if(nid <= 0)
      {
         PrintFormat("ZO_Analyst: cannot open the %s chart (err %d)", ZoTfName(tf), GetLastError());
         continue;
      }
      if(!ChartApplyTemplate(nid, InpDataTemplate + ".tpl"))
         PrintFormat("ZO_Analyst: template %s.tpl not applied to the %s chart - save a template with ZOS + ZO_LP under that name",
                     InpDataTemplate, ZoTfName(tf));
      else
         PrintFormat("ZO_Analyst: opened the %s chart with template %s", ZoTfName(tf), InpDataTemplate);
   }
   ChartSetInteger(0, CHART_BRING_TO_TOP, true);
}

void OnTick()
{
}

void OnTimer()
{
   if(InpForwardQueue)
      ForwardQueue();
   if(InpNews)
      NewsTick();

   if(DataChanged())
   {
      LoadAll();
      if(!g_primed)
      {
         g_primed = true;
         TakeSnapshot();
         PrimeTouches();
         if(InpAnalysisOnStart && StartAllowed())
            SendFull("PHÂN TÍCH (vừa gắn EA)");
         else if(InpWriteFile)
            WriteFile(InpAnalysisStyle == 0 ? BuildZos() : BuildAnalysis("PHÂN TÍCH"));
      }
      else
      {
         DiffAndQueue();
         TakeSnapshot();
      }
   }
   if(InpManualManage)
      ManageManual();   // before the hints: an order moved to BE here needs no BE hint
   if(g_primed)
   {
      CheckTouches();
      if(InpSignals)
         CheckSignal();
      if(InpManageHints)
         ManageHints();
   }
   if(AutoOn())
      ManageAuto();
   FlushMessages();
}

//+------------------------------------------------------------------+
//| Loading                                                          |
//+------------------------------------------------------------------+
int DataIndex(int tf)
{
   for(int i = 0; i < ArraySize(g_tfs); i++)
      if(g_tfs[i] == tf)
         return i;
   return -1;
}

bool DataChanged()
{
   bool changed = !g_primed;
   if(Time[0] != g_chartBar)
   {
      g_chartBar = Time[0];
      changed = true;
   }
   for(int i = 0; i < ArraySize(g_tfs); i++)
   {
      if(g_tfs[i] == Period())
         continue;
      long mod = FileGetInteger(ZoShareFile(g_tfs[i]), FILE_MODIFY_DATE, true);
      if(mod != g_fileMod[i])
      {
         g_fileMod[i] = mod;
         changed = true;
      }
   }
   return changed;
}

void LoadAll()
{
   ArrayResize(g_all, 0);
   for(int i = 0; i < ArraySize(g_tfs); i++)
      ZoLoadTf(g_tfs[i], g_all, g_d[i], InpEstimate);
}

bool Reliable(int tf)
{
   int di = DataIndex(tf);
   return di >= 0 && (g_d[di].source == ZO_SRC_CHART || g_d[di].source == ZO_SRC_SHARED);
}

// Trend of a timeframe = direction of its latest Main LP (research 30/9).
int TrendOf(int tf)
{
   datetime since;
   return ZoMainTrend(g_all, tf, since);
}

string ZoneKey(const ZoZone &z)
{
   return IntegerToString(z.tf) + "|" + IntegerToString((long)z.t0);
}

//+------------------------------------------------------------------+
//| Change detection                                                 |
//+------------------------------------------------------------------+
void TakeSnapshot()
{
   int n = ArraySize(g_all);
   ArrayResize(g_snapKeys, n);
   ArrayResize(g_snapState, n);
   ArrayResize(g_snapDir, n);
   ArrayResize(g_snapMain, n);
   for(int i = 0; i < n; i++)
   {
      g_snapKeys[i] = ZoneKey(g_all[i]);
      g_snapState[i] = g_all[i].state;
      g_snapDir[i] = g_all[i].dir;
      g_snapMain[i] = g_all[i].isMain;
   }
   for(int f = 0; f < ArraySize(g_tfs); f++)
      g_snapTrend[f] = TrendOf(g_tfs[f]);
}

int FindSnap(string key)
{
   for(int i = 0; i < ArraySize(g_snapKeys); i++)
      if(g_snapKeys[i] == key)
         return i;
   return -1;
}

void Minor(string s)
{
   g_minor += "\n- " + s;
}

void Major(string s)
{
   g_majorLines += "\n- " + s;
   g_majorPending = true;
}

void DiffAndQueue()
{
   for(int f = 0; f < ArraySize(g_tfs); f++)
   {
      int tf = g_tfs[f];
      if(tf < InpEventMinTf || !Reliable(tf))
         continue;
      int tr = TrendOf(tf);
      if(tr != g_snapTrend[f] && tr != 0)
      {
         string s = "Xu thế Main " + ZoTfName(tf) + " đổi sang " + ZoTrendText(tr) +
                    (tf == 240 ? " → kiểu MAIN-AB / PULLBACK chỉ vào lệnh " + (tr > 0 ? "MUA" : "BÁN") : "");
         if(tf >= 240) Major(s); else Minor(s);
      }
   }

   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf < InpEventMinTf || !Reliable(z.tf))
         continue;
      bool big = z.tf >= 1440;
      int p = FindSnap(ZoneKey(z));
      if(p < 0)
      {
         if(!ZoIsAlive(z))
            continue;   // appeared and died between two loads: nothing to act on
         string s = "LP mới " + ZoTfName(z.tf) + " " + ZoDate(z.t0) + " (" + ZoPx(z.lo) + "-" + ZoPx(z.hi) + ")" +
                    (z.dir != 0 ? " đã " + (z.dir > 0 ? "thành GLP" : "thành RLP") : " - chưa break, chưa vào");
         if(big) Major(s); else Minor(s);
         continue;
      }
      if(g_snapDir[p] == 0 && z.dir != 0)
      {
         string s = ZoShortName(z) + " vừa break " + (z.dir > 0 ? "LÊN" : "XUỐNG") + " → chờ retest, không đuổi";
         if(big) Major(s); else Minor(s);
      }
      bool wasAlive = g_snapState[p] != ZO_ST_FAILED && g_snapState[p] != ZO_ST_CLEARED;
      if(wasAlive && !ZoIsAlive(z) && z.dir != 0)
      {
         string s = ZoShortName(z) + (z.state == ZO_ST_CLEARED ? " bị CLEAR" : " bị phá thủng");
         if(z.tBreak > 0 && z.tDead - z.tBreak <= 3 * PeriodSeconds(z.tf))
            s += " ngay sau khi tạo (dấu hiệu SHs - cẩn thận cú quay lại)";
         if(big || z.tf >= 240) Major(s); else Minor(s);
      }
      if(!g_snapMain[p] && z.isMain && ZoIsAlive(z))
         Major("MAIN mới: " + ZoZoneText(z) + " → xu thế " + ZoTfName(z.tf) + " " + (z.dir > 0 ? "TĂNG" : "GIẢM") +
               "; không đánh ngược Main này");
      if(g_snapState[p] != ZO_ST_RETEST && z.state == ZO_ST_RETEST && z.tf >= 240)
         Minor(ZoShortName(z) + " đang RETEST (lần " + IntegerToString(z.retests) + ") → xuống khung nhỏ chờ thu nến / LP cùng chiều");
   }
}

// Price touching an H4+ LP between bar closes.
string TouchKey(const ZoZone &z) { return ZoneKey(z); }

bool InList(const string &arr[], string key)
{
   for(int i = 0; i < ArraySize(arr); i++)
      if(arr[i] == key)
         return true;
   return false;
}

void RemoveFromList(string &arr[], string key)
{
   for(int i = 0; i < ArraySize(arr); i++)
      if(arr[i] == key)
      {
         arr[i] = arr[ArraySize(arr) - 1];
         ArrayResize(arr, ArraySize(arr) - 1);
         return;
      }
}

bool Touching(const ZoZone &z)
{
   return Bid >= z.lo - InpTouchPips * g_pip && Bid <= z.hi + InpTouchPips * g_pip;
}

void PrimeTouches()
{
   ArrayResize(g_touched, 0);
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf >= InpTouchMinTf && ZoIsAlive(g_all[i]) && g_all[i].dir != 0 && Touching(g_all[i]))
      {
         int k = ArraySize(g_touched);
         ArrayResize(g_touched, k + 1);
         g_touched[k] = TouchKey(g_all[i]);
      }
}

void CheckTouches()
{
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf < InpTouchMinTf || !ZoIsAlive(z) || z.dir == 0 || !Reliable(z.tf))
         continue;
      string key = TouchKey(z);
      if(Touching(z))
      {
         if(InList(g_touched, key))
            continue;
         int k = ArraySize(g_touched);
         ArrayResize(g_touched, k + 1);
         g_touched[k] = key;
         bool withTrend = TrendOf(z.tf) == z.dir || TrendOf(z.tf) == 0;
         double end = z.dir > 0 ? z.lo : z.hi;
         string s = StringFormat("Giá %s chạm %s. Điểm cuối (%s) %s, SL gợi ý %s.", ZoPx(Bid), ZoZoneText(z),
                                 z.dir > 0 ? "Low" : "High", ZoPx(end),
                                 ZoPx(z.dir > 0 ? end - InpSlBufferPips * g_pip : end + InpSlBufferPips * g_pip));
         s += withTrend ? " Cùng xu thế → chờ M15/H1 thu nến hoặc LP cùng chiều rồi " + (z.dir > 0 ? "MUA" : "BÁN") + "."
                        : " NGƯỢC xu thế " + ZoTfName(z.tf) + " → dễ bị clear, chỉ quan sát.";
         if(z.tf >= 1440) Major(s); else Minor(s);
      }
      else if(InList(g_touched, key) && ZoDist(z, Bid) > 3 * InpTouchPips)
         RemoveFromList(g_touched, key);   // re-arm once price has left the LP
   }
}

//+------------------------------------------------------------------+
//| Analysis text                                                    |
//+------------------------------------------------------------------+
string TfReading(int tf)
{
   int di = DataIndex(tf);
   if(di < 0)
      return "";
   ZoTf d = g_d[di];
   if(d.source == ZO_SRC_NONE)
      return "\n[" + ZoTfName(tf) + "] không có dữ liệu → mở chart " + ZoTfName(tf) + " có ZOS + ZO_LP.";
   int code;
   int run = ZoColorRun(d, code);
   string s = "\n[" + ZoTfName(tf) + "] ZOS " + ZoColorName(code) + ", " + IntegerToString(run) + " nến" + ZoSourceNote(d) + ".";
   int tw = ZoTwoWickCount(d, 5);
   double br = ZoBodyRatio(d, 1, 3);
   if(tw >= 3)
      s += " Thu nến / nến 2 đầu (" + IntegerToString(tw) + "/5) → giảm áp lực, sắp có run.";
   else if(br < 0.6)
      s += " Thân nến ngắn dần → áp lực yếu đi.";
   else if(br > 1.6)
      s += " Thân nến dài ra → áp lực đang tăng.";
   datetime since;
   int tr = ZoMainTrend(g_all, tf, since);
   s += "\n  Xu thế Main: " + ZoTrendText(tr) + (since > 0 ? " (từ " + ZoDate(since) + ")" : "");
   int mg = ZoMainOf(g_all, tf, 1), mr = ZoMainOf(g_all, tf, -1);
   if(mg >= 0) s += " | Main mua " + ZoPx(g_all[mg].lo) + "-" + ZoPx(g_all[mg].hi) + " (" + ZoDate(g_all[mg].t0) + ")";
   if(mr >= 0) s += " | Main bán " + ZoPx(g_all[mr].lo) + "-" + ZoPx(g_all[mr].hi) + " (" + ZoDate(g_all[mr].t0) + ")";

   int at = ZoZoneAt(g_all, tf, Bid);
   if(at >= 0)
   {
      ZoZone z = g_all[at];
      double pos = (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100;
      if(z.dir == 0)
         s += StringFormat("\n  Giá trong %s chưa break (%.0f%%) → tranh chấp, không vào.", ZoZoneText(z), pos);
      else
         s += StringFormat("\n  Giá trong %s [%s] ở %.0f%% vùng.", ZoZoneText(z), ZoStateVi(z.state), pos);
   }
   int up = ZoNeighbour(g_all, tf, Bid, true), dn = ZoNeighbour(g_all, tf, Bid, false);
   s += "\n  Trên: " + (up >= 0 ? StringFormat("%s +%.0fp", ZoZoneText(g_all[up]), ZoDist(g_all[up], Bid)) : "trống");
   s += " | Dưới: " + (dn >= 0 ? StringFormat("%s -%.0fp", ZoZoneText(g_all[dn]), ZoDist(g_all[dn], Bid)) : "trống");
   if(up >= 0 && dn >= 0)
   {
      double room = (g_all[up].lo - g_all[dn].hi) / g_pip;
      if(room < 15)
         s += StringFormat(" → kẹp chật %.0f pip, dễ bị quét.", room);
   }
   return s;
}

// Nearest live LP of direction dir on timeframe tf at or on the pull-back side of price.
int PullbackZone(int dir, int tf)
{
   int best = -1;
   double bestD = 0;
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf != tf || z.dir != dir || !ZoIsAlive(z))
         continue;
      if(dir > 0 && z.lo > Bid) continue;
      if(dir < 0 && z.hi < Bid) continue;
      double dd = ZoDist(z, Bid);
      if(best < 0 || dd < bestD)
      {
         best = i;
         bestD = dd;
      }
   }
   return best;
}

// H4 -> M15 plan of the MAIN-AB / PULLBACK system.
string ZouBlock()
{
   string s = "\n\n▶ KẾ HOẠCH MAIN-AB / PULLBACK (H4 → M15)";
   if(!Reliable(240) || !Reliable(15))
      return s + ": thiếu dữ liệu H4 / M15 → mở chart H4 và M15 có ZOS + ZO_LP.";
   datetime since;
   int tr = ZoMainTrend(g_all, 240, since);
   if(tr == 0)
      return s + ": chưa có Main H4 → chưa có xu thế, không vào.";
   double age = (double)(TimeCurrent() - since) / 3600;
   string side = tr > 0 ? "MUA" : "BÁN";
   s += StringFormat(": Main H4 %s từ %s (%.0fh) → chỉ %s.", ZoTrendText(tr), ZoDate(since), age, side);
   datetime pu = PausedUntil(tr);
   if(pu > TimeCurrent())
   {
      datetime hn = ZoHanoi(pu);
      s += StringFormat(" ĐANG TẠM DỪNG %s tới %02d:%02d %d/%d (vừa thua %d lệnh liên tiếp).", side, TimeHour(hn), TimeMinute(hn),
                        TimeDay(hn), TimeMonth(hn), InpLossPause);
   }
   int z4 = PullbackZone(tr, 240);
   if(z4 >= 0)
   {
      ZoZone z = g_all[z4];
      double mid = (z.hi + z.lo) / 2;
      s += StringFormat("\n  MAIN-AB: nửa sâu %s = %s-%s (cách %.0fp)%s. Chờ nến ZO M15 A bị kéo ngược vào đó (râu ≥ thân), nến B hết râu kéo.",
                        ZoZoneText(z), ZoPx(tr > 0 ? z.lo : mid), ZoPx(tr > 0 ? mid : z.hi), ZoDist(z, Bid),
                        age >= 48 ? "" : StringFormat(" - Main mới %.0fh, MAIN-AB cần ≥ 48h", age));
   }
   else
      s += "\n  MAIN-AB: chưa có " + (tr > 0 ? "GLP" : "RLP") + " H4 phía " + (tr > 0 ? "dưới" : "trên") + " giá.";
   int z15 = PullbackZone(tr, 15);
   s += "\n  PULLBACK: mốc " + (z15 >= 0 ? ZoZoneText(g_all[z15]) + StringFormat(" (cách %.0fp)", ZoDist(g_all[z15], Bid)) : "LP M15 cùng chiều: chưa có") +
        " hoặc LP H4 cùng chiều. Chờ giá bị kéo ngược ≥ 15 pip vào mốc, 1 nến ZO râu kéo ≥ 5 pip, nến sau hết râu kéo.";
   for(int i = 0; i < ArraySize(g_all); i++)
      if((g_all[i].tf == 1440 || g_all[i].tf == 10080) && g_all[i].tMain > 0 && g_all[i].dir == -tr && ZoIsAlive(g_all[i]) &&
         Bid >= g_all[i].lo && Bid <= g_all[i].hi)
         s += "\n  ⛔ Giá đang trong " + ZoZoneText(g_all[i]) + " (Main " + ZoTfName(g_all[i].tf) + " ngược chiều) → không vào cho tới khi ra khỏi vùng.";
   s += "\n  Vào market khi nến M15 đóng; SL sau 4 nến +3 pip (10-15 pip, xa hơn thì bỏ); chốt 1R / giữa / xa LP H4 ngược; " +
        "BE ở 1R; phần còn lại giữ khi nến ZO M15 còn màu mạnh, không râu kéo ngược. Không vào 0-6h.";
   return s;
}

string BuildAnalysis(string title)
{
   datetime hn = ZoHanoiNow();
   string s = StringFormat("📊 %s %s — %02d:%02d %d/%d (Hà Nội) — giá %s", title, Symbol(), TimeHour(hn), TimeMinute(hn),
                           TimeDay(hn), TimeMonth(hn), ZoPx(Bid));
   for(int i = 0; i < ArraySize(g_tfs); i++)
      s += TfReading(g_tfs[i]);
   s += ZouBlock();
   s += NewsBlock();
   s += "\n\nNguyên tắc: chỉ theo Main H4 · không đuổi break · vào khi phe kéo ngược đã hết lực (nến ZO) · SL trước · " +
        "nội chiến / trước tin đỏ thì nghỉ.";
   return s;
}

//+------------------------------------------------------------------+
//| MAIN-AB / PULLBACK signals and trade hints                                      |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Rounds 59-66: extra blocks, spread-wide stops, risk by confidence |
//+------------------------------------------------------------------+
// Stops are widened by the spread above the spread the rules were fitted on.
void UpdateSlAdd()
{
   RefreshRates();
   g_zoSlAdd = InpSlSpreadAdj ? MathMax(0.0, (Ask - Bid) / g_pip - InpSlBaseSpread) : 0.0;
}

// The two blocks every entry kind obeys. why = text for the messages.
bool ExtraBlock(int d, double ep, string &why)
{
   why = "";
   if(InpMainLagBlock && InpMainLagDays > 0 && iBars(Symbol(), PERIOD_D1) > InpMainLagDays + 2)
   {
      datetime since;
      double move = (iClose(Symbol(), PERIOD_D1, 1) - iClose(Symbol(), PERIOD_D1, 1 + InpMainLagDays)) * d;
      if(ZoMainTrend(g_all, 240, since) == d && move < 0)
      {
         why = StringFormat("Main trễ: lệnh theo Main H4 nhưng %d ngày qua giá đã đi ngược %.0f pip", InpMainLagDays, -move / g_pip);
         return true;
      }
   }
   if(InpNoBuyInDwGlp && d > 0)
      for(int i = 0; i < ArraySize(g_all); i++)
         if((g_all[i].tf == 1440 || g_all[i].tf == 10080) && g_all[i].dir > 0 && ZoIsAlive(g_all[i]) && ep >= g_all[i].lo && ep <= g_all[i].hi)
         {
            why = "giá đang trong GLP " + ZoTfName(g_all[i].tf) + " " + ZoPx(g_all[i].lo) + "-" + ZoPx(g_all[i].hi) + " (không mua trong GLP D1 / W1)";
            return true;
         }
   return false;
}

// Closed entries of this EA, newest first (orders opened in the same M15 candle = one entry; an entry with an order
// still open does not count yet). out: +1 win, 0 flat, -1 loss (result beyond +-5 % of the money risked).
int EntryHistory(int &dirs[], int &outs[], int maxN)
{
   datetime bucket[], closed[];
   double profit[], risk[];
   int dir[];
   int n = 0;
   double tickVal = MarketInfo(Symbol(), MODE_TICKVALUE) * (g_pip / MarketInfo(Symbol(), MODE_TICKSIZE));
   datetime oldest = TimeCurrent() - 120 * 86400;
   for(int i = OrdersHistoryTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic || OrderType() > OP_SELL)
         continue;
      if(OrderCloseTime() < oldest)
         continue;
      datetime b = OrderOpenTime() / 900 * 900;
      int k = -1;
      for(int j = 0; j < n; j++)
         if(bucket[j] == b)
            k = j;
      if(k < 0)
      {
         k = n++;
         ArrayResize(bucket, n);
         ArrayResize(closed, n);
         ArrayResize(profit, n);
         ArrayResize(risk, n);
         ArrayResize(dir, n);
         bucket[k] = b;
         closed[k] = 0;
         profit[k] = 0;
         risk[k] = 0;
         dir[k] = OrderType() == OP_BUY ? 1 : -1;
      }
      string gv = "ZOAN_R_" + IntegerToString(OrderTicket());
      double rp = GlobalVariableCheck(gv) ? GlobalVariableGet(gv) : 10 * g_pip;
      profit[k] += OrderProfit() + OrderSwap() + OrderCommission();
      risk[k] += OrderLots() * rp / g_pip * tickVal;
      closed[k] = MathMax(closed[k], OrderCloseTime());
   }
   // an entry is finished only when none of its orders is still open
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic)
         continue;
      datetime b = OrderOpenTime() / 900 * 900;
      for(int j = 0; j < n; j++)
         if(bucket[j] == b)
            closed[j] = 0;
   }
   ArrayResize(dirs, 0);
   ArrayResize(outs, 0);
   int m = 0;
   while(m < maxN)
   {
      int best = -1;
      for(int j = 0; j < n; j++)
         if(closed[j] > 0 && (best < 0 || closed[j] > closed[best]))
            best = j;
      if(best < 0)
         break;
      ArrayResize(dirs, m + 1);
      ArrayResize(outs, m + 1);
      dirs[m] = dir[best];
      double r = risk[best] > 0 ? profit[best] / risk[best] : 0;
      outs[m] = r > 0.05 ? 1 : r < -0.05 ? -1 : 0;
      closed[best] = 0;
      m++;
   }
   return m;
}

// Risk of an entry in % of the balance and the text explaining it (round 65). The 7 confidence factors: last
// closed entry not a loss; last closed entry of this direction a win; own H4 LP a Shield; own LP 4-14 days old;
// opposite H4 LP ahead 20-50 pip away; the last 10 days sideways; stop below 13 pip (+ the spread allowance).
double RiskFor(int d, double ep, double slPips, string &note)
{
   note = "";
   if(InpRiskMode != 1)
      return InpRiskPct;
   int dirs[], outs[];
   int n = EntryHistory(dirs, outs, 30);
   int losses = 0;
   for(int i = 0; i < n; i++)
   {
      if(outs[i] < 0)
         losses++;
      else if(outs[i] > 0)
         break;
   }
   int cnt = 0;
   string yes = "";
   if(n == 0 || outs[0] >= 0)
   {
      cnt++;
      yes += ", lệnh trước không thua";
   }
   for(int i = 0; i < n; i++)
      if(dirs[i] == d)
      {
         if(outs[i] > 0)
         {
            cnt++;
            yes += ", lệnh cùng hướng trước thắng";
         }
         break;
      }
   // own LP: the live H4 LP of our side nearest to the entry (inside it or within 10 pip counts as "at" it)
   int own = -1;
   double ownGap = 0;
   double ahead = -1;
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      if(g_all[i].tf != 240 || !ZoIsAlive(g_all[i]) || g_all[i].dir == 0)
         continue;
      if(g_all[i].dir == d)
      {
         double gap = (ep >= g_all[i].lo - 10 * g_pip && ep <= g_all[i].hi + 10 * g_pip) ? 0 : MathMin(MathAbs(ep - g_all[i].hi), MathAbs(ep - g_all[i].lo));
         if(own < 0 || gap < ownGap)
         {
            own = i;
            ownGap = gap;
         }
      }
      else
      {
         double a = (d > 0 ? g_all[i].lo - ep : ep - g_all[i].hi) / g_pip;
         if(a > 0 && (ahead < 0 || a < ahead))
            ahead = a;
      }
   }
   if(own >= 0)
   {
      datetime tM;
      int iM = ZoLastMain(g_all, 240, d, tM);
      if(iM >= 0 && own != iM && g_all[own].tLast + 240 * 60 > tM)
      {
         cnt++;
         yes += ", LP của mình là Shield";
      }
      double ageH = (double)(TimeCurrent() - (g_all[own].tLast + 240 * 60)) / 3600.0;
      if(ageH >= 96 && ageH < 336)
      {
         cnt++;
         yes += ", LP 4-14 ngày tuổi";
      }
   }
   if(ahead > 20 && ahead <= 50)
   {
      cnt++;
      yes += StringFormat(", LP H4 ngược cách %.0f pip", ahead);
   }
   if(iBars(Symbol(), PERIOD_D1) > 13)
   {
      double path = 0;
      for(int s = 1; s <= 10; s++)
         path += MathAbs(iClose(Symbol(), PERIOD_D1, s) - iClose(Symbol(), PERIOD_D1, s + 1));
      if(path > 0 && MathAbs(iClose(Symbol(), PERIOD_D1, 1) - iClose(Symbol(), PERIOD_D1, 11)) / path < 0.15)
      {
         cnt++;
         yes += ", 10 ngày qua đi ngang";
      }
   }
   if(slPips < 13 + g_zoSlAdd)
   {
      cnt++;
      yes += ", SL gọn";
   }
   double pct = cnt >= InpRiskHighFactors ? InpRiskHigh : InpRiskBase;
   string cut = "";
   if(InpRiskLossStreak > 0 && losses >= InpRiskLossStreak)
   {
      pct = MathMax(InpRiskMin, pct - InpRiskLossCut);
      cut = StringFormat("; đang thua %d lệnh liên tiếp nên trừ %.1f%%", losses, InpRiskLossCut);
   }
   pct = MathMax(InpRiskMin, MathMin(5.0, pct));
   note = StringFormat("Rủi ro %.1f%%: %d/7 yếu tố tin cậy%s%s", pct, cnt, yes == "" ? "" : " (" + StringSubstr(yes, 2) + ")", cut);
   return pct;
}

void CheckSignal()
{
   int di = DataIndex(15);
   datetime bar = iTime(Symbol(), PERIOD_M15, 1);
   if(di < 0 || bar == g_lastSigBar || !Reliable(15) || !Reliable(240))
      return;
   if(g_d[di].lastBar < bar)
      return;   // ZO_LP on the M15 chart has not written this candle yet
   g_lastSigBar = bar;
   UpdateOutcomes();
   UpdateSlAdd();
   if(InpEpSignals)
      CheckEP(di);
   ZoSignal sig;
   if(!ZoCheckTrendEntry(g_all, g_d[di], g_d[DataIndex(240)], sig))
      return;
   if(InpH4Veto && ZoH4Against(g_d[DataIndex(240)], sig.dir))
   {
      Print(ZoUnaccent("ZO_Analyst: bỏ tín hiệu " + (sig.dir > 0 ? "BUY" : "SELL") + " (nến ZOS H4 vừa đóng màu mạnh ngược)"));
      return;
   }
   string blockWhy;
   if(ExtraBlock(sig.dir, sig.ep, blockWhy))
   {
      Print(ZoUnaccent("ZO_Analyst: bỏ tín hiệu " + (sig.dir > 0 ? "BUY" : "SELL") + " " + sig.kind + " (" + blockWhy + ")"));
      if(InpMsgLevel == 0)
         Send("⛔ " + Symbol() + ": bỏ tín hiệu " + (sig.dir > 0 ? "BUY" : "SELL") + " " + sig.kind + " — " + blockWhy + ".");
      return;
   }
   if(InpNews)
   {
      int nk = ZoNewsActive(InpNewsCurrencies, InpNewsMinImpact, InpNewsBlockMin, InpNewsBlockMin, TimeGMT());
      if(nk >= 0)
      {
         Send("📰 " + Symbol() + ": bỏ tín hiệu " + (sig.dir > 0 ? "BUY" : "SELL") + " vì đang trong khung tin " + ZoNewsText(nk) +
              StringFormat(" (±%d phút).", InpNewsBlockMin));
         return;
      }
   }
   if(InpLossPause > 0 && PausedUntil(sig.dir) > TimeCurrent())
   {
      Print(ZoUnaccent("ZO_Analyst: bỏ qua tín hiệu " + (sig.dir > 0 ? "BUY" : "SELL") + " (đang tạm dừng hướng này)"));
      return;
   }
   // Re-attaching the EA must not resend the same signal.
   string gv = "ZOAN_SIG_" + Symbol();
   if(GlobalVariableCheck(gv) && (datetime)GlobalVariableGet(gv) >= sig.barTime)
      return;
   GlobalVariableSet(gv, (double)sig.barTime);
   double slPips = MathAbs(sig.ep - sig.sl) / g_pip;
   double tickVal = MarketInfo(Symbol(), MODE_TICKVALUE) * (g_pip / MarketInfo(Symbol(), MODE_TICKSIZE));
   string riskNote;
   double riskPct = RiskFor(sig.dir, sig.ep, slPips, riskNote);
   double lots = tickVal > 0 ? AccountBalance() * riskPct / 100 / (slPips * tickVal) : 0;
   datetime hn = ZoHanoi(sig.barTime + 900);
   string msg = StringFormat("🎯 TÍN HIỆU %s %s (%s) — nến M15 đóng %02d:%02d %d/%d\nVào market ~%s | SL %s (%.1f pip) | lot gợi ý %.2f (%.1f%%)",
                             sig.dir > 0 ? "BUY" : "SELL", Symbol(), sig.kind, TimeHour(hn), TimeMinute(hn), TimeDay(hn),
                             TimeMonth(hn), ZoPx(sig.ep), ZoPx(sig.sl), slPips, lots, riskPct);
   if(riskNote != "")
      msg += "\n" + riskNote;
   for(int k = 0; k < sig.ntp; k++)
      msg += StringFormat("\nTP%d %s (%.1fR)%s", k + 1, ZoPx(sig.tp[k]), MathAbs(sig.tp[k] - sig.ep) / MathAbs(sig.ep - sig.sl),
                          sig.ntp > 1 ? StringFormat(" - chốt 1/%d", sig.ntp) : "");
   if(lots < 0.03)
   {
      double one = ZoSmallTarget(g_all, sig);
      msg += StringFormat("\nLot < 0.03 (không chia 3 phần được): đặt 1 TP ở %s (%.1fR) thay cho 3 TP trên.", ZoPx(one),
                          MathAbs(one - sig.ep) / MathAbs(sig.ep - sig.sl));
   }
   msg += "\nLý do: " + sig.why + ".\nQuản lý: BE khi đi được 1R; " + HoldText() + ". Giá đã chạy xa giá vào > 3 pip thì bỏ, không đuổi.";
   msg += "\n\nLP H4" + LpList(240, 6);
   Send(msg);
   if(InpDrawSignals)
      DrawSignal(sig);
   if(AutoOn())
      AutoTrade(sig);
   int k = ArraySize(g_sDir);
   ArrayResize(g_sDir, k + 1);
   ArrayResize(g_sEp, k + 1);
   ArrayResize(g_sSl, k + 1);
   ArrayResize(g_sBar, k + 1);
   g_sDir[k] = sig.dir;
   g_sEp[k] = sig.ep;
   g_sSl[k] = sig.sl;
   g_sBar[k] = sig.barTime;
}

string   PauseKey(int d)  { return "ZOAN_PAUSE_" + Symbol() + (d > 0 ? "_BUY" : "_SELL"); }
string   StreakKey(int d) { return "ZOAN_LOSSES_" + Symbol() + (d > 0 ? "_BUY" : "_SELL"); }
datetime PausedUntil(int d) { return GlobalVariableCheck(PauseKey(d)) ? (datetime)GlobalVariableGet(PauseKey(d)) : 0; }

// Resolves the signals sent: a loss when the SL is touched before price went 1R our way (a candle touching both
// counts as a loss, as in the backtest). InpLossPause straight losses in one direction pause it.
void UpdateOutcomes()
{
   for(int k = ArraySize(g_sDir) - 1; k >= 0; k--)
   {
      int d = g_sDir[k];
      double risk = MathAbs(g_sEp[k] - g_sSl[k]);
      int from = iBarShift(Symbol(), PERIOD_M15, g_sBar[k]) - 1;   // candles after the signal candle
      int result = 0;   // -1 loss, +1 safe (1R reached)
      datetime at = 0;
      for(int sft = from; sft >= 1 && result == 0; sft--)
      {
         double h = iHigh(Symbol(), PERIOD_M15, sft), l = iLow(Symbol(), PERIOD_M15, sft);
         bool slHit = d > 0 ? l <= g_sSl[k] : h >= g_sSl[k];
         bool oneR = d > 0 ? h >= g_sEp[k] + risk : l <= g_sEp[k] - risk;
         if(slHit)       { result = -1; at = iTime(Symbol(), PERIOD_M15, sft) + 900; }
         else if(oneR)   result = 1;
      }
      if(result == 0)
         continue;
      if(result > 0)
         GlobalVariableSet(StreakKey(d), 0);
      else
      {
         double n = (GlobalVariableCheck(StreakKey(d)) ? GlobalVariableGet(StreakKey(d)) : 0) + 1;
         GlobalVariableSet(StreakKey(d), n);
         if(InpLossPause > 0 && n >= InpLossPause)
         {
            datetime until = at + InpPauseHours * 3600;
            GlobalVariableSet(PauseKey(d), (double)until);
            GlobalVariableSet(StreakKey(d), 0);
            datetime hn = ZoHanoi(until);
            Send(StringFormat("⏸ %s: thua %d tín hiệu %s liên tiếp → tạm dừng %s tới %02d:%02d %d/%d (Main H4 có thể đang trễ so với giá).",
                              Symbol(), (int)n, d > 0 ? "BUY" : "SELL", d > 0 ? "BUY" : "SELL", TimeHour(hn), TimeMinute(hn),
                              TimeDay(hn), TimeMonth(hn)));
         }
      }
      int last = ArraySize(g_sDir) - 1;
      g_sDir[k] = g_sDir[last];
      g_sEp[k] = g_sEp[last];
      g_sSl[k] = g_sSl[last];
      g_sBar[k] = g_sBar[last];
      ArrayResize(g_sDir, last);
      ArrayResize(g_sEp, last);
      ArrayResize(g_sSl, last);
      ArrayResize(g_sBar, last);
   }
}

void DrawSignal(const ZoSignal &sig)
{
   string base = "ZOAN_SIG_" + IntegerToString((long)sig.barTime);
   datetime t0 = sig.barTime, t1 = sig.barTime + 8 * 3600;
   color clr = sig.dir > 0 ? clrDodgerBlue : clrOrange;
   ObjectCreate(0, base + "a", OBJ_ARROW, 0, t0, sig.ep);
   ObjectSetInteger(0, base + "a", OBJPROP_ARROWCODE, sig.dir > 0 ? 233 : 234);
   ObjectSetInteger(0, base + "a", OBJPROP_COLOR, clr);
   ObjectSetInteger(0, base + "a", OBJPROP_WIDTH, 2);
   ObjectSetInteger(0, base + "a", OBJPROP_ANCHOR, sig.dir > 0 ? ANCHOR_TOP : ANCHOR_BOTTOM);
   ObjectSetString(0, base + "a", OBJPROP_TOOLTIP, ZoUnaccent(sig.kind + ": " + sig.why));
   string names[4];
   double px[4];
   names[0] = "SL";
   px[0] = sig.sl;
   for(int k = 0; k < sig.ntp; k++)
   {
      names[k + 1] = "TP" + IntegerToString(k + 1);
      px[k + 1] = sig.tp[k];
   }
   for(int k = 0; k <= sig.ntp; k++)
   {
      string n = base + names[k];
      ObjectCreate(0, n, OBJ_TREND, 0, t0, px[k], t1, px[k]);
      ObjectSetInteger(0, n, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, n, OBJPROP_COLOR, k == 0 ? clrRed : clrLime);
      ObjectSetInteger(0, n, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetString(0, n, OBJPROP_TOOLTIP, names[k] + " " + ZoPx(px[k]));
   }
}

//+------------------------------------------------------------------+
//| Auto trading (demo accounts by default)                          |
//+------------------------------------------------------------------+
// Management line of the signal messages, per hold mode.
string HoldText()
{
   if(InpHoldMode != 1)
      return "tới TP mà nến ZO M15 còn màu mạnh, không râu kéo ngược thì giữ, hết mạnh thì chốt";
   string s = "tới TP thì giữ tới khi có nến ZO M15 màu ngược rồi chốt";
   if(InpTpProfile == 0)
      s = "TP1 chốt hẳn; TP2, TP3: " + s;
   else if(InpHoldLockR > 0)
      s += StringFormat("; khi bắt đầu giữ thì kéo SL lên +%.1fR", InpHoldLockR);
   return s;
}

// Part k of an entry may be held past its target: all parts with the LP targets, parts 2-3 with the 1R-first targets
// (the 1R target is always banked) - as in the backtest systems ZO-FLEX.
bool Holdable(int k)
{
   return InpHoldMode == 1 && k >= (InpTpProfile == 0 ? 1 : 0);
}

// Orders are placed on demo accounts; a real account only gets signals unless InpAllowRealAccount is set.
bool AutoOn()
{
   return InpAutoTrade && (IsDemo() || InpAllowRealAccount);
}

bool AutoAllowed(string &why)
{
   why = "";
   if(!IsDemo() && !InpAllowRealAccount)
      why = "tài khoản THẬT - bật InpAllowRealAccount nếu thật sự muốn tự đặt lệnh";
   else if(!IsTradeAllowed())
      why = "MT4 chưa cho phép trade (nút AutoTrading / Allow live trading)";
   else if(!IsConnected())
      why = "mất kết nối";
   return why == "";
}

// Open entries of this EA: orders sharing the same open time bucket count as one entry.
int AutoOpenEntries()
{
   datetime seen[];
   ArrayResize(seen, 0);
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic || OrderType() > OP_SELL)
         continue;
      datetime b = OrderOpenTime() / 900 * 900;
      bool dup = false;
      for(int k = 0; k < ArraySize(seen); k++)
         if(seen[k] == b)
            dup = true;
      if(!dup)
      {
         int n = ArraySize(seen);
         ArrayResize(seen, n + 1);
         seen[n] = b;
      }
   }
   return ArraySize(seen);
}

// Places the signal as market orders: the position is split into one order per target (MT4 has no partial take
// profit), each with the signal's SL. Too small to split -> one order with the single "small lot" target.
void AutoTrade(const ZoSignal &sig)
{
   string why;
   int d = sig.dir;
   string side = d > 0 ? "BUY" : "SELL";
   if(!AutoAllowed(why))
   {
      Send("🤖 Không tự đặt lệnh " + side + " " + sig.kind + ": " + why + ".");
      return;
   }
   RefreshRates();
   double spread = (Ask - Bid) / g_pip;
   double drift = (Bid - sig.ep) * d / g_pip;
   double price = d > 0 ? Ask : Bid;
   double slPips = MathAbs(price - sig.sl) / g_pip;
   if(spread > InpMaxSpreadPips)
      why = StringFormat("spread %.1f pip > %.1f", spread, InpMaxSpreadPips);
   else if(drift > InpMaxDriftPips)
      why = StringFormat("giá đã chạy %.1f pip khỏi giá tín hiệu", drift);
   else if((price - sig.sl) * d < 5 * g_pip)
      why = "giá đã về quá gần SL";
   else if(AutoOpenEntries() >= InpMaxOpenTrades)
      why = StringFormat("đang có %d lệnh mở (tối đa %d)", AutoOpenEntries(), InpMaxOpenTrades);
   if(why != "")
   {
      Send("🤖 Bỏ lệnh " + side + " " + sig.kind + ": " + why + ".");
      return;
   }
   double tickVal = MarketInfo(Symbol(), MODE_TICKVALUE) * (g_pip / MarketInfo(Symbol(), MODE_TICKSIZE));
   double step = MarketInfo(Symbol(), MODE_LOTSTEP), minLot = MarketInfo(Symbol(), MODE_MINLOT), maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   if(tickVal <= 0 || step <= 0)
   {
      Send("🤖 Không tính được lot (thiếu thông tin symbol) - không đặt lệnh.");
      return;
   }
   string riskNote;
   double riskPct = RiskFor(d, sig.ep, MathAbs(sig.ep - sig.sl) / g_pip, riskNote);
   double total = AccountBalance() * riskPct / 100 / (slPips * tickVal);
   int n = sig.ntp;
   double per = MathFloor(total / n / step + 1e-9) * step;
   double tps[3];
   ArrayInitialize(tps, 0);
   for(int k = 0; k < sig.ntp; k++)
      tps[k] = sig.tp[k];
   if(per < minLot)
   {
      // Cannot split: one order, single target (backtest rule for 0.01-0.02 lot).
      n = 1;
      per = MathFloor(total / step + 1e-9) * step;
      tps[0] = sig.ntp > 1 ? ZoSmallTarget(g_all, sig) : sig.tp[0];
   }
   if(per < minLot)
   {
      Send(StringFormat("🤖 Bỏ lệnh %s %s: lot tối thiểu %.2f vượt mức rủi ro %.1f%% (SL %.1f pip).", side, sig.kind, minLot, riskPct, slPips));
      return;
   }
   per = MathMin(per, maxLot);
   int digits = (int)MarketInfo(Symbol(), MODE_DIGITS);
   double sl = NormalizeDouble(sig.sl, digits);
   string done = "";
   int opened = 0;
   for(int k = 0; k < n; k++)
   {
      RefreshRates();
      price = d > 0 ? Ask : Bid;
      double tp = NormalizeDouble(tps[k], digits);
      double target = tp;
      if(Holdable(k))
         tp = 0;   // held parts carry no TP order: ManageHold() closes them at an M15 close
      ResetLastError();
      int ticket = OrderSend(Symbol(), d > 0 ? OP_BUY : OP_SELL, per, price, InpSlippagePoints, sl, tp, "ZO " + sig.kind, InpMagic, 0,
                             d > 0 ? clrDodgerBlue : clrOrange);
      if(ticket < 0 && GetLastError() == 130)
      {
         // Brokers that refuse stops on a market order: open first, then set SL / TP.
         ticket = OrderSend(Symbol(), d > 0 ? OP_BUY : OP_SELL, per, price, InpSlippagePoints, 0, 0, "ZO " + sig.kind, InpMagic, 0,
                            d > 0 ? clrDodgerBlue : clrOrange);
         if(ticket > 0 && OrderSelect(ticket, SELECT_BY_TICKET))
            if(!OrderModify(ticket, OrderOpenPrice(), sl, tp, 0))
               done += StringFormat("\n⚠ #%d mở được nhưng CHƯA đặt được SL / TP (lỗi %d) - đặt tay ngay!", ticket, GetLastError());
      }
      if(ticket < 0)
      {
         done += StringFormat("\n✖ phần %d: lỗi %d", k + 1, GetLastError());
         continue;
      }
      opened++;
      GlobalVariableSet("ZOAN_R_" + IntegerToString(ticket), MathAbs(price - sig.sl));
      if(tp == 0)
         GlobalVariableSet("ZOAN_TG_" + IntegerToString(ticket), target);
      done += StringFormat("\n#%d %.2f lot @%s %s %s", ticket, per, ZoPx(price), tp == 0 ? "đích (giữ theo nến)" : "TP", ZoPx(target));
   }
   Send(StringFormat("🤖 %s %s %s — %d/%d lệnh, SL %s (%.1f pip), rủi ro ~%.1f%%%s", opened > 0 ? "ĐÃ ĐẶT" : "KHÔNG ĐẶT ĐƯỢC", side, sig.kind,
                     opened, n, ZoPx(sl), slPips, per * opened * slPips * tickVal / MathMax(AccountBalance(), 1) * 100, done));
}

// Hold mode: the EA's orders without a TP order. At every M15 close: an order whose target was touched is kept
// ("armed") while the M15 ZOS candle is not of the other side's colour, else closed at market; an armed order is
// closed at the first candle of the other side's colour. When an order gets armed, the SL of every order of that
// entry is raised to +InpHoldLockR x R (LP targets).
datetime g_lastHoldBar = 0;

void ManageHold()
{
   int di = DataIndex(15);
   datetime bar = iTime(Symbol(), PERIOD_M15, 1);
   if(InpHoldMode != 1 || di < 0 || bar == g_lastHoldBar || !Reliable(15) || g_d[di].lastBar < bar)
      return;
   g_lastHoldBar = bar;
   double hi = iHigh(Symbol(), PERIOD_M15, 1), lo = iLow(Symbol(), PERIOD_M15, 1);
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic || OrderType() > OP_SELL)
         continue;
      int ticket = OrderTicket();
      string gvT = "ZOAN_TG_" + IntegerToString(ticket), gvA = "ZOAN_ARM_" + IntegerToString(ticket);
      if(!GlobalVariableCheck(gvT) || OrderOpenTime() >= bar + 900)
         continue;
      int d = OrderType() == OP_BUY ? 1 : -1;
      double target = GlobalVariableGet(gvT);
      RefreshRates();
      double px = d > 0 ? Bid : Ask;
      bool armed = GlobalVariableCheck(gvA);
      bool touched = d > 0 ? (hi >= target || px >= target) : (lo + (Ask - Bid) <= target || px <= target);
      if(!armed && !touched)
         continue;
      bool hold = ZoHoldOn(g_d[di], d);
      string side = d > 0 ? "BUY" : "SELL";
      if(!hold)
      {
         if(OrderClose(ticket, OrderLots(), px, InpSlippagePoints))
         {
            Send(StringFormat("🤖 #%d %s: %s, nến ZO M15 màu ngược → chốt @%s (đích %s).", ticket, side,
                              armed ? "đang giữ qua đích" : "chạm đích", ZoPx(px), ZoPx(target)));
            GlobalVariableDel(gvT);
            GlobalVariableDel(gvA);
         }
         continue;
      }
      if(armed)
         continue;
      GlobalVariableSet(gvA, (double)bar);
      Send(StringFormat("🤖 #%d %s: chạm đích %s, nến ZO M15 chưa đổi màu → giữ tiếp.", ticket, side, ZoPx(target)));
      if(InpHoldLockR <= 0 || InpTpProfile == 0)
         continue;
      // Lock profit on every order of this entry (same M15 candle, same direction).
      datetime bucket = OrderOpenTime() / 900 * 900;
      int type = OrderType();
      for(int j = OrdersTotal() - 1; j >= 0; j--)
      {
         if(!OrderSelect(j, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic || OrderType() != type ||
            OrderOpenTime() / 900 * 900 != bucket)
            continue;
         string gvR = "ZOAN_R_" + IntegerToString(OrderTicket());
         double risk = GlobalVariableCheck(gvR) ? GlobalVariableGet(gvR) : 0;
         double lock = NormalizeDouble(OrderOpenPrice() + d * InpHoldLockR * risk, Digits);
         double stop = MarketInfo(Symbol(), MODE_STOPLEVEL) * Point;
         if(risk <= 0 || (OrderStopLoss() > 0 && (OrderStopLoss() - lock) * d >= 0) || (px - lock) * d <= stop)
            continue;
         if(OrderModify(OrderTicket(), OrderOpenPrice(), lock, OrderTakeProfit(), 0))
            Send(StringFormat("🤖 #%d %s: khoá lời, SL lên %s (+%.1fR).", OrderTicket(), side, ZoPx(lock), InpHoldLockR));
      }
   }
}

// The EA's own orders: SL to the entry price at 1R, close on Friday night.
void ManageAuto()
{
   ManageHold();
   datetime hn = ZoHanoiNow();
   bool friday = InpAutoFridayClose && TimeDayOfWeek(hn) == 5 && TimeHour(hn) >= 22;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != InpMagic || OrderType() > OP_SELL)
         continue;
      int d = OrderType() == OP_BUY ? 1 : -1;
      int ticket = OrderTicket();
      RefreshRates();
      double px = d > 0 ? Bid : Ask;
      if(friday)
      {
         if(OrderClose(ticket, OrderLots(), px, InpSlippagePoints))
            Send(StringFormat("🤖 Đóng cuối tuần #%d %s @%s", ticket, d > 0 ? "BUY" : "SELL", ZoPx(px)));
         continue;
      }
      if(!InpAutoBE)
         continue;
      string gv = "ZOAN_R_" + IntegerToString(ticket);
      double risk = GlobalVariableCheck(gv) ? GlobalVariableGet(gv) : MathAbs(OrderOpenPrice() - OrderStopLoss());
      bool atBe = OrderStopLoss() > 0 && (OrderStopLoss() - OrderOpenPrice()) * d >= 0;
      // LP-AB entries (order comment "ZO LP-AB") get their break-even later: at 1R many of them were stopped flat and ran after.
      bool lpAb = StringFind(OrderComment(), "LP-AB") >= 0 || StringFind(OrderComment(), "EPA") >= 0;   // "EPA" = the old name
      double beR = lpAb ? MathMax(InpLpAbBeR, 1.0) : 1.0;
      if(risk <= 0 || atBe || (px - OrderOpenPrice()) * d < beR * risk)
         continue;
      double stop = MarketInfo(Symbol(), MODE_STOPLEVEL) * Point;
      if((px - OrderOpenPrice()) * d <= stop)
         continue;
      if(OrderModify(ticket, OrderOpenPrice(), NormalizeDouble(OrderOpenPrice(), Digits), OrderTakeProfit(), 0))
         Send(StringFormat("🤖 #%d %s: đã dời SL về BE %s (giá đi được %.1fR).", ticket, d > 0 ? "BUY" : "SELL", ZoPx(OrderOpenPrice()), beR));
   }
}

//+------------------------------------------------------------------+
//| Orders opened by hand                                            |
//+------------------------------------------------------------------+
#define GV_MANUAL "ZOAN_M_"

// Modifying somebody's order is a trade operation: demo accounts, or a real one explicitly allowed.
bool ManualMayModify()
{
   return (IsDemo() || InpAllowRealAccount) && IsTradeAllowed() && IsConnected();
}

// SL behind the last M15 swing (clamped), TP at the near end of the next H4 LP ahead (not of our side) when it
// leaves InpManualTpMinRR, else InpManualTpFallbackR x risk. Round 38: this plan cost the least on entries
// without an edge and kept most of a real run.
void ManualPlan(int d, double ep, double &sl, double &tp, string &slWhy, string &tpWhy)
{
   RefreshRates();
   double spread = Ask - Bid;
   int n = MathMax(2, InpManualSwingBars);
   double ext = d > 0 ? iLow(Symbol(), PERIOD_M15, iLowest(Symbol(), PERIOD_M15, MODE_LOW, n, 0))
                      : iHigh(Symbol(), PERIOD_M15, iHighest(Symbol(), PERIOD_M15, MODE_HIGH, n, 0));
   sl = d > 0 ? ext - InpManualSlPadPips * g_pip : ext + InpManualSlPadPips * g_pip + spread;
   double dist = (ep - sl) * d;
   slWhy = StringFormat("sau %s %d nến M15 gần nhất (%s) %.0f pip", d > 0 ? "đáy" : "đỉnh", n, ZoPx(ext), InpManualSlPadPips);
   if(dist < InpManualSlMinPips * g_pip)
   {
      dist = InpManualSlMinPips * g_pip;
      slWhy += StringFormat(", nới ra tối thiểu %.0f pip", InpManualSlMinPips);
   }
   else if(dist > InpManualSlMaxPips * g_pip)
   {
      dist = InpManualSlMaxPips * g_pip;
      slWhy = StringFormat("%s đã xa quá → giới hạn %.0f pip", d > 0 ? "đáy" : "đỉnh", InpManualSlMaxPips);
   }
   sl = NormalizeDouble(ep - d * dist, Digits);
   double nearE = 0, mid = 0, farE = 0;
   tp = 0;
   if(Reliable(240) && ZoOppositeH4(g_all, d, ep, nearE, mid, farE))
   {
      double t = nearE - d * 2 * g_pip;
      if((t - ep) * d >= InpManualTpMinRR * dist)
      {
         tp = t;
         tpWhy = "trước mép gần LP H4 cản phía trước (" + ZoPx(nearE) + ") 2 pip";
      }
      else
         tpWhy = StringFormat("LP H4 cản (%s) chỉ cách %.1fR → lấy %.1fR", ZoPx(nearE), (nearE - ep) * d / dist, InpManualTpFallbackR);
   }
   else
      tpWhy = StringFormat("không có LP H4 cản phía trước → %.1fR", InpManualTpFallbackR);
   if(tp == 0)
      tp = ep + d * InpManualTpFallbackR * dist;
   tp = NormalizeDouble(tp, Digits);
}

// What the chart says about a trade in direction d right now (for the report of a manual order).
string ManualContext(int d)
{
   string s = "";
   int i4 = DataIndex(240), i15 = DataIndex(15);
   if(i4 < 0 || i15 < 0 || !Reliable(240))
      return "\n(chưa có dữ liệu LP H4 - cần chart H4 có ZOS + ZO_LP)";
   string fb[], fs[];
   double buyPct = ZoBias(g_all, g_d[i4], g_d[i15], Bid, fb, fs);
   s += StringFormat("\nThiên hướng theo ZO: BUY %.0f%% / SELL %.0f%%", buyPct, 100 - buyPct);
   s += "\n✅ Ủng hộ:" + (d > 0 ? (ArraySize(fb) > 0 ? Bullets(fb, "•") : " (không có)") : (ArraySize(fs) > 0 ? Bullets(fs, "•") : " (không có)"));
   string warn = "";
   datetime since;
   int main4 = ZoMainTrend(g_all, 240, since);
   if(main4 == -d)
      warn += "\n• ngược Main H4 (Q10)";
   if(ZoH4Against(g_d[i4], d))
      warn += "\n• nến ZOS H4 vừa đóng màu mạnh ngược";
   // Round 38: the worst place of all swing entries - buying the dear end / selling the cheap end of the last 5 days.
   int hh = iHighest(Symbol(), PERIOD_H4, MODE_HIGH, 30, 1), ll = iLowest(Symbol(), PERIOD_H4, MODE_LOW, 30, 1);
   double hi = iHigh(Symbol(), PERIOD_H4, hh), lo = iLow(Symbol(), PERIOD_H4, ll);
   if(hi > lo)
   {
      double pos = (Bid - lo) / (hi - lo);
      if(d < 0)
         pos = 1 - pos;
      if(pos > 0.8)
         warn += StringFormat("\n• %s của biên độ 5 ngày (%.0f%%)", d > 0 ? "mua ở vùng đắt" : "bán ở vùng rẻ", pos * 100);
   }
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == 240 && ZoIsAlive(g_all[i]) && g_all[i].dir == -d && Bid >= g_all[i].lo && Bid <= g_all[i].hi)
      {
         warn += "\n• giá đang trong " + ZoShortName(g_all[i]) + " ngược chiều (nội chiến)";
         break;
      }
   datetime hn = ZoHanoiNow();
   if(TimeHour(hn) < 6)
      warn += "\n• giờ khuya (0-6h)";
   if(InpNews)
   {
      int nk = ZoNewsActive(InpNewsCurrencies, InpNewsMinImpact, InpNewsBlockMin, InpNewsBlockMin, TimeGMT());
      if(nk >= 0)
         warn += "\n• đang trong khung tin " + ZoNewsText(nk);
   }
   s += "\n⚠️ Không ủng hộ:" + (warn == "" ? " (không có)" : warn);
   return s;
}

// A new manual order: fill in the missing SL / TP and report it.
void ManualOpen(int ticket)
{
   if(!OrderSelect(ticket, SELECT_BY_TICKET))
      return;
   int d = OrderType() == OP_BUY ? 1 : -1;
   double ep = OrderOpenPrice(), lots = OrderLots();
   double sl, tp;
   string slWhy, tpWhy;
   ManualPlan(d, ep, sl, tp, slWhy, tpWhy);
   bool hadSl = OrderStopLoss() > 0, hadTp = OrderTakeProfit() > 0;
   if(InpManualKeepStops && hadSl)
   {
      sl = OrderStopLoss();
      slWhy = "bạn đã đặt";
      // The TP follows the SL actually used.
      double dist0 = (ep - sl) * d;
      if(dist0 > 0 && !hadTp)
      {
         double nearE = 0, mid = 0, farE = 0;
         tp = 0;
         if(Reliable(240) && ZoOppositeH4(g_all, d, ep, nearE, mid, farE) && (nearE - d * 2 * g_pip - ep) * d >= InpManualTpMinRR * dist0)
         {
            tp = nearE - d * 2 * g_pip;
            tpWhy = "trước mép gần LP H4 cản phía trước (" + ZoPx(nearE) + ") 2 pip";
         }
         else
         {
            tp = ep + d * InpManualTpFallbackR * dist0;
            tpWhy = StringFormat("%.1fR theo SL của bạn", InpManualTpFallbackR);
         }
         tp = NormalizeDouble(tp, Digits);
      }
   }
   if(InpManualKeepStops && hadTp)
   {
      tp = OrderTakeProfit();
      tpWhy = "bạn đã đặt";
   }
   double dist = (ep - sl) * d;
   // Stops must respect the broker's minimum distance from the current price.
   RefreshRates();
   double stopLv = MarketInfo(Symbol(), MODE_STOPLEVEL) * Point;
   double px = d > 0 ? Bid : Ask;
   string act = "";
   bool need = MathAbs(sl - OrderStopLoss()) > Point / 2 || MathAbs(tp - OrderTakeProfit()) > Point / 2;
   if(!need)
      act = "SL / TP giữ nguyên như bạn đặt.";
   else if(!ManualMayModify())
      act = IsDemo() || InpAllowRealAccount ? "⚠️ MT4 chưa cho phép EA trade (nút AutoTrading) → bạn tự đặt SL / TP như trên."
                                              : "⚠️ Tài khoản THẬT: EA không tự sửa lệnh → bạn tự đặt SL / TP như trên.";
   else if((px - sl) * d <= stopLv || (tp - px) * d <= stopLv)
      act = "⚠️ Giá đã quá gần SL / TP dự tính → không đặt được, bạn tự xử lý.";
   else if(OrderModify(ticket, ep, sl, tp, 0))
      act = "🤖 Đã đặt SL / TP vào lệnh.";
   else
      act = StringFormat("⚠️ Không sửa được lệnh (lỗi %d) → bạn tự đặt SL / TP.", GetLastError());
   double tickVal = MarketInfo(Symbol(), MODE_TICKVALUE) * (g_pip / MarketInfo(Symbol(), MODE_TICKSIZE));
   double riskMoney = dist / g_pip * tickVal * lots;
   double riskPct = AccountBalance() > 0 ? 100 * riskMoney / AccountBalance() : 0;
   string msg = StringFormat("✍️ LỆNH TAY #%d %s %s %.2f lot @%s", ticket, d > 0 ? "BUY" : "SELL", Symbol(), lots, ZoPx(ep));
   msg += StringFormat("\nSL %s (%.1f pip) — %s", ZoPx(sl), dist / g_pip, slWhy);
   msg += StringFormat("\nTP %s (%.1f pip = %.1fR) — %s", ZoPx(tp), (tp - ep) * d / g_pip, dist > 0 ? (tp - ep) * d / dist : 0, tpWhy);
   msg += StringFormat("\nRủi ro %.2f %s = %.1f%% số dư%s", riskMoney, AccountCurrency(), riskPct,
                       riskPct > (InpRiskMode == 1 ? InpRiskHigh : InpRiskPct) * 1.2 ? StringFormat(" ⚠️ vượt mức %.1f%% bạn đặt", InpRiskMode == 1 ? InpRiskHigh : InpRiskPct) : "");
   if(InpManualBeR > 0)
      msg += StringFormat("\nBE: dời SL về giá vào khi giá đi %.1fR (%s)", InpManualBeR, ZoPx(ep + d * InpManualBeR * dist));
   msg += "\n" + act;
   msg += ManualContext(d);
   Send(msg);
   GlobalVariableSet(GV_MANUAL + IntegerToString(ticket), dist);            // initial risk in price
   GlobalVariableSet("ZOAN_R_" + IntegerToString(ticket), dist);            // shared with the hints
}

// A managed manual order was closed: report the result and forget it.
void ManualClosed(int ticket, double risk)
{
   if(OrderSelect(ticket, SELECT_BY_TICKET, MODE_HISTORY) && OrderCloseTime() > 0)
   {
      int d = OrderType() == OP_BUY ? 1 : -1;
      double pips = (OrderClosePrice() - OrderOpenPrice()) * d / g_pip;
      double money = OrderProfit() + OrderSwap() + OrderCommission();
      Send(StringFormat("%s LỆNH TAY #%d %s đã đóng @%s: %+.1f pip (%+.2fR), %+.2f %s", money > 0 ? "✅" : money < 0 ? "❌" : "➖",
                        ticket, d > 0 ? "BUY" : "SELL", ZoPx(OrderClosePrice()), pips, risk > 0 ? pips * g_pip / risk : 0,
                        money, AccountCurrency()));
   }
   GlobalVariableDel(GV_MANUAL + IntegerToString(ticket));
   GlobalVariableDel("ZOAN_R_" + IntegerToString(ticket));
   GlobalVariableDel("ZOAN_BE_" + IntegerToString(ticket));
   GlobalVariableDel("ZOAN_HOLD_" + IntegerToString(ticket));
}

// Orders opened by hand on this symbol (magic 0): report + SL / TP once, BE at InpManualBeR, result at the close.
void ManageManual()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderMagicNumber() != 0 || OrderType() > OP_SELL)
         continue;
      int ticket = OrderTicket();
      string gv = GV_MANUAL + IntegerToString(ticket);
      if(!GlobalVariableCheck(gv))
      {
         ManualOpen(ticket);
         continue;
      }
      if(InpManualBeR <= 0 || !ManualMayModify() || !OrderSelect(ticket, SELECT_BY_TICKET))
         continue;
      int d = OrderType() == OP_BUY ? 1 : -1;
      double risk = GlobalVariableGet(gv);
      RefreshRates();
      double px = d > 0 ? Bid : Ask;
      bool atBe = OrderStopLoss() > 0 && (OrderStopLoss() - OrderOpenPrice()) * d >= 0;
      if(risk <= 0 || atBe || (px - OrderOpenPrice()) * d < InpManualBeR * risk)
         continue;
      if((px - OrderOpenPrice()) * d <= MarketInfo(Symbol(), MODE_STOPLEVEL) * Point)
         continue;
      if(OrderModify(ticket, OrderOpenPrice(), NormalizeDouble(OrderOpenPrice(), Digits), OrderTakeProfit(), 0))
      {
         GlobalVariableSet("ZOAN_BE_" + IntegerToString(ticket), 1);   // the hint of ManageHints() is not needed any more
         Send(StringFormat("🛡 LỆNH TAY #%d %s: giá đã đi %.1fR → đã dời SL về BE %s.", ticket, d > 0 ? "BUY" : "SELL",
                           InpManualBeR, ZoPx(OrderOpenPrice())));
      }
   }
   // Managed orders that are no longer open.
   for(int g = GlobalVariablesTotal() - 1; g >= 0; g--)
   {
      string name = GlobalVariableName(g);
      if(StringFind(name, GV_MANUAL) != 0)
         continue;
      int ticket = (int)StringToInteger(StringSubstr(name, StringLen(GV_MANUAL)));
      if(OrderSelect(ticket, SELECT_BY_TICKET) && OrderCloseTime() == 0)
         continue;
      if(OrderSelect(ticket, SELECT_BY_TICKET) && OrderSymbol() != Symbol())
         continue;   // belongs to the EA instance of another symbol
      ManualClosed(ticket, GlobalVariableGet(name));
   }
}

// BE at 1R and ZO-hold hints for the open trades of this symbol, once per M15 candle.
void ManageHints()
{
   datetime bar = iTime(Symbol(), PERIOD_M15, 1);
   int di = DataIndex(15);
   if(bar == g_lastMgmtBar || di < 0 || !Reliable(15))
      return;
   g_lastMgmtBar = bar;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol() || OrderType() > OP_SELL)
         continue;
      int d = OrderType() == OP_BUY ? 1 : -1;
      string gvRisk = "ZOAN_R_" + IntegerToString(OrderTicket());
      if(!GlobalVariableCheck(gvRisk))
      {
         if(OrderStopLoss() <= 0)
            continue;
         GlobalVariableSet(gvRisk, MathAbs(OrderOpenPrice() - OrderStopLoss()));   // initial risk
      }
      double risk = GlobalVariableGet(gvRisk);
      if(risk <= 0)
         continue;
      double px = d > 0 ? Bid : Ask;
      double r = (px - OrderOpenPrice()) * d / risk;
      bool atBe = OrderStopLoss() > 0 && (OrderStopLoss() - OrderOpenPrice()) * d >= 0;
      string gvBe = "ZOAN_BE_" + IntegerToString(OrderTicket());
      // The EA's own orders are moved by ManageAuto() (LP-AB at InpLpAbBeR): no "move to BE at 1R" hint for them.
      if(r >= 1 && !atBe && !GlobalVariableCheck(gvBe) && !(OrderMagicNumber() == InpMagic && AutoOn()))
      {
         GlobalVariableSet(gvBe, 1);
         Send(StringFormat("🛡 Lệnh #%d %s %s đã đi %.1fR → dời SL về BE %s, chốt phần TP1 (1R).", OrderTicket(),
                           d > 0 ? "BUY" : "SELL", Symbol(), r, ZoPx(OrderOpenPrice())));
      }
      string gvHold = "ZOAN_HOLD_" + IntegerToString(OrderTicket());
      if(OrderMagicNumber() == InpMagic && InpHoldMode == 1)
         continue;   // the EA's own held orders are handled by ManageHold()
      bool keep = InpHoldMode == 1 ? ZoHoldOn(g_d[di], d) : ZoStillStrong(g_d[di], d);
      if(r >= 1 && !keep)
      {
         if(!GlobalVariableCheck(gvHold) || (datetime)GlobalVariableGet(gvHold) < bar - 3600)
         {
            GlobalVariableSet(gvHold, (double)bar);
            Send(StringFormat(InpHoldMode == 1 ? "✋ Lệnh #%d %s %s (%.1fR): nến ZO M15 đổi sang màu ngược → chốt phần đang giữ đã qua mục tiêu."
                              : "✋ Lệnh #%d %s %s (%.1fR): nến ZO M15 hết màu mạnh / có râu kéo ngược → chốt phần đang giữ " +
                              "đã qua mục tiêu.", OrderTicket(), d > 0 ? "BUY" : "SELL", Symbol(), r));
         }
      }
   }
}

//+------------------------------------------------------------------+
//| "ZOS MARKET ANALYSIS" message                                    |
//+------------------------------------------------------------------+
#define BAR "━━━━━━━━━━━━━━━━━━━━━━"

string Arr(int d) { return d > 0 ? "↑" : d < 0 ? "↓" : "→"; }

string PhaseLines(int tf)
{
   int di = DataIndex(tf);
   if(di < 0 || !Reliable(tf))
      return "  (thiếu dữ liệu)";
   double pct[];
   int rd;
   ZoPhasePct(g_d[di], g_all, pct, rd);
   string names[5] = {"Accumulation", "Run", "Distribution", "SHS", "Unclear"};
   int order[5] = {0, 1, 2, 3, 4};
   for(int a = 0; a < 5; a++)
      for(int b = a + 1; b < 5; b++)
         if(pct[order[b]] > pct[order[a]])
         {
            int t = order[a];
            order[a] = order[b];
            order[b] = t;
         }
   string s = "";
   for(int a = 0; a < 5; a++)
      s += StringFormat("\n  %-13s %2.0f%%", names[order[a]], pct[order[a]]);
   return s;
}

// Nearest LP High above / LP Low below the price on a timeframe (0 = none).
double EdgeAbove(int tf)
{
   double best = 0;
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == tf && ZoIsAlive(g_all[i]) && g_all[i].hi > Bid && (best == 0 || g_all[i].hi < best))
         best = g_all[i].hi;
   return best;
}

double EdgeBelow(int tf)
{
   double best = 0;
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == tf && ZoIsAlive(g_all[i]) && g_all[i].lo < Bid && g_all[i].lo > best)
         best = g_all[i].lo;
   return best;
}

string LocLine(string mark, string label, double px)
{
   if(px <= 0)
      return "\n" + mark + " " + label + ": -";
   return StringFormat("\n%s %s: %s  [%.2f%% | %.0f pip]", mark, label, ZoPx(px), MathAbs(px - Bid) / Bid * 100, MathAbs(px - Bid) / g_pip);
}

string MainText(int tf)
{
   int mg = ZoMainOf(g_all, tf, 1), mr = ZoMainOf(g_all, tf, -1);
   string s = "";
   if(mg >= 0) s += "mua " + ZoPx(g_all[mg].lo) + "-" + ZoPx(g_all[mg].hi) + " (" + ZoDate(g_all[mg].t0) + ")";
   if(mr >= 0) s += (s == "" ? "" : "; ") + "bán " + ZoPx(g_all[mr].lo) + "-" + ZoPx(g_all[mr].hi) + " (" + ZoDate(g_all[mr].t0) + ")";
   return s == "" ? "chưa có" : s;
}

// Shields of the trend side: same-direction live LPs born after its Main.
string ShieldText(int tf)
{
   datetime since;
   int tr = ZoMainTrend(g_all, tf, since);
   if(tr == 0)
      return "chưa có Main";
   datetime tM;
   int iM = ZoLastMain(g_all, tf, tr, tM);
   int n = 0;
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == tf && g_all[i].dir == tr && ZoIsAlive(g_all[i]) && i != iM && g_all[i].tLast + tf * 60 > tM)
         n++;
   return n == 0 ? "chưa có Shield sau Main " + (tr > 0 ? "mua" : "bán") + " (Main còn mới)"
                 : IntegerToString(n) + " Shield " + (tr > 0 ? "mua" : "bán") + " sau Main" + (n >= 2 ? " (xu thế đã đi xa)" : "");
}

// Price inside a live opposite-direction LP while a same-side LP also holds it = internal battle.
string BattleText(int tf)
{
   int g = -1, r = -1;
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == tf && ZoIsAlive(g_all[i]) && Bid >= g_all[i].lo && Bid <= g_all[i].hi)
      {
         if(g_all[i].dir > 0) g = i;
         if(g_all[i].dir < 0) r = i;
      }
   if(g >= 0 && r >= 0)
      return "CÓ - giá nằm trong cả GLP " + ZoDate(g_all[g].t0) + " và RLP " + ZoDate(g_all[r].t0) + " → hai phe giằng co, không vào giữa";
   return "không";
}

string RelationText(int tf)
{
   int at = ZoZoneAt(g_all, tf, Bid);
   if(at >= 0)
      return StringFormat("giá trong %s ở %.0f%% vùng%s", ZoZoneText(g_all[at]),
                          (Bid - g_all[at].lo) / MathMax(g_all[at].hi - g_all[at].lo, Point) * 100,
                          g_all[at].dir == 0 ? " (chưa break - tranh chấp)" : "");
   int up = ZoNeighbour(g_all, tf, Bid, true), dn = ZoNeighbour(g_all, tf, Bid, false);
   return "giữa " + (dn >= 0 ? StringFormat("%s (-%.0fp)", ZoShortName(g_all[dn]), ZoDist(g_all[dn], Bid)) : "khoảng trống dưới") +
          " và " + (up >= 0 ? StringFormat("%s (+%.0fp)", ZoShortName(g_all[up]), ZoDist(g_all[up], Bid)) : "khoảng trống trên");
}

string MomentumText()
{
   int di = DataIndex(15);
   if(di < 0 || !Reliable(15))
      return "thiếu dữ liệu M15";
   ZoTf m = g_d[di];
   int code;
   int run = ZoColorRun(m, code);
   double agB, twB, agS, twS;
   ZoPull(m.cH[1], m.cL[1], m.cO[1], m.cC[1], 1, agB, twB);
   ZoPull(m.cH[1], m.cL[1], m.cO[1], m.cC[1], -1, agS, twS);
   string s = "ZOS " + ZoColorName(code) + " x" + IntegerToString(run);
   if(agB > 3 * g_pip && agB > agS)
      s += StringFormat("; nến vừa đóng có râu dưới %.1f pip (lực kéo xuống)", agB / g_pip);
   else if(agS > 3 * g_pip && agS > agB)
      s += StringFormat("; nến vừa đóng có râu trên %.1f pip (lực kéo lên)", agS / g_pip);
   else
      s += "; nến vừa đóng không có râu kéo đáng kể";
   if(ZoTwoWickCount(m, 5) >= 3)
      s += "; thu nến (≥ 3/5 nến 2 đầu)";
   return s;
}

// Role of a live H4+ LP among the LPs of its side: Main, Shield (born after the Main), or an ordinary GLP / RLP.
string LpRole(int i)
{
   if(g_all[i].dir == 0)
      return "chưa break";
   datetime tM;
   int iM = ZoLastMain(g_all, g_all[i].tf, g_all[i].dir, tM);
   if(i == iM)
      return "Main";
   if(iM >= 0 && g_all[i].tLast + g_all[i].tf * 60 > tM)
      return "Shield";
   return "thường";
}

// Every live LP of a timeframe, nearest first (at most maxN): kind, range, role, distance - for the analysis and
// the entry messages, so the ordinary GLP / RLP are named as well as the Main and its Shields.
string LpList(int tf, int maxN)
{
   int idx[];
   ArrayResize(idx, 0);
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == tf && ZoIsAlive(g_all[i]))
      {
         int k = ArraySize(idx);
         ArrayResize(idx, k + 1);
         idx[k] = i;
      }
   for(int a = 0; a < ArraySize(idx); a++)
      for(int b = a + 1; b < ArraySize(idx); b++)
         if(ZoDist(g_all[idx[b]], Bid) < ZoDist(g_all[idx[a]], Bid))
         {
            int t = idx[a];
            idx[a] = idx[b];
            idx[b] = t;
         }
   string s = "";
   for(int a = 0; a < ArraySize(idx) && a < maxN; a++)
   {
      int i = idx[a];
      bool inside = Bid >= g_all[i].lo && Bid <= g_all[i].hi;
      s += "\n" + (g_all[i].lo > Bid ? "▲ " : g_all[i].hi < Bid ? "▼ " : "● ") + ZoKind(g_all[i]) + " " + ZoDate(g_all[i].t0) + " " +
           ZoPx(g_all[i].lo) + "-" + ZoPx(g_all[i].hi) + " [" + LpRole(i) + "]" +
           (inside ? " - giá đang ở trong" : StringFormat(" - cách %.0f pip", ZoDist(g_all[i], Bid)));
   }
   if(ArraySize(idx) > maxN)
      s += StringFormat("\n… và %d LP xa hơn", ArraySize(idx) - maxN);
   return s == "" ? "\n(không có LP nào còn sống)" : s;
}

// A live H4 LP of side d at price px (within pad): Main / Shield first, then - when InpEpAnyH4Lp - any GLP / RLP.
int LpAt(int d, double px, double pad, string &role)
{
   int zi = ZoShieldAt(g_all, 240, d, px, pad, role);
   if(zi >= 0 || !InpEpAnyH4Lp)
      return zi;
   for(int z = 0; z < ArraySize(g_all); z++)
      if(g_all[z].tf == 240 && g_all[z].dir == d && ZoIsAlive(g_all[z]) && px >= g_all[z].lo - pad && px <= g_all[z].hi + pad)
      {
         role = d > 0 ? "GLP" : "RLP";
         return z;
      }
   return -1;
}

string BuildZos()
{
   datetime hn = ZoHanoiNow();
   datetime s4, s15, sd, sw;
   int t15 = ZoMainTrend(g_all, 15, s15), t4 = ZoMainTrend(g_all, 240, s4);
   int td = ZoMainTrend(g_all, 1440, sd), tw = ZoMainTrend(g_all, 10080, sw);
   string s = BAR + "\nZOS MARKET ANALYSIS — " + Symbol() +
              StringFormat("\n%04d-%02d-%02d %02d:%02d (Hà Nội)\n", TimeYear(hn), TimeMonth(hn), TimeDay(hn), TimeHour(hn), TimeMinute(hn)) + BAR;
   s += "\n\nPRICE\nCurrent: " + ZoPx(Bid) + "\nM15: " + Arr(t15) + "\nH4: " + Arr(t4) + "\nD1: " + Arr(td) + "\nW1: " + Arr(tw);
   if(!Reliable(240) || !Reliable(15))
      return s + "\n\n⚠ Thiếu dữ liệu " + (Reliable(240) ? "" : "H4 ") + (Reliable(15) ? "" : "M15 ") +
             "→ cần một chart của khung đó có ZOS + ZO_LP đang chạy (EA đọc dữ liệu ZO_LP ghi ra). " +
             "Lưu template tên " + InpDataTemplate + " (chart có ZOS + ZO_LP > chuột phải > Template > Save Template) để EA tự mở các chart còn thiếu.";
   int d4 = DataIndex(240), d15 = DataIndex(15);

   s += "\n\n" + BAR + "\n1. MARKET STRUCTURE\n" + BAR;
   s += "\n\nH4\nTrend: " + Arr(t4) + " " + (t4 > 0 ? "Bullish" : t4 < 0 ? "Bearish" : "chưa có Main") +
        (s4 > 0 ? " (Main từ " + ZoDate(s4) + ")" : "") + "\nPhase:" + PhaseLines(240);
   s += "\n\nM15\nTrend: " + Arr(t15) + " " + (t15 > 0 ? "Bullish" : t15 < 0 ? "Bearish" : "chưa có Main") + "\nPhase:" + PhaseLines(15);
   string conflict = (t4 == 0 || t15 == 0) ? "LOW (một khung chưa có Main)" : t4 == t15 ? "NONE (cùng hướng)" : "HIGH (M15 ngược H4)";
   s += "\n\nMTF:\nH4 " + (t4 > 0 ? "↗" : t4 < 0 ? "↘" : "→") + " / M15 " + (t15 > 0 ? "↗" : t15 < 0 ? "↘" : "→") + "\nConflict: " + conflict;
   s += "\n(Phase % là ước lượng từ nến ZOS, chưa phải xác suất đã kiểm chứng.)";

   s += "\n\n" + BAR + "\n2. IMPORTANT LOCATIONS\n" + BAR;
   double rnUp = MathCeil(Bid / ZO_RN_STEP) * ZO_RN_STEP, rnDn = MathFloor(Bid / ZO_RN_STEP) * ZO_RN_STEP;
   double rn = (rnUp - Bid < Bid - rnDn) ? rnUp : rnDn;
   s += "\n\nH4" + LocLine("▲", "LP High", EdgeAbove(240)) + LocLine("●", "RN     ", rn) + LocLine("▼", "LP Low ", EdgeBelow(240));
   s += "\n\nLP H4 còn sống (▲ trên giá, ▼ dưới giá, ● giá ở trong):" + LpList(240, 10);
   s += "\n\nM15" + LocLine("▲", "LP High", EdgeAbove(15)) + LocLine("▼", "LP Low ", EdgeBelow(15));
   string role = "", roleB, roleS;
   int zb = LpAt(1, Bid, 10 * g_pip, roleB), zs_ = LpAt(-1, Bid, 10 * g_pip, roleS);
   if(zb >= 0) role += roleB + " mua " + ZoPx(g_all[zb].lo) + "-" + ZoPx(g_all[zb].hi);
   if(zs_ >= 0) role += (role == "" ? "" : " | ") + roleS + " bán " + ZoPx(g_all[zs_].lo) + "-" + ZoPx(g_all[zs_].hi);
   s += "\n\nCurrent location:\n→ H4: " + RelationText(240) + "\n→ M15: " + RelationText(15) +
        "\n→ LP H4 vào lệnh được: " + (role == "" ? "không (giá không ở LP H4 cùng chiều nào)" : role);
   string wd = "";
   for(int i = 0; i < ArraySize(g_all); i++)
      if((g_all[i].tf == 1440 || g_all[i].tf == 10080) && ZoIsAlive(g_all[i]) &&
         (ZoDist(g_all[i], Bid) <= 15 || (Bid >= g_all[i].lo && Bid <= g_all[i].hi)))
         wd += "\n→ " + ZoZoneText(g_all[i]) + (g_all[i].tMain > 0 ? " [Main]" : "") +
               (Bid >= g_all[i].lo && Bid <= g_all[i].hi ? " - giá đang ở trong" : StringFormat(" - cách %.0f pip", ZoDist(g_all[i], Bid)));
   s += "\n\nD1/W1:" + (wd == "" ? "\n→ Not activated (giá không gần LP quan trọng của D1 / W1)" : "\n→ ACTIVATED" + wd);

   s += "\n\n" + BAR + "\n3. ZOS CONTEXT\n" + BAR;
   s += "\n\nH4:\n- Main: " + MainText(240) + "\n- Shield: " + ShieldText(240) + "\n- Internal battle: " + BattleText(240) +
        "\n- LP relationship: " + RelationText(240);
   s += "\n\nM15:\n- Main: " + MainText(15) + "\n- Shield: " + ShieldText(15) + "\n- Internal battle: " + BattleText(15) +
        "\n- Momentum: " + MomentumText();

   string fb[], fs[];
   double buy = ZoBias(g_all, g_d[d4], g_d[d15], Bid, fb, fs);
   double diff = MathAbs(buy - 50) * 2;
   int lead = buy >= 50 ? 1 : -1;
   s += "\n\n" + BAR + "\n4. CURRENT BIAS\n" + BAR + StringFormat("\n\nBUY: %.0f%%\nSELL: %.0f%%\n\nConfidence: %s\n\nReason:", buy, 100 - buy,
        diff >= 40 ? "HIGH" : diff >= 20 ? "MEDIUM" : "LOW");
   for(int i = 0; i < ArraySize(fb); i++) s += "\n- BUY: " + fb[i];
   for(int i = 0; i < ArraySize(fs); i++) s += "\n- SELL: " + fs[i];
   if(ArraySize(fb) + ArraySize(fs) == 0)
      s += "\n- chưa có bằng chứng rõ cho phe nào";
   s += "\n- Chưa có Momentum Shift được xác nhận (xem STATUS)";

   // Scenarios: the zone where the primary side would get a valid EP (nearest Main / Shield of that side).
   s += "\n\n" + BAR + "\n5. SCENARIOS TO WATCH\n" + BAR;
   for(int k = 0; k < 2; k++)
   {
      int d = k == 0 ? lead : -lead;
      datetime tM;
      int iM = ZoLastMain(g_all, 240, d, tM);
      int zi = -1;
      double bd = 0;
      for(int i = 0; i < ArraySize(g_all); i++)
      {
         if(g_all[i].tf != 240 || g_all[i].dir != d || !ZoIsAlive(g_all[i]))
            continue;
         // Without InpEpAnyH4Lp only the Main and its Shields are entry zones; with it, every GLP / RLP H4 of that side.
         if(!InpEpAnyH4Lp && (iM < 0 || (i != iM && g_all[i].tLast + 240 * 60 <= tM)))
            continue;
         if(d > 0 && g_all[i].lo > Bid) continue;
         if(d < 0 && g_all[i].hi < Bid) continue;
         double dd = ZoDist(g_all[i], Bid);
         if(zi < 0 || dd < bd)
         {
            zi = i;
            bd = dd;
         }
      }
      s += "\n\n" + (k == 0 ? "① " : "② ") + (d > 0 ? "BUY" : "SELL") + " SCENARIO — " + (k == 0 ? "PRIMARY" : "ALTERNATIVE") + "\nCondition:";
      if(zi >= 0)
         s += "\nM15 về " + ZoKind(g_all[zi]) + " H4 " + ZoPx(g_all[zi].lo) + "-" + ZoPx(g_all[zi].hi) + " [" + LpRole(zi) + "]" +
              StringFormat(" (cách %.0f pip)", bd);
      else
         s += "\nChưa có LP H4 phía " + (d > 0 ? "mua dưới" : "bán trên") + " giá → chờ H4 tạo vùng mới";
      s += "\n+ Potential EP: cặp nến ZO A/B (A bị kéo " + (d > 0 ? "xuống" : "lên") + ", B hết lực kéo)" +
           "\n+ " + IntegerToString(InpEpConfirm) + " nến ZO tiếp theo không râu ngược, thân " + (d > 0 ? "tăng" : "giảm") +
           "\n→ " + (d > 0 ? "BUY" : "SELL") + " becomes actionable." + (k == 1 ? " Ngược thiên hướng chính → khối lượng nhỏ hơn." : "");
   }
   s += "\n\n③ NO-TRADE\nKhông có Potential EP hợp lệ, phiên New York (19-24h) / khuya (0-6h), hoặc ±30 phút quanh tin đỏ:\n→ WAIT";
   s += NewsBlock();
   s += "\n\n" + BAR + "\nSTATUS\n" + StatusText() + "\n" + BAR;
   return s;
}

string g_status = "WAITING FOR POTENTIAL EP";
string StatusText() { return g_status; }

//+------------------------------------------------------------------+
//| Potential EP alerts and LP-AB entries                              |
//+------------------------------------------------------------------+
datetime g_watchBar[2];     // EP candle already alerted, per direction (0 buy, 1 sell)

// Evidence around a Potential EP of direction d whose pulling candle is at shift sA. confDone = confirming
// candles already closed (0..2). Returns the quality 0-100 and fills the lists; okRules = every LP-AB rule holds.
// Why the last EpEval() said "no entry": hard blocks (never worth an alert) and soft ones (alert-only EPs, round 54).
int    g_epHard = 0;
string g_epSoft = "";

// Position of a price in the High-Low range of the last 30 closed H4 candles, seen from direction d:
// 0 = the cheap end for a buy / the dear end for a sell, 1 = the wrong end.
double RangePos(int d, double px)
{
   int hh = iHighest(Symbol(), PERIOD_H4, MODE_HIGH, 30, 1), ll = iLowest(Symbol(), PERIOD_H4, MODE_LOW, 30, 1);
   double hi = iHigh(Symbol(), PERIOD_H4, hh), lo = iLow(Symbol(), PERIOD_H4, ll);
   if(hi <= lo)
      return 0.5;
   double rp = (px - lo) / (hi - lo);
   return d > 0 ? rp : 1 - rp;
}

int EpEval(int d, int det, int sA, int confDone, string &why[], string &sup[], string &agn[], double &tip, bool &okRules)
{
   g_epHard = 0;
   g_epSoft = "";
   ArrayResize(why, 0);
   ArrayResize(sup, 0);
   ArrayResize(agn, 0);
   int q = 0;
   okRules = true;
   int di = DataIndex(15), d4 = DataIndex(240);
   ZoTf m = g_d[di];
   tip = d > 0 ? iLow(Symbol(), PERIOD_M15, 1) : iHigh(Symbol(), PERIOD_M15, 1);
   for(int x = 2; x <= sA; x++)
      tip = d > 0 ? MathMin(tip, iLow(Symbol(), PERIOD_M15, x)) : MathMax(tip, iHigh(Symbol(), PERIOD_M15, x));
   double ag, tw;
   ZoPull(m.cH[sA], m.cL[sA], m.cO[sA], m.cC[sA], d, ag, tw);
   ZoPush(why, StringFormat("M15 xuất hiện lực kéo %s (râu %s %.1f pip ở nến ZO %d nến trước)", d > 0 ? "↓" : "↑", d > 0 ? "dưới" : "trên",
                            ag / g_pip, sA - 1));
   ZoPush(why, det == 1 ? "Nến sau hết lực kéo đó (cặp nến ZO A/B)" : "Lực kéo ngắn dần rồi hết (râu hết dần)");
   if(det == 1) q += 15;
   else { ZoPush(agn, "kiểu râu hết dần - kiểu LP-AB chỉ vào cặp A/B"); okRules = false; g_epHard++; }

   string role;
   int zi = LpAt(d, tip, 10 * g_pip, role);   // Main / Shield, or any GLP / RLP H4 of our side (round 52)
   if(zi >= 0)
   {
      q += (role == "Main" || role == "Shield") ? 35 : 30;
      ZoPush(why, "Đầu râu ở " + role + " H4 " + (d > 0 ? "mua " : "bán ") + ZoPx(g_all[zi].lo) + "-" + ZoPx(g_all[zi].hi));
      ZoPush(sup, role + " H4 cùng chiều (" + ZoDate(g_all[zi].t0) + ")");
   }
   else
   {
      ZoPush(agn, InpEpAnyH4Lp ? "không ở LP H4 cùng chiều nào" : "không ở Main / Shield H4 cùng chiều");
      okRules = false;
      g_epHard++;   // no H4 LP of our side at the tip: not worth an alert either (user, 2/10)
   }
   double rn = MathRound(tip / ZO_RN_STEP) * ZO_RN_STEP;
   if(MathAbs(tip - rn) <= 3 * g_pip)
      ZoPush(why, "RN " + ZoPx(rn) + " hội tụ (chỉ để tham khảo)");

   int pdir;
   string ph = ZoPhaseCode(g_d[d4], pdir);
   if(ph == "FADE" && pdir == d)
   {
      ZoPush(agn, "H4 màu yếu phía " + (d > 0 ? "mua" : "bán") + " (phe mình mất áp lực)");
      okRules = false;
      g_epHard++;
   }
   else
   {
      q += 10;
      if(ph == "ACC") ZoPush(sup, "H4 tích luỹ (nhóm EP tốt nhất trong backtest)");
      if(ph == "FADE") ZoPush(sup, "phe " + (d > 0 ? "bán" : "mua") + " yếu màu trên H4");
      if(ph == "RUN" && pdir == d) ZoPush(sup, "H4 đang chạy cùng hướng");
      if(ph == "RUN" && pdir == -d) ZoPush(agn, "H4 đang chạy mạnh ngược hướng");
   }
   datetime since;
   int t4 = ZoMainTrend(g_all, 240, since), t15 = ZoMainTrend(g_all, 15, since);
   if(t4 == d) ZoPush(sup, "H4 bias: " + (d > 0 ? "BUY" : "SELL") + " (Main H4)");
   if(t4 == -d) ZoPush(agn, "H4 bias ngược (Main H4 " + (t4 > 0 ? "tăng" : "giảm") + ")");
   if(t15 == -d)
   {
      if(t4 == d) ZoPush(sup, "M15 đang hồi ngược H4 (pullback)");
      else        ZoPush(agn, "M15 trend vẫn " + (t15 > 0 ? "BUY" : "SELL"));
   }

   int hour = TimeHour(ZoHanoi(iTime(Symbol(), PERIOD_M15, 1) + 900));
   if(hour < 6 || hour >= 19)
   {
      ZoPush(agn, hour < 6 ? "khuya 0-6h" : "phiên New York (19-24h)");
      okRules = false;
      // Each soft reason carries what the 3-year backtest says about entries of that kind (rs_alertonly.py).
      g_epSoft += hour < 6
                  ? "\n− GIỜ KHUYA (0-6h VN): hệ không vào giờ này.\n   Backtest 275 EP: chốt 1R thắng 41%; thoát theo LP H4 lãi 15% / hoà 27% / lỗ 59%, trung bình −0.19R/lệnh"
                  : "\n− PHIÊN NEW YORK (19-24h VN): kiểu LP-AB không vào phiên này.\n   Backtest 94 EP: chốt 1R thắng 37%; thoát theo LP H4 lãi 14% / hoà 24% / lỗ 62%, trung bình −0.18R/lệnh";
   }
   else
   {
      q += 10;
      ZoPush(sup, hour < 13 ? "phiên Á" : "phiên London");
   }
   bool wdOpp = false;
   double px = iClose(Symbol(), PERIOD_M15, 1);
   for(int i = 0; i < ArraySize(g_all); i++)
      if((g_all[i].tf == 1440 || g_all[i].tf == 10080) && g_all[i].tMain > 0 && g_all[i].dir == -d && ZoIsAlive(g_all[i]) &&
         px >= g_all[i].lo && px <= g_all[i].hi)
         wdOpp = true;
   if(wdOpp) ZoPush(agn, "giá trong Main D1 / W1 ngược chiều");
   else q += 5;
   int nk = InpNews ? ZoNewsActive(InpNewsCurrencies, InpNewsMinImpact, InpNewsBlockMin, InpNewsBlockMin, TimeGMT()) : -1;
   if(nk >= 0)
   {
      ZoPush(agn, "gần tin đỏ: " + ZoNewsText(nk));
      okRules = false;
      g_epHard++;
   }
   else
      q += 5;
   // Cases that were bad on every period of the 3-year swing study (round 38) and on the ZO-FLEX trades (round 46).
   // They lower the quality of the alert only; the ZO-FLEX entry rules above are unchanged.
   int avoid = 0;
   double rp = RangePos(d, tip);
   if(rp > 0.8)
   {
      ZoPush(agn, d > 0 ? "mua ở 20% đầu đắt của biên độ 5 ngày" : "bán ở 20% đầu rẻ của biên độ 5 ngày");
      avoid++;
   }
   else if(rp <= 0.35)
      ZoPush(sup, StringFormat("ở %.0f%% đầu %s của biên độ 5 ngày", rp * 100, d > 0 ? "rẻ" : "đắt"));
   int far = d > 0 ? iHighest(Symbol(), PERIOD_M15, MODE_HIGH, 96, sA) : iLowest(Symbol(), PERIOD_M15, MODE_LOW, 96, sA);
   double leg = (d > 0 ? iHigh(Symbol(), PERIOD_M15, far) - tip : tip - iLow(Symbol(), PERIOD_M15, far)) / g_pip;
   if(leg < 20)
   {
      ZoPush(agn, StringFormat("đợt %s trước đó chỉ %.0f pip (< 20 pip)", d > 0 ? "giảm" : "tăng", leg));
      avoid++;
   }
   else
      ZoPush(sup, StringFormat("đợt %s trước đó %.0f pip", d > 0 ? "giảm" : "tăng", leg));
   for(int a = 0; a < ArraySize(g_all); a++)
   {
      if(g_all[a].dir != -d)
         continue;
      if(g_all[a].tf == 15 && ZoIsAlive(g_all[a]) && tip >= g_all[a].lo && tip <= g_all[a].hi)
      {
         ZoPush(agn, "đầu râu nằm trong " + ZoShortName(g_all[a]) + " ngược chiều");
         avoid++;
         break;
      }
   }
   for(int a = 0; a < ArraySize(g_all); a++)
      if(g_all[a].tf == 240 && g_all[a].dir == -d && !ZoIsAlive(g_all[a]) && g_all[a].tDead > 0 &&
         TimeCurrent() - g_all[a].tDead <= 10 * 86400 && MathAbs(tip - (d > 0 ? g_all[a].hi : g_all[a].lo)) <= 8 * g_pip)
      {
         ZoPush(agn, "retest " + ZoShortName(g_all[a]) + " vừa bị phá (đổi vai)");
         avoid++;
         break;
      }
   q = MathMax(0, q - 10 * avoid);
   q += 10 * MathMin(confDone, 2);
   if(confDone < InpEpConfirm)
      okRules = false;
   return q;
}

string Bullets(const string &arr[], string mark)
{
   string s = "";
   for(int i = 0; i < ArraySize(arr); i++)
      s += "\n" + mark + " " + arr[i];
   return s == "" ? "\n" + mark + " (không có)" : s;
}

// What the trade would look like if this Potential EP is confirmed now: stop behind the pull tip, ZO-FLEX targets.
string PlanPreview(int d, double tip)
{
   ZoSignal sig;
   if(!ZoPlanEP(g_all, d, tip, InpTpProfile, sig))
      return "\n\nPLAN DỰ KIẾN\nChưa có kế hoạch hợp lệ (SL cấu trúc > 15 pip hoặc không có đích ở LP H4 ngược)";
   double dist = MathAbs(sig.ep - sig.sl);
   string s = StringFormat("\n\nPLAN DỰ KIẾN (nếu được xác nhận)\nĐầu râu %s | SL %s (%.1f pip)", ZoPx(tip), ZoPx(sig.sl), dist / g_pip);
   for(int k = 0; k < sig.ntp; k++)
      s += StringFormat("\nTP%d %s (%.1fR)", k + 1, ZoPx(sig.tp[k]), MathAbs(sig.tp[k] - sig.ep) / dist);
   return s;
}

// Alert-only EP (round 54): the pair and its confirming candles are there, but the entry rules stop it for a soft
// reason - night / New York hours, or a structure stop of 15 .. InpEpAlertSlMax pip. Reported with its plan, the
// reason and the backtest record of that reason; NEVER sent to AutoTrade. In the 3-year backtest these EPs lost on
// average, which is why they are not traded. An EP with no H4 LP of our side at the tip is not reported.
bool AlertOnlyEP(int d, double tip, int q, string &why[], string &sup[], string &agn[], datetime hn)
{
   ZoSignal sig;
   g_zoEpSlMax = InpEpAlertSlMax;
   bool planned = ZoPlanEP(g_all, d, tip, InpTpProfile, sig);
   g_zoEpSlMax = 15;
   if(!planned)
      return false;
   double slPips = MathAbs(sig.ep - sig.sl) / g_pip;
   string soft = g_epSoft;
   if(slPips > 15)
      soft += StringFormat("\n− SL CẤU TRÚC %.1f pip > 15 pip: hệ bỏ lệnh khi SL sau đầu râu quá 15 pip.", slPips) +
              "\n   Backtest 79 EP có SL 15-17 pip: chốt 1R thắng 42%; thoát theo LP H4 lãi 20% / hoà 22% / lỗ 58%, trung bình −0.26R/lệnh";
   if(soft == "")
      return false;
   string gv = "ZOAN_EPO_" + Symbol() + (d > 0 ? "_BUY" : "_SELL");
   datetime bar1 = iTime(Symbol(), PERIOD_M15, 1);
   if(GlobalVariableCheck(gv) && bar1 - (datetime)GlobalVariableGet(gv) < 4 * 3600)
      return false;   // one alert per direction per 4 hours
   GlobalVariableSet(gv, (double)bar1);
   string dirTxt = d > 0 ? "BUY" : "SELL";
   string msg = StringFormat("👀 ZOS — EP TIỀM NĂNG (chỉ báo, EA KHÔNG tự vào)\n\n%s / M15\n%02d:%02d | %s\n\nVÌ SAO KHÔNG TỰ VÀO",
                             dirTxt, TimeHour(hn), TimeMinute(hn), ZoPx(sig.ep)) + soft +
                StringFormat("\n\nPLAN NẾU BẠN TỰ VÀO\nVào market ~%s\nSL %s (%.1f pip)", ZoPx(sig.ep), ZoPx(sig.sl), slPips);
   for(int k = 0; k < sig.ntp; k++)
      msg += StringFormat("\nTP%d %s (%.1fR)", k + 1, ZoPx(sig.tp[k]), MathAbs(sig.tp[k] - sig.ep) / MathAbs(sig.ep - sig.sl));
   msg += "\n\nLP H4" + LpList(240, 6) + "\n\nWHY?" + Bullets(why, "•") + "\n• đã đủ nến ZO xác nhận" + "\n\nSUPPORT" + Bullets(sup, "+") +
          "\n\nAGAINST" + Bullets(agn, "−") + StringFormat("\n\nQUALITY\nPotential EP: %d/100", q) +
          "\n\nSO SÁNH\nLệnh EA tự vào (đủ luật): chốt 1R thắng khoảng 50%; thoát theo LP H4 lãi 27% / hoà 13% / lỗ 60%, trung bình +0.61R/lệnh." +
          "\nNếu bạn vào tay, EA sẽ quản lý SL / TP / BE như mọi lệnh tay.";
   Send(msg);
   return true;
}

void CheckEP(int di)
{
   int d4 = DataIndex(240);
   if(d4 < 0)
      return;
   ZoTf m = g_d[di];
   datetime bar1 = iTime(Symbol(), PERIOD_M15, 1);
   datetime hn = ZoHanoi(bar1 + 900);
   string fb[], fs[];
   double buy = ZoBias(g_all, g_d[d4], m, iClose(Symbol(), PERIOD_M15, 1), fb, fs);
   for(int side = 0; side < 2; side++)
   {
      int d = side == 0 ? 1 : -1;
      string dirTxt = d > 0 ? "BUY" : "SELL";
      string why[], sup[], agn[];
      double tip;
      bool ok;
      int sA = 0;
      // 1) Entry: the EP candle is 2 candles back and both candles since confirm the shift.
      // The EP candle sits InpEpConfirm candles back; every candle since must confirm the shift.
      int nc = MathMax(1, MathMin(InpEpConfirm, 4));
      bool c1 = ZoConfirmed(m, 1, d);
      // Round 53: the A/B pair may sit up to InpEpConfWindow candles back. The entry candle is the one that brings
      // the number of confirming candles to nc, provided no candle since went past the pull tip.
      int det3 = 0, firstWatch = 0;
      int win = MathMin(MathMax(InpEpConfWindow, nc), ZO_CACHE - 3);
      for(int k = 1; k <= win; k++)
      {
         int sx;
         if(ZoPotentialEP(m, k + 1, d, sx) != 1)
            continue;
         double tip0 = d > 0 ? MathMin(iLow(Symbol(), PERIOD_M15, k + 1), iLow(Symbol(), PERIOD_M15, k + 2))
                             : MathMax(iHigh(Symbol(), PERIOD_M15, k + 1), iHigh(Symbol(), PERIOD_M15, k + 2));
         int cnt = 0;
         bool held = true;
         for(int cs = 1; cs <= k; cs++)
         {
            if(ZoConfirmed(m, cs, d))
               cnt++;
            if(d > 0 ? iLow(Symbol(), PERIOD_M15, cs) < tip0 : iHigh(Symbol(), PERIOD_M15, cs) > tip0)
               held = false;
         }
         if(!c1 || !held)
            continue;
         if(cnt == nc && k >= nc && det3 == 0)
         {
            det3 = 1;
            sA = sx;
         }
         if(cnt == 1 && firstWatch == 0)
            firstWatch = k;      // the first confirming candle after this pair has just closed
      }
      if(det3 == 1)
      {
         int q = EpEval(d, det3, sA, nc, why, sup, agn, tip, ok);
         if(InpH4Veto && ZoH4Against(g_d[d4], d))
         {
            ok = false;
            g_epHard++;
            ZoPush(agn, "nến ZOS H4 vừa đóng màu mạnh ngược hướng lệnh");
         }
         string blockWhy;
         if(ExtraBlock(d, iClose(Symbol(), PERIOD_M15, 1), blockWhy))
         {
            ok = false;
            g_epHard++;
            ZoPush(agn, blockWhy + " (chặn lệnh)");
         }
         string gv = "ZOAN_EPA_" + Symbol() + (d > 0 ? "_BUY" : "_SELL");
         bool cool = GlobalVariableCheck(gv) && bar1 - (datetime)GlobalVariableGet(gv) < 4 * 3600;
         ZoSignal sig;
         if(ok && !cool && ZoPlanEP(g_all, d, tip, InpTpProfile, sig))
         {
            GlobalVariableSet(gv, (double)bar1);
            sig.kind = "LP-AB";
            sig.why = "cặp nến ZO A/B tại LP H4 cùng chiều + " + IntegerToString(nc) + " nến ZO xác nhận";
            double slPips = MathAbs(sig.ep - sig.sl) / g_pip;
            double tickVal = MarketInfo(Symbol(), MODE_TICKVALUE) * (g_pip / MarketInfo(Symbol(), MODE_TICKSIZE));
            string riskNote;
            double riskPct = RiskFor(d, sig.ep, slPips, riskNote);
            double lots = tickVal > 0 ? AccountBalance() * riskPct / 100 / (slPips * tickVal) : 0;
            string msg = StringFormat("✅ ZOS — ENTRY\n\n%s / M15\n%02d:%02d | %s\n\nPLAN\nVào market ~%s\nSL %s (%.1f pip)\nLot gợi ý %.2f (%.1f%%)",
                                      dirTxt, TimeHour(hn), TimeMinute(hn), ZoPx(sig.ep), ZoPx(sig.ep), ZoPx(sig.sl), slPips, lots, riskPct);
            if(riskNote != "")
               msg += "\n" + riskNote;
            for(int k = 0; k < sig.ntp; k++)
               msg += StringFormat("\nTP%d %s (%.1fR)", k + 1, ZoPx(sig.tp[k]), MathAbs(sig.tp[k] - sig.ep) / MathAbs(sig.ep - sig.sl));
            if(lots < 0.03)
            {
               double one = ZoSmallTarget(g_all, sig);
               msg += StringFormat("\nLot < 0.03 (không chia 3 phần được): đặt 1 TP ở %s (%.1fR)", ZoPx(one),
                                   MathAbs(one - sig.ep) / MathAbs(sig.ep - sig.sl));
            }
            msg += "\n\nLP H4" + LpList(240, 6);
            msg += "\n\nWHY?" + Bullets(why, "•") + "\n• " + IntegerToString(nc) + " nến ZO tiếp theo xác nhận Momentum Shift " + (d > 0 ? "↑" : "↓") +
                   "\n\nSUPPORT" + Bullets(sup, "+") + "\n\nAGAINST" + Bullets(agn, "−") +
                   StringFormat("\n\nQUALITY\nPotential EP: %d/100\n%s evidence: %.0f%%\n%s evidence: %.0f%%", q, dirTxt, d > 0 ? buy : 100 - buy,
                                d > 0 ? "SELL" : "BUY", d > 0 ? 100 - buy : buy) +
                   "\n\nSTATUS\n✅ ENTRY — đủ điều kiện hệ ZO-FLEX (kiểu LP-AB)\n\nMANAGE\n→ BE khi đi được " + DoubleToString(MathMax(InpLpAbBeR, 1.0), 1) + "R\n→ " + HoldText() +
                   "\n→ Giá đã chạy xa giá vào > 3 pip thì bỏ, không đuổi";
            Send(msg);
            g_status = "ENTRY " + dirTxt + " (LP-AB) lúc " + StringFormat("%02d:%02d", TimeHour(hn), TimeMinute(hn));
            if(InpDrawSignals)
               DrawSignal(sig);
            if(AutoOn())
               AutoTrade(sig);
         }
         else if(InpEpAlertOnly && !cool && g_epHard == 0 && AlertOnlyEP(d, tip, q, why, sup, agn, hn))
         {
            g_status = "EP TIỀM NĂNG " + dirTxt + " (chỉ báo, không tự vào) lúc " + StringFormat("%02d:%02d", TimeHour(hn), TimeMinute(hn));
         }
         else if(g_watchBar[side] == iTime(Symbol(), PERIOD_M15, nc + 1))
         {
            string reason = cool ? "vừa có lệnh " + dirTxt + " trong 4h" : !ok ? "chưa đạt luật LP-AB:" + Bullets(agn, "−") : "SL cấu trúc > 15 pip hoặc không có đích";
            if(InpMsgLevel == 0)
               Send("⛔ ZOS — KHÔNG VÀO\n\n" + dirTxt + " / M15 — Potential EP đã đủ " + IntegerToString(nc) + " nến xác nhận nhưng " + reason);
            g_status = "WAITING FOR POTENTIAL EP";
         }
      }
      else if(g_watchBar[side] > 0 && !c1 && g_watchBar[side] < bar1 && g_watchBar[side] >= iTime(Symbol(), PERIOD_M15, nc + 1))
      {
         if(InpMsgLevel == 0)
            Send("❌ ZOS — POTENTIAL EP HUỶ\n\n" + dirTxt + " / M15\nNến ZO tiếp theo không xác nhận (có lực kéo ngược hoặc thân ngược hướng) → bỏ, chờ EP khác.");
         g_watchBar[side] = 0;
         g_status = "WAITING FOR POTENTIAL EP";
      }
      // 2) Watch: a new Potential EP on the candle that just closed.
      // With the flexible window the alert goes out at the FIRST confirming candle after an A/B pair (the entry
      // then needs one more); with the strict rule, at the pair itself as before.
      bool flex = InpEpConfWindow > nc;
      int det1 = flex ? (firstWatch > 0 && nc > 1 ? ZoPotentialEP(m, firstWatch + 1, d, sA) : 0) : ZoPotentialEP(m, 1, d, sA);
      if(!flex && det1 == 2 && !InpEpAlertFade)
         det1 = 0;
      if(det1 == 1 || det1 == 2)
      {
         int q = EpEval(d, det1, sA, flex ? 1 : 0, why, sup, agn, tip, ok);
         if(q >= InpEpMinQuality && g_watchBar[side] != bar1)
         {
            g_watchBar[side] = bar1;
            string msg = StringFormat("🔔 ZOS — POTENTIAL EP\n\n%s / M15\n%02d:%02d | %s\n\nWHY?", dirTxt, TimeHour(hn), TimeMinute(hn),
                                      ZoPx(iClose(Symbol(), PERIOD_M15, 1))) + Bullets(why, "•") +
                         "\n\nSUPPORT" + Bullets(sup, "+") + "\n\nAGAINST" + Bullets(agn, "−") +
                         StringFormat("\n\nQUALITY\nPotential EP: %d/100\n%s evidence: %.0f%%\n%s evidence: %.0f%%", q, dirTxt,
                                      d > 0 ? buy : 100 - buy, d > 0 ? "SELL" : "BUY", d > 0 ? 100 - buy : buy) +
                         PlanPreview(d, tip) + "\n\nLP H4" + LpList(240, 6) +
                         "\n\nSTATUS\n⚠️ WATCH — chưa Entry" + (flex ? " (đã có 1 nến ZO xác nhận)" : "") + "\n\nWAIT FOR\n→ " +
                         IntegerToString(flex ? InpEpConfirm - 1 : InpEpConfirm) + " nến ZO M15 nữa: không râu " + (d > 0 ? "dưới" : "trên") +
                         ", thân " + (d > 0 ? "tăng" : "giảm") + " (Momentum Shift xác nhận)\n→ EP quality đạt đủ luật LP-AB (không còn mục AGAINST chặn lệnh)";
            Send(msg);
            g_status = "POTENTIAL EP " + dirTxt + " — chờ " + IntegerToString(InpEpConfirm) + " nến ZO xác nhận";
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Economic calendar                                                |
//+------------------------------------------------------------------+
string JsonField(string obj, string key)
{
   int p = StringFind(obj, "\"" + key + "\":\"");
   if(p < 0)
      return "";
   p += StringLen(key) + 4;
   int q = StringFind(obj, "\"", p);
   return q < 0 ? "" : StringSubstr(obj, p, q - p);
}

// "2026-09-30T08:30:00-04:00" -> GMT.
datetime IsoToGmt(string iso)
{
   if(StringLen(iso) < 25)
      return 0;
   string d = StringSubstr(iso, 0, 10);
   StringReplace(d, "-", ".");
   datetime local = StringToTime(d + " " + StringSubstr(iso, 11, 5));
   int sign = StringSubstr(iso, 19, 1) == "-" ? -1 : 1;
   int off = (int)StringToInteger(StringSubstr(iso, 20, 2)) * 3600 + (int)StringToInteger(StringSubstr(iso, 23, 2)) * 60;
   return local - sign * off;
}

// Downloads this week's calendar and rewrites Common\Files\zo_lp\news.csv (time GMT;currency;impact;title).
bool FetchNews()
{
   char data[], result[];
   string resultHeaders;
   ResetLastError();
   int status = WebRequest("GET", InpNewsUrl, "User-Agent: Mozilla/5.0\r\n", 8000, data, result, resultHeaders);
   if(status != 200)
   {
      PrintFormat("ZO_Analyst: news download failed (HTTP %d, err %d)%s", status, GetLastError(),
                  GetLastError() == 4060 ? " - add https://nfs.faireconomy.media in Tools > Options > Expert Advisors" : "");
      return false;
   }
   string body = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   FolderCreate("zo_lp", FILE_COMMON);
   int h = FileOpen(ZO_NEWS_FILE, FILE_WRITE | FILE_CSV | FILE_COMMON | FILE_ANSI, ';');
   if(h == INVALID_HANDLE)
      return false;
   int n = 0, pos = 0;
   while(true)
   {
      int a = StringFind(body, "{", pos);
      if(a < 0)
         break;
      int b = StringFind(body, "}", a);
      if(b < 0)
         break;
      string obj = StringSubstr(body, a, b - a + 1);
      pos = b + 1;
      datetime t = IsoToGmt(JsonField(obj, "date"));
      string imp = JsonField(obj, "impact");
      string title = JsonField(obj, "title");
      StringReplace(title, ";", ",");
      if(t <= 0)
         continue;
      FileWrite(h, IntegerToString((long)t), JsonField(obj, "country"), imp == "High" ? 3 : imp == "Medium" ? 2 : imp == "Low" ? 1 : 0, title);
      n++;
   }
   FileClose(h);
   PrintFormat("ZO_Analyst: calendar updated, %d events", n);
   return n > 0;
}

void DrawNewsLines()
{
   ObjectsDeleteAll(0, "ZOAN_NEWS_");
   if(!InpNewsLines)
      return;
   long shift = (long)TimeCurrent() - (long)TimeGMT();
   shift = (long)MathRound((double)shift / 1800.0) * 1800;      // server - GMT, to the half hour
   for(int k = 0; k < ArraySize(g_zoNewsTime); k++)
   {
      if(!ZoNewsWanted(k, InpNewsCurrencies, InpNewsMinImpact))
         continue;
      string name = "ZOAN_NEWS_" + IntegerToString(k);
      ObjectCreate(0, name, OBJ_VLINE, 0, (datetime)((long)g_zoNewsTime[k] + shift), 0);
      ObjectSetInteger(0, name, OBJPROP_COLOR, g_zoNewsImp[k] >= 3 ? clrCrimson : clrDarkOrange);
      ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetInteger(0, name, OBJPROP_BACK, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetString(0, name, OBJPROP_TOOLTIP, ZoNewsText(k));
      ObjectSetString(0, name, OBJPROP_TEXT, g_zoNewsCur[k] + " " + g_zoNewsTitle[k]);
   }
}

// Every timer tick: refresh the calendar when due and announce the next watched news once.
void NewsTick()
{
   if(g_newsFetched == 0 || TimeLocal() - g_newsFetched >= InpNewsRefreshHours * 3600)
   {
      g_newsFetched = TimeLocal();
      FetchNews();
      ZoNewsLoad();
      DrawNewsLines();
   }
   if(InpNewsWarnMin <= 0)
      return;
   int k = ZoNewsNext(InpNewsCurrencies, InpNewsMinImpact, TimeGMT());
   if(k < 0 || g_zoNewsTime[k] - TimeGMT() > InpNewsWarnMin * 60 || g_zoNewsTime[k] <= g_newsWarned)
      return;
   // All watched news of the same minute go into one message.
   string list = "";
   for(int j = 0; j < ArraySize(g_zoNewsTime); j++)
      if(g_zoNewsTime[j] == g_zoNewsTime[k] && ZoNewsWanted(j, InpNewsCurrencies, InpNewsMinImpact))
         list += "\n- " + ZoNewsText(j);
   g_newsWarned = g_zoNewsTime[k];
   Send(StringFormat("📰 %d phút nữa có tin:%s\nKhông vào lệnh mới trong ±%d phút; lệnh đang mở: cân nhắc dời BE / chốt bớt.",
                     (int)((g_zoNewsTime[k] - TimeGMT()) / 60), list, InpNewsBlockMin));
}

// Watched news of the next 24 hours, for the analysis text.
string NewsBlock()
{
   if(!InpNews)
      return "";
   string s = "";
   for(int k = 0; k < ArraySize(g_zoNewsTime); k++)
      if(ZoNewsWanted(k, InpNewsCurrencies, InpNewsMinImpact) && g_zoNewsTime[k] > TimeGMT() - 1800 &&
         g_zoNewsTime[k] < TimeGMT() + 24 * 3600)
         s += "\n  - " + ZoNewsText(k);
   if(s == "")
      return ArraySize(g_zoNewsTime) == 0 ? "\n\n📰 Chưa tải được lịch tin (thêm https://nfs.faireconomy.media vào Allow WebRequest)."
                                          : "\n\n📰 24h tới không có tin " + (InpNewsMinImpact >= 3 ? "đỏ" : "đỏ / cam") + " của " + InpNewsCurrencies + ".";
   return "\n\n📰 Tin " + (InpNewsMinImpact >= 3 ? "đỏ" : "đỏ / cam") + " 24h tới (không vào lệnh ±" + IntegerToString(InpNewsBlockMin) + " phút):" + s;
}

//+------------------------------------------------------------------+
//| Sending                                                          |
//+------------------------------------------------------------------+
bool IsQuiet()
{
   if(InpQuietFrom == InpQuietTo)
      return false;
   int h = TimeHour(ZoHanoiNow());
   if(InpQuietFrom < InpQuietTo)
      return h >= InpQuietFrom && h < InpQuietTo;
   return h >= InpQuietFrom || h < InpQuietTo;
}

bool StartAllowed()
{
   string gv = "ZOAN_START_" + Symbol();
   if(GlobalVariableCheck(gv) && TimeLocal() - (datetime)GlobalVariableGet(gv) < InpStartThrottleMin * 60)
      return false;
   GlobalVariableSet(gv, (double)TimeLocal());
   return true;
}

void WriteFile(string text)
{
   int h = FileOpen("zo_analysis_" + Symbol() + ".txt", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, text);
   FileClose(h);
}

void SendFull(string title)
{
   string text = InpAnalysisStyle == 0 ? BuildZos() : BuildAnalysis(title);
   if(InpWriteFile)
      WriteFile(text);
   Send(text);
   g_lastFullSent = TimeCurrent();
}

void FlushMessages()
{
   if(IsQuiet())
   {
      g_minor = "";   // minor events are stale by morning; major ones are sent when quiet hours end
      return;
   }
   if(InpMsgLevel == 1 || (InpMsgLevel == 2 && !g_majorPending))
   {
      // EP-focused levels: LP events and touches are not sent; the analysis file is still refreshed on big changes.
      if(g_majorPending && InpWriteFile)
         WriteFile(InpAnalysisStyle == 0 ? BuildZos() : BuildAnalysis("CẬP NHẬT"));
      g_minor = "";
      g_majorLines = "";
      g_majorPending = false;
      return;
   }
   if(g_majorPending && TimeCurrent() - g_lastFullSent >= InpFullGapMin * 60)
   {
      string text = (InpAnalysisStyle == 0 ? BuildZos() : BuildAnalysis("CẬP NHẬT")) + "\n\nThay đổi:" + g_majorLines + g_minor;
      g_minor = "";
      g_majorLines = "";
      g_majorPending = false;
      if(InpWriteFile)
         WriteFile(text);
      Send(text);
      g_lastFullSent = TimeCurrent();
      g_lastMinorSent = TimeCurrent();
      return;
   }
   // A major event inside the full-analysis gap still goes out right away, as a short alert.
   if(InpMsgLevel == 2)
      return;   // level 2: the big change waits for the next full analysis, no short alert
   if((g_majorPending || g_minor != "") && TimeCurrent() - g_lastMinorSent >= InpMinGapMin * 60)
   {
      Send((g_majorPending ? "⚠ " : "🔔 ") + Symbol() + " " + ZoPx(Bid) + g_majorLines + g_minor);
      g_minor = "";
      g_majorLines = "";
      g_majorPending = false;
      g_lastMinorSent = TimeCurrent();
   }
}

// ZO_LP alert files (UTF-16, named "<unix time>_<hash>.txt").
void ForwardQueue()
{
   string names[];
   string name;
   long handle = FileFindFirst(QUEUE_DIR + "*.txt", name, FILE_COMMON);
   if(handle == INVALID_HANDLE)
      return;
   do
   {
      int k = ArraySize(names);
      ArrayResize(names, k + 1);
      names[k] = name;
   }
   while(FileFindNext(handle, name));
   FileFindClose(handle);
   // ArraySort() does not handle strings in MQL4: sort by hand (names start with a timestamp).
   for(int a = 0; a < ArraySize(names); a++)
      for(int b = a + 1; b < ArraySize(names); b++)
         if(StringCompare(names[b], names[a]) < 0)
         {
            string tmp = names[a];
            names[a] = names[b];
            names[b] = tmp;
         }
   for(int i = 0; i < ArraySize(names); i++)
   {
      string path = QUEUE_DIR + names[i];
      long queuedAt = StringToInteger(StringSubstr(names[i], 0, StringFind(names[i], "_")));
      if(InpMaxAgeMinutes > 0 && queuedAt > 0 && (long)TimeLocal() - queuedAt > InpMaxAgeMinutes * 60)
      {
         FileDelete(path, FILE_COMMON);
         continue;
      }
      int h = FileOpen(path, FILE_READ | FILE_TXT | FILE_COMMON | FILE_UNICODE);
      if(h == INVALID_HANDLE)
         continue;
      string msg = "";
      while(!FileIsEnding(h))
         msg += (msg == "" ? "" : "\n") + FileReadString(h);
      FileClose(h);
      // Message level 1 / 2: the ZO_LP alerts (every LP event of every chart) are dropped, not forwarded.
      if(msg == "" || InpMsgLevel != 0 || Send(msg))
         FileDelete(path, FILE_COMMON);
      else
         break;
   }
}

bool Send(string msg)
{
   if(StringLen(msg) > 4000)   // Telegram limit is 4096 characters
      msg = StringSubstr(msg, 0, 3990) + "\n…";
   bool ok = true;
   if(InpTelegramToken != "" && InpTelegramChatId != "")
      ok = SendTelegram(msg) && ok;
   if(InpDiscordWebhook != "")
      ok = SendDiscord(StringLen(msg) > 1990 ? StringSubstr(msg, 0, 1985) + "\n…" : msg) && ok;
   if(InpTelegramToken == "" && InpDiscordWebhook == "")
      Print(msg);
   return ok;
}

bool Post(string url, string headers, string body)
{
   char data[], result[];
   string resultHeaders;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0)
      ArrayResize(data, len - 1);
   ResetLastError();
   int status = WebRequest("POST", url, headers, 5000, data, result, resultHeaders);
   if(status == -1)
   {
      int err = GetLastError();
      PrintFormat("ZO_Analyst: WebRequest failed err=%d%s", err,
                  err == 4060 ? " - add the URL in Tools > Options > Expert Advisors" : "");
      return false;
   }
   if(status < 200 || status >= 300)
   {
      PrintFormat("ZO_Analyst: HTTP %d %s", status, CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8));
      return false;
   }
   return true;
}

bool SendTelegram(string msg)
{
   string url = "https://api.telegram.org/bot" + InpTelegramToken + "/sendMessage";
   string body = "chat_id=" + UrlEncode(InpTelegramChatId) + "&text=" + UrlEncode(msg);
   return Post(url, "Content-Type: application/x-www-form-urlencoded\r\n", body);
}

bool SendDiscord(string msg)
{
   string body = "{\"content\":\"" + JsonEscape(msg) + "\"}";
   return Post(InpDiscordWebhook, "Content-Type: application/json\r\n", body);
}

string UrlEncode(string s)
{
   uchar bytes[];
   int n = StringToCharArray(s, bytes, 0, WHOLE_ARRAY, CP_UTF8) - 1;
   string out = "";
   for(int i = 0; i < n; i++)
   {
      uchar b = bytes[i];
      if((b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') ||
         b == '-' || b == '_' || b == '.' || b == '~')
         out += CharToString(b);
      else
         out += StringFormat("%%%02X", b);
   }
   return out;
}

string JsonEscape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   StringReplace(s, "\r", "");
   StringReplace(s, "\n", "\\n");
   StringReplace(s, "\t", " ");
   return s;
}

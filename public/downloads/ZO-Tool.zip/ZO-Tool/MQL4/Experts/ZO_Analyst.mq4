﻿//+------------------------------------------------------------------+
//| ZO_Analyst.mq4                                                   |
//| Writes a ZO reading of the chart (W1 / D1 / H4 / H1 / M15, bias  |
//| of both trading frames, buy / sell scenarios with EP-SL-TP-RR,   |
//| no-trade warnings) when attached and whenever the structure      |
//| changes, and sends it to Telegram / Discord.                     |
//|                                                                  |
//| Events watched (from ZO_LP's shared files, one chart per         |
//| timeframe):                                                      |
//|  - new LP, LP broken into GLP / RLP, LP cleared / failed         |
//|    (SHs sign when it dies right after its break),                |
//|  - new Main LP, LP-trend change of a timeframe,                  |
//|  - price touching an H4 / D1 / W1 LP (checked every few seconds).|
//| Major events (new Main, trend change on H4+, anything on D1/W1)  |
//| trigger a full analysis (at most once per InpFullGapMin); the    |
//| others are batched into short alerts (InpMinGapMin apart).       |
//|                                                                  |
//| Also forwards the alerts ZO_LP queues in Common\Files\zo_alerts\ |
//| (replaces ZO_Notifier - do not run both). Places no orders.      |
//| Required: Tools > Options > Expert Advisors > Allow WebRequest   |
//| for https://api.telegram.org (and https://discord.com).          |
//+------------------------------------------------------------------+
#property strict

#include <ZO/ZoCore.mqh>

// Fill in your own bot token and chat id (see the Telegram guide).
input string InpTelegramToken   = ""; // Telegram bot token, empty = off
input string InpTelegramChatId  = "";                                      // Telegram chat id
input string InpDiscordWebhook  = "";                     // Discord webhook URL, empty = off
input string InpZosName         = "ZOS";                  // ZOS indicator file name
input string InpTimeframes      = "10080,1440,240,60,15"; // Timeframes read (each needs ZO_LP on its own chart)
input bool   InpEstimate        = false;                  // Estimate timeframes without a ZO_LP file (iCustom, may be wrong)
input string InpLongCtx         = "10080,1440";           // Long frame: context timeframes
input int    InpLongEntry       = 240;                    // Long frame: entry timeframe
input string InpShortCtx        = "240,60";               // Short frame: context timeframes
input int    InpShortEntry      = 15;                     // Short frame: entry timeframe
input bool   InpAnalysisOnStart = true;                   // Send the analysis when attached
input int    InpStartThrottleMin = 10;                    // ... at most once per N minutes (timeframe switches re-attach)
input int    InpEventMinTf      = 60;                     // Events reported from this timeframe up
input int    InpTouchMinTf      = 240;                    // Price-touch alerts from this timeframe up
input double InpTouchPips       = 3;                      // "Touch" = price within N pips of the LP
input int    InpMinGapMin       = 10;                     // Min minutes between two short alert messages
input int    InpFullGapMin      = 60;                     // Min minutes between two change-driven full analyses
input int    InpQuietFrom       = 0;                      // Quiet hours (Hanoi): minor events dropped, major kept for later
input int    InpQuietTo         = 7;
input double InpSlBufferPips    = 2;                      // SL beyond the LP end point
input double InpMinRR           = 1.5;                    // Scenarios below this RR are flagged
input bool   InpForwardQueue    = true;                   // Forward ZO_LP alerts (replaces ZO_Notifier)
input int    InpMaxAgeMinutes   = 15;                     // Drop queued ZO_LP alerts older than this
input bool   InpWriteFile       = true;                   // Also write MQL4\Files\zo_analysis_<symbol>.txt

#define QUEUE_DIR "zo_alerts\\"

ZoZone   g_all[];
ZoTf     g_d[];
int      g_tfs[];
long     g_fileMod[];
datetime g_chartBar = 0;
bool     g_primed = false;

// Snapshot of the previous load, to detect changes.
string   g_snapKeys[];
int      g_snapState[];
int      g_snapDir[];
bool     g_snapMain[];
int      g_snapTrend[];
string   g_touched[];

string   g_minor = "";           // batched short alerts
bool     g_majorPending = false;
string   g_majorLines = "";      // major events, kept through quiet hours
datetime g_lastMinorSent = 0;
datetime g_lastFullSent = 0;
double   g_pip;

//+------------------------------------------------------------------+
int OnInit()
{
   g_zoName = InpZosName;
   g_pip = ZoPip();
   ArrayResize(g_tfs, 0);
   string parts[];
   int n = StringSplit(InpTimeframes, ',', parts);
   for(int i = 0; i < n; i++)
   {
      int tf = (int)StringToInteger(parts[i]);
      if(tf > 0)
      {
         int k = ArraySize(g_tfs);
         ArrayResize(g_tfs, k + 1);
         g_tfs[k] = tf;
      }
   }
   ArrayResize(g_d, ArraySize(g_tfs));
   ArrayResize(g_fileMod, ArraySize(g_tfs));
   ArrayInitialize(g_fileMod, -1);
   ArrayResize(g_snapTrend, ArraySize(g_tfs));
   ArrayInitialize(g_snapTrend, 0);
   g_primed = false;
   if(InpForwardQueue)
      FolderCreate(QUEUE_DIR, FILE_COMMON);
   EventSetTimer(5);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTick()
{
}

void OnTimer()
{
   if(InpForwardQueue)
      ForwardQueue();

   if(DataChanged())
   {
      LoadAll();
      if(!g_primed)
      {
         g_primed = true;
         TakeSnapshot();
         PrimeTouches();
         if(InpAnalysisOnStart && StartAllowed())
            SendFull("PHÂN TÍCH (vừa gắn EA)");
         else if(InpWriteFile)
            WriteFile(BuildAnalysis("PHÂN TÍCH"));
      }
      else
      {
         DiffAndQueue();
         TakeSnapshot();
      }
   }
   if(g_primed)
      CheckTouches();
   FlushMessages();
}

//+------------------------------------------------------------------+
//| Loading                                                          |
//+------------------------------------------------------------------+
int DataIndex(int tf)
{
   for(int i = 0; i < ArraySize(g_tfs); i++)
      if(g_tfs[i] == tf)
         return i;
   return -1;
}

bool DataChanged()
{
   bool changed = !g_primed;
   if(Time[0] != g_chartBar)
   {
      g_chartBar = Time[0];
      changed = true;
   }
   for(int i = 0; i < ArraySize(g_tfs); i++)
   {
      if(g_tfs[i] == Period())
         continue;
      long mod = FileGetInteger(ZoShareFile(g_tfs[i]), FILE_MODIFY_DATE, true);
      if(mod != g_fileMod[i])
      {
         g_fileMod[i] = mod;
         changed = true;
      }
   }
   return changed;
}

void LoadAll()
{
   ArrayResize(g_all, 0);
   for(int i = 0; i < ArraySize(g_tfs); i++)
      ZoLoadTf(g_tfs[i], g_all, g_d[i], InpEstimate);
}

bool Reliable(int tf)
{
   int di = DataIndex(tf);
   return di >= 0 && (g_d[di].source == ZO_SRC_CHART || g_d[di].source == ZO_SRC_SHARED);
}

int TrendOf(int tf)
{
   int di = DataIndex(tf);
   return di >= 0 ? g_d[di].trend : 0;
}

string ZoneKey(const ZoZone &z)
{
   return IntegerToString(z.tf) + "|" + IntegerToString((long)z.t0);
}

//+------------------------------------------------------------------+
//| Change detection                                                 |
//+------------------------------------------------------------------+
void TakeSnapshot()
{
   int n = ArraySize(g_all);
   ArrayResize(g_snapKeys, n);
   ArrayResize(g_snapState, n);
   ArrayResize(g_snapDir, n);
   ArrayResize(g_snapMain, n);
   for(int i = 0; i < n; i++)
   {
      g_snapKeys[i] = ZoneKey(g_all[i]);
      g_snapState[i] = g_all[i].state;
      g_snapDir[i] = g_all[i].dir;
      g_snapMain[i] = g_all[i].isMain;
   }
   for(int f = 0; f < ArraySize(g_tfs); f++)
      g_snapTrend[f] = g_d[f].trend;
}

int FindSnap(string key)
{
   for(int i = 0; i < ArraySize(g_snapKeys); i++)
      if(g_snapKeys[i] == key)
         return i;
   return -1;
}

void Minor(string s)
{
   g_minor += "\n- " + s;
}

void Major(string s)
{
   g_majorLines += "\n- " + s;
   g_majorPending = true;
}

void DiffAndQueue()
{
   for(int f = 0; f < ArraySize(g_tfs); f++)
   {
      int tf = g_tfs[f];
      if(tf < InpEventMinTf || !Reliable(tf))
         continue;
      if(g_d[f].trend != g_snapTrend[f] && g_d[f].trend != 0)
      {
         string s = "Xu thế LP " + ZoTfName(tf) + " đổi sang " + ZoTrendText(g_d[f].trend);
         if(tf >= 240) Major(s); else Minor(s);
      }
   }

   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf < InpEventMinTf || !Reliable(z.tf))
         continue;
      bool big = z.tf >= 1440;
      int p = FindSnap(ZoneKey(z));
      if(p < 0)
      {
         if(!ZoIsAlive(z))
            continue;   // appeared and died between two loads: nothing to act on
         string s = "LP mới " + ZoTfName(z.tf) + " " + ZoDate(z.t0) + " (" + ZoPx(z.lo) + "-" + ZoPx(z.hi) + ")" +
                    (z.dir != 0 ? " đã " + (z.dir > 0 ? "thành GLP" : "thành RLP") : " - chưa break, chưa vào");
         if(big) Major(s); else Minor(s);
         continue;
      }
      if(g_snapDir[p] == 0 && z.dir != 0)
      {
         string s = ZoShortName(z) + " vừa break " + (z.dir > 0 ? "LÊN" : "XUỐNG") + " → chờ retest, không đuổi";
         if(big) Major(s); else Minor(s);
      }
      bool wasAlive = g_snapState[p] != ZO_ST_FAILED && g_snapState[p] != ZO_ST_CLEARED;
      if(wasAlive && !ZoIsAlive(z) && z.dir != 0)
      {
         string s = ZoShortName(z) + (z.state == ZO_ST_CLEARED ? " bị CLEAR" : " bị phá thủng");
         if(z.tBreak > 0 && z.tDead - z.tBreak <= 3 * PeriodSeconds(z.tf))
            s += " ngay sau khi tạo (dấu hiệu SHs - cẩn thận cú quay lại)";
         if(big || z.tf >= 240) Major(s); else Minor(s);
      }
      if(!g_snapMain[p] && z.isMain && ZoIsAlive(z))
         Major("MAIN mới: " + ZoZoneText(z) + " → xu thế " + ZoTfName(z.tf) + " " + (z.dir > 0 ? "TĂNG" : "GIẢM") +
               "; không đánh ngược Main này");
      if(g_snapState[p] != ZO_ST_RETEST && z.state == ZO_ST_RETEST && z.tf >= 240)
         Minor(ZoShortName(z) + " đang RETEST (lần " + IntegerToString(z.retests) + ") → xuống khung nhỏ chờ thu nến / LP cùng chiều");
   }
}

// Price touching an H4+ LP between bar closes.
string TouchKey(const ZoZone &z) { return ZoneKey(z); }

bool InList(const string &arr[], string key)
{
   for(int i = 0; i < ArraySize(arr); i++)
      if(arr[i] == key)
         return true;
   return false;
}

void RemoveFromList(string &arr[], string key)
{
   for(int i = 0; i < ArraySize(arr); i++)
      if(arr[i] == key)
      {
         arr[i] = arr[ArraySize(arr) - 1];
         ArrayResize(arr, ArraySize(arr) - 1);
         return;
      }
}

bool Touching(const ZoZone &z)
{
   return Bid >= z.lo - InpTouchPips * g_pip && Bid <= z.hi + InpTouchPips * g_pip;
}

void PrimeTouches()
{
   ArrayResize(g_touched, 0);
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf >= InpTouchMinTf && ZoIsAlive(g_all[i]) && g_all[i].dir != 0 && Touching(g_all[i]))
      {
         int k = ArraySize(g_touched);
         ArrayResize(g_touched, k + 1);
         g_touched[k] = TouchKey(g_all[i]);
      }
}

void CheckTouches()
{
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf < InpTouchMinTf || !ZoIsAlive(z) || z.dir == 0 || !Reliable(z.tf))
         continue;
      string key = TouchKey(z);
      if(Touching(z))
      {
         if(InList(g_touched, key))
            continue;
         int k = ArraySize(g_touched);
         ArrayResize(g_touched, k + 1);
         g_touched[k] = key;
         bool withTrend = TrendOf(z.tf) == z.dir || TrendOf(z.tf) == 0;
         double end = z.dir > 0 ? z.lo : z.hi;
         string s = StringFormat("Giá %s chạm %s. Điểm cuối (%s) %s, SL gợi ý %s.", ZoPx(Bid), ZoZoneText(z),
                                 z.dir > 0 ? "Low" : "High", ZoPx(end),
                                 ZoPx(z.dir > 0 ? end - InpSlBufferPips * g_pip : end + InpSlBufferPips * g_pip));
         s += withTrend ? " Cùng xu thế → chờ M15/H1 thu nến hoặc LP cùng chiều rồi " + (z.dir > 0 ? "MUA" : "BÁN") + "."
                        : " NGƯỢC xu thế " + ZoTfName(z.tf) + " → dễ bị clear, chỉ quan sát.";
         if(z.tf >= 1440) Major(s); else Minor(s);
      }
      else if(InList(g_touched, key) && ZoDist(z, Bid) > 3 * InpTouchPips)
         RemoveFromList(g_touched, key);   // re-arm once price has left the LP
   }
}

//+------------------------------------------------------------------+
//| Analysis text                                                    |
//+------------------------------------------------------------------+
string TfReading(int tf)
{
   int di = DataIndex(tf);
   if(di < 0)
      return "";
   ZoTf d = g_d[di];
   if(d.source == ZO_SRC_NONE)
      return "\n[" + ZoTfName(tf) + "] không có dữ liệu → mở chart " + ZoTfName(tf) + " có ZOS + ZO_LP.";
   int code;
   int run = ZoColorRun(d, code);
   string s = "\n[" + ZoTfName(tf) + "] ZOS " + ZoColorName(code) + ", " + IntegerToString(run) + " nến" + ZoSourceNote(d) + ".";
   int tw = ZoTwoWickCount(d, 5);
   double br = ZoBodyRatio(d, 1, 3);
   if(tw >= 3)
      s += " Thu nến / nến 2 đầu (" + IntegerToString(tw) + "/5) → giảm áp lực, sắp có run.";
   else if(br < 0.6)
      s += " Thân nến ngắn dần → áp lực yếu đi.";
   else if(br > 1.6)
      s += " Thân nến dài ra → áp lực đang tăng.";
   s += "\n  Xu thế LP: " + ZoTrendText(d.trend) + (d.trendTime > 0 ? " (từ " + ZoDate(d.trendTime) + ")" : "");
   int mg = ZoMainOf(g_all, tf, 1), mr = ZoMainOf(g_all, tf, -1);
   if(mg >= 0) s += " | Main mua " + ZoPx(g_all[mg].lo) + "-" + ZoPx(g_all[mg].hi) + " (" + ZoDate(g_all[mg].t0) + ")";
   if(mr >= 0) s += " | Main bán " + ZoPx(g_all[mr].lo) + "-" + ZoPx(g_all[mr].hi) + " (" + ZoDate(g_all[mr].t0) + ")";

   int at = ZoZoneAt(g_all, tf, Bid);
   if(at >= 0)
   {
      ZoZone z = g_all[at];
      double pos = (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100;
      if(z.dir == 0)
         s += StringFormat("\n  Giá trong %s chưa break (%.0f%%) → tranh chấp, không vào.", ZoZoneText(z), pos);
      else
         s += StringFormat("\n  Giá trong %s [%s] ở %.0f%% vùng.", ZoZoneText(z), ZoStateVi(z.state), pos);
   }
   int up = ZoNeighbour(g_all, tf, Bid, true), dn = ZoNeighbour(g_all, tf, Bid, false);
   s += "\n  Trên: " + (up >= 0 ? StringFormat("%s +%.0fp", ZoZoneText(g_all[up]), ZoDist(g_all[up], Bid)) : "trống");
   s += " | Dưới: " + (dn >= 0 ? StringFormat("%s -%.0fp", ZoZoneText(g_all[dn]), ZoDist(g_all[dn], Bid)) : "trống");
   if(up >= 0 && dn >= 0)
   {
      double room = (g_all[up].lo - g_all[dn].hi) / g_pip;
      if(room < 15)
         s += StringFormat(" → kẹp chật %.0f pip, dễ bị quét.", room);
   }
   return s;
}

// Nearest live LP of direction dir on timeframes >= minTf, on the pull-back side of price (or containing it).
int PullbackZone(int dir, int minTf, int maxTf)
{
   int best = -1;
   double bestD = 0;
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.dir != dir || !ZoIsAlive(z) || z.tf < minTf || z.tf > maxTf || !Reliable(z.tf))
         continue;
      if(dir > 0 && z.lo > Bid) continue;
      if(dir < 0 && z.hi < Bid) continue;
      double dd = ZoDist(z, Bid);
      if(best < 0 || dd < bestD || (dd == bestD && z.tf > g_all[best].tf))
      {
         best = i;
         bestD = dd;
      }
   }
   return best;
}

// First opposite live LP edge ahead of ep in direction dir (timeframe >= minTf).
bool TargetAhead(int dir, double ep, int minTf, double &tp, string &name)
{
   bool found = false;
   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(!ZoIsAlive(z) || z.tf < minTf || z.dir == dir || !Reliable(z.tf))
         continue;
      double edge = dir > 0 ? z.lo : z.hi;
      if(dir > 0 && edge <= ep + 2 * g_pip) continue;
      if(dir < 0 && edge >= ep - 2 * g_pip) continue;
      if(!found || (dir > 0 && edge < tp) || (dir < 0 && edge > tp))
      {
         tp = edge;
         name = ZoShortName(z);
         found = true;
      }
   }
   return found;
}

string Scenario(int dir, int entryTf, int maxTf)
{
   int zi = PullbackZone(dir, entryTf, maxTf);
   string side = dir > 0 ? "MUA" : "BÁN";
   if(zi < 0)
      return "\n  " + side + ": chưa có LP " + (dir > 0 ? "G bên dưới" : "R bên trên") + " để dựa → chờ LP mới.";
   ZoZone z = g_all[zi];
   double end = dir > 0 ? z.lo : z.hi;
   double nearEdge = dir > 0 ? z.hi : z.lo;
   double sl = dir > 0 ? end - InpSlBufferPips * g_pip : end + InpSlBufferPips * g_pip;
   double ep = (nearEdge + end) / 2;   // 50% of the LP: the usual ZO compromise between fill and risk
   string s = StringFormat("\n  %s: vùng %s, cách %.0fp. EP 50%% %s (càng gần %s %s càng tốt), SL %s",
                           side, ZoZoneText(z), ZoDist(z, Bid), ZoPx(ep), dir > 0 ? "Low" : "High", ZoPx(end), ZoPx(sl));
   double tp;
   string tpName;
   if(TargetAhead(dir, ep, entryTf, tp, tpName))
   {
      double rr = MathAbs(tp - ep) / MathMax(MathAbs(ep - sl), Point);
      s += StringFormat(", TP %s (%s) → RR %.1f%s", ZoPx(tp), tpName, rr, rr < InpMinRR ? " (THẤP - bỏ)" : "");
   }
   else
      s += ", phía trước trống → TP theo BE dời sau mỗi LP mới";
   int opp = ZoMainOf(g_all, entryTf, -dir);
   if(opp >= 0 && ((dir > 0 && g_all[opp].lo > ep) || (dir < 0 && g_all[opp].hi < ep)))
      s += StringFormat(". Lưu ý: Main %s %s chặn phía trước.", dir > 0 ? "bán" : "mua", ZoTfName(entryTf));
   s += ". Điều kiện: chạm vùng + " + ZoTfName(entryTf == 240 ? 60 : 15) + " thu nến / LP cùng chiều.";
   return s;
}

string FrameBlock(string title, string ctx, int entryTf)
{
   string parts[];
   if(StringSplit(ctx, ',', parts) < 2)
      return "";
   int a = (int)StringToInteger(parts[0]), b = (int)StringToInteger(parts[1]);
   int ta = TrendOf(a), tb = TrendOf(b);
   string s = "\n\n▶ " + title + " (" + ZoTfName(a) + "/" + ZoTfName(b) + " → " + ZoTfName(entryTf) + "): ";
   int maxTf = MathMax(a, b);
   if(ta > 0 && tb > 0)
      s += "ƯU TIÊN MUA - " + ZoTfName(a) + " và " + ZoTfName(b) + " cùng TĂNG." + Scenario(1, entryTf, maxTf) +
           "\n  BÁN: không - ngược xu thế.";
   else if(ta < 0 && tb < 0)
      s += "ƯU TIÊN BÁN - " + ZoTfName(a) + " và " + ZoTfName(b) + " cùng GIẢM." + Scenario(-1, entryTf, maxTf) +
           "\n  MUA: không - ngược xu thế.";
   else
   {
      s += StringFormat("LỆCH PHA (%s %s, %s %s) → đứng ngoài, hoặc chỉ theo %s khi giá tới điểm cuối LP của nó.",
                        ZoTfName(a), ZoTrendText(ta), ZoTfName(b), ZoTrendText(tb), ZoTfName(a));
      if(ta != 0)
         s += Scenario(ta, b, maxTf);
   }
   // No-trade warning: price inside an unbroken LP of a context timeframe (tranh chấp / nội chiến).
   for(int i = 0; i < ArraySize(parts); i++)
   {
      int tf = (int)StringToInteger(parts[i]);
      int at = ZoZoneAt(g_all, tf, Bid);
      if(at >= 0 && g_all[at].dir == 0)
         s += "\n  ⚠ Giá đang trong LP " + ZoTfName(tf) + " chưa break → tranh chấp, không vào lệnh ở giữa.";
   }
   return s;
}

string BuildAnalysis(string title)
{
   datetime hn = ZoHanoiNow();
   string s = StringFormat("📊 %s %s — %02d:%02d %d/%d (Hà Nội) — giá %s", title, Symbol(), TimeHour(hn), TimeMinute(hn),
                           TimeDay(hn), TimeMonth(hn), ZoPx(Bid));
   for(int i = 0; i < ArraySize(g_tfs); i++)
      s += TfReading(g_tfs[i]);
   s += FrameBlock("Bộ dài", InpLongCtx, InpLongEntry);
   s += FrameBlock("Bộ ngắn", InpShortCtx, InpShortEntry);
   s += "\n\nNguyên tắc: không đuổi break · chỉ mua Low G / bán High R · chờ khung nhỏ chậm lại · SL trước, RR ≥ " +
        DoubleToString(InpMinRR, 1) + " · nội chiến / trước tin đỏ thì nghỉ.";
   return s;
}

//+------------------------------------------------------------------+
//| Sending                                                          |
//+------------------------------------------------------------------+
bool IsQuiet()
{
   if(InpQuietFrom == InpQuietTo)
      return false;
   int h = TimeHour(ZoHanoiNow());
   if(InpQuietFrom < InpQuietTo)
      return h >= InpQuietFrom && h < InpQuietTo;
   return h >= InpQuietFrom || h < InpQuietTo;
}

bool StartAllowed()
{
   string gv = "ZOAN_START_" + Symbol();
   if(GlobalVariableCheck(gv) && TimeLocal() - (datetime)GlobalVariableGet(gv) < InpStartThrottleMin * 60)
      return false;
   GlobalVariableSet(gv, (double)TimeLocal());
   return true;
}

void WriteFile(string text)
{
   int h = FileOpen("zo_analysis_" + Symbol() + ".txt", FILE_WRITE | FILE_TXT | FILE_UNICODE);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, text);
   FileClose(h);
}

void SendFull(string title)
{
   string text = BuildAnalysis(title);
   if(InpWriteFile)
      WriteFile(text);
   Send(text);
   g_lastFullSent = TimeCurrent();
}

void FlushMessages()
{
   if(IsQuiet())
   {
      g_minor = "";   // minor events are stale by morning; major ones are sent when quiet hours end
      return;
   }
   if(g_majorPending && TimeCurrent() - g_lastFullSent >= InpFullGapMin * 60)
   {
      string text = BuildAnalysis("CẬP NHẬT") + "\n\nThay đổi:" + g_majorLines + g_minor;
      g_minor = "";
      g_majorLines = "";
      g_majorPending = false;
      if(InpWriteFile)
         WriteFile(text);
      Send(text);
      g_lastFullSent = TimeCurrent();
      g_lastMinorSent = TimeCurrent();
      return;
   }
   // A major event inside the full-analysis gap still goes out right away, as a short alert.
   if((g_majorPending || g_minor != "") && TimeCurrent() - g_lastMinorSent >= InpMinGapMin * 60)
   {
      Send((g_majorPending ? "⚠ " : "🔔 ") + Symbol() + " " + ZoPx(Bid) + g_majorLines + g_minor);
      g_minor = "";
      g_majorLines = "";
      g_majorPending = false;
      g_lastMinorSent = TimeCurrent();
   }
}

// ZO_LP alert files (UTF-16, named "<unix time>_<hash>.txt").
void ForwardQueue()
{
   string names[];
   string name;
   long handle = FileFindFirst(QUEUE_DIR + "*.txt", name, FILE_COMMON);
   if(handle == INVALID_HANDLE)
      return;
   do
   {
      int k = ArraySize(names);
      ArrayResize(names, k + 1);
      names[k] = name;
   }
   while(FileFindNext(handle, name));
   FileFindClose(handle);
   // ArraySort() does not handle strings in MQL4: sort by hand (names start with a timestamp).
   for(int a = 0; a < ArraySize(names); a++)
      for(int b = a + 1; b < ArraySize(names); b++)
         if(StringCompare(names[b], names[a]) < 0)
         {
            string tmp = names[a];
            names[a] = names[b];
            names[b] = tmp;
         }
   for(int i = 0; i < ArraySize(names); i++)
   {
      string path = QUEUE_DIR + names[i];
      long queuedAt = StringToInteger(StringSubstr(names[i], 0, StringFind(names[i], "_")));
      if(InpMaxAgeMinutes > 0 && queuedAt > 0 && (long)TimeLocal() - queuedAt > InpMaxAgeMinutes * 60)
      {
         FileDelete(path, FILE_COMMON);
         continue;
      }
      int h = FileOpen(path, FILE_READ | FILE_TXT | FILE_COMMON | FILE_UNICODE);
      if(h == INVALID_HANDLE)
         continue;
      string msg = "";
      while(!FileIsEnding(h))
         msg += (msg == "" ? "" : "\n") + FileReadString(h);
      FileClose(h);
      if(msg == "" || Send(msg))
         FileDelete(path, FILE_COMMON);
      else
         break;
   }
}

bool Send(string msg)
{
   if(StringLen(msg) > 4000)   // Telegram limit is 4096 characters
      msg = StringSubstr(msg, 0, 3990) + "\n…";
   bool ok = true;
   if(InpTelegramToken != "" && InpTelegramChatId != "")
      ok = SendTelegram(msg) && ok;
   if(InpDiscordWebhook != "")
      ok = SendDiscord(StringLen(msg) > 1990 ? StringSubstr(msg, 0, 1985) + "\n…" : msg) && ok;
   if(InpTelegramToken == "" && InpDiscordWebhook == "")
      Print(msg);
   return ok;
}

bool Post(string url, string headers, string body)
{
   char data[], result[];
   string resultHeaders;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0)
      ArrayResize(data, len - 1);
   ResetLastError();
   int status = WebRequest("POST", url, headers, 5000, data, result, resultHeaders);
   if(status == -1)
   {
      int err = GetLastError();
      PrintFormat("ZO_Analyst: WebRequest failed err=%d%s", err,
                  err == 4060 ? " - add the URL in Tools > Options > Expert Advisors" : "");
      return false;
   }
   if(status < 200 || status >= 300)
   {
      PrintFormat("ZO_Analyst: HTTP %d %s", status, CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8));
      return false;
   }
   return true;
}

bool SendTelegram(string msg)
{
   string url = "https://api.telegram.org/bot" + InpTelegramToken + "/sendMessage";
   string body = "chat_id=" + UrlEncode(InpTelegramChatId) + "&text=" + UrlEncode(msg);
   return Post(url, "Content-Type: application/x-www-form-urlencoded\r\n", body);
}

bool SendDiscord(string msg)
{
   string body = "{\"content\":\"" + JsonEscape(msg) + "\"}";
   return Post(InpDiscordWebhook, "Content-Type: application/json\r\n", body);
}

string UrlEncode(string s)
{
   uchar bytes[];
   int n = StringToCharArray(s, bytes, 0, WHOLE_ARRAY, CP_UTF8) - 1;
   string out = "";
   for(int i = 0; i < n; i++)
   {
      uchar b = bytes[i];
      if((b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') ||
         b == '-' || b == '_' || b == '.' || b == '~')
         out += CharToString(b);
      else
         out += StringFormat("%%%02X", b);
   }
   return out;
}

string JsonEscape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   StringReplace(s, "\r", "");
   StringReplace(s, "\n", "\\n");
   StringReplace(s, "\t", " ");
   return s;
}

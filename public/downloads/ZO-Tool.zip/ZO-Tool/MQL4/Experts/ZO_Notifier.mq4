﻿//+------------------------------------------------------------------+
//| ZO_Notifier.mq4                                                  |
//| Forwards alerts queued by ZO_LP (Common\Files\zo_alerts\*.txt)   |
//| to Telegram and/or a Discord webhook.                            |
//|                                                                  |
//| Indicators cannot call WebRequest(), so ZO_LP writes one file    |
//| per alert and this EA sends and deletes them. Attach it to ONE   |
//| chart only. Required: Tools > Options > Expert Advisors >        |
//| "Allow WebRequest for listed URL" with                           |
//|   https://api.telegram.org                                       |
//|   https://discord.com                                            |
//| Places no orders.                                                |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_Notifier - Chi chuyen canh bao cua ZO_LP sang Telegram / Discord."
#property description "KHONG can neu da dung ZO_Analyst (chay ca hai se gui trung tin)."

#include <ZO/ZoSecrets.mqh>
// Defaults come from ZoSecrets.mqh (git-ignored; copy ZoSecrets.example.mqh): the owner's build carries its own bot.
input string InpTelegramToken  = ZO_TELEGRAM_TOKEN; // Telegram bot token, empty = off
input string InpTelegramChatId = ZO_TELEGRAM_CHAT_ID;                                      // Telegram chat id
input string InpDiscordWebhook = "";   // Discord webhook URL, empty = off
input int    InpPollSeconds    = 3;    // Queue polling interval
input bool   InpSendTestOnStart = true; // Send a test message when attached
input int    InpMaxAgeMinutes  = 15;   // Drop queued alerts older than this (backlog from when the EA was off)

#define QUEUE_DIR "zo_alerts\\"

//+------------------------------------------------------------------+
int OnInit()
{
   if(InpTelegramToken == "" && InpDiscordWebhook == "")
   {
      Alert("ZO_Notifier: set a Telegram token/chat id or a Discord webhook");
      return INIT_PARAMETERS_INCORRECT;
   }
   FolderCreate(QUEUE_DIR, FILE_COMMON);
   EventSetTimer(MathMax(1, InpPollSeconds));
   if(InpSendTestOnStart)
      Send("ZO_Notifier đã kết nối: " + AccountServer() + " (" + Symbol() + ")");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTick()
{
}

void OnTimer()
{
   // Collect names first: deleting while iterating a find handle is unreliable.
   string names[];
   string name;
   long handle = FileFindFirst(QUEUE_DIR + "*.txt", name, FILE_COMMON);
   if(handle == INVALID_HANDLE)
      return;
   do
   {
      int k = ArraySize(names);
      ArrayResize(names, k + 1);
      names[k] = name;
   }
   while(FileFindNext(handle, name));
   FileFindClose(handle);

   // File names start with a timestamp -> sorting them gives chronological order.
   // (ArraySort() does not support string arrays in MQL4, so sort by hand.)
   for(int a = 0; a < ArraySize(names); a++)
      for(int b = a + 1; b < ArraySize(names); b++)
         if(StringCompare(names[b], names[a]) < 0)
         {
            string tmp = names[a];
            names[a] = names[b];
            names[b] = tmp;
         }
   int dropped = 0;
   for(int i = 0; i < ArraySize(names); i++)
   {
      string path = QUEUE_DIR + names[i];
      // Stale alerts (queued while this EA was not running) are dropped: old prices only confuse.
      long queuedAt = StringToInteger(StringSubstr(names[i], 0, StringFind(names[i], "_")));
      if(InpMaxAgeMinutes > 0 && queuedAt > 0 && (long)TimeLocal() - queuedAt > InpMaxAgeMinutes * 60)
      {
         FileDelete(path, FILE_COMMON);
         dropped++;
         continue;
      }
      // ZO_LP writes UTF-16 so Vietnamese text survives; it is converted to UTF-8 when posted.
      int h = FileOpen(path, FILE_READ | FILE_TXT | FILE_COMMON | FILE_UNICODE);
      if(h == INVALID_HANDLE)
         continue;
      string msg = "";
      while(!FileIsEnding(h))
         msg += (msg == "" ? "" : "\n") + FileReadString(h);
      FileClose(h);

      if(msg == "" || Send(msg))
         FileDelete(path, FILE_COMMON);
      else
         break;   // keep the file and retry on the next poll
   }
   if(dropped > 0)
      Send(StringFormat("ZO_Notifier: bỏ qua %d cảnh báo cũ hơn %d phút (tồn lại lúc EA chưa chạy).",
                        dropped, InpMaxAgeMinutes));
}

//+------------------------------------------------------------------+
// Sends to every configured channel. Returns false if any channel failed.
bool Send(string msg)
{
   bool ok = true;
   if(InpTelegramToken != "" && InpTelegramChatId != "")
      ok = SendTelegram(msg) && ok;
   if(InpDiscordWebhook != "")
      ok = SendDiscord(msg) && ok;
   return ok;
}

bool Post(string url, string headers, string body)
{
   char data[], result[];
   string resultHeaders;
   int len = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(len > 0)
      ArrayResize(data, len - 1);   // drop the trailing null terminator
   ResetLastError();
   int status = WebRequest("POST", url, headers, 5000, data, result, resultHeaders);
   if(status == -1)
   {
      int err = GetLastError();
      PrintFormat("ZO_Notifier: WebRequest failed err=%d%s", err,
                  err == 4060 ? " - add the URL in Tools > Options > Expert Advisors" : "");
      return false;
   }
   if(status < 200 || status >= 300)
   {
      PrintFormat("ZO_Notifier: HTTP %d %s", status, CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8));
      return false;
   }
   return true;
}

bool SendTelegram(string msg)
{
   string url = "https://api.telegram.org/bot" + InpTelegramToken + "/sendMessage";
   string body = "chat_id=" + UrlEncode(InpTelegramChatId) + "&text=" + UrlEncode(msg);
   return Post(url, "Content-Type: application/x-www-form-urlencoded\r\n", body);
}

bool SendDiscord(string msg)
{
   string body = "{\"content\":\"" + JsonEscape(msg) + "\"}";
   return Post(InpDiscordWebhook, "Content-Type: application/json\r\n", body);
}

//+------------------------------------------------------------------+
string UrlEncode(string s)
{
   uchar bytes[];
   int n = StringToCharArray(s, bytes, 0, WHOLE_ARRAY, CP_UTF8) - 1;
   string out = "";
   for(int i = 0; i < n; i++)
   {
      uchar b = bytes[i];
      if((b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') ||
         b == '-' || b == '_' || b == '.' || b == '~')
         out += CharToString(b);
      else
         out += StringFormat("%%%02X", b);
   }
   return out;
}

string JsonEscape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   StringReplace(s, "\r", "");
   StringReplace(s, "\n", "\\n");
   StringReplace(s, "\t", " ");
   return s;
}

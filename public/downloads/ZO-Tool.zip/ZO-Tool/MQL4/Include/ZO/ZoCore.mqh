﻿//+------------------------------------------------------------------+
//| ZoCore.mqh                                                       |
//| Shared LP model for ZO_DrawLP (script), ZO_View (indicator) and  |
//| ZO_Analyst (EA).                                                 |
//|                                                                  |
//| Data sources per timeframe, best first:                          |
//|  1. the chart's own timeframe: ZOS read directly (always right); |
//|  2. Common\Files\zo_lp\<symbol>_<tf>.csv written by ZO_LP running |
//|     on that timeframe's own chart;                               |
//|  3. iCustom(ZOS) on another timeframe = ESTIMATE (ZOS read from  |
//|     a different chart timeframe returns different candles).      |
//|                                                                  |
//| LP rules are the same as ZO_LP (see its header). Main LPs are    |
//| recomputed here for every timeframe (ZO_LP only tags them up to  |
//| H1): an LP becomes Main when it is the newest live opposite LP,  |
//| broken before, sitting on its own side and formed AFTER the LP   |
//| that dies; only the newest Main per direction is kept. H4+ LPs   |
//| die when a ZOS body is cut by their end point. Trend = direction |
//| of the latest Main (ZoMainTrend). ZoCheckZOU = entry signals of  |
//| the backtested ZOU system.                                       |
//+------------------------------------------------------------------+
#property strict

#define ZO_ST_FRESH   0
#define ZO_ST_BROKEN  1
#define ZO_ST_RETEST  2
#define ZO_ST_RUN     3
#define ZO_ST_FAILED  4
#define ZO_ST_CLEARED 5

#define ZO_SRC_NONE     0
#define ZO_SRC_CHART    1
#define ZO_SRC_SHARED   2
#define ZO_SRC_ESTIMATE 3

#define ZO_SHARE_DIR  "zo_lp\\"
#define ZO_CACHE      13          // closed candles kept per timeframe (shift 1..12)
#define ZO_RN_STEP    0.0025      // round numbers: every 25 pip (ZO definition); shown as context, not an entry level

struct ZoZone
{
   int      tf;
   datetime t0;        // open time of the first Build candle
   datetime tLast;     // last candle that shaped the zone
   datetime tBreak;    // candle that broke it into GLP / RLP
   datetime tDead;     // candle that cleared / failed it
   datetime tMain;     // candle whose kill made this LP Main (0 = not Main)
   double   hi;
   double   lo;
   int      dir;       // +1 GLP, -1 RLP, 0 not broken
   int      state;
   int      retests;
   int      builds;
   bool     isMain;
};

struct ZoTf
{
   int      tf;
   int      source;       // ZO_SRC_*
   bool     stale;        // shared file older than one closed bar
   int      trend;        // +1 up, -1 down, 0 unknown (side that killed the last LP)
   datetime trendTime;
   datetime lastBar;     // newest closed bar the data covers
   double   cH[ZO_CACHE];
   double   cL[ZO_CACHE];
   double   cO[ZO_CACHE];
   double   cC[ZO_CACHE];
   bool     cB[ZO_CACHE];
   int      cCol[ZO_CACHE];  // 1 green, 2 blue, -1 red, -2 pink, 9 build, 0 unknown
};

string g_zoName = "ZOS";      // ZOS indicator file name, set by the program
int    g_zoLookback = 500;
double g_zoMinWickPts = 1;

//+------------------------------------------------------------------+
//| Small helpers                                                    |
//+------------------------------------------------------------------+
string ZoTfName(int tf)
{
   switch(tf)
   {
      case 1:     return "M1";
      case 5:     return "M5";
      case 15:    return "M15";
      case 30:    return "M30";
      case 60:    return "H1";
      case 240:   return "H4";
      case 1440:  return "D1";
      case 10080: return "W1";
      case 43200: return "MN";
   }
   return "TF" + IntegerToString(tf);
}

double ZoPip()
{
   return (Digits == 3 || Digits == 5) ? Point * 10 : Point;
}

string ZoPx(double p)
{
   return DoubleToString(p, Digits);
}

bool ZoIsAlive(const ZoZone &z)
{
   return z.state != ZO_ST_FAILED && z.state != ZO_ST_CLEARED;
}

string ZoKind(const ZoZone &z)
{
   if(z.dir > 0) return z.isMain ? "MGLP" : "GLP";
   if(z.dir < 0) return z.isMain ? "MRLP" : "RLP";
   return "LP";
}

string ZoDate(datetime t)
{
   return IntegerToString(TimeDay(t)) + "/" + IntegerToString(TimeMonth(t));
}

string ZoStateVi(int st)
{
   switch(st)
   {
      case ZO_ST_FRESH:   return "chưa break";
      case ZO_ST_BROKEN:  return "chờ retest";
      case ZO_ST_RETEST:  return "RETEST";
      case ZO_ST_RUN:     return "đã chạy";
      case ZO_ST_FAILED:  return "thủng";
      case ZO_ST_CLEARED: return "bị clear";
   }
   return "?";
}

string ZoZoneText(const ZoZone &z)
{
   return ZoKind(z) + " " + ZoTfName(z.tf) + " " + ZoDate(z.t0) + " (" + ZoPx(z.lo) + "-" + ZoPx(z.hi) + ")";
}

string ZoShortName(const ZoZone &z)
{
   return ZoKind(z) + " " + ZoTfName(z.tf) + " " + ZoDate(z.t0);
}

double ZoDist(const ZoZone &z, double p)
{
   double pip = ZoPip();
   if(p > z.hi) return (p - z.hi) / pip;
   if(p < z.lo) return (z.lo - p) / pip;
   return 0;
}

string ZoColorName(int code)
{
   switch(code)
   {
      case 1:  return "xanh lá (tăng mạnh)";
      case 2:  return "xanh dương (tăng yếu dần)";
      case -1: return "đỏ (giảm mạnh)";
      case -2: return "tím (giảm yếu dần)";
      case 9:  return "vàng (build)";
   }
   return "?";
}

string ZoColorShort(int code)
{
   switch(code)
   {
      case 1:  return "xanh lá";
      case 2:  return "xanh dương";
      case -1: return "đỏ";
      case -2: return "tím";
      case 9:  return "vàng";
   }
   return "?";
}

string ZoTrendText(int t)
{
   return t > 0 ? "TĂNG" : t < 0 ? "GIẢM" : "chưa rõ";
}

string ZoSourceNote(const ZoTf &d)
{
   if(d.source == ZO_SRC_ESTIMATE) return " [ƯỚC TÍNH]";
   if(d.source == ZO_SRC_NONE)     return " [không có dữ liệu]";
   if(d.stale)                     return " [dữ liệu cũ]";
   return "";
}

//+------------------------------------------------------------------+
//| ZOS access (iCustom on this terminal)                            |
//+------------------------------------------------------------------+
bool ZoReadChart(int tf, int shift, double &h, double &l, double &o, double &c, bool &build)
{
   h = iCustom(Symbol(), tf, g_zoName, 0, shift);
   l = iCustom(Symbol(), tf, g_zoName, 1, shift);
   o = iCustom(Symbol(), tf, g_zoName, 2, shift);
   c = iCustom(Symbol(), tf, g_zoName, 3, shift);
   if(h == EMPTY_VALUE || l == EMPTY_VALUE || o == EMPTY_VALUE || c == EMPTY_VALUE)
      return false;
   if(l <= 0 || l > MathMin(o, c) + Point || h < MathMax(o, c) - Point)
      return false;
   build = (iCustom(Symbol(), tf, g_zoName, 14, shift) > 0.5);
   return true;
}

int ZoReadColorChart(int tf, int shift)
{
   int codes[5] = {1, 2, -1, -2, 9};
   for(int p = 0; p < 5; p++)
   {
      double v = iCustom(Symbol(), tf, g_zoName, 4 + p * 2, shift);
      if(v != EMPTY_VALUE && v > 0)
         return codes[p];
   }
   return 0;
}

void ZoFillCacheFromChart(ZoTf &d)
{
   for(int s = 1; s < ZO_CACHE; s++)
   {
      double h, l, o, c;
      bool b;
      if(!ZoReadChart(d.tf, s, h, l, o, c, b))
      {
         h = l = o = c = 0;
         b = false;
      }
      d.cH[s] = h; d.cL[s] = l; d.cO[s] = o; d.cC[s] = c; d.cB[s] = b;
      d.cCol[s] = ZoReadColorChart(d.tf, s);
   }
}

//+------------------------------------------------------------------+
//| LP detection (same rules as ZO_LP)                               |
//+------------------------------------------------------------------+
void ZoAddZone(ZoZone &out[], int tf, datetime t0, datetime tLast, double hi, double lo, int builds)
{
   int k = ArraySize(out);
   ArrayResize(out, k + 1);
   out[k].tf = tf;
   out[k].t0 = t0;
   out[k].tLast = tLast;
   out[k].tBreak = 0;
   out[k].tDead = 0;
   out[k].tMain = 0;
   out[k].hi = hi;
   out[k].lo = lo;
   out[k].dir = 0;
   out[k].state = ZO_ST_FRESH;
   out[k].retests = 0;
   out[k].builds = builds;
   out[k].isMain = false;
}

void ZoStep(ZoZone &z, datetime t, double h, double l, double o, double c)
{
   if(!ZoIsAlive(z))
      return;
   if(z.state == ZO_ST_FRESH)
   {
      if(c > z.hi)      { z.dir = 1;  z.state = ZO_ST_BROKEN; z.tBreak = t; }
      else if(c < z.lo) { z.dir = -1; z.state = ZO_ST_BROKEN; z.tBreak = t; }
      return;
   }
   double bodyHi = MathMax(o, c), bodyLo = MathMin(o, c);
   if(bodyLo <= z.lo && bodyHi >= z.hi)
   {
      z.state = ZO_ST_CLEARED;
      return;
   }
   // H4 and above (user rule 30/9, backtest BODY_DEATH): a broken LP dies as soon as a ZOS BODY is cut by its
   // end point (GLP: body below the Low; RLP: body above the High), not only on a close beyond it.
   if(z.tf >= 240 && ((z.dir > 0 && bodyLo < z.lo) || (z.dir < 0 && bodyHi > z.hi)))
   {
      z.state = ZO_ST_FAILED;
      return;
   }
   if(z.dir > 0)
   {
      if(c < z.lo)                                  { z.state = ZO_ST_FAILED; return; }
      bool inside = (l <= z.hi);
      if((z.state == ZO_ST_BROKEN || z.state == ZO_ST_RUN) && inside) { z.state = ZO_ST_RETEST; z.retests++; }
      else if(z.state == ZO_ST_RETEST && l > z.hi)  z.state = ZO_ST_RUN;
   }
   else
   {
      if(c > z.hi)                                  { z.state = ZO_ST_FAILED; return; }
      bool inside = (h >= z.lo);
      if((z.state == ZO_ST_BROKEN || z.state == ZO_ST_RUN) && inside) { z.state = ZO_ST_RETEST; z.retests++; }
      else if(z.state == ZO_ST_RETEST && h < z.lo)  z.state = ZO_ST_RUN;
   }
}

// Rebuilds every LP of one timeframe from ZOS on this terminal, oldest bar first.
void ZoScan(int tf, ZoZone &out[], int &trend, datetime &trendTime)
{
   int bars = MathMin(g_zoLookback, iBars(Symbol(), tf) - 2);
   ZoZone zs[];
   ArrayResize(zs, 0);
   trend = 0;
   trendTime = 0;
   bool     inChain = false;
   datetime chT0 = 0, chTLast = 0;
   double   chHi = 0, chLo = 0;
   int      chCount = 0;
   bool     chTwoWick = false;

   for(int s = bars; s >= 1; s--)
   {
      double h, l, o, c;
      bool build;
      if(!ZoReadChart(tf, s, h, l, o, c, build))
      {
         inChain = false;
         continue;
      }
      datetime t = iTime(Symbol(), tf, s);
      bool twoWick = (h - MathMax(o, c) >= g_zoMinWickPts * Point) && (MathMin(o, c) - l >= g_zoMinWickPts * Point);

      if(inChain && !build)
      {
         if(chCount >= 2 || chTwoWick)
            ZoAddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);
         inChain = false;
      }

      bool consumed = false;
      if(build && !inChain)
      {
         for(int i = ArraySize(zs) - 1; i >= 0; i--)
         {
            if(zs[i].state != ZO_ST_FRESH)
               continue;
            if(!(h >= zs[i].lo && l <= zs[i].hi) || !(c >= zs[i].lo && c <= zs[i].hi))
               continue;
            if(h > zs[i].hi || l < zs[i].lo)
            {
               zs[i].hi = MathMax(zs[i].hi, h);
               zs[i].lo = MathMin(zs[i].lo, l);
               zs[i].tLast = t;
               zs[i].builds++;
            }
            consumed = true;
            break;
         }
      }

      for(int i = 0; i < ArraySize(zs); i++)
      {
         if(zs[i].tLast >= t)
            continue;
         bool wasBroken = (zs[i].dir != 0 && ZoIsAlive(zs[i]));
         ZoStep(zs[i], t, h, l, o, c);
         if(wasBroken && !ZoIsAlive(zs[i]))
         {
            zs[i].tDead = t;
            trend = -zs[i].dir;
            trendTime = t;
         }
      }

      if(build && !consumed)
      {
         if(!inChain)
         {
            inChain = true;
            chT0 = t; chHi = h; chLo = l; chCount = 0; chTwoWick = false;
         }
         chTLast = t;
         chHi = MathMax(chHi, h);
         chLo = MathMin(chLo, l);
         chCount++;
         chTwoWick = chTwoWick || twoWick;
      }
   }
   if(inChain && (chCount >= 2 || chTwoWick))
      ZoAddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);

   for(int i = 0; i < ArraySize(zs); i++)
   {
      int k = ArraySize(out);
      ArrayResize(out, k + 1);
      out[k] = zs[i];
   }
}

// Main tagging for the zones of one timeframe [from, to), replaying LP deaths in time order.
void ZoRecomputeMain(ZoZone &zs[], int from, int to)
{
   for(int i = from; i < to; i++)
   {
      zs[i].isMain = false;
      zs[i].tMain = 0;
   }
   // Victims: broken LPs that died, processed oldest death first.
   int victims[];
   ArrayResize(victims, 0);
   for(int i = from; i < to; i++)
      if(zs[i].dir != 0 && zs[i].tDead > 0)
      {
         int k = ArraySize(victims);
         ArrayResize(victims, k + 1);
         victims[k] = i;
      }
   for(int a = 0; a < ArraySize(victims); a++)
      for(int b = a + 1; b < ArraySize(victims); b++)
         if(zs[victims[b]].tDead < zs[victims[a]].tDead)
         {
            int tmp = victims[a];
            victims[a] = victims[b];
            victims[b] = tmp;
         }

   for(int v = 0; v < ArraySize(victims); v++)
   {
      int vi = victims[v];
      datetime t = zs[vi].tDead;
      int attackDir = -zs[vi].dir;
      int best = -1;
      for(int i = from; i < to; i++)
      {
         if(i == vi || zs[i].dir != attackDir || zs[i].tBreak == 0 || zs[i].tBreak > t)
            continue;
         if(zs[i].tDead != 0 && zs[i].tDead <= t)   // not alive at that moment
            continue;
         if(attackDir > 0 && zs[i].lo > zs[vi].lo) continue;
         if(attackDir < 0 && zs[i].hi < zs[vi].hi) continue;
         // An LP becomes Main only by clearing an OLDER opposite LP, never one formed after it.
         if(zs[i].t0 <= zs[vi].t0) continue;
         if(best < 0 || zs[i].tBreak > zs[best].tBreak)
            best = i;
      }
      if(best < 0)
         continue;
      for(int i = from; i < to; i++)
         if(zs[i].dir == attackDir)
            zs[i].isMain = false;
      zs[best].isMain = true;
      zs[best].tMain = t;
   }
}

//+------------------------------------------------------------------+
//| Shared files written by ZO_LP                                    |
//+------------------------------------------------------------------+
string ZoShareFile(int tf)
{
   return ZO_SHARE_DIR + Symbol() + "_" + IntegerToString(tf) + ".csv";
}

long   ZoReadLong(int h) { return StringToInteger(FileReadString(h)); }
double ZoReadDbl(int h)  { return StringToDouble(FileReadString(h)); }

bool ZoLoadShared(ZoTf &d, ZoZone &out[])
{
   string name = ZoShareFile(d.tf);
   if(!FileIsExist(name, FILE_COMMON))
      return false;
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_COMMON | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
      return false;
   bool gotHeader = false;
   while(!FileIsEnding(h))
   {
      string type = FileReadString(h);
      if(type == "H")
      {
         d.lastBar = (datetime)ZoReadLong(h);
         d.trend = (int)ZoReadLong(h);
         d.trendTime = (datetime)ZoReadLong(h);
         ZoReadLong(h);   // valid bars
         ZoReadLong(h);   // first valid bar
         gotHeader = true;
      }
      else if(type == "C")
      {
         int s = (int)ZoReadLong(h);
         double zh = ZoReadDbl(h), zl = ZoReadDbl(h), zo = ZoReadDbl(h), zc = ZoReadDbl(h), zb = ZoReadDbl(h);
         int col = (int)ZoReadLong(h);
         if(s >= 1 && s < ZO_CACHE)
         {
            d.cH[s] = zh; d.cL[s] = zl; d.cO[s] = zo; d.cC[s] = zc; d.cB[s] = zb > 0.5; d.cCol[s] = col;
         }
      }
      else if(type == "Z")
      {
         int k = ArraySize(out);
         ArrayResize(out, k + 1);
         out[k].tf = d.tf;
         out[k].t0 = (datetime)ZoReadLong(h);
         out[k].tLast = (datetime)ZoReadLong(h);
         out[k].tBreak = (datetime)ZoReadLong(h);
         out[k].tDead = (datetime)ZoReadLong(h);
         out[k].lo = ZoReadDbl(h);
         out[k].hi = ZoReadDbl(h);
         out[k].dir = (int)ZoReadLong(h);
         out[k].state = (int)ZoReadLong(h);
         out[k].retests = (int)ZoReadLong(h);
         out[k].builds = (int)ZoReadLong(h);
         ZoReadLong(h);   // ZO_LP's own Main flag (H1 and below only) - recomputed
         out[k].isMain = false;
         out[k].tMain = 0;
      }
      else
         while(!FileIsLineEnding(h) && !FileIsEnding(h))
            FileReadString(h);
   }
   FileClose(h);
   if(!gotHeader)
      return false;
   d.stale = d.lastBar < iTime(Symbol(), d.tf, 2);
   return true;
}

// Loads one timeframe into all[] (appended) and fills d. allowEstimate: fall back to iCustom.
bool ZoLoadTf(int tf, ZoZone &all[], ZoTf &d, bool allowEstimate)
{
   d.tf = tf;
   d.source = ZO_SRC_NONE;
   d.stale = false;
   d.trend = 0;
   d.trendTime = 0;
   d.lastBar = 0;
   for(int s = 0; s < ZO_CACHE; s++)
   {
      d.cH[s] = 0; d.cL[s] = 0; d.cO[s] = 0; d.cC[s] = 0; d.cB[s] = false; d.cCol[s] = 0;
   }
   int from = ArraySize(all);
   if(tf == Period())
   {
      ZoScan(tf, all, d.trend, d.trendTime);
      ZoFillCacheFromChart(d);
      d.lastBar = iTime(Symbol(), tf, 1);
      d.source = ZO_SRC_CHART;
   }
   else if(ZoLoadShared(d, all))
      d.source = ZO_SRC_SHARED;
   else if(allowEstimate)
   {
      ZoScan(tf, all, d.trend, d.trendTime);
      ZoFillCacheFromChart(d);
      d.lastBar = iTime(Symbol(), tf, 1);
      d.source = ZO_SRC_ESTIMATE;
   }
   else
      return false;
   ZoRecomputeMain(all, from, ArraySize(all));
   return true;
}

//+------------------------------------------------------------------+
//| Queries                                                          |
//+------------------------------------------------------------------+
int ZoMainOf(const ZoZone &zs[], int tf, int dir)
{
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].tf == tf && zs[i].dir == dir && zs[i].isMain && ZoIsAlive(zs[i]))
         return i;
   return -1;
}

bool ZoIsShield(const ZoZone &zs[], int idx)
{
   if(zs[idx].isMain || zs[idx].dir == 0 || !ZoIsAlive(zs[idx]))
      return false;
   int m = ZoMainOf(zs, zs[idx].tf, zs[idx].dir);
   return m >= 0 && zs[idx].t0 > zs[m].tBreak;
}

// Live LP of a timeframe that contains the price (broken ones first).
int ZoZoneAt(const ZoZone &zs[], int tf, double p)
{
   int best = -1;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]) || p < zs[i].lo || p > zs[i].hi)
         continue;
      if(best < 0 || (zs[best].dir == 0 && zs[i].dir != 0) || zs[i].t0 > zs[best].t0)
         best = i;
   }
   return best;
}

// Nearest live LP of a timeframe fully above / below the price.
int ZoNeighbour(const ZoZone &zs[], int tf, double p, bool above)
{
   int best = -1;
   double bestD = 0;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]))
         continue;
      if(above && zs[i].lo <= p) continue;
      if(!above && zs[i].hi >= p) continue;
      double dd = ZoDist(zs[i], p);
      if(best < 0 || dd < bestD)
      {
         best = i;
         bestD = dd;
      }
   }
   return best;
}

double ZoScore(const ZoZone &zs[], int i)
{
   double s = 0;
   if(zs[i].isMain)               s += 100;
   s += MathMin(zs[i].builds, 4) * 5;
   if(zs[i].state == ZO_ST_RETEST) s += 12;
   else if(zs[i].state == ZO_ST_BROKEN) s += 10;
   else if(zs[i].state == ZO_ST_FRESH) s += 6;
   else if(zs[i].state == ZO_ST_RUN) s += 2;
   s -= MathMin(zs[i].retests, 5) * 2;
   s += (double)zs[i].t0 / 1.0e9;
   return s;
}

// Important LPs of one timeframe: overlapping same-direction LPs reduced to the strongest,
// then Mains + the LP at price + the nearest perSide above and below.
int ZoSelect(const ZoZone &zs[], int tf, double p, int perSide, bool withFresh, int &sel[])
{
   ArrayResize(sel, 0);
   int cand[];
   ArrayResize(cand, 0);
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]))
         continue;
      if(zs[i].dir == 0 && !withFresh)
         continue;
      bool dominated = false;
      for(int j = 0; j < ArraySize(zs) && !dominated; j++)
      {
         if(j == i || zs[j].tf != tf || !ZoIsAlive(zs[j]) || zs[j].dir != zs[i].dir)
            continue;
         if(zs[j].dir == 0 && !withFresh)
            continue;
         bool overlap = zs[i].lo <= zs[j].hi && zs[i].hi >= zs[j].lo;
         if(overlap && ZoScore(zs, j) > ZoScore(zs, i))
            dominated = true;
      }
      if(!dominated)
      {
         int k = ArraySize(cand);
         ArrayResize(cand, k + 1);
         cand[k] = i;
      }
   }
   // Sort candidates by distance to price.
   for(int a = 0; a < ArraySize(cand); a++)
      for(int b = a + 1; b < ArraySize(cand); b++)
         if(ZoDist(zs[cand[b]], p) < ZoDist(zs[cand[a]], p))
         {
            int tmp = cand[a];
            cand[a] = cand[b];
            cand[b] = tmp;
         }
   int nAbove = 0, nBelow = 0;
   for(int a = 0; a < ArraySize(cand); a++)
   {
      int i = cand[a];
      bool keep = zs[i].isMain;
      if(p >= zs[i].lo && p <= zs[i].hi)
         keep = true;
      else if(zs[i].lo > p && nAbove < perSide)
      {
         keep = true;
         nAbove++;
      }
      else if(zs[i].hi < p && nBelow < perSide)
      {
         keep = true;
         nBelow++;
      }
      if(keep)
      {
         int k = ArraySize(sel);
         ArrayResize(sel, k + 1);
         sel[k] = i;
      }
   }
   return ArraySize(sel);
}

// Consecutive closed candles with the colour of shift 1.
int ZoColorRun(const ZoTf &d, int &code)
{
   code = d.cCol[1];
   if(code == 0)
      return 0;
   int n = 1;
   for(int s = 2; s < ZO_CACHE; s++)
   {
      if(d.cCol[s] != code)
         break;
      n++;
   }
   return n;
}

// Two-wick candles with a small body among the last n closed candles ("thu nến").
int ZoTwoWickCount(const ZoTf &d, int n)
{
   int cnt = 0;
   for(int s = 1; s <= n && s < ZO_CACHE; s++)
   {
      double h = d.cH[s], l = d.cL[s], o = d.cO[s], c = d.cC[s];
      if(h <= 0 || h <= l)
         continue;
      double body = MathAbs(c - o), range = h - l;
      if(body <= range * 0.4 && h > MathMax(o, c) && l < MathMin(o, c))
         cnt++;
   }
   return cnt;
}

// Average body of candles [from, from+n) relative to [from+n, from+2n): < 1 = bodies shrinking.
double ZoBodyRatio(const ZoTf &d, int from, int n)
{
   double a = 0, b = 0;
   int na = 0, nb = 0;
   for(int s = from; s < from + n && s < ZO_CACHE; s++)
      if(d.cH[s] > 0) { a += MathAbs(d.cC[s] - d.cO[s]); na++; }
   for(int s = from + n; s < from + 2 * n && s < ZO_CACHE; s++)
      if(d.cH[s] > 0) { b += MathAbs(d.cC[s] - d.cO[s]); nb++; }
   if(na == 0 || nb == 0 || b <= 0)
      return 1;
   return (a / na) / (b / nb);
}

datetime ZoHanoiNow()
{
   return TimeGMT() + 7 * 3600;
}

// Hanoi time of a server time (the broker's offset is taken from the current clocks).
datetime ZoHanoi(datetime server)
{
   return server + (ZoHanoiNow() - TimeCurrent());
}

// Vietnamese letters show as "?" in chart objects under Wine (ANSI code page): text drawn on the chart goes
// through this ("đây là LP H1" -> "day la LP H1"). Telegram messages keep their accents.
string ZoUnaccent(string s)
{
   string from[] = {"àáạảãâầấậẩẫăằắặẳẵ", "èéẹẻẽêềếệểễ", "ìíịỉĩ", "òóọỏõôồốộổỗơờớợởỡ", "ùúụủũưừứựửữ", "ỳýỵỷỹ", "đ",
                    "ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ", "ÈÉẸẺẼÊỀẾỆỂỄ", "ÌÍỊỈĨ", "ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ", "ÙÚỤỦŨƯỪỨỰỬỮ", "ỲÝỴỶỸ", "Đ"};
   string to[] = {"a", "e", "i", "o", "u", "y", "d", "A", "E", "I", "O", "U", "Y", "D"};
   string out = "";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
   {
      ushort c = StringGetCharacter(s, i);
      string ch = ShortToString(c);
      if(c >= 128)
         for(int g = 0; g < ArraySize(from); g++)
            if(StringFind(from[g], ch) >= 0)
            {
               ch = to[g];
               break;
            }
      out += ch;
   }
   return out;
}

//+------------------------------------------------------------------+
//| Main trend (research 30/9)                                       |
//+------------------------------------------------------------------+
// Trend of a timeframe = direction of its latest Main event (an LP became Main by killing an OLDER opposite
// LP). since = time of that event. 0 when no Main yet.
int ZoMainTrend(const ZoZone &zs[], int tf, datetime &since)
{
   since = 0;
   int dir = 0;
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].tf == tf && zs[i].tMain > since)
      {
         since = zs[i].tMain;
         dir = zs[i].dir;
      }
   return dir;
}

//+------------------------------------------------------------------+
//| ZOU entry signals on M15 (backtest/bt_lab.py FINAL "ZOU")        |
//|  ZM : ZO A/B pair - candle A pulled against us (counter wick >=  |
//|       body and >= 1/3 range), candle B lost that pull - after    |
//|       price reached the deep half of a same-direction H4 LP;     |
//|       Main H4 our way for >= 48h.                                |
//|  U1w: one of the 3 candles before pulled against us (>= 5 pip,   |
//|       >= 1/3 range), the last candle has no counter wick and its |
//|       body goes our way; price was pulled >= 15 pip in 4h into a |
//|       same-direction H4 LP or M15 LP; Main H4 our                |
//|       way.                                                       |
//| Targets: 1R / middle / far edge of the opposite H4 LP.           |
//| No entry inside an opposite W1 / D1 Main zone (needs the W1 / D1 |
//| data loaded in zs).                                              |
//| Both: market at the M15 close, SL beyond the last 4 candles +3   |
//| pip (10-15 pip, wider = no trade), no entries 0-6h Hanoi, BE 1R, |
//| hold the rest while the ZO candles stay strong without a pull.   |
//+------------------------------------------------------------------+
struct ZoSignal
{
   int      dir;
   string   kind;        // "ZM" or "U1w"
   datetime barTime;     // open time of the confirming M15 candle
   double   ep;
   double   sl;
   double   tp[3];
   int      ntp;
   string   level;       // where price was pulled into
   string   why;
};

// Counter / toward wick of a ZOS candle for a trade in direction d.
void ZoPull(double h, double l, double o, double c, int d, double &against, double &toward)
{
   double up = h - MathMax(o, c), down = MathMin(o, c) - l;
   against = d > 0 ? down : up;
   toward = d > 0 ? up : down;
}

bool ZoAB(const ZoTf &m, int sa, int sb, int d)
{
   if(m.cH[sa] <= 0 || m.cH[sb] <= 0)
      return false;
   double ag, tw;
   ZoPull(m.cH[sa], m.cL[sa], m.cO[sa], m.cC[sa], d, ag, tw);
   double body = MathAbs(m.cC[sa] - m.cO[sa]), rng = m.cH[sa] - m.cL[sa];
   if(rng <= 0 || ag < MathMax(MathMax(body, rng / 3), ZoPip()))
      return false;
   double bag, btw;
   ZoPull(m.cH[sb], m.cL[sb], m.cO[sb], m.cC[sb], d, bag, btw);
   return bag <= MathMax(0.5 * ZoPip(), 0.1 * (m.cH[sb] - m.cL[sb])) || btw > bag;
}

bool ZoPullGone(const ZoTf &m, int d, double minWickPips)
{
   if(m.cH[1] <= 0)
      return false;
   double ag, tw;
   ZoPull(m.cH[1], m.cL[1], m.cO[1], m.cC[1], d, ag, tw);
   bool ourBody = d > 0 ? m.cC[1] > m.cO[1] : m.cC[1] < m.cO[1];
   if(ag > MathMax(0.5 * ZoPip(), 0.1 * (m.cH[1] - m.cL[1])) || !ourBody)
      return false;
   for(int s = 2; s <= 4; s++)
   {
      if(m.cH[s] <= 0)
         continue;
      double a2, t2;
      ZoPull(m.cH[s], m.cL[s], m.cO[s], m.cC[s], d, a2, t2);
      if(a2 >= MathMax(minWickPips * ZoPip(), (m.cH[s] - m.cL[s]) / 3))
         return true;
   }
   return false;
}

// Nearest live opposite H4 LP beyond ep: near edge, middle, far edge.
bool ZoOppositeH4(const ZoZone &zs[], int d, double ep, double &nearE, double &mid, double &farE)
{
   bool found = false;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != 240 || !ZoIsAlive(zs[i]) || zs[i].dir == d)
         continue;
      double n = d > 0 ? zs[i].lo : zs[i].hi;
      if((d > 0 && n > ep) || (d < 0 && n < ep))
         if(!found || (d > 0 && n < nearE) || (d < 0 && n > nearE))
         {
            nearE = n;
            mid = (zs[i].hi + zs[i].lo) / 2;
            farE = d > 0 ? zs[i].hi : zs[i].lo;
            found = true;
         }
   }
   return found;
}

// SL / TP plan shared by both setups; false = no trade (SL wider than 15 pip or no target >= 1R).
// Targets (backtest round 22, winrate ~50%): 1R, middle and far edge of the opposite H4 LP (5R when none).
bool ZoPlan(const ZoZone &zs[], int d, double ext, ZoSignal &sig)
{
   double pip = ZoPip();
   double ep = iClose(Symbol(), PERIOD_M15, 1);
   double sl = d > 0 ? ext - 3 * pip : ext + 3 * pip;
   double dist = MathAbs(ep - sl);
   if(dist < 10 * pip)
      dist = 10 * pip;
   if(dist > 15 * pip)
      return false;
   sl = ep - d * dist;
   double n, m, f;
   bool opp = ZoOppositeH4(zs, d, ep, n, m, f);
   double lv[3];
   int k = 0;
   lv[k++] = ep + d * dist;
   if(opp) { lv[k++] = m; lv[k++] = f; }
   else      lv[k++] = ep + d * 5 * dist;
   sig.ntp = 0;
   // Keep targets >= 1R, nearest first.
   for(int a = 0; a < k; a++)
      for(int b = a + 1; b < k; b++)
         if((lv[b] - ep) * d < (lv[a] - ep) * d)
         {
            double t = lv[a];
            lv[a] = lv[b];
            lv[b] = t;
         }
   for(int a = 0; a < k; a++)
      if((lv[a] - ep) * d >= dist - Point && (sig.ntp == 0 || MathAbs(lv[a] - sig.tp[sig.ntp - 1]) > Point))
         sig.tp[sig.ntp++] = lv[a];
   if(sig.ntp == 0)
      return false;
   sig.dir = d;
   sig.ep = ep;
   sig.sl = sl;
   sig.barTime = iTime(Symbol(), PERIOD_M15, 1);
   return true;
}

// Checks the last closed M15 candle. zs must hold live H4 (240) and M15 (15) zones with Main recomputed;
// m15 = ZOS M15 cache (shift 1 = last closed). Returns true and fills sig on a ZOU entry.
bool ZoCheckZOU(const ZoZone &zs[], const ZoTf &m15, const ZoTf &h4, ZoSignal &sig)
{
   double pip = ZoPip();
   datetime since;
   int trend = ZoMainTrend(zs, 240, since);
   if(trend == 0 || m15.cH[1] <= 0)
      return false;
   datetime barClose = iTime(Symbol(), PERIOD_M15, 1) + 900;
   if(TimeHour(ZoHanoi(barClose)) < 6)
      return false;   // no entries 0-6h Hanoi
   int d = trend;
   // Round 28: no entry while price sits inside a W1 / D1 Main zone of the opposite direction.
   double px = iClose(Symbol(), PERIOD_M15, 1);
   for(int i = 0; i < ArraySize(zs); i++)
      if((zs[i].tf == 1440 || zs[i].tf == 10080) && zs[i].tMain > 0 && zs[i].dir == -d && ZoIsAlive(zs[i]) &&
         px >= zs[i].lo && px <= zs[i].hi)
         return false;
   double ext = d > 0 ? iLow(Symbol(), PERIOD_M15, 1) : iHigh(Symbol(), PERIOD_M15, 1);
   for(int s = 2; s <= 4; s++)
      ext = d > 0 ? MathMin(ext, iLow(Symbol(), PERIOD_M15, s)) : MathMax(ext, iHigh(Symbol(), PERIOD_M15, s));
   double pad = 10 * pip;

   // ZM: candle A (shift 2) / B (shift 1), level = deep half of a same-direction H4 LP reached by shift 2..3.
   // (round 42-43: the H4 LP must be the Main or a Shield of our side)
   datetime tMainD;
   int iMainD = ZoLastMain(zs, 240, d, tMainD);
   if(barClose - since >= 48 * 3600 && ZoAB(m15, 2, 1, d))
      for(int i = 0; i < ArraySize(zs); i++)
      {
         if(zs[i].tf != 240 || zs[i].dir != d || !ZoIsAlive(zs[i]))
            continue;
         if(iMainD < 0 || (i != iMainD && zs[i].tLast + 240 * 60 <= tMainD))
            continue;
         double deepLo = zs[i].hi - 0.5 * (zs[i].hi - zs[i].lo), deepHi = zs[i].lo + 0.5 * (zs[i].hi - zs[i].lo);
         bool reached = false;
         for(int s = 2; s <= 3; s++)
         {
            double l = iLow(Symbol(), PERIOD_M15, s), h = iHigh(Symbol(), PERIOD_M15, s);
            if(d > 0 && l >= zs[i].lo - 3 * pad && l <= deepLo) reached = true;
            if(d < 0 && h <= zs[i].hi + 3 * pad && h >= deepHi) reached = true;
         }
         if(!reached)
            continue;
         if(!ZoPlan(zs, d, ext, sig))
            return false;
         sig.kind = "ZM";
         sig.level = (d > 0 ? "nửa sâu GLP-H4 " : "nửa sâu RLP-H4 ") + ZoDate(zs[i].t0) + " " + ZoPx(zs[i].lo) + "-" + ZoPx(zs[i].hi);
         sig.why = "nến ZO A bị kéo ngược vào LP H4, nến B hết lực kéo; Main H4 " + (d > 0 ? "tăng" : "giảm") +
                   " từ " + ZoDate(since);
         return true;
      }

   // U1w (round 42-43: not while H4 runs hard, 3 strong-coloured H4 candles in a row either way)
   int phaseDir;
   if(ZoPhaseCode(h4, phaseDir) == "RUN")
      return false;
   if(!ZoPullGone(m15, d, 5))
      return false;
   double far = ext;
   for(int s = 1; s <= 17; s++)
      far = d > 0 ? MathMax(far, iHigh(Symbol(), PERIOD_M15, s)) : MathMin(far, iLow(Symbol(), PERIOD_M15, s));
   if(MathAbs(far - ext) < 15 * pip)
      return false;
   string level = "";
   for(int i = 0; i < ArraySize(zs) && level == ""; i++)
      if(zs[i].tf == 240 && zs[i].dir == d && ZoIsAlive(zs[i]) && ext >= zs[i].lo - pad && ext <= zs[i].hi + pad)
         level = (d > 0 ? "GLP-H4 " : "RLP-H4 ") + ZoDate(zs[i].t0);
   for(int i = 0; i < ArraySize(zs) && level == ""; i++)
      if(zs[i].tf == 15 && zs[i].dir == d && ZoIsAlive(zs[i]) && ext >= zs[i].lo - pad && ext <= zs[i].hi + pad)
         level = (d > 0 ? "GLP-M15 " : "RLP-M15 ") + ZoDate(zs[i].t0);
   // Round numbers are no longer a level (backtest round 41: they only added losing trades).
   if(level == "" || !ZoPlan(zs, d, ext, sig))
      return false;
   sig.kind = "U1w";
   sig.level = level;
   sig.why = StringFormat("giá bị kéo ngược %.0f pip vào %s, nến ZO trước có râu kéo, nến vừa đóng hết râu kéo; Main H4 %s",
                          MathAbs(far - ext) / pip, level, d > 0 ? "tăng" : "giảm");
   return true;
}

// Single target for positions too small to split in 3 (0.01-0.02 lot; backtest "tp_small"): ZM 2R or the
// opposite H4 LP near edge, U1w 3R / middle / far edge - the nearest one >= 1.5R.
double ZoSmallTarget(const ZoZone &zs[], const ZoSignal &sig)
{
   int d = sig.dir;
   double dist = MathAbs(sig.ep - sig.sl);
   double n, m, f;
   bool opp = ZoOppositeH4(zs, d, sig.ep, n, m, f);
   double lv[3];
   int k = 0;
   if(sig.kind == "ZM")
   {
      lv[k++] = sig.ep + d * 2 * dist;
      lv[k++] = opp ? n : sig.ep + d * 5 * dist;
   }
   else
   {
      lv[k++] = sig.ep + d * 3 * dist;
      if(opp) { lv[k++] = m; lv[k++] = f; }
      else      lv[k++] = sig.ep + d * 5 * dist;
   }
   double best = 0;
   for(int a = 0; a < k; a++)
      if((lv[a] - sig.ep) * d >= 1.5 * dist && (best == 0 || (lv[a] - sig.ep) * d < (best - sig.ep) * d))
         best = lv[a];
   return best > 0 ? best : sig.ep + d * 2 * dist;
}

// Holding rule for an open trade in direction d: true while the last M15 ZOS candle is the strong colour of
// our side (green buy / red sell) and shows no pull against us.
bool ZoStillStrong(const ZoTf &m15, int d)
{
   if(m15.cCol[1] != (d > 0 ? 1 : -1))
      return false;
   double ag, tw;
   ZoPull(m15.cH[1], m15.cL[1], m15.cO[1], m15.cC[1], d, ag, tw);
   return ag <= MathMax(0.5 * ZoPip(), 0.2 * (m15.cH[1] - m15.cL[1]));
}

// Hold rule of ZEAR2 / ZEA2 (backtest round 33): a part that reached its target stays open until the last closed
// M15 ZOS candle shows the other side's colour (strong or weak); Build and same-side candles keep it open.
bool ZoHoldOn(const ZoTf &m15, int d)
{
   int c = m15.cCol[1];
   return !(c == -d || c == -2 * d);
}

// Entry veto of ZEAR2 / ZEA2 (backtest round 32): the last closed H4 ZOS candle shows the other side's strong colour.
bool ZoH4Against(const ZoTf &h4, int d)
{
   return h4.cCol[1] == -d;
}

//+------------------------------------------------------------------+
//| EPA entries and market context (research lan 24-27)              |
//| EPA: Potential EP = ZO A/B pair on M15, then 2 more ZOS candles  |
//| that keep the shift, with the pull tip at a same-direction H4    |
//| Main / Shield; not while H4 shows weak colour on our side, not   |
//| in the New York session (19-24h Hanoi) nor 0-6h.                 |
//+------------------------------------------------------------------+
// A ZOS candle that keeps the momentum shift: no pull against d and a body going our way.
bool ZoConfirmed(const ZoTf &m, int s, int d)
{
   if(s < 1 || s >= ZO_CACHE || m.cH[s] <= 0)
      return false;
   double ag, tw;
   ZoPull(m.cH[s], m.cL[s], m.cO[s], m.cC[s], d, ag, tw);
   bool ourBody = d > 0 ? m.cC[s] > m.cO[s] : m.cC[s] < m.cO[s];
   return ag <= MathMax(0.5 * ZoPip(), 0.2 * (m.cH[s] - m.cL[s])) && ourBody;
}

// Potential EP at the candle of shift s0 for a trade in direction d: 1 = ZO A/B pair, 2 = "fade" (a pull of at
// least 4 pip that faded, s0 = first candle without it), 0 = none. sA = shift of the pulling candle.
int ZoPotentialEP(const ZoTf &m, int s0, int d, int &sA)
{
   sA = 0;
   if(s0 < 1 || s0 + 1 >= ZO_CACHE || m.cH[s0] <= 0)
      return 0;
   double pip = ZoPip();
   // fade
   for(int back = 1; back <= 5 && s0 + back < ZO_CACHE; back++)
   {
      int a = s0 + back;
      if(m.cH[a] <= 0)
         continue;
      double w, tw;
      ZoPull(m.cH[a], m.cL[a], m.cO[a], m.cC[a], d, w, tw);
      if(w < 4 * pip || w <= tw)
         continue;
      bool valid = true;
      for(int x = a - 1; x > s0 && valid; x--)
      {
         double ag, t2;
         ZoPull(m.cH[x], m.cL[x], m.cO[x], m.cC[x], d, ag, t2);
         bool gone = ag <= 0.1 * w || (ag > 0 && t2 > 0 && t2 >= ag);
         valid = m.cH[x] > 0 && ag < w && !gone;
      }
      if(!valid)
         continue;
      double ag0, t0;
      ZoPull(m.cH[s0], m.cL[s0], m.cO[s0], m.cC[s0], d, ag0, t0);
      if(ag0 <= 0.1 * w || (ag0 > 0 && t0 > 0 && t0 >= ag0))
      {
         sA = a;
         return 2;
      }
      break;
   }
   if(ZoAB(m, s0 + 1, s0, d))
   {
      sA = s0 + 1;
      return 1;
   }
   return 0;
}

// Backtest phase of a timeframe from its last closed ZOS candles: "ACC" (>= 3 of 5 two-wick candles), "RUN"
// (3 strong-coloured candles one way), "FADE" (last 2 weak-coloured one way), "UNK". dir = side of RUN / FADE.
string ZoPhaseCode(const ZoTf &t, int &dir)
{
   dir = 0;
   if(t.cH[5] <= 0)
      return "UNK";
   if(ZoTwoWickCount(t, 5) >= 3)
      return "ACC";
   if(t.cCol[1] == 1 && t.cCol[2] == 1 && t.cCol[3] == 1)   { dir = 1;  return "RUN"; }
   if(t.cCol[1] == -1 && t.cCol[2] == -1 && t.cCol[3] == -1) { dir = -1; return "RUN"; }
   if(t.cCol[1] == 2 && t.cCol[2] == 2)   { dir = 1;  return "FADE"; }
   if(t.cCol[1] == -2 && t.cCol[2] == -2) { dir = -1; return "FADE"; }
   return "UNK";
}

// Heuristic phase reading in percent (NOT a tested probability): pct[0] Accumulation, [1] Run, [2] Distribution,
// [3] SHS (stop hunt), [4] Unclear. runDir = direction of the run / of the side being distributed.
void ZoPhasePct(const ZoTf &t, const ZoZone &zs[], double &pct[], int &runDir)
{
   ArrayResize(pct, 5);
   int tw = ZoTwoWickCount(t, 5);
   int up = 0, dn = 0, weakUp = 0, weakDn = 0, builds = 0;
   for(int s = 1; s <= 5 && s < ZO_CACHE; s++)
   {
      if(s <= 3)
      {
         if(t.cCol[s] == 1) up++;
         if(t.cCol[s] == -1) dn++;
      }
      if(t.cCol[s] == 2) weakUp++;
      if(t.cCol[s] == -2) weakDn++;
      if(t.cB[s]) builds++;
   }
   runDir = up > dn ? 1 : dn > up ? -1 : (weakUp > weakDn ? 1 : weakDn > weakUp ? -1 : 0);
   double ratio = ZoBodyRatio(t, 1, 3);
   // An LP of this timeframe that died within 3 candles of its break, in the last 6 candles = stop-hunt sign.
   bool quickDeath = false;
   int tfSec = t.tf * 60;
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].tf == t.tf && zs[i].tDead > 0 && zs[i].tBreak > 0 && t.lastBar - zs[i].tDead <= 6 * tfSec &&
         zs[i].tDead - zs[i].tBreak <= 3 * tfSec)
         quickDeath = true;
   double acc = 8 + 20 * tw + (ratio < 0.7 ? 8 : 0);
   double run = 8 + 26 * MathMax(up, dn) + (ratio > 1.4 ? 10 : 0);
   double dist = 6 + 16 * MathMax(weakUp, weakDn) + 6 * builds + (ratio < 0.7 && MathMax(up, dn) == 0 ? 6 : 0);
   double shs = 5 + (quickDeath ? 45 : 0) + (ratio > 2.0 ? 12 : 0);
   double unc = 14;
   double sum = acc + run + dist + shs + unc;
   pct[0] = 100 * acc / sum;
   pct[1] = 100 * run / sum;
   pct[2] = 100 * dist / sum;
   pct[3] = 100 * shs / sum;
   pct[4] = 100 * unc / sum;
}

// Latest Main of a direction on a timeframe: zone index (-1 = none) and the time it became Main.
int ZoLastMain(const ZoZone &zs[], int tf, int d, datetime &tM)
{
   int best = -1;
   tM = 0;
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].tf == tf && zs[i].dir == d && zs[i].tMain > tM)
      {
         tM = zs[i].tMain;
         best = i;
      }
   return best;
}

// Live H4 LP of direction d that is the Main or a Shield (born after that side's last Main) with px inside it or
// within pad of it: zone index or -1. role = "Main" / "Shield".
int ZoShieldAt(const ZoZone &zs[], int tf, int d, double px, double pad, string &role)
{
   datetime tM;
   int iM = ZoLastMain(zs, tf, d, tM);
   role = "";
   if(iM < 0)
      return -1;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || zs[i].dir != d || !ZoIsAlive(zs[i]) || px < zs[i].lo - pad || px > zs[i].hi + pad)
         continue;
      if(i == iM)
      {
         role = "Main";
         return i;
      }
      if(zs[i].tLast + tf * 60 > tM)
      {
         role = "Shield";
         return i;
      }
   }
   return -1;
}

// EPA plan: SL beyond the pull tip + 3 pip (slMin-15 pip, wider = no trade). profile 0 = targets 1R / middle / far
// edge of the opposite H4 LP (ZEA); 1 = near edge / middle / far edge (ZEAR).
bool ZoPlanEP(const ZoZone &zs[], int d, double tip, int profile, ZoSignal &sig)
{
   double pip = ZoPip();
   double ep = iClose(Symbol(), PERIOD_M15, 1);
   double dist = MathAbs(ep - (d > 0 ? tip - 3 * pip : tip + 3 * pip));
   double slMin = profile == 1 ? 8 : 10;
   if(dist > 15 * pip)
      return false;
   if(dist < slMin * pip)
      dist = slMin * pip;
   double n, m, f;
   bool opp = ZoOppositeH4(zs, d, ep, n, m, f);
   double lv[3];
   int k = 0;
   lv[k++] = profile == 1 ? (opp ? n : ep + d * 5 * dist) : ep + d * dist;
   if(opp)
   {
      lv[k++] = m;
      lv[k++] = f;
   }
   else if(profile != 1)
      lv[k++] = ep + d * 5 * dist;
   for(int a = 0; a < k; a++)
      for(int b = a + 1; b < k; b++)
         if((lv[b] - ep) * d < (lv[a] - ep) * d)
         {
            double t = lv[a];
            lv[a] = lv[b];
            lv[b] = t;
         }
   sig.ntp = 0;
   for(int a = 0; a < k; a++)
      if((lv[a] - ep) * d >= dist - Point && (sig.ntp == 0 || MathAbs(lv[a] - sig.tp[sig.ntp - 1]) > Point))
         sig.tp[sig.ntp++] = lv[a];
   if(sig.ntp == 0)
      return false;
   sig.dir = d;
   sig.ep = ep;
   sig.sl = ep - d * dist;
   sig.barTime = iTime(Symbol(), PERIOD_M15, 1);
   return true;
}

// Evidence for BUY and for SELL at the current price (weights from the research: location at a Main / Shield
// counts most). Fills the reason lists; returns the BUY share in percent.
double ZoBias(const ZoZone &zs[], const ZoTf &h4, const ZoTf &m15, double px, string &forBuy[], string &forSell[])
{
   ArrayResize(forBuy, 0);
   ArrayResize(forSell, 0);
   double w[2];
   w[0] = 1;
   w[1] = 1;
   double pad = 10 * ZoPip();
   datetime since;
   int main4 = ZoMainTrend(zs, 240, since);
   int main15 = ZoMainTrend(zs, 15, since);
   int pdir;
   string ph = ZoPhaseCode(h4, pdir);
   for(int side = 0; side < 2; side++)
   {
      int d = side == 0 ? 1 : -1;
      string r[];
      ArrayResize(r, 0);
      string role;
      int zi = ZoShieldAt(zs, 240, d, px, pad, role);
      if(zi >= 0)
      {
         w[side] += 3;
         ZoPush(r, "giá ở " + role + " H4 " + (d > 0 ? "mua " : "bán ") + ZoPx(zs[zi].lo) + "-" + ZoPx(zs[zi].hi));
      }
      if(main4 == d)
      {
         w[side] += 2;
         ZoPush(r, "Main H4 " + (d > 0 ? "tăng" : "giảm"));
      }
      if(h4.cCol[1] == d || h4.cCol[1] == 2 * d)
      {
         w[side] += 1;
         ZoPush(r, "nến ZOS H4 " + ZoColorName(h4.cCol[1]));
      }
      if(ph == "RUN" && pdir == d)
      {
         w[side] += 1;
         ZoPush(r, "H4 đang chạy " + (d > 0 ? "lên" : "xuống"));
      }
      if(ph == "FADE" && pdir == -d)
      {
         w[side] += 1;
         ZoPush(r, "phe " + (d > 0 ? "bán" : "mua") + " yếu màu trên H4");
      }
      if(main4 == d && main15 == -d)
      {
         w[side] += 1;
         ZoPush(r, "M15 đang hồi ngược Main H4 (pullback)");
      }
      for(int i = 0; i < ArraySize(zs); i++)
         if((zs[i].tf == 1440 || zs[i].tf == 10080) && zs[i].tMain > 0 && ZoIsAlive(zs[i]) && px >= zs[i].lo && px <= zs[i].hi)
         {
            if(zs[i].dir == d)
            {
               w[side] += 1;
               ZoPush(r, "giá trong Main " + ZoTfName(zs[i].tf) + " cùng chiều");
            }
            else if(zs[i].dir == -d)
               w[side] = MathMax(0.5, w[side] - 2);
         }
      if(side == 0)
         ArrayCopy(forBuy, r);
      else
         ArrayCopy(forSell, r);
   }
   return 100 * w[0] / (w[0] + w[1]);
}

void ZoPush(string &arr[], string s)
{
   int k = ArraySize(arr);
   ArrayResize(arr, k + 1);
   arr[k] = s;
}

//+------------------------------------------------------------------+
//| Economic calendar (news)                                         |
//| ZO_Analyst downloads this week's calendar (ForexFactory feed)    |
//| and writes Common\Files\zo_lp\news.csv; indicators read it here. |
//| Times are GMT.                                                   |
//+------------------------------------------------------------------+
#define ZO_NEWS_FILE "zo_lp\\news.csv"

datetime g_zoNewsTime[];
string   g_zoNewsCur[];
int      g_zoNewsImp[];     // 3 high, 2 medium, 1 low, 0 holiday / other
string   g_zoNewsTitle[];

bool ZoNewsLoad()
{
   ArrayResize(g_zoNewsTime, 0);
   ArrayResize(g_zoNewsCur, 0);
   ArrayResize(g_zoNewsImp, 0);
   ArrayResize(g_zoNewsTitle, 0);
   int h = FileOpen(ZO_NEWS_FILE, FILE_READ | FILE_CSV | FILE_COMMON | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ';');
   if(h == INVALID_HANDLE)
      return false;
   while(!FileIsEnding(h))
   {
      string t = FileReadString(h);
      if(t == "")
         continue;
      string cur = FileReadString(h);
      string imp = FileReadString(h);
      string title = FileReadString(h);
      int k = ArraySize(g_zoNewsTime);
      ArrayResize(g_zoNewsTime, k + 1);
      ArrayResize(g_zoNewsCur, k + 1);
      ArrayResize(g_zoNewsImp, k + 1);
      ArrayResize(g_zoNewsTitle, k + 1);
      g_zoNewsTime[k] = (datetime)StringToInteger(t);
      g_zoNewsCur[k] = cur;
      g_zoNewsImp[k] = (int)StringToInteger(imp);
      g_zoNewsTitle[k] = title;
   }
   FileClose(h);
   return ArraySize(g_zoNewsTime) > 0;
}

bool ZoNewsWanted(int k, string currencies, int minImpact)
{
   return g_zoNewsImp[k] >= minImpact && StringFind("," + currencies + ",", "," + g_zoNewsCur[k] + ",") >= 0;
}

// News whose window [time - beforeMin, time + afterMin] contains gmtNow: index or -1.
int ZoNewsActive(string currencies, int minImpact, int beforeMin, int afterMin, datetime gmtNow)
{
   for(int k = 0; k < ArraySize(g_zoNewsTime); k++)
      if(ZoNewsWanted(k, currencies, minImpact) && gmtNow >= g_zoNewsTime[k] - beforeMin * 60 &&
         gmtNow <= g_zoNewsTime[k] + afterMin * 60)
         return k;
   return -1;
}

// Next wanted news after gmtNow: index or -1.
int ZoNewsNext(string currencies, int minImpact, datetime gmtNow)
{
   int best = -1;
   for(int k = 0; k < ArraySize(g_zoNewsTime); k++)
      if(ZoNewsWanted(k, currencies, minImpact) && g_zoNewsTime[k] > gmtNow && (best < 0 || g_zoNewsTime[k] < g_zoNewsTime[best]))
         best = k;
   return best;
}

string ZoNewsText(int k)
{
   datetime hn = g_zoNewsTime[k] + 7 * 3600;
   return StringFormat("%s %s (%02d:%02d %d/%d HN)", g_zoNewsCur[k], g_zoNewsTitle[k], TimeHour(hn), TimeMinute(hn), TimeDay(hn), TimeMonth(hn));
}

﻿//+------------------------------------------------------------------+
//| ZoCore.mqh                                                       |
//| Shared LP model for ZO_DrawLP (script), ZO_View (indicator) and  |
//| ZO_Analyst (EA).                                                 |
//|                                                                  |
//| Data sources per timeframe, best first:                          |
//|  1. the chart's own timeframe: ZOS read directly (always right); |
//|  2. Common\Files\zo_lp\<symbol>_<tf>.csv written by ZO_LP running |
//|     on that timeframe's own chart;                               |
//|  3. iCustom(ZOS) on another timeframe = ESTIMATE (ZOS read from  |
//|     a different chart timeframe returns different candles).      |
//|                                                                  |
//| LP rules are the same as ZO_LP (see its header). Main LPs are    |
//| recomputed here for every timeframe (ZO_LP only tags them up to  |
//| H1): an LP becomes Main when it is the newest live opposite LP,  |
//| broken before and sitting on its own side, at the moment an LP   |
//| of the same timeframe dies; only the newest Main per direction   |
//| is kept.                                                         |
//+------------------------------------------------------------------+
#property strict

#define ZO_ST_FRESH   0
#define ZO_ST_BROKEN  1
#define ZO_ST_RETEST  2
#define ZO_ST_RUN     3
#define ZO_ST_FAILED  4
#define ZO_ST_CLEARED 5

#define ZO_SRC_NONE     0
#define ZO_SRC_CHART    1
#define ZO_SRC_SHARED   2
#define ZO_SRC_ESTIMATE 3

#define ZO_SHARE_DIR  "zo_lp\\"
#define ZO_CACHE      13          // closed candles kept per timeframe (shift 1..12)

struct ZoZone
{
   int      tf;
   datetime t0;        // open time of the first Build candle
   datetime tLast;     // last candle that shaped the zone
   datetime tBreak;    // candle that broke it into GLP / RLP
   datetime tDead;     // candle that cleared / failed it
   datetime tMain;     // candle whose kill made this LP Main (0 = not Main)
   double   hi;
   double   lo;
   int      dir;       // +1 GLP, -1 RLP, 0 not broken
   int      state;
   int      retests;
   int      builds;
   bool     isMain;
};

struct ZoTf
{
   int      tf;
   int      source;       // ZO_SRC_*
   bool     stale;        // shared file older than one closed bar
   int      trend;        // +1 up, -1 down, 0 unknown (side that killed the last LP)
   datetime trendTime;
   datetime lastBar;     // newest closed bar the data covers
   double   cH[ZO_CACHE];
   double   cL[ZO_CACHE];
   double   cO[ZO_CACHE];
   double   cC[ZO_CACHE];
   bool     cB[ZO_CACHE];
   int      cCol[ZO_CACHE];  // 1 green, 2 blue, -1 red, -2 pink, 9 build, 0 unknown
};

string g_zoName = "ZOS";      // ZOS indicator file name, set by the program
int    g_zoLookback = 500;
double g_zoMinWickPts = 1;

//+------------------------------------------------------------------+
//| Small helpers                                                    |
//+------------------------------------------------------------------+
string ZoTfName(int tf)
{
   switch(tf)
   {
      case 1:     return "M1";
      case 5:     return "M5";
      case 15:    return "M15";
      case 30:    return "M30";
      case 60:    return "H1";
      case 240:   return "H4";
      case 1440:  return "D1";
      case 10080: return "W1";
      case 43200: return "MN";
   }
   return "TF" + IntegerToString(tf);
}

double ZoPip()
{
   return (Digits == 3 || Digits == 5) ? Point * 10 : Point;
}

string ZoPx(double p)
{
   return DoubleToString(p, Digits);
}

bool ZoIsAlive(const ZoZone &z)
{
   return z.state != ZO_ST_FAILED && z.state != ZO_ST_CLEARED;
}

string ZoKind(const ZoZone &z)
{
   if(z.dir > 0) return z.isMain ? "MGLP" : "GLP";
   if(z.dir < 0) return z.isMain ? "MRLP" : "RLP";
   return "LP";
}

string ZoDate(datetime t)
{
   return IntegerToString(TimeDay(t)) + "/" + IntegerToString(TimeMonth(t));
}

string ZoStateVi(int st)
{
   switch(st)
   {
      case ZO_ST_FRESH:   return "chưa break";
      case ZO_ST_BROKEN:  return "chờ retest";
      case ZO_ST_RETEST:  return "RETEST";
      case ZO_ST_RUN:     return "đã chạy";
      case ZO_ST_FAILED:  return "thủng";
      case ZO_ST_CLEARED: return "bị clear";
   }
   return "?";
}

string ZoZoneText(const ZoZone &z)
{
   return ZoKind(z) + " " + ZoTfName(z.tf) + " " + ZoDate(z.t0) + " (" + ZoPx(z.lo) + "-" + ZoPx(z.hi) + ")";
}

string ZoShortName(const ZoZone &z)
{
   return ZoKind(z) + " " + ZoTfName(z.tf) + " " + ZoDate(z.t0);
}

double ZoDist(const ZoZone &z, double p)
{
   double pip = ZoPip();
   if(p > z.hi) return (p - z.hi) / pip;
   if(p < z.lo) return (z.lo - p) / pip;
   return 0;
}

string ZoColorName(int code)
{
   switch(code)
   {
      case 1:  return "xanh lá (tăng mạnh)";
      case 2:  return "xanh dương (tăng yếu dần)";
      case -1: return "đỏ (giảm mạnh)";
      case -2: return "tím (giảm yếu dần)";
      case 9:  return "vàng (build)";
   }
   return "?";
}

string ZoColorShort(int code)
{
   switch(code)
   {
      case 1:  return "xanh lá";
      case 2:  return "xanh dương";
      case -1: return "đỏ";
      case -2: return "tím";
      case 9:  return "vàng";
   }
   return "?";
}

string ZoTrendText(int t)
{
   return t > 0 ? "TĂNG" : t < 0 ? "GIẢM" : "chưa rõ";
}

string ZoSourceNote(const ZoTf &d)
{
   if(d.source == ZO_SRC_ESTIMATE) return " [ƯỚC TÍNH]";
   if(d.source == ZO_SRC_NONE)     return " [không có dữ liệu]";
   if(d.stale)                     return " [dữ liệu cũ]";
   return "";
}

//+------------------------------------------------------------------+
//| ZOS access (iCustom on this terminal)                            |
//+------------------------------------------------------------------+
bool ZoReadChart(int tf, int shift, double &h, double &l, double &o, double &c, bool &build)
{
   h = iCustom(Symbol(), tf, g_zoName, 0, shift);
   l = iCustom(Symbol(), tf, g_zoName, 1, shift);
   o = iCustom(Symbol(), tf, g_zoName, 2, shift);
   c = iCustom(Symbol(), tf, g_zoName, 3, shift);
   if(h == EMPTY_VALUE || l == EMPTY_VALUE || o == EMPTY_VALUE || c == EMPTY_VALUE)
      return false;
   if(l <= 0 || l > MathMin(o, c) + Point || h < MathMax(o, c) - Point)
      return false;
   build = (iCustom(Symbol(), tf, g_zoName, 14, shift) > 0.5);
   return true;
}

int ZoReadColorChart(int tf, int shift)
{
   int codes[5] = {1, 2, -1, -2, 9};
   for(int p = 0; p < 5; p++)
   {
      double v = iCustom(Symbol(), tf, g_zoName, 4 + p * 2, shift);
      if(v != EMPTY_VALUE && v > 0)
         return codes[p];
   }
   return 0;
}

void ZoFillCacheFromChart(ZoTf &d)
{
   for(int s = 1; s < ZO_CACHE; s++)
   {
      double h, l, o, c;
      bool b;
      if(!ZoReadChart(d.tf, s, h, l, o, c, b))
      {
         h = l = o = c = 0;
         b = false;
      }
      d.cH[s] = h; d.cL[s] = l; d.cO[s] = o; d.cC[s] = c; d.cB[s] = b;
      d.cCol[s] = ZoReadColorChart(d.tf, s);
   }
}

//+------------------------------------------------------------------+
//| LP detection (same rules as ZO_LP)                               |
//+------------------------------------------------------------------+
void ZoAddZone(ZoZone &out[], int tf, datetime t0, datetime tLast, double hi, double lo, int builds)
{
   int k = ArraySize(out);
   ArrayResize(out, k + 1);
   out[k].tf = tf;
   out[k].t0 = t0;
   out[k].tLast = tLast;
   out[k].tBreak = 0;
   out[k].tDead = 0;
   out[k].tMain = 0;
   out[k].hi = hi;
   out[k].lo = lo;
   out[k].dir = 0;
   out[k].state = ZO_ST_FRESH;
   out[k].retests = 0;
   out[k].builds = builds;
   out[k].isMain = false;
}

void ZoStep(ZoZone &z, datetime t, double h, double l, double o, double c)
{
   if(!ZoIsAlive(z))
      return;
   if(z.state == ZO_ST_FRESH)
   {
      if(c > z.hi)      { z.dir = 1;  z.state = ZO_ST_BROKEN; z.tBreak = t; }
      else if(c < z.lo) { z.dir = -1; z.state = ZO_ST_BROKEN; z.tBreak = t; }
      return;
   }
   double bodyHi = MathMax(o, c), bodyLo = MathMin(o, c);
   if(bodyLo <= z.lo && bodyHi >= z.hi)
   {
      z.state = ZO_ST_CLEARED;
      return;
   }
   if(z.dir > 0)
   {
      if(c < z.lo)                                  { z.state = ZO_ST_FAILED; return; }
      bool inside = (l <= z.hi);
      if((z.state == ZO_ST_BROKEN || z.state == ZO_ST_RUN) && inside) { z.state = ZO_ST_RETEST; z.retests++; }
      else if(z.state == ZO_ST_RETEST && l > z.hi)  z.state = ZO_ST_RUN;
   }
   else
   {
      if(c > z.hi)                                  { z.state = ZO_ST_FAILED; return; }
      bool inside = (h >= z.lo);
      if((z.state == ZO_ST_BROKEN || z.state == ZO_ST_RUN) && inside) { z.state = ZO_ST_RETEST; z.retests++; }
      else if(z.state == ZO_ST_RETEST && h < z.lo)  z.state = ZO_ST_RUN;
   }
}

// Rebuilds every LP of one timeframe from ZOS on this terminal, oldest bar first.
void ZoScan(int tf, ZoZone &out[], int &trend, datetime &trendTime)
{
   int bars = MathMin(g_zoLookback, iBars(Symbol(), tf) - 2);
   ZoZone zs[];
   ArrayResize(zs, 0);
   trend = 0;
   trendTime = 0;
   bool     inChain = false;
   datetime chT0 = 0, chTLast = 0;
   double   chHi = 0, chLo = 0;
   int      chCount = 0;
   bool     chTwoWick = false;

   for(int s = bars; s >= 1; s--)
   {
      double h, l, o, c;
      bool build;
      if(!ZoReadChart(tf, s, h, l, o, c, build))
      {
         inChain = false;
         continue;
      }
      datetime t = iTime(Symbol(), tf, s);
      bool twoWick = (h - MathMax(o, c) >= g_zoMinWickPts * Point) && (MathMin(o, c) - l >= g_zoMinWickPts * Point);

      if(inChain && !build)
      {
         if(chCount >= 2 || chTwoWick)
            ZoAddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);
         inChain = false;
      }

      bool consumed = false;
      if(build && !inChain)
      {
         for(int i = ArraySize(zs) - 1; i >= 0; i--)
         {
            if(zs[i].state != ZO_ST_FRESH)
               continue;
            if(!(h >= zs[i].lo && l <= zs[i].hi) || !(c >= zs[i].lo && c <= zs[i].hi))
               continue;
            if(h > zs[i].hi || l < zs[i].lo)
            {
               zs[i].hi = MathMax(zs[i].hi, h);
               zs[i].lo = MathMin(zs[i].lo, l);
               zs[i].tLast = t;
               zs[i].builds++;
            }
            consumed = true;
            break;
         }
      }

      for(int i = 0; i < ArraySize(zs); i++)
      {
         if(zs[i].tLast >= t)
            continue;
         bool wasBroken = (zs[i].dir != 0 && ZoIsAlive(zs[i]));
         ZoStep(zs[i], t, h, l, o, c);
         if(wasBroken && !ZoIsAlive(zs[i]))
         {
            zs[i].tDead = t;
            trend = -zs[i].dir;
            trendTime = t;
         }
      }

      if(build && !consumed)
      {
         if(!inChain)
         {
            inChain = true;
            chT0 = t; chHi = h; chLo = l; chCount = 0; chTwoWick = false;
         }
         chTLast = t;
         chHi = MathMax(chHi, h);
         chLo = MathMin(chLo, l);
         chCount++;
         chTwoWick = chTwoWick || twoWick;
      }
   }
   if(inChain && (chCount >= 2 || chTwoWick))
      ZoAddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);

   for(int i = 0; i < ArraySize(zs); i++)
   {
      int k = ArraySize(out);
      ArrayResize(out, k + 1);
      out[k] = zs[i];
   }
}

// Main tagging for the zones of one timeframe [from, to), replaying LP deaths in time order.
void ZoRecomputeMain(ZoZone &zs[], int from, int to)
{
   for(int i = from; i < to; i++)
   {
      zs[i].isMain = false;
      zs[i].tMain = 0;
   }
   // Victims: broken LPs that died, processed oldest death first.
   int victims[];
   ArrayResize(victims, 0);
   for(int i = from; i < to; i++)
      if(zs[i].dir != 0 && zs[i].tDead > 0)
      {
         int k = ArraySize(victims);
         ArrayResize(victims, k + 1);
         victims[k] = i;
      }
   for(int a = 0; a < ArraySize(victims); a++)
      for(int b = a + 1; b < ArraySize(victims); b++)
         if(zs[victims[b]].tDead < zs[victims[a]].tDead)
         {
            int tmp = victims[a];
            victims[a] = victims[b];
            victims[b] = tmp;
         }

   for(int v = 0; v < ArraySize(victims); v++)
   {
      int vi = victims[v];
      datetime t = zs[vi].tDead;
      int attackDir = -zs[vi].dir;
      int best = -1;
      for(int i = from; i < to; i++)
      {
         if(i == vi || zs[i].dir != attackDir || zs[i].tBreak == 0 || zs[i].tBreak > t)
            continue;
         if(zs[i].tDead != 0 && zs[i].tDead <= t)   // not alive at that moment
            continue;
         if(attackDir > 0 && zs[i].lo > zs[vi].lo) continue;
         if(attackDir < 0 && zs[i].hi < zs[vi].hi) continue;
         if(best < 0 || zs[i].tBreak > zs[best].tBreak)
            best = i;
      }
      if(best < 0)
         continue;
      for(int i = from; i < to; i++)
         if(zs[i].dir == attackDir)
            zs[i].isMain = false;
      zs[best].isMain = true;
      zs[best].tMain = t;
   }
}

//+------------------------------------------------------------------+
//| Shared files written by ZO_LP                                    |
//+------------------------------------------------------------------+
string ZoShareFile(int tf)
{
   return ZO_SHARE_DIR + Symbol() + "_" + IntegerToString(tf) + ".csv";
}

long   ZoReadLong(int h) { return StringToInteger(FileReadString(h)); }
double ZoReadDbl(int h)  { return StringToDouble(FileReadString(h)); }

bool ZoLoadShared(ZoTf &d, ZoZone &out[])
{
   string name = ZoShareFile(d.tf);
   if(!FileIsExist(name, FILE_COMMON))
      return false;
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_COMMON | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
      return false;
   bool gotHeader = false;
   while(!FileIsEnding(h))
   {
      string type = FileReadString(h);
      if(type == "H")
      {
         d.lastBar = (datetime)ZoReadLong(h);
         d.trend = (int)ZoReadLong(h);
         d.trendTime = (datetime)ZoReadLong(h);
         ZoReadLong(h);   // valid bars
         ZoReadLong(h);   // first valid bar
         gotHeader = true;
      }
      else if(type == "C")
      {
         int s = (int)ZoReadLong(h);
         double zh = ZoReadDbl(h), zl = ZoReadDbl(h), zo = ZoReadDbl(h), zc = ZoReadDbl(h), zb = ZoReadDbl(h);
         int col = (int)ZoReadLong(h);
         if(s >= 1 && s < ZO_CACHE)
         {
            d.cH[s] = zh; d.cL[s] = zl; d.cO[s] = zo; d.cC[s] = zc; d.cB[s] = zb > 0.5; d.cCol[s] = col;
         }
      }
      else if(type == "Z")
      {
         int k = ArraySize(out);
         ArrayResize(out, k + 1);
         out[k].tf = d.tf;
         out[k].t0 = (datetime)ZoReadLong(h);
         out[k].tLast = (datetime)ZoReadLong(h);
         out[k].tBreak = (datetime)ZoReadLong(h);
         out[k].tDead = (datetime)ZoReadLong(h);
         out[k].lo = ZoReadDbl(h);
         out[k].hi = ZoReadDbl(h);
         out[k].dir = (int)ZoReadLong(h);
         out[k].state = (int)ZoReadLong(h);
         out[k].retests = (int)ZoReadLong(h);
         out[k].builds = (int)ZoReadLong(h);
         ZoReadLong(h);   // ZO_LP's own Main flag (H1 and below only) - recomputed
         out[k].isMain = false;
         out[k].tMain = 0;
      }
      else
         while(!FileIsLineEnding(h) && !FileIsEnding(h))
            FileReadString(h);
   }
   FileClose(h);
   if(!gotHeader)
      return false;
   d.stale = d.lastBar < iTime(Symbol(), d.tf, 2);
   return true;
}

// Loads one timeframe into all[] (appended) and fills d. allowEstimate: fall back to iCustom.
bool ZoLoadTf(int tf, ZoZone &all[], ZoTf &d, bool allowEstimate)
{
   d.tf = tf;
   d.source = ZO_SRC_NONE;
   d.stale = false;
   d.trend = 0;
   d.trendTime = 0;
   d.lastBar = 0;
   for(int s = 0; s < ZO_CACHE; s++)
   {
      d.cH[s] = 0; d.cL[s] = 0; d.cO[s] = 0; d.cC[s] = 0; d.cB[s] = false; d.cCol[s] = 0;
   }
   int from = ArraySize(all);
   if(tf == Period())
   {
      ZoScan(tf, all, d.trend, d.trendTime);
      ZoFillCacheFromChart(d);
      d.lastBar = iTime(Symbol(), tf, 1);
      d.source = ZO_SRC_CHART;
   }
   else if(ZoLoadShared(d, all))
      d.source = ZO_SRC_SHARED;
   else if(allowEstimate)
   {
      ZoScan(tf, all, d.trend, d.trendTime);
      ZoFillCacheFromChart(d);
      d.lastBar = iTime(Symbol(), tf, 1);
      d.source = ZO_SRC_ESTIMATE;
   }
   else
      return false;
   ZoRecomputeMain(all, from, ArraySize(all));
   return true;
}

//+------------------------------------------------------------------+
//| Queries                                                          |
//+------------------------------------------------------------------+
int ZoMainOf(const ZoZone &zs[], int tf, int dir)
{
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].tf == tf && zs[i].dir == dir && zs[i].isMain && ZoIsAlive(zs[i]))
         return i;
   return -1;
}

bool ZoIsShield(const ZoZone &zs[], int idx)
{
   if(zs[idx].isMain || zs[idx].dir == 0 || !ZoIsAlive(zs[idx]))
      return false;
   int m = ZoMainOf(zs, zs[idx].tf, zs[idx].dir);
   return m >= 0 && zs[idx].t0 > zs[m].tBreak;
}

// Live LP of a timeframe that contains the price (broken ones first).
int ZoZoneAt(const ZoZone &zs[], int tf, double p)
{
   int best = -1;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]) || p < zs[i].lo || p > zs[i].hi)
         continue;
      if(best < 0 || (zs[best].dir == 0 && zs[i].dir != 0) || zs[i].t0 > zs[best].t0)
         best = i;
   }
   return best;
}

// Nearest live LP of a timeframe fully above / below the price.
int ZoNeighbour(const ZoZone &zs[], int tf, double p, bool above)
{
   int best = -1;
   double bestD = 0;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]))
         continue;
      if(above && zs[i].lo <= p) continue;
      if(!above && zs[i].hi >= p) continue;
      double dd = ZoDist(zs[i], p);
      if(best < 0 || dd < bestD)
      {
         best = i;
         bestD = dd;
      }
   }
   return best;
}

double ZoScore(const ZoZone &zs[], int i)
{
   double s = 0;
   if(zs[i].isMain)               s += 100;
   s += MathMin(zs[i].builds, 4) * 5;
   if(zs[i].state == ZO_ST_RETEST) s += 12;
   else if(zs[i].state == ZO_ST_BROKEN) s += 10;
   else if(zs[i].state == ZO_ST_FRESH) s += 6;
   else if(zs[i].state == ZO_ST_RUN) s += 2;
   s -= MathMin(zs[i].retests, 5) * 2;
   s += (double)zs[i].t0 / 1.0e9;
   return s;
}

// Important LPs of one timeframe: overlapping same-direction LPs reduced to the strongest,
// then Mains + the LP at price + the nearest perSide above and below.
int ZoSelect(const ZoZone &zs[], int tf, double p, int perSide, bool withFresh, int &sel[])
{
   ArrayResize(sel, 0);
   int cand[];
   ArrayResize(cand, 0);
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(zs[i].tf != tf || !ZoIsAlive(zs[i]))
         continue;
      if(zs[i].dir == 0 && !withFresh)
         continue;
      bool dominated = false;
      for(int j = 0; j < ArraySize(zs) && !dominated; j++)
      {
         if(j == i || zs[j].tf != tf || !ZoIsAlive(zs[j]) || zs[j].dir != zs[i].dir)
            continue;
         if(zs[j].dir == 0 && !withFresh)
            continue;
         bool overlap = zs[i].lo <= zs[j].hi && zs[i].hi >= zs[j].lo;
         if(overlap && ZoScore(zs, j) > ZoScore(zs, i))
            dominated = true;
      }
      if(!dominated)
      {
         int k = ArraySize(cand);
         ArrayResize(cand, k + 1);
         cand[k] = i;
      }
   }
   // Sort candidates by distance to price.
   for(int a = 0; a < ArraySize(cand); a++)
      for(int b = a + 1; b < ArraySize(cand); b++)
         if(ZoDist(zs[cand[b]], p) < ZoDist(zs[cand[a]], p))
         {
            int tmp = cand[a];
            cand[a] = cand[b];
            cand[b] = tmp;
         }
   int nAbove = 0, nBelow = 0;
   for(int a = 0; a < ArraySize(cand); a++)
   {
      int i = cand[a];
      bool keep = zs[i].isMain;
      if(p >= zs[i].lo && p <= zs[i].hi)
         keep = true;
      else if(zs[i].lo > p && nAbove < perSide)
      {
         keep = true;
         nAbove++;
      }
      else if(zs[i].hi < p && nBelow < perSide)
      {
         keep = true;
         nBelow++;
      }
      if(keep)
      {
         int k = ArraySize(sel);
         ArrayResize(sel, k + 1);
         sel[k] = i;
      }
   }
   return ArraySize(sel);
}

// Consecutive closed candles with the colour of shift 1.
int ZoColorRun(const ZoTf &d, int &code)
{
   code = d.cCol[1];
   if(code == 0)
      return 0;
   int n = 1;
   for(int s = 2; s < ZO_CACHE; s++)
   {
      if(d.cCol[s] != code)
         break;
      n++;
   }
   return n;
}

// Two-wick candles with a small body among the last n closed candles ("thu nến").
int ZoTwoWickCount(const ZoTf &d, int n)
{
   int cnt = 0;
   for(int s = 1; s <= n && s < ZO_CACHE; s++)
   {
      double h = d.cH[s], l = d.cL[s], o = d.cO[s], c = d.cC[s];
      if(h <= 0 || h <= l)
         continue;
      double body = MathAbs(c - o), range = h - l;
      if(body <= range * 0.4 && h > MathMax(o, c) && l < MathMin(o, c))
         cnt++;
   }
   return cnt;
}

// Average body of candles [from, from+n) relative to [from+n, from+2n): < 1 = bodies shrinking.
double ZoBodyRatio(const ZoTf &d, int from, int n)
{
   double a = 0, b = 0;
   int na = 0, nb = 0;
   for(int s = from; s < from + n && s < ZO_CACHE; s++)
      if(d.cH[s] > 0) { a += MathAbs(d.cC[s] - d.cO[s]); na++; }
   for(int s = from + n; s < from + 2 * n && s < ZO_CACHE; s++)
      if(d.cH[s] > 0) { b += MathAbs(d.cC[s] - d.cO[s]); nb++; }
   if(na == 0 || nb == 0 || b <= 0)
      return 1;
   return (a / na) / (b / nb);
}

datetime ZoHanoiNow()
{
   return TimeGMT() + 7 * 3600;
}

﻿//+------------------------------------------------------------------+
//| ZoSecrets.mqh                                                    |
//| Personal defaults of the EAs' Telegram inputs. This file is      |
//| git-ignored: copy ZoSecrets.example.mqh to ZoSecrets.mqh and     |
//| fill in your own bot, or leave both empty and type them in the   |
//| Inputs tab when attaching the EA.                                |
//+------------------------------------------------------------------+
#property strict
#define ZO_TELEGRAM_TOKEN   ""
#define ZO_TELEGRAM_CHAT_ID ""

﻿//+------------------------------------------------------------------+
//| ZO_LP.mq4                                                        |
//| Data writer: computes the LPs of the chart's own timeframe from  |
//| the ZOS candles (ZoCore.mqh) and writes them to the shared file  |
//| Common\\Files\\zo_lp\\<symbol>_<minutes>.csv at every new candle. |
//| Draws nothing and sends nothing.                                 |
//|                                                                  |
//| Why it exists: ZOS is only right on the chart of its own         |
//| timeframe, so the EA ZO_Analyst (on M15) needs an H4 chart that  |
//| keeps the H4 LPs up to date - this indicator on that chart. The  |
//| EA opens that chart itself (template ZO_DATA = ZOS + ZO_LP) and  |
//| visits D1 / W1 the same way once a day.                          |
//| Looking at LPs is ZO_View's job; it writes the same file for the |
//| timeframe it is on, so a chart with ZO_View needs no ZO_LP.      |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_LP - Ghi du lieu LP cua khung chart nay (tu nen ZOS) cho EA ZO_Analyst va ZO_View doc. Khong ve, khong gui tin."
#property description "Chi can tren chart du lieu H4 (EA tu mo bang template ZO_DATA). Chart de nhin thi dung ZO_View."
#property indicator_chart_window
#property indicator_buffers 0

#include <ZO/ZoCore.mqh>

input string InpZosName       = "ZOS";    // ZOS indicator file name
input int    InpLookback      = 500;      // Bars scanned
input double InpMinWickPoints = 1;        // Min wick (points) on both ends of a single Build

datetime g_lastBar = 0;      // candle the file was last written for
datetime g_initLocal = 0;

int OnInit()
{
   g_zoName = InpZosName;
   g_zoLookback = InpLookback;
   g_zoMinWickPts = InpMinWickPoints;
   g_lastBar = 0;
   g_initLocal = TimeLocal();
   EventSetTimer(10);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

// Scans the chart and writes the file; false while ZOS has not drawn yet (tried again by the timer).
bool WriteNow()
{
   ZoZone zs[];
   ZoTf d;
   ArrayResize(zs, 0);
   if(!ZoLoadTf(Period(), zs, d, true))
      return false;
   return ZoSaveShared(d, zs, 0, ArraySize(zs));
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   if(Time[0] != g_lastBar && WriteNow())
      g_lastBar = Time[0];
   return rates_total;
}

// No tick may arrive for a while (a weekly chart, a quiet market), and ZOS may still be loading right after the
// chart opened: the timer writes as soon as the data is there, and once more a little later.
void OnTimer()
{
   if(Time[0] != g_lastBar || TimeLocal() - g_initLocal < 90)
      if(WriteNow())
         g_lastBar = Time[0];
}

﻿//+------------------------------------------------------------------+
//| ZO_LP.mq4                                                        |
//| Detects ZO liquidity pools (LP) from ZOS Build candles on        |
//| several timeframes, tracks their state and raises alerts.        |
//|                                                                  |
//| Zone rules (ZO wiki + community):                                |
//|  - Zone = High..Low (ZOS candle) of a Build candle with wicks on |
//|    both ends, or of a chain of consecutive Build candles.        |
//|  - While not broken, a Build candle touching the zone and        |
//|    closing inside extends it ("extended Build cluster").         |
//|  - ZOS close above the zone -> GLP, below -> RLP.                |
//|  - Price coming back into the zone after the break -> RETEST.    |
//|  - Retested and left in the break direction -> RUN (missed).     |
//|  - Close back through the opposite edge -> FAILED (H4 and above: |
//|    as soon as a ZOS body is cut by the end point, 30/9).         |
//|  - A ZOS body spanning both edges -> CLEARED.                    |
//| Importance rules (community):                                    |
//|  - Main LP (MGLP/MRLP): an LP whose move clears an opposite LP   |
//|    of the same timeframe; only the newest per direction is kept. |
//|    Tagged up to InpMainMaxTf (M1..H1).                           |
//|  - Shield: same-direction LP born after a live Main.             |
//|  - LPs "leaning" on a higher-timeframe LP are stronger.          |
//|  - Overlapping same-direction LPs of one timeframe are reduced   |
//|    to the most important one.                                    |
//|  - Timeframe trend from LP structure: the last LP to die tells   |
//|    who won (RLP cleared -> up, GLP cleared -> down).             |
//| Trade assistance (read-only, never touches orders):              |
//|  - SETUP alert with EP / SL / TP / RR plan.                      |
//|  - Break-even hint: move SL 1-2 pips beyond each new LP that     |
//|    forms in favour of an open position.                          |
//|  - Entry audit: flags new positions that break the ZO entry      |
//|    rules (inside an unbroken LP, wrong half of the LP, no LP     |
//|    context, against the LP trend, SL inside the LP).             |
//| Drawing (InpDraw, off by default - ZO_View draws the chart):     |
//| chart-timeframe LPs as rectangles, higher-timeframe LPs          |
//| as two lines labelled e.g. "H-GLP-H4 25/9" / "L-GLP-H4 25/9".    |
//| Alerts are also queued as files for the ZO_Notifier EA           |
//| (Telegram / Discord).                                            |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_LP - May tinh vung thanh khoan (LP) tu nen Build cua ZOS."
#property description "CACH DUNG: gan len chart cua TUNG KHUNG (W1, D1, H4, H1, M15); moi chart phai co ZOS."
#property description "Theo doi trang thai LP (GLP/RLP, retest, chet), gan Main/Shield, gui canh bao."
#property description "Ghi du lieu cho ZO_View, ZO_DrawLP va ZO_Analyst doc. Khong dat lenh."
#property indicator_chart_window
#property indicator_buffers 0

//--- inputs
input string InpZosName         = "ZOS";                  // ZOS indicator file name
input string InpTimeframes      = "10080,1440,240,60,15"; // LP timeframes (minutes)
input int    InpLookback        = 500;                    // Bars scanned per timeframe
input double InpMinWickPoints   = 1;                      // Min wick (points) on both ends of a single Build
input double InpMaxZonePips     = 0;                      // Skip zones wider than this (0 = off; e.g. news Builds)
input bool   InpBreakOnZosClose = true;                   // Breakout by ZOS close (false = real close)
input int    InpMainMaxTf       = 240;                    // Tag Main LP up to this timeframe (Main H4 = trend, 30/9)
input int    InpMaxZonesPerTf   = 2;                      // LPs shown per timeframe (nearest after dedupe)
input bool   InpShowFresh       = true;                   // Show LPs not broken yet
input bool   InpShowRun         = true;                   // Show LPs already retested and left
input bool   InpAlertPopup      = true;                   // Popup alerts
input bool   InpAlertPush       = false;                  // MT4 push notifications (MetaQuotes ID in Options)
input bool   InpAlertQueue      = true;                   // Queue alerts for ZO_Notifier (Telegram / Discord)
input bool   InpAlertNewLp      = true;                   // Alert when a new LP appears / extends
input bool   InpAlertBreak      = true;                   // Alert when an LP breaks into GLP/RLP
input bool   InpAlertDeath      = true;                   // Alert when an LP is cleared / fails (+ SHs sign)
input bool   InpAlertWeakRetest = true;                   // Alert when the retest loses strength on the entry timeframe
input bool   InpAlertAttack     = true;                   // Alert when an opposite LP is attacked (close past 50%)
input int    InpShsMaxBars      = 3;                      // LP killed within N bars of its break = SHs sign
input double InpNearPips        = 5;                      // Alert when price gets this close to an HTF LP
input int    InpNearMinTf       = 240;                    // Timeframes used for the "getting close" alert
input bool   InpMorningReport   = true;                   // Daily analysis message
input int    InpReportHour      = 7;                      // Report time (Hanoi)
input int    InpReportMinute    = 15;
input int    InpReportTzOffset  = 7;                      // Hanoi = GMT+7
input int    InpReportLateHours = 4;                      // Still send if MT4 starts up to N hours late
input bool   InpReportOnStart   = false;                  // Send a report right after attaching (for testing)
input bool   InpUseSharedCharts = true;                   // Read other timeframes from ZO_LP running on their own charts
input int    InpMasterMode      = 0;                      // Who sends messages: 0 = the chart on InpShortEntryTf (M15), 1 = this chart, 2 = never
input bool   InpDebugDump       = true;                   // Write all zones to MQL4\Files\zo_lp_zones_<symbol>.csv
input bool   InpDraw            = false;                  // Draw LPs + Comment panel (off when ZO_View shows the chart)
input string InpLongCtxTfs      = "10080,1440";           // Long frame: context timeframes (W1, D1)
input int    InpLongEntryTf     = 240;                    // Long frame: entry timeframe (H4)
input string InpShortCtxTfs     = "240,60";               // Short frame: context timeframes (H4, H1)
input int    InpShortEntryTf    = 15;                     // Short frame: entry timeframe (M15)
input int    InpMinGapMin       = 10;                     // Min minutes between two batched event messages
input int    InpCooldownShortMin = 60;                    // Same LP event not repeated within N min (H1)
input int    InpCooldownLongMin = 360;                    // Same LP event not repeated within N min (H4, D1, W1)
input int    InpQuietFrom       = 0;                      // Quiet hours (Hanoi): only SETUP / order checks / BE / long-frame weak retest
input int    InpQuietTo         = 7;
input bool   InpDigests         = true;                   // Periodic frame summaries
input string InpLongDigestHours = "14,20";                // Long-frame summary hours (Hanoi, :15), only if changed or price near W1/D1
input double InpLongActivePips  = 20;                     // Long frame "active": price within N pips of a W1/D1 LP
input double InpShortActivePips = 10;                     // Short frame "active": price within N pips of an H4/H1 LP
input int    InpShortIdleHours  = 4;                      // Short-frame summary every N hours when not active (hourly when active)
input double InpSlBufferPips    = 2;                      // SL distance beyond the LP edge
input double InpMinRR           = 2;                      // Setups below this RR are flagged
input int    InpTrendTf         = 240;                    // Timeframe whose LP trend the entry audit checks
input bool   InpBeHints         = true;                   // Suggest moving SL/BE behind new LPs
input int    InpBeTf            = 15;                     // Timeframe of LPs used for BE hints
input double InpBeBufferPips    = 1.5;                    // BE distance beyond the new LP edge
input bool   InpEntryAudit      = true;                   // Check new positions against ZO entry rules
input color  InpClrGlp          = C'0,70,0';
input color  InpClrGlpRetest    = C'0,130,0';
input color  InpClrRlp          = C'80,0,0';
input color  InpClrRlpRetest    = C'150,0,0';
input color  InpClrFresh        = C'150,150,0';
input color  InpClrRun          = C'90,90,90';
input color  InpClrLineGlp      = clrLimeGreen;
input color  InpClrLineRlp      = clrTomato;
input color  InpClrLineFresh    = clrGold;

//--- zone states
#define ST_FRESH   0
#define ST_BROKEN  1
#define ST_RETEST  2
#define ST_RUN     3
#define ST_FAILED  4
#define ST_CLEARED 5

#define PREFIX      "ZOLP_"
#define QUEUE_DIR   "zo_alerts\\"
#define SHARE_DIR   "zo_lp\\"   // Common\Files\zo_lp\<symbol>_<tf>.csv, one per chart timeframe
#define CACHE_SIZE  13            // last closed ZOS candles shared per timeframe (shift 1..12)

struct Zone
{
   int      tf;
   datetime t0;        // open time of the first Build candle
   datetime tLast;     // open time of the last candle that shaped the zone
   datetime tBreak;
   datetime tDead;     // bar that cleared / failed the zone
   double   hi;
   double   lo;
   int      dir;       // +1 GLP, -1 RLP, 0 not broken
   int      state;
   int      retests;   // times price came back into the zone after the break
   int      builds;    // Build candles in the zone
   bool     isMain;
};

Zone     g_zones[];
int      g_tfs[];
datetime g_lastBarTime[];
int      g_tfTrend[];      // +1 up, -1 down, 0 unknown (from the last LP that died)
datetime g_tfTrendTime[];
int      g_tfValid[];      // valid ZOS bars found per timeframe (diagnostics)
// ZOS read through iCustom() for a timeframe other than the chart's gives different values than ZOS
// attached to that timeframe's own chart (seen on D1: other color, other LPs). So every timeframe is
// computed by ZO_LP on its own chart and shared through files; iCustom() is only a fallback.
bool     g_tfShared[];     // data of this timeframe was loaded from its own chart
bool     g_tfFallback[];   // computed here through iCustom() (estimate, may differ from the real chart)
long     g_tfFileMod[];
double   g_cH[][CACHE_SIZE];
double   g_cL[][CACHE_SIZE];
double   g_cO[][CACHE_SIZE];
double   g_cC[][CACHE_SIZE];
double   g_cB[][CACHE_SIZE];
int      g_cCol[][CACHE_SIZE];
datetime g_tfFirstValid[];
string   g_prevKeys[];
int      g_prevStates[];
bool     g_prevMain[];
double   g_prevHi[];
double   g_prevLo[];
string   g_signalAlerted[];  // weak-retest / attack / near alerts already sent
bool     g_initialized = false;
string   g_tickAlerted[];
string   g_beAlerted[];
int      g_knownTickets[];
bool     g_ticketsLoaded = false;
bool     g_reportOnStartSent = false;
bool     g_silent = false;   // suppresses Notify() while the first pass primes the "already alerted" sets
double   g_pip;

//+------------------------------------------------------------------+
string TfName(int tf)
{
   switch(tf)
   {
      case 1:     return "M1";
      case 5:     return "M5";
      case 15:    return "M15";
      case 30:    return "M30";
      case 60:    return "H1";
      case 240:   return "H4";
      case 1440:  return "D1";
      case 10080: return "W1";
      case 43200: return "MN";
   }
   return "TF" + IntegerToString(tf);
}

string StateName(int st)
{
   switch(st)
   {
      case ST_FRESH:   return "NEW";
      case ST_BROKEN:  return "WAIT RETEST";
      case ST_RETEST:  return "RETEST";
      case ST_RUN:     return "RUN";
      case ST_FAILED:  return "FAILED";
      case ST_CLEARED: return "CLEARED";
   }
   return "?";
}

bool IsAlive(const Zone &z)
{
   return z.state != ST_FAILED && z.state != ST_CLEARED;
}

// "GLP", "MGLP", "RLP", "MRLP" or "LP".
string ZoneKind(const Zone &z)
{
   if(z.dir > 0) return z.isMain ? "MGLP" : "GLP";
   if(z.dir < 0) return z.isMain ? "MRLP" : "RLP";
   return "LP";
}

string ZoneKey(const Zone &z)
{
   return IntegerToString(z.tf) + "|" + IntegerToString((long)z.t0);
}

// Day/month of the first Build candle, the way the community names LPs ("Low H4 25/9").
string ZoneDate(const Zone &z)
{
   return IntegerToString(TimeDay(z.t0)) + "/" + IntegerToString(TimeMonth(z.t0));
}

string Px(double p)
{
   return DoubleToString(p, Digits);
}

int TfIndex(int tf)
{
   for(int i = 0; i < ArraySize(g_tfs); i++)
      if(g_tfs[i] == tf)
         return i;
   return -1;
}

//+------------------------------------------------------------------+
int OnInit()
{
   g_pip = (Digits == 3 || Digits == 5) ? Point * 10 : Point;

   string parts[];
   int n = StringSplit(InpTimeframes, ',', parts);
   ArrayResize(g_tfs, 0);
   for(int i = 0; i < n; i++)
   {
      int tf = (int)StringToInteger(parts[i]);
      if(tf <= 0 || tf < Period())
         continue;   // never use LPs from timeframes below the chart
      int k = ArraySize(g_tfs);
      ArrayResize(g_tfs, k + 1);
      g_tfs[k] = tf;
   }
   int m = ArraySize(g_tfs);
   ArrayResize(g_lastBarTime, m);
   ArrayResize(g_tfTrend, m);
   ArrayResize(g_tfTrendTime, m);
   ArrayResize(g_tfValid, m);
   ArrayResize(g_tfShared, m);
   ArrayResize(g_tfFallback, m);
   ArrayResize(g_tfFileMod, m);
   ArrayResize(g_cH, m);
   ArrayResize(g_cL, m);
   ArrayResize(g_cO, m);
   ArrayResize(g_cC, m);
   ArrayResize(g_cB, m);
   ArrayResize(g_cCol, m);
   ArrayInitialize(g_tfShared, false);
   ArrayInitialize(g_tfFallback, false);
   ArrayInitialize(g_tfFileMod, -1);
   ArrayResize(g_tfFirstValid, m);
   ArrayInitialize(g_lastBarTime, 0);
   ArrayInitialize(g_tfTrend, 0);
   ArrayInitialize(g_tfTrendTime, 0);
   g_initialized = false;
   g_ticketsLoaded = false;
   if(InpAlertQueue)
      FolderCreate(QUEUE_DIR, FILE_COMMON);
   if(InpUseSharedCharts)
      FolderCreate(SHARE_DIR, FILE_COMMON);
   EventSetTimer(5);   // keep higher timeframes in sync even without ticks
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, PREFIX);
   if(InpDraw)
      Comment("");
}

//+------------------------------------------------------------------+
//| ZOS access                                                       |
//+------------------------------------------------------------------+
// ZOS candle of a closed bar. Returns false when ZOS has no valid data there.
// Index into the shared candle cache, or -1 when this timeframe / shift must be read through iCustom().
int CacheIndex(int tf, int shift)
{
   int f = TfIndex(tf);
   if(f < 0 || !g_tfShared[f] || shift < 1 || shift >= CACHE_SIZE)
      return -1;
   return f;
}

bool ReadZos(int tf, int shift, double &h, double &l, double &o, double &c, bool &build)
{
   int ci = CacheIndex(tf, shift);
   if(ci >= 0)
   {
      h = g_cH[ci][shift]; l = g_cL[ci][shift]; o = g_cO[ci][shift]; c = g_cC[ci][shift];
      build = g_cB[ci][shift] > 0.5;
      return h > 0 && l > 0;
   }
   h = iCustom(Symbol(), tf, InpZosName, 0, shift);
   l = iCustom(Symbol(), tf, InpZosName, 1, shift);
   o = iCustom(Symbol(), tf, InpZosName, 2, shift);
   c = iCustom(Symbol(), tf, InpZosName, 3, shift);
   if(h == EMPTY_VALUE || l == EMPTY_VALUE || o == EMPTY_VALUE || c == EMPTY_VALUE)
      return false;
   if(l <= 0 || l > MathMin(o, c) + Point || h < MathMax(o, c) - Point)
      return false;
   build = (iCustom(Symbol(), tf, InpZosName, 14, shift) > 0.5);
   return true;
}

// Trend color of a closed bar: 1 green, 2 blue, -1 red, -2 pink, 9 build, 0 unknown.
int ReadColor(int tf, int shift)
{
   int ci = CacheIndex(tf, shift);
   if(ci >= 0)
      return g_cCol[ci][shift];
   int codes[5] = {1, 2, -1, -2, 9};
   for(int p = 0; p < 5; p++)
   {
      double v = iCustom(Symbol(), tf, InpZosName, 4 + p * 2, shift);
      if(v != EMPTY_VALUE && v > 0)
         return codes[p];
   }
   return 0;
}

//+------------------------------------------------------------------+
//| Zone detection                                                   |
//+------------------------------------------------------------------+
void AddZone(Zone &out[], int tf, datetime t0, datetime tLast, double hi, double lo, int builds)
{
   if(InpMaxZonePips > 0 && (hi - lo) / g_pip > InpMaxZonePips)
      return;
   int k = ArraySize(out);
   ArrayResize(out, k + 1);
   out[k].tf = tf;
   out[k].t0 = t0;
   out[k].tLast = tLast;
   out[k].tBreak = 0;
   out[k].tDead = 0;
   out[k].hi = hi;
   out[k].lo = lo;
   out[k].dir = 0;
   out[k].state = ST_FRESH;
   out[k].retests = 0;
   out[k].builds = builds;
   out[k].isMain = false;
}

// Advance one zone with one closed ZOS candle.
void StepZone(Zone &z, datetime t, double h, double l, double o, double c, double closeForBreak)
{
   if(!IsAlive(z))
      return;

   if(z.state == ST_FRESH)
   {
      if(closeForBreak > z.hi)       { z.dir = 1;  z.state = ST_BROKEN; z.tBreak = t; }
      else if(closeForBreak < z.lo)  { z.dir = -1; z.state = ST_BROKEN; z.tBreak = t; }
      return;
   }

   double bodyHi = MathMax(o, c), bodyLo = MathMin(o, c);
   if(bodyLo <= z.lo && bodyHi >= z.hi)
   {
      z.state = ST_CLEARED;
      return;
   }
   // H4 and above (user rule 30/9, backtest BODY_DEATH): a broken LP dies as soon as a ZOS BODY is cut by its
   // end point (GLP: body below the Low; RLP: body above the High), not only on a close beyond it.
   if(z.tf >= 240 && ((z.dir > 0 && bodyLo < z.lo) || (z.dir < 0 && bodyHi > z.hi)))
   {
      z.state = ST_FAILED;
      return;
   }

   if(z.dir > 0)
   {
      if(closeForBreak < z.lo)                 { z.state = ST_FAILED; return; }
      bool inside = (l <= z.hi);
      if(z.state == ST_BROKEN && inside)       { z.state = ST_RETEST; z.retests++; }
      else if(z.state == ST_RUN && inside)     { z.state = ST_RETEST; z.retests++; }
      else if(z.state == ST_RETEST && l > z.hi) z.state = ST_RUN;
   }
   else
   {
      if(closeForBreak > z.hi)                 { z.state = ST_FAILED; return; }
      bool inside = (h >= z.lo);
      if(z.state == ST_BROKEN && inside)       { z.state = ST_RETEST; z.retests++; }
      else if(z.state == ST_RUN && inside)     { z.state = ST_RETEST; z.retests++; }
      else if(z.state == ST_RETEST && h < z.lo) z.state = ST_RUN;
   }
}

// A broken LP just died at time t: the latest live opposite LP on the attacking side becomes Main.
void TagMain(Zone &zs[], int victim, datetime t)
{
   if(zs[victim].tf > InpMainMaxTf || zs[victim].dir == 0)
      return;
   int attackDir = -zs[victim].dir;   // RLP killed by buyers -> GLP is Main
   int best = -1;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      if(i == victim || zs[i].dir != attackDir || !IsAlive(zs[i]) || zs[i].tBreak == 0 || zs[i].tBreak > t)
         continue;
      // The attacker must sit on its own side of the victim (GLP below the RLP it cleared, and vice versa).
      if(attackDir > 0 && zs[i].lo > zs[victim].lo) continue;
      if(attackDir < 0 && zs[i].hi < zs[victim].hi) continue;
      // An LP becomes Main only by clearing an OLDER opposite LP, never one formed after it.
      if(zs[i].t0 <= zs[victim].t0) continue;
      if(best < 0 || zs[i].tBreak > zs[best].tBreak)
         best = i;
   }
   if(best < 0)
      return;
   // Only the newest Main per direction leads the current trend; older ones are superseded.
   for(int i = 0; i < ArraySize(zs); i++)
      if(zs[i].dir == attackDir)
         zs[i].isMain = false;
   zs[best].isMain = true;
}

// Rebuild every zone of one timeframe from scratch, oldest bar to newest closed bar.
// Also returns the LP-structure trend of that timeframe.
void ScanTimeframe(int tf, Zone &out[], int &trend, datetime &trendTime, int &valid, datetime &firstValid)
{
   valid = 0;
   firstValid = 0;
   int bars = MathMin(InpLookback, iBars(Symbol(), tf) - 2);
   Zone zs[];
   ArrayResize(zs, 0);
   trend = 0;
   trendTime = 0;

   // Pending chain of consecutive Build candles.
   bool     inChain = false;
   datetime chT0 = 0, chTLast = 0;
   double   chHi = 0, chLo = 0;
   int      chCount = 0;
   bool     chTwoWick = false;

   for(int s = bars; s >= 1; s--)
   {
      double h, l, o, c;
      bool build;
      if(!ReadZos(tf, s, h, l, o, c, build))
      {
         inChain = false;
         continue;
      }
      datetime t = iTime(Symbol(), tf, s);
      valid++;
      if(firstValid == 0)
         firstValid = t;
      double closeForBreak = InpBreakOnZosClose ? c : iClose(Symbol(), tf, s);
      bool twoWick = (h - MathMax(o, c) >= InpMinWickPoints * Point) &&
                     (MathMin(o, c) - l >= InpMinWickPoints * Point);

      // Chain ended on the previous bar -> the chain becomes a zone before this bar is applied.
      if(inChain && !build)
      {
         if(chCount >= 2 || chTwoWick)
            AddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);
         inChain = false;
      }

      // A Build candle that touches a not-yet-broken zone and closes inside it extends that zone.
      bool consumed = false;
      if(build && !inChain)
      {
         for(int i = ArraySize(zs) - 1; i >= 0; i--)
         {
            if(zs[i].state != ST_FRESH)
               continue;
            bool touches = (h >= zs[i].lo && l <= zs[i].hi);
            bool closesInside = (closeForBreak >= zs[i].lo && closeForBreak <= zs[i].hi);
            if(!touches || !closesInside)
               continue;
            if(h > zs[i].hi || l < zs[i].lo)
            {
               zs[i].hi = MathMax(zs[i].hi, h);
               zs[i].lo = MathMin(zs[i].lo, l);
               zs[i].tLast = t;
               zs[i].builds++;
            }
            consumed = true;   // a Build fully inside an unbroken zone adds nothing new
            break;
         }
      }

      // Existing zones react to this candle.
      for(int i = 0; i < ArraySize(zs); i++)
      {
         if(zs[i].tLast >= t)
            continue;
         bool wasBroken = (zs[i].dir != 0 && IsAlive(zs[i]));
         StepZone(zs[i], t, h, l, o, c, closeForBreak);
         if(wasBroken && !IsAlive(zs[i]))
         {
            zs[i].tDead = t;
            TagMain(zs, i, t);
            trend = -zs[i].dir;   // the side that killed this LP leads the timeframe
            trendTime = t;
         }
      }

      if(build && !consumed)
      {
         if(!inChain)
         {
            inChain = true;
            chT0 = t; chHi = h; chLo = l; chCount = 0; chTwoWick = false;
         }
         chTLast = t;
         chHi = MathMax(chHi, h);
         chLo = MathMin(chLo, l);
         chCount++;
         chTwoWick = chTwoWick || twoWick;
      }
   }
   if(inChain && (chCount >= 2 || chTwoWick))
      AddZone(zs, tf, chT0, chTLast, chHi, chLo, chCount);

   for(int i = 0; i < ArraySize(zs); i++)
   {
      int k = ArraySize(out);
      ArrayResize(out, k + 1);
      out[k] = zs[i];
   }
}

//+------------------------------------------------------------------+
//| Importance and selection                                         |
//+------------------------------------------------------------------+
bool IsShield(const Zone &z)
{
   if(z.isMain || z.dir == 0)
      return false;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone m = g_zones[i];
      if(m.isMain && IsAlive(m) && m.tf == z.tf && m.dir == z.dir && z.t0 > m.tBreak)
         return true;
   }
   return false;
}

// The LP overlaps a live, broken LP of a higher timeframe ("leans on" it).
bool LeansOnHigherTf(const Zone &z)
{
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone h = g_zones[i];
      if(h.tf > z.tf && h.dir != 0 && IsAlive(h) && z.lo <= h.hi && z.hi >= h.lo)
         return true;
   }
   return false;
}

// Higher = more important. Used to pick one LP out of an overlapping group.
double Importance(const Zone &z)
{
   double s = 0;
   if(z.isMain)                  s += 100;
   if(IsShield(z))               s -= 10;
   if(LeansOnHigherTf(z))        s += 8;
   s += MathMin(z.builds, 4) * 5;             // Build clusters are stronger
   if(z.state == ST_RETEST)      s += 12;
   else if(z.state == ST_BROKEN) s += 10;
   else if(z.state == ST_FRESH)  s += 6;
   else if(z.state == ST_RUN)    s += 2;
   s -= MathMin(z.retests, 5) * 2;            // every retest consumes liquidity
   s += (double)z.t0 / 1.0e9;                 // tie-break: newer LPs matter more
   return s;
}

bool IsVisible(const Zone &z)
{
   if(!IsAlive(z))         return false;
   if(z.state == ST_FRESH) return InpShowFresh;
   if(z.state == ST_RUN)   return InpShowRun;
   return true;
}

double DistancePips(const Zone &z, double p)
{
   if(p > z.hi) return (p - z.hi) / g_pip;
   if(p < z.lo) return (z.lo - p) / g_pip;
   return 0;
}

// Indexes of the LPs to draw for one timeframe: dedupe overlapping same-direction LPs by
// importance, then keep the nearest ones; a live Main LP is always kept.
int SelectZones(int tf, int &sel[])
{
   int cand[];
   double score[];
   ArrayResize(cand, 0);
   ArrayResize(score, 0);
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      if(g_zones[i].tf != tf || !IsVisible(g_zones[i]))
         continue;
      int k = ArraySize(cand);
      ArrayResize(cand, k + 1);
      ArrayResize(score, k + 1);
      cand[k] = i;
      score[k] = Importance(g_zones[i]);
   }
   int n = ArraySize(cand);
   for(int a = 0; a < n; a++)   // sort by importance, descending
      for(int b = a + 1; b < n; b++)
         if(score[b] > score[a])
         {
            double ts = score[a]; score[a] = score[b]; score[b] = ts;
            int ti = cand[a]; cand[a] = cand[b]; cand[b] = ti;
         }

   int kept[];
   ArrayResize(kept, 0);
   for(int a = 0; a < n; a++)
   {
      Zone z = g_zones[cand[a]];
      bool overlaps = false;
      for(int j = 0; j < ArraySize(kept); j++)
      {
         Zone k2 = g_zones[kept[j]];
         if(k2.dir == z.dir && z.lo <= k2.hi && z.hi >= k2.lo)
         {
            overlaps = true;
            break;
         }
      }
      if(overlaps)
         continue;
      int k = ArraySize(kept);
      ArrayResize(kept, k + 1);
      kept[k] = cand[a];
   }

   int m = ArraySize(kept);
   double dist[];
   ArrayResize(dist, m);
   for(int a = 0; a < m; a++)
      dist[a] = DistancePips(g_zones[kept[a]], Bid);
   for(int a = 0; a < m; a++)   // sort by distance to price, ascending
      for(int b = a + 1; b < m; b++)
         if(dist[b] < dist[a])
         {
            double td = dist[a]; dist[a] = dist[b]; dist[b] = td;
            int ti = kept[a]; kept[a] = kept[b]; kept[b] = ti;
         }

   ArrayResize(sel, 0);
   for(int a = 0; a < m; a++)
   {
      if(a >= InpMaxZonesPerTf && !g_zones[kept[a]].isMain)
         continue;
      int k = ArraySize(sel);
      ArrayResize(sel, k + 1);
      sel[k] = kept[a];
   }
   return ArraySize(sel);
}

//+------------------------------------------------------------------+
//| Alerts (user-facing text is Vietnamese)                          |
//+------------------------------------------------------------------+
// Small string hash so identical alerts from several charts map to the same queue file.
uint HashText(string s)
{
   uint h = 2166136261;
   for(int i = 0; i < StringLen(s); i++)
      h = (h ^ (uint)StringGetCharacter(s, i)) * 16777619;
   return h;
}

// Each alert becomes one file in Common\Files\zo_alerts\ for ZO_Notifier to send and delete.
// The name is <unix time>_<hash of message and minute>: the same alert raised by ZO_LP on two charts
// of one symbol within the same minute overwrites a single file instead of being sent twice.
void QueueAlert(string msg)
{
   long minute = (long)TimeLocal() / 60 * 60;
   string name = QUEUE_DIR + StringFormat("%I64d_%u.txt", minute, HashText(msg));
   int h = FileOpen(name, FILE_WRITE | FILE_TXT | FILE_COMMON | FILE_UNICODE);
   if(h == INVALID_HANDLE)
   {
      PrintFormat("ZO_LP: cannot queue alert err=%d", GetLastError());
      return;
   }
   FileWriteString(h, msg);
   FileClose(h);
}

// Only one chart per symbol talks: by default the chart on the short-frame entry timeframe (M15).
bool IsMaster()
{
   if(InpMasterMode == 1) return true;
   if(InpMasterMode == 2) return false;
   return Period() == InpShortEntryTf;
}

// Timeframe computed from its own chart (or it is this chart): safe to alert on.
bool IsReliable(int tf)
{
   int f = TfIndex(tf);
   return f >= 0 && !g_tfFallback[f];
}

// Sends one finished message to every enabled channel.
void Deliver(string full, bool popup = true)
{
   if(g_silent || !IsMaster())
      return;   // first pass after attaching: conditions are only recorded, not announced
   if(InpAlertPopup && popup) Alert(full);
   else                       Print(full);
   if(InpAlertPush)  SendNotification(StringSubstr(full, 0, 255));   // MT4 push limit
   if(InpAlertQueue) QueueAlert(full);
}

// Urgent message (SETUP, weak retest, order checks, BE hints): sent immediately, also in quiet hours.
void Notify(string msg)
{
   Deliver(Symbol() + " | " + msg);
}

int FindPrev(string key)
{
   for(int i = 0; i < ArraySize(g_prevKeys); i++)
      if(g_prevKeys[i] == key)
         return i;
   return -1;
}

bool Contains(const string &arr[], string key)
{
   for(int i = 0; i < ArraySize(arr); i++)
      if(arr[i] == key)
         return true;
   return false;
}

void Remember(string &arr[], string key)
{
   int k = ArraySize(arr);
   ArrayResize(arr, k + 1);
   arr[k] = key;
}

// e.g. "H4 GLP 25/9 (1.13581-1.13904)"
string ZoneText(const Zone &z)
{
   return StringFormat("%s %s %s (%s-%s)", TfName(z.tf), ZoneKind(z), ZoneDate(z), Px(z.lo), Px(z.hi));
}

string TrendText(int tf)
{
   int i = TfIndex(tf);
   if(i < 0 || g_tfTrend[i] == 0) return "chưa rõ";
   return g_tfTrend[i] > 0 ? "TĂNG" : "GIẢM";
}

// Nearest live opposite LP edge beyond the entry, on this timeframe or higher: the natural TP.
bool FindTarget(int dir, double ep, int minTf, double &tp, string &tpName)
{
   bool found = false;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z) || z.tf < minTf || z.dir == dir)
         continue;   // same-direction LPs support the move, they are not targets
      double edge = (dir > 0) ? z.lo : z.hi;
      if((dir > 0 && edge <= ep) || (dir < 0 && edge >= ep))
         continue;
      if(!found || (dir > 0 && edge < tp) || (dir < 0 && edge > tp))
      {
         tp = edge;
         tpName = ZoneText(z);
         found = true;
      }
   }
   return found;
}

// SETUP alert with a concrete plan: EP in the half of the small LP nearest its protective edge,
// SL beyond that edge, TP at the nearest opposite LP.
void NotifySetup(const Zone &z, const Zone &hz, string frame)
{
   int dir = z.dir;
   double ep = (z.hi + z.lo) / 2;
   double sl = (dir > 0) ? z.lo - InpSlBufferPips * g_pip : z.hi + InpSlBufferPips * g_pip;
   double tp = 0;
   string tpName = "";
   bool hasTp = FindTarget(dir, ep, z.tf, tp, tpName);
   double risk = MathAbs(ep - sl) / g_pip;

   string msg = StringFormat("SETUP %s [%s]: %s nằm trong %s đang retest.\n", dir > 0 ? "BUY" : "SELL",
                             frame, ZoneText(z), ZoneText(hz));
   msg += StringFormat("Xu thế LP: %s %s", TfName(hz.tf), TrendText(hz.tf));
   if(hz.tf != InpTrendTf)
      msg += StringFormat(", %s %s", TfName(InpTrendTf), TrendText(InpTrendTf));
   msg += ".\n";
   msg += StringFormat("Gợi ý: EP limit %s (50%% LP), SL %s (%.1f pip)", Px(ep), Px(sl), risk);
   if(hasTp)
   {
      double rr = MathAbs(tp - ep) / MathAbs(ep - sl);
      msg += StringFormat(", TP %s tại %s, RR 1:%.1f", Px(tp), tpName, rr);
      if(rr < InpMinRR)
         msg += StringFormat("\nCẢNH BÁO: RR < 1:%.1f, LP ngược chiều quá gần (không trống) - cân nhắc bỏ kèo.", InpMinRR);
   }
   else
      msg += ", TP: phía trước trống, chưa có LP ngược chiều";
   int ti = TfIndex(InpTrendTf);
   if(ti >= 0 && g_tfTrend[ti] != 0 && g_tfTrend[ti] != dir)
      msg += StringFormat("\nCẢNH BÁO: ngược xu thế LP %s.", TfName(InpTrendTf));
   Notify(msg);
}

//+------------------------------------------------------------------+
//| Market reading helpers (ZOS candles)                             |
//+------------------------------------------------------------------+
string ColorName(int code)
{
   switch(code)
   {
      case 1:  return "XANH LÁ (áp lực tăng mạnh)";
      case 2:  return "XANH DƯƠNG (hồi / bắt đầu tăng)";
      case -1: return "ĐỎ (áp lực giảm mạnh)";
      case -2: return "HỒNG-TÍM (hồi / bắt đầu giảm)";
      case 9:  return "VÀNG (Build)";
   }
   return "chưa có dữ liệu";
}

// Number of consecutive closed candles (from shift 1) with the same ZOS color: "áp lực giảm nến thứ 2".
int ColorRun(int tf, int &code)
{
   code = ReadColor(tf, 1);
   int n = 0;
   for(int s = 1; s <= 60; s++)
   {
      if(ReadColor(tf, s) != code)
         break;
      n++;
   }
   return n;
}

// Small body with wicks on both ends: the "nến 2 đầu" / "thu nến" of accumulation.
bool IsTwoWickSmall(int tf, int shift)
{
   double h, l, o, c;
   bool build;
   if(!ReadZos(tf, shift, h, l, o, c, build))
      return false;
   double range = h - l;
   if(range <= 0)
      return false;
   double body = MathAbs(c - o);
   return body <= 0.4 * range && (h - MathMax(o, c)) >= 0.15 * range && (MathMin(o, c) - l) >= 0.15 * range;
}

int TwoWickCount(int tf, int from, int n)
{
   int k = 0;
   for(int s = from; s < from + n; s++)
      if(IsTwoWickSmall(tf, s))
         k++;
   return k;
}

double AvgBody(int tf, int from, int n)
{
   double sum = 0;
   int k = 0;
   for(int s = from; s < from + n; s++)
   {
      double h, l, o, c;
      bool build;
      if(!ReadZos(tf, s, h, l, o, c, build))
         continue;
      sum += MathAbs(c - o);
      k++;
   }
   return k > 0 ? sum / k : 0;
}

// Nearest live LP edge strictly above (up) or below the given price, on timeframes >= minTf.
bool NearestEdge(double from, bool up, int minTf, double &edge, string &name)
{
   bool found = false;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z) || z.tf < minTf)
         continue;
      double e = up ? z.lo : z.hi;
      if((up && e <= from) || (!up && e >= from))
         continue;
      if(!found || (up && e < edge) || (!up && e > edge))
      {
         edge = e;
         name = ZoneText(z);
         found = true;
      }
   }
   return found;
}

// Nearest live LP of one timeframe entirely above / below the current price.
int Neighbour(int tf, bool above)
{
   int best = -1;
   double bestD = 0;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(z.tf != tf || !IsAlive(z))
         continue;
      if(above && z.lo <= Bid) continue;
      if(!above && z.hi >= Bid) continue;
      double d = DistancePips(z, Bid);
      if(best < 0 || d < bestD)
      {
         best = i;
         bestD = d;
      }
   }
   return best;
}

// Live LP of one timeframe that contains the current price (broken LPs first).
int ZoneAtPrice(int tf)
{
   int best = -1;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(z.tf != tf || !IsAlive(z) || Bid < z.lo || Bid > z.hi)
         continue;
      if(best < 0 || (g_zones[best].dir == 0 && z.dir != 0) || Importance(z) > Importance(g_zones[best]))
         best = i;
   }
   return best;
}

int MainOf(int tf, int dir)
{
   for(int i = 0; i < ArraySize(g_zones); i++)
      if(g_zones[i].tf == tf && g_zones[i].isMain && g_zones[i].dir == dir && IsAlive(g_zones[i]))
         return i;
   return -1;
}

string EdgeText(double from, bool up, int minTf)
{
   double e = 0;
   string name = "";
   if(!NearestEdge(from, up, minTf, e, name))
      return up ? "phía trên trống" : "phía dưới trống";
   return StringFormat("%s %s (%.0f pip)", up ? "H" : "L", name, MathAbs(e - from) / g_pip);
}

// Zerd-style two-way reading of a key LP: what a clear means and what a hold means.
string KeyScenario(const Zone &z)
{
   string up = EdgeText(z.hi, true, z.tf), down = EdgeText(z.lo, false, z.tf);
   if(z.dir == 0)
      return "LP chưa break (nội chiến). Lên G → nhắm " + up + ". Xuống R → nhắm " + down + ".";
   if(z.dir < 0)
      return "Clear = xoá đà giảm, mở đường lên " + up + ". Giữ được (hold) = nối đà giảm về " + down + ".";
   return "Giữ được (hold) = nối đà tăng lên " + up + ". Clear = sập về " + down + ".";
}

//+------------------------------------------------------------------+
//| Trading frames                                                   |
//+------------------------------------------------------------------+
// Long frame: context W1 / D1, entries on H4. Short frame: context H4 / H1, entries on M15.
// H4 belongs to both: entry timeframe of the long frame and context of the short frame.
bool InList(string csv, int value)
{
   string parts[];
   int n = StringSplit(csv, ',', parts);
   for(int i = 0; i < n; i++)
      if((int)StringToInteger(parts[i]) == value)
         return true;
   return false;
}

bool IsLongCtx(int tf)  { return InList(InpLongCtxTfs, tf); }
bool IsShortCtx(int tf) { return InList(InpShortCtxTfs, tf); }

// Timeframes whose LP events are announced: both context sets plus the long entry timeframe.
bool IsEventTf(int tf)  { return (IsLongCtx(tf) || IsShortCtx(tf) || tf == InpLongEntryTf) && IsReliable(tf); }

// Section of the batched message: 0 long (W1/D1), 1 shared (H4), 2 short (H1 / M15).
int Section(int tf)
{
   if(IsLongCtx(tf))
      return 0;
   if(tf == InpLongEntryTf)
      return IsShortCtx(tf) ? 1 : 0;
   return 2;
}

// Lower timeframe that tells whether a retest of this LP is losing strength
// (Zerd: "nhìn M15 đoán được H4, nhìn M5 đoán được H1").
int TriggerTf(int tf)
{
   return IsLongCtx(tf) ? InpLongEntryTf : InpShortEntryTf;
}

int CooldownMin(int tf)
{
   return tf >= InpLongEntryTf ? InpCooldownLongMin : InpCooldownShortMin;
}

string LongTitle()
{
   return "KHUNG DÀI (W1-D1 → vào lệnh " + TfName(InpLongEntryTf) + ")";
}

string ShortTitle()
{
   return "KHUNG NGẮN (H4-H1 → vào lệnh " + TfName(InpShortEntryTf) + ")";
}

datetime HanoiNow()
{
   return TimeGMT() + InpReportTzOffset * 3600;
}

bool IsQuiet()
{
   if(InpQuietFrom == InpQuietTo)
      return false;
   int h = TimeHour(HanoiNow());
   if(InpQuietFrom < InpQuietTo)
      return h >= InpQuietFrom && h < InpQuietTo;
   return h >= InpQuietFrom || h < InpQuietTo;
}

//+------------------------------------------------------------------+
//| Message pacing                                                   |
//+------------------------------------------------------------------+
string   g_events[3];          // batched non-urgent events per section
datetime g_lastEventSent = 0;
string   g_cdKeys[];
datetime g_cdTimes[];
string   g_lastLongSig = "";   // FrameSig() at the last long-frame summary / morning report
string   g_lastShortSig = "";

// Non-urgent event: collected per section and sent as one message, at most one every InpMinGapMin.
// Dropped during quiet hours (the next morning report recaps the last 24 hours).
void AddEvent(int tf, string msg)
{
   if(g_silent || IsQuiet())
      return;
   g_events[Section(tf)] += "\n- " + msg;
}

// true (and the key is stamped) when this key was not announced within the last `minutes`.
bool CooledDown(string key, int minutes)
{
   datetime now = TimeLocal();
   for(int i = 0; i < ArraySize(g_cdKeys); i++)
   {
      if(g_cdKeys[i] != key)
         continue;
      if(now - g_cdTimes[i] < minutes * 60)
         return false;
      g_cdTimes[i] = now;
      return true;
   }
   int k = ArraySize(g_cdKeys);
   ArrayResize(g_cdKeys, k + 1);
   ArrayResize(g_cdTimes, k + 1);
   g_cdKeys[k] = key;
   g_cdTimes[k] = now;
   return true;
}

void FlushEvents(bool force)
{
   if(g_events[0] == "" && g_events[1] == "" && g_events[2] == "")
      return;
   if(!force && TimeLocal() - g_lastEventSent < InpMinGapMin * 60)
      return;   // keep collecting; sent on a later tick / timer
   string titles[3];
   titles[0] = LongTitle();
   titles[1] = "H4 (vào lệnh khung dài + khung cao của khung ngắn)";
   titles[2] = ShortTitle();
   string msg = StringFormat("%s | CẬP NHẬT %s - giá %s", Symbol(), TimeToString(HanoiNow(), TIME_MINUTES), Px(Bid));
   for(int s = 0; s < 3; s++)
   {
      if(g_events[s] != "")
         msg += "\n\n[" + titles[s] + "]" + g_events[s];
      g_events[s] = "";
   }
   Deliver(msg);
   g_lastEventSent = TimeLocal();
}

//+------------------------------------------------------------------+
//| Event alerts                                                     |
//+------------------------------------------------------------------+
// Compare new zone states against the previous scan and alert on transitions.
void AlertTransitions()
{
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      int p = FindPrev(ZoneKey(z));
      bool eventTf = IsEventTf(z.tf);
      string key = ZoneKey(z);

      // A zone never seen before: alert only if it really was born on the last closed bars
      // (zones reappearing at the lookback edge or after a history load are ignored).
      if(g_initialized && p < 0)
      {
         if(InpAlertNewLp && eventTf && z.state == ST_FRESH && z.tLast >= iTime(Symbol(), z.tf, 2))
            AddEvent(z.tf, StringFormat("%s vừa xuất hiện LP mới %s (%s-%s, %d nến Build). Chưa biết G hay R: chờ nến ZOS đóng ra ngoài.",
                                        TfName(z.tf), ZoneDate(z), Px(z.lo), Px(z.hi), z.builds));
         continue;
      }
      if(!g_initialized)
         continue;
      int prev = g_prevStates[p];

      if(InpAlertNewLp && eventTf && z.state == ST_FRESH && prev == ST_FRESH &&
         (z.hi > g_prevHi[p] + Point || z.lo < g_prevLo[p] - Point) && CooledDown(key + "|ext", CooldownMin(z.tf)))
         AddEvent(z.tf, StringFormat("%s MỞ RỘNG thành %s-%s (%d nến Build): MM vẫn đang xây vị trí, chưa có hướng.",
                                     ZoneText(z), Px(z.lo), Px(z.hi), z.builds));

      if(z.isMain && !g_prevMain[p] && IsAlive(z))
         AddEvent(z.tf, ZoneText(z) + " trở thành MAIN - vị trí phòng thủ chính của phe " + (z.dir > 0 ? "mua" : "bán") +
                        ". Xu thế " + TfName(z.tf) + " đang do phe này dẫn dắt.");

      if(prev == z.state)
         continue;

      if(z.state == ST_BROKEN && prev == ST_FRESH && InpAlertBreak && eventTf)
         AddEvent(z.tf, StringFormat("%s LP %s vừa break %s → thành %s. Chờ retest vùng %s-%s, KHÔNG đuổi giá.",
                                     TfName(z.tf), ZoneDate(z), z.dir > 0 ? "LÊN" : "XUỐNG", ZoneKind(z),
                                     Px(z.lo), Px(z.hi)));

      if(z.state == ST_RETEST && eventTf && CooledDown(key + "|retest", CooldownMin(z.tf)))
         AddEvent(z.tf, ZoneText(z) + " đang RETEST (nến đóng trong vùng" +
                        (z.retests > 1 ? ", lần " + IntegerToString(z.retests) : "") + "). Theo dõi " +
                        TfName(TriggerTf(z.tf)) + " tìm kích.");

      if(z.state == ST_RUN && prev == ST_RETEST && eventTf && CooledDown(key + "|run", CooldownMin(z.tf)))
         AddEvent(z.tf, StringFormat("%s đã RUN: retest xong, giá chạy %s khỏi vùng. Chưa vào thì BỎ, không đuổi; đang có lệnh thì dời BE.",
                                     ZoneText(z), z.dir > 0 ? "lên" : "xuống"));

      bool died = (prev != ST_FAILED && prev != ST_CLEARED && !IsAlive(z));
      if(died && InpAlertDeath && eventTf && z.dir != 0)
      {
         string winner = z.dir < 0 ? "mua" : "bán";
         string msg = StringFormat("%s bị %s → phe %s thắng ở %s, xu thế LP %s: %s. Tiếp theo nhắm %s.",
                                   ZoneText(z), z.state == ST_CLEARED ? "CLEAR" : "phá thủng", winner,
                                   TfName(z.tf), TfName(z.tf), TrendText(z.tf),
                                   EdgeText(z.dir < 0 ? z.hi : z.lo, z.dir < 0, z.tf));
         if(z.tBreak > 0 && z.tDead - z.tBreak <= InpShsMaxBars * PeriodSeconds(z.tf))
            msg += " DẤU HIỆU SHs: LP vừa tạo đã bị xoá ngay (bẫy quét SL). Đừng vào theo breakout, chờ tích luỹ rồi mới tính.";
         AddEvent(z.tf, msg);
      }

      if(z.state == ST_BROKEN && prev == ST_FRESH)
      {
         // Setup: an entry-timeframe LP just broke in the same direction inside a context LP under retest.
         bool shortEntry = (z.tf == InpShortEntryTf), longEntry = (z.tf == InpLongEntryTf);
         for(int j = 0; j < ArraySize(g_zones) && (shortEntry || longEntry); j++)
         {
            Zone hz = g_zones[j];
            bool ctx = ((shortEntry && IsShortCtx(hz.tf) && hz.tf > z.tf) || (longEntry && IsLongCtx(hz.tf))) &&
                       IsReliable(hz.tf) && IsReliable(z.tf);
            if(!ctx || hz.state != ST_RETEST || hz.dir != z.dir)
               continue;
            if(z.hi < hz.lo || z.lo > hz.hi)
               continue;
            NotifySetup(z, hz, longEntry ? LongTitle() : ShortTitle());
            break;
         }
         if(InpBeHints && z.tf == InpBeTf)
            CheckBreakEven(z);
      }
   }

   int n = ArraySize(g_zones);
   ArrayResize(g_prevKeys, n);
   ArrayResize(g_prevStates, n);
   ArrayResize(g_prevMain, n);
   ArrayResize(g_prevHi, n);
   ArrayResize(g_prevLo, n);
   for(int i = 0; i < n; i++)
   {
      g_prevKeys[i] = ZoneKey(g_zones[i]);
      g_prevStates[i] = g_zones[i].state;
      g_prevMain[i] = g_zones[i].isMain;
      g_prevHi[i] = g_zones[i].hi;
      g_prevLo[i] = g_zones[i].lo;
   }
}

// Bar-close signals that need the lower timeframe: the retest losing strength, an opposite LP under attack.
void CheckMarketSignals()
{
   if(!g_initialized)
      return;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z) || z.dir == 0 || !(IsLongCtx(z.tf) || IsShortCtx(z.tf)) || !IsReliable(z.tf))
         continue;
      int trig = TriggerTf(z.tf);

      // Retest weakening: during the pullback into the LP the lower timeframe "thu nến" (bodies shrink),
      // prints two-wick candles and turns back to the LP's color (Zerd: "đợi nến khung dưới giảm lực, sideway thì vào").
      // It is the moment to prepare an entry, so it is sent immediately (once per retest).
      if(InpAlertWeakRetest && z.state == ST_RETEST && z.tf > trig &&
         Bid >= z.lo - g_pip && Bid <= z.hi + g_pip)
      {
         double recent = AvgBody(trig, 1, 3), before = AvgBody(trig, 4, 5);
         bool shrinking = (before > 0 && recent < 0.5 * before);
         int twoWick = TwoWickCount(trig, 1, 3);
         int c1 = ReadColor(trig, 1);
         bool against = false;
         for(int s = 2; s <= 4; s++)
         {
            int cs = ReadColor(trig, s);
            if((z.dir > 0 && cs < 0) || (z.dir < 0 && cs > 0 && cs != 9))
               against = true;
         }
         bool flipped = against && ((z.dir > 0 && (c1 == 1 || c1 == 2)) || (z.dir < 0 && (c1 == -1 || c1 == -2)));
         int score = (shrinking ? 1 : 0) + (twoWick >= 2 ? 1 : 0) + (flipped ? 1 : 0);
         string key = ZoneKey(z) + "|weak|" + IntegerToString(z.retests);
         if(score >= 2 && !Contains(g_signalAlerted, key))
         {
            Remember(g_signalAlerted, key);
            string why = "";
            if(shrinking) why += " thân nến ZOS thu nhỏ;";
            if(twoWick >= 2) why += StringFormat(" %d/3 nến 2 đầu (tích luỹ);", twoWick);
            if(flipped) why += " màu chuyển sang " + ColorName(c1) + ";";
            double pos = (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100;
            if(!IsQuiet() || IsLongCtx(z.tf))
               Notify(StringFormat("[%s] LỰC RETEST YẾU DẦN tại %s:%s giá đang ở %.0f%% vùng.\nGợi ý %s: chờ %s tạo %s trong vùng (kích) hoặc limit ở nửa %s, SL %s %s.",
                                   IsLongCtx(z.tf) ? LongTitle() : ShortTitle(), ZoneText(z), why, pos,
                                   z.dir > 0 ? "BUY" : "SELL", TfName(trig), z.dir > 0 ? "G" : "R",
                                   z.dir > 0 ? "dưới" : "trên", z.dir > 0 ? "dưới" : "trên",
                                   Px(z.dir > 0 ? z.lo - InpSlBufferPips * g_pip : z.hi + InpSlBufferPips * g_pip)));
         }
      }

      // Opposite LP under attack: a candle of its timeframe closed past its 50% line from the wrong side.
      if(InpAlertAttack && (z.state == ST_BROKEN || z.state == ST_RETEST || z.state == ST_RUN))
      {
         double h, l, o, c;
         bool build;
         if(!ReadZos(z.tf, 1, h, l, o, c, build))
            continue;
         double mid = (z.hi + z.lo) / 2;
         bool attacked = (z.dir < 0) ? (c > mid && c <= z.hi) : (c < mid && c >= z.lo);
         string key = ZoneKey(z) + "|atk";
         if(attacked && !Contains(g_signalAlerted, key))
         {
            Remember(g_signalAlerted, key);
            AddEvent(z.tf, StringFormat("%s ĐANG BỊ TẤN CÔNG: nến ZOS %s đóng %s 50%% vùng. Nếu clear → phe %s có thể tạo MAIN, xu thế %s đảo chiều. Giữ được → %s nối đà.",
                                        ZoneText(z), TfName(z.tf), z.dir < 0 ? "trên" : "dưới",
                                        z.dir < 0 ? "mua" : "bán", TfName(z.tf), ZoneKind(z)));
         }
      }
   }
}

// Tick-level: price enters a broken LP, or gets close to a higher-timeframe LP.
void CheckTickRetest()
{
   if(!g_initialized)
      return;
   string today = TimeToString(TimeCurrent(), TIME_DATE);
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z))
         continue;
      string key = ZoneKey(z);

      if(z.state == ST_BROKEN && IsEventTf(z.tf))
      {
         bool inside = (z.dir > 0) ? (Bid <= z.hi && Bid >= z.lo) : (Ask >= z.lo && Ask <= z.hi);
         if(inside && !Contains(g_tickAlerted, key))
         {
            Remember(g_tickAlerted, key);
            AddEvent(z.tf, "Giá bắt đầu vào " + ZoneText(z) + " (retest). Chuẩn bị theo dõi " + TfName(TriggerTf(z.tf)) + ".");
         }
      }

      if(InpNearPips > 0 && z.tf >= InpNearMinTf && z.state != ST_RETEST)
      {
         double d = DistancePips(z, Bid);
         string nkey = key + "|near|" + today;
         if(d > 0 && d <= InpNearPips && !Contains(g_signalAlerted, nkey))
         {
            Remember(g_signalAlerted, nkey);
            AddEvent(z.tf, StringFormat("Giá còn %.1f pip tới %s mép %s. Vùng khung lớn: chú ý phản ứng.",
                                        d, Bid > z.hi ? "High" : "Low", ZoneText(z)));
         }
      }
   }
   FlushEvents(false);
}

//+------------------------------------------------------------------+
//| Reports and frame summaries (Zerd-style top-down reading)        |
//+------------------------------------------------------------------+
string WeekdayVi(int dow)
{
   string names[7] = {"Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"};
   return names[dow];
}

string ColorShort(int code)
{
   switch(code)
   {
      case 1:  return "XANH LÁ";
      case 2:  return "XANH DƯƠNG";
      case -1: return "ĐỎ";
      case -2: return "HỒNG-TÍM";
      case 9:  return "VÀNG";
   }
   return "-";
}

string EstimateNote(int tf)
{
   if(IsReliable(tf))
      return "";
   return " [ƯỚC TÍNH - có thể sai: mở chart " + TfName(tf) + " có ZOS + ZO_LP để chính xác]";
}

// Full multi-line reading of one timeframe (morning report).
string TfLine(int tf)
{
   int f = TfIndex(tf);
   if(f < 0)
      return "";
   int code;
   int run = ColorRun(tf, code);
   if(code == 0)
      return StringFormat("\n[%s] Không đọc được ZOS khung này (thiếu lịch sử?) → bỏ qua. Mở chart %s một lần để MT4 tải dữ liệu.",
                          TfName(tf), TfName(tf));
   string s = StringFormat("\n[%s] ZOS %s, nến thứ %d.", TfName(tf), ColorName(code), run) + EstimateNote(tf);
   int tw = TwoWickCount(tf, 1, 5);
   if(tw >= 3)
      s += StringFormat(" Đang thu nến / tích luỹ (%d/5 nến 2 đầu) → sắp có run.", tw);

   s += "\n  Xu thế LP: " + TrendText(tf);
   if(g_tfTrendTime[f] > 0)
      s += " từ " + IntegerToString(TimeDay(g_tfTrendTime[f])) + "/" + IntegerToString(TimeMonth(g_tfTrendTime[f]));
   int mg = MainOf(tf, 1), mr = MainOf(tf, -1);
   if(mg >= 0) s += ". Main mua: " + ZoneText(g_zones[mg]);
   if(mr >= 0) s += ". Main bán: " + ZoneText(g_zones[mr]);

   int at = ZoneAtPrice(tf);
   if(at >= 0)
   {
      Zone z = g_zones[at];
      double pos = (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100;
      if(z.dir == 0)
         s += StringFormat("\n  Giá đang NỘI CHIẾN trong %s (%.0f%% vùng, chưa break).", ZoneText(z), pos);
      else
         s += StringFormat("\n  Giá đang ở trong %s [%s] (%.0f%% vùng).", ZoneText(z), StateName(z.state), pos);
   }
   int up = Neighbour(tf, true), dn = Neighbour(tf, false);
   if(up >= 0 || dn >= 0)
   {
      s += "\n  Kẹp giữa: ";
      s += (dn >= 0) ? StringFormat("%s dưới %.0f pip", ZoneText(g_zones[dn]), DistancePips(g_zones[dn], Bid)) : "dưới trống";
      s += " | ";
      s += (up >= 0) ? StringFormat("%s trên %.0f pip", ZoneText(g_zones[up]), DistancePips(g_zones[up], Bid)) : "trên trống";
      if(up >= 0 && dn >= 0)
      {
         double room = (g_zones[up].lo - g_zones[dn].hi) / g_pip;
         s += StringFormat(" → không gian %.0f pip%s", room, room < 15 ? " (chật, dễ bị quét)" : "");
      }
   }
   return s;
}

// One-line reading of a timeframe (periodic summaries).
string CompactLine(int tf)
{
   if(TfIndex(tf) < 0)
      return "";
   int code;
   int run = ColorRun(tf, code);
   if(code == 0)
      return "\n" + TfName(tf) + ": không đọc được ZOS";
   string s = StringFormat("\n%s: ZOS %s (nến %d), xu thế %s", TfName(tf), ColorShort(code), run, TrendText(tf)) + EstimateNote(tf);
   if(TwoWickCount(tf, 1, 5) >= 3)
      s += ", đang tích luỹ";
   int at = ZoneAtPrice(tf);
   if(at >= 0)
   {
      Zone z = g_zones[at];
      s += StringFormat(" | giá trong %s %s [%s %.0f%%]", ZoneKind(z), ZoneDate(z), StateName(z.state),
                        (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100);
   }
   int up = Neighbour(tf, true), dn = Neighbour(tf, false);
   s += " | trên: " + (up >= 0 ? StringFormat("%s %s +%.0fp", ZoneKind(g_zones[up]), ZoneDate(g_zones[up]), DistancePips(g_zones[up], Bid)) : "trống");
   s += ", dưới: " + (dn >= 0 ? StringFormat("%s %s -%.0fp", ZoneKind(g_zones[dn]), ZoneDate(g_zones[dn]), DistancePips(g_zones[dn], Bid)) : "trống");
   return s;
}

// The LP that matters most for a timeframe right now: the one price is in, else the nearest shown one.
int KeyZone(int tf)
{
   if(TfIndex(tf) < 0)
      return -1;
   int at = ZoneAtPrice(tf);
   if(at >= 0)
      return at;
   int sel[];
   return SelectZones(tf, sel) > 0 ? sel[0] : -1;
}

string KeyLine(string label, int tf)
{
   int k = KeyZone(tf);
   if(k < 0)
      return "";
   return "\n- " + label + " " + ZoneText(g_zones[k]) + ": " + KeyScenario(g_zones[k]);
}

// Recent events on event timeframes during the last 24 hours.
string RecentEvents()
{
   string s = "";
   datetime since = TimeCurrent() - 24 * 3600;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsEventTf(z.tf) || z.dir == 0)
         continue;
      if(z.tDead >= since)
      {
         s += StringFormat("\n- %s bị %s", ZoneText(z), z.state == ST_CLEARED ? "clear" : "phá thủng");
         if(z.tBreak > 0 && z.tDead - z.tBreak <= InpShsMaxBars * PeriodSeconds(z.tf))
            s += " ngay sau khi tạo (dấu hiệu SHs)";
      }
      else if(z.tBreak >= since && IsAlive(z))
         s += StringFormat("\n- %s mới xác nhận (break %s)", ZoneText(z), z.dir > 0 ? "lên" : "xuống");
   }
   return s == "" ? "\n- Không có biến động LP đáng kể." : s;
}

int TrendOf(int tf)
{
   int i = TfIndex(tf);
   return i >= 0 ? g_tfTrend[i] : 0;
}

// Two context timeframes → bias of a frame.
string BiasText(int tfA, int tfB, int entryTf)
{
   int a = TrendOf(tfA), b = TrendOf(tfB);
   if(a != 0 && a == b)
      return StringFormat("%s và %s cùng %s → chỉ %s ở %s các %s khi có retest + %s kích. Không %s ngược.",
                          TfName(tfA), TfName(tfB), a > 0 ? "TĂNG" : "GIẢM", a > 0 ? "BUY" : "SELL",
                          a > 0 ? "Low" : "High", a > 0 ? "GLP" : "RLP", TfName(entryTf), a > 0 ? "SELL" : "BUY");
   if(a != 0 && b != 0)
      return StringFormat("%s %s nhưng %s %s → giằng co. Đứng ngoài hoặc scalp ngắn ở mép vùng, chờ key xác nhận (clear hay hold).",
                          TfName(tfA), TrendText(tfA), TfName(tfB), TrendText(tfB));
   if(a != 0 || b != 0)
   {
      int t = (a != 0) ? a : b;
      return StringFormat("Thiên hướng %s (mới 1 khung xác nhận) → thận trọng, chỉ vào khi có SETUP rõ.", t > 0 ? "TĂNG" : "GIẢM");
   }
   return "Xu thế chưa rõ → đợi. Chart chưa có key rõ ràng thì không trade.";
}

// Is price in, or within `pips` of, a live broken LP of the given context timeframes?
bool FrameActive(bool longFrame)
{
   double pips = longFrame ? InpLongActivePips : InpShortActivePips;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z) || z.dir == 0)
         continue;
      bool ctx = longFrame ? IsLongCtx(z.tf) : IsShortCtx(z.tf);
      bool entryRetest = (z.state == ST_RETEST && z.tf == (longFrame ? InpLongEntryTf : InpShortEntryTf));
      if((ctx && DistancePips(z, Bid) <= pips) || entryRetest)
         return true;
   }
   return false;
}

// What to do right now in a frame: in a context retest, close to one, or nothing.
string ActionLine(bool longFrame)
{
   int entry = longFrame ? InpLongEntryTf : InpShortEntryTf;
   double pips = longFrame ? InpLongActivePips : InpShortActivePips;
   int nearest = -1;
   double best = 0;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      bool ctx = longFrame ? IsLongCtx(z.tf) : IsShortCtx(z.tf);
      if(!ctx || !IsAlive(z) || z.dir == 0)
         continue;
      if(z.state == ST_RETEST && Bid >= z.lo - g_pip && Bid <= z.hi + g_pip)
         return StringFormat("ĐANG CÓ CƠ HỘI: giá retest %s → canh %s tạo %s trong vùng (kích).",
                             ZoneText(z), TfName(entry), z.dir > 0 ? "G" : "R");
      double d = DistancePips(z, Bid);
      if(nearest < 0 || d < best) { nearest = i; best = d; }
   }
   if(nearest >= 0 && best <= pips)
      return StringFormat("CHUẨN BỊ: giá cách %s %.0f pip.", ZoneText(g_zones[nearest]), best);
   return "CHỜ: chưa có vùng khung cao để vào lệnh.";
}

string LongSection(bool full)
{
   string s = "\n\n=== " + LongTitle() + " ===";
   s += full ? TfLine(10080) + TfLine(1440) + TfLine(InpLongEntryTf)
             : CompactLine(10080) + CompactLine(1440) + CompactLine(InpLongEntryTf);
   s += KeyLine("Key D1", 1440) + KeyLine("Key tuần (" + TfName(InpLongEntryTf) + ")", InpLongEntryTf);
   int w = TrendOf(10080) != 0 ? 10080 : 1440;
   s += "\n→ " + BiasText(w, w == 10080 ? 1440 : InpLongEntryTf, InpLongEntryTf);
   s += "\n→ " + ActionLine(true);
   return s;
}

string ShortSection(bool full)
{
   string s = "\n\n=== " + ShortTitle() + " ===";
   if(full)
      s += "\n(" + TfName(InpLongEntryTf) + " xem ở trên)" + TfLine(60) + TfLine(InpShortEntryTf);
   else
      s += CompactLine(240) + CompactLine(60) + CompactLine(InpShortEntryTf);
   s += KeyLine("Key H1", 60) + KeyLine("Key ngày (" + TfName(InpShortEntryTf) + ")", InpShortEntryTf);
   s += "\n→ " + BiasText(240, 60, InpShortEntryTf);
   s += "\n→ " + ActionLine(false);
   return s;
}

string BuildReport(datetime hanoi)
{
   string r = StringFormat("%s | PHÂN TÍCH ĐẦU NGÀY - %s %02d/%02d\nGiá hiện tại: %s",
                           Symbol(), WeekdayVi(TimeDayOfWeek(hanoi)), TimeDay(hanoi), TimeMonth(hanoi), Px(Bid));
   r += LongSection(true);
   r += ShortSection(true);
   r += "\n\n24H QUA" + RecentEvents();
   r += "\n\nNhớ: không có SETUP thì không vào. Kiểm tra lịch tin đỏ trong ngày trước khi đặt lệnh.";
   return r;
}

// Frame fingerprint: states of the LPs near price, to tell whether a summary would say anything new.
string FrameSig(bool longFrame)
{
   string s = "";
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      bool member = longFrame ? (IsLongCtx(z.tf) || z.tf == InpLongEntryTf)
                              : (IsShortCtx(z.tf) || z.tf == InpShortEntryTf);
      if(member && IsAlive(z) && DistancePips(z, Bid) <= 150)
         s += ZoneKey(z) + ":" + IntegerToString(z.state) + ":" + IntegerToString(z.retests) + ",";
   }
   return s;
}

// Atomically claims a slot in a terminal-wide global variable (one sender across charts and restarts).
bool ClaimSlot(string gv, double slot)
{
   if(!GlobalVariableCheck(gv))
      GlobalVariableSet(gv, 0);
   double last = GlobalVariableGet(gv);
   return last < slot && GlobalVariableSetOnCondition(gv, slot, last);
}

// Sends the morning report once per Hanoi day (Mon-Fri).
void CheckMorningReport(bool force)
{
   // Only the messaging chart may claim the daily slot, otherwise another chart would "use" it silently.
   if(!g_initialized || !IsMaster() || (!InpMorningReport && !force))
      return;
   datetime hanoi = HanoiNow();
   int dow = TimeDayOfWeek(hanoi);
   int minutes = TimeHour(hanoi) * 60 + TimeMinute(hanoi);
   int start = InpReportHour * 60 + InpReportMinute;
   if(!force && (dow < 1 || dow > 5 || minutes < start || minutes > start + InpReportLateHours * 60))
      return;
   double today = TimeYear(hanoi) * 10000 + TimeMonth(hanoi) * 100 + TimeDay(hanoi);
   if(!force && !ClaimSlot("ZOLP_REPORT_" + Symbol(), today))
      return;
   string report = BuildReport(hanoi);
   Print(report);
   Deliver(report, false);
   g_lastLongSig = FrameSig(true);
   g_lastShortSig = FrameSig(false);
   GlobalVariableSet("ZOLP_SHORTSENT_" + Symbol(), (double)TimeLocal());
}

// Periodic frame summaries.
//  - Long frame: at InpLongDigestHours (Hanoi, minute 15), only when its LPs changed since the last
//    summary or price is near a W1/D1 LP (the morning report already covers the quiet case).
//  - Short frame: at every H1 close; hourly while price is in / near an H4-H1 LP, else every
//    InpShortIdleHours. Nothing during quiet hours or weekends.
void CheckDigests()
{
   if(!g_initialized || !IsMaster() || !InpDigests || IsQuiet())
      return;
   datetime hanoi = HanoiNow();
   int dow = TimeDayOfWeek(hanoi);
   if(dow < 1 || dow > 5)
      return;

   int hour = TimeHour(hanoi);
   if(InList(InpLongDigestHours, hour) && TimeMinute(hanoi) >= 15)
   {
      double slot = (TimeYear(hanoi) * 10000 + TimeMonth(hanoi) * 100 + TimeDay(hanoi)) * 100.0 + hour;
      string sig = FrameSig(true);
      bool worth = (sig != g_lastLongSig) || FrameActive(true);
      if(ClaimSlot("ZOLP_LONGSLOT_" + Symbol(), slot) && worth)
      {
         Deliver(StringFormat("%s | TÓM TẮT %s - %s, giá %s", Symbol(), LongTitle(),
                              TimeToString(hanoi, TIME_MINUTES), Px(Bid)) + LongSection(false), false);
         g_lastLongSig = sig;
      }
   }

   datetime h1 = iTime(Symbol(), PERIOD_H1, 0);
   if(h1 > 0 && TimeCurrent() - h1 >= 60)
   {
      string gvSent = "ZOLP_SHORTSENT_" + Symbol();
      datetime lastSent = GlobalVariableCheck(gvSent) ? (datetime)GlobalVariableGet(gvSent) : 0;
      bool active = FrameActive(false);
      bool idleDue = TimeLocal() - lastSent >= InpShortIdleHours * 3600 - 300;
      if((active || idleDue) && ClaimSlot("ZOLP_SHORTBAR_" + Symbol(), (double)h1))
      {
         Deliver(StringFormat("%s | TÓM TẮT %s - %s, giá %s%s", Symbol(), ShortTitle(),
                              TimeToString(hanoi, TIME_MINUTES), Px(Bid), active ? "" : " (thị trường yên)") +
                 ShortSection(false), false);
         g_lastShortSig = FrameSig(false);
         GlobalVariableSet(gvSent, (double)TimeLocal());
      }
   }
}

//+------------------------------------------------------------------+
//| Position assistance (reads orders, never modifies them)          |
//+------------------------------------------------------------------+
// A new LP formed in favour of an open position: suggest moving SL/BE just beyond its edge.
void CheckBreakEven(const Zone &z)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol())
         continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL)
         continue;
      int dir = (type == OP_BUY) ? 1 : -1;
      if(dir != z.dir)
         continue;
      double newSl = (dir > 0) ? z.lo - InpBeBufferPips * g_pip : z.hi + InpBeBufferPips * g_pip;
      bool beyondEntry = (dir > 0) ? newSl > OrderOpenPrice() : newSl < OrderOpenPrice();
      bool improves = (OrderStopLoss() == 0) || ((dir > 0) ? newSl > OrderStopLoss() + g_pip / 2
                                                           : newSl < OrderStopLoss() - g_pip / 2);
      string key = IntegerToString(OrderTicket()) + "|" + ZoneKey(z);
      if(!improves || Contains(g_beAlerted, key))
         continue;
      Remember(g_beAlerted, key);
      Notify(StringFormat("Lệnh #%d %s: vừa có %s. Dời SL%s về %s (cách mép LP %.1f pip).",
                          OrderTicket(), dir > 0 ? "BUY" : "SELL", ZoneText(z),
                          beyondEntry ? "/BE" : "", Px(newSl), InpBeBufferPips));
   }
}

// Checks a freshly opened position against the ZO entry rules (Zerd's list of common mistakes).
void AuditEntry(int ticket, int dir, double ep, double sl)
{
   string issues = "";
   bool inLpContext = false;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(!IsAlive(z) || z.tf < Period() || ep < z.lo || ep > z.hi)
         continue;
      double mid = (z.hi + z.lo) / 2;
      if(z.state == ST_FRESH)
         issues += "\n- Vào lệnh bên trong " + ZoneText(z) + " chưa break (chưa rõ G hay R).";
      else if(z.dir == dir)
      {
         inLpContext = true;
         if(dir > 0 && ep > mid)
            issues += "\n- BUY ở nửa trên " + ZoneText(z) + ": nên mua gần Low.";
         if(dir < 0 && ep < mid)
            issues += "\n- SELL ở nửa dưới " + ZoneText(z) + ": nên bán gần High.";
         bool slInside = (sl == 0) || (dir > 0 ? sl > z.lo : sl < z.hi);
         if(slInside)
            issues += "\n- SL " + (sl == 0 ? "chưa đặt" : "nằm trong LP") + ": SL phải ngoài mép " +
                      (dir > 0 ? "Low " : "High ") + ZoneText(z) + ".";
      }
      else
         issues += "\n- Vào ngược chiều " + ZoneText(z) + ".";
   }
   if(!inLpContext)
      issues += "\n- Giá vào không nằm trong GLP/RLP cùng chiều nào: có phải đang đuổi giá (FOMO)?";
   int ti = TfIndex(InpTrendTf);
   if(ti >= 0 && g_tfTrend[ti] != 0 && g_tfTrend[ti] != dir)
      issues += StringFormat("\n- Ngược xu thế LP %s.", TfName(InpTrendTf));

   if(issues == "")
      Notify(StringFormat("Lệnh #%d %s %s: đúng luật ZO. Nhớ dời BE khi có LP mới.", ticket,
                          dir > 0 ? "BUY" : "SELL", Px(ep)));
   else
      Notify(StringFormat("KIỂM TRA LỆNH #%d %s %s:%s", ticket, dir > 0 ? "BUY" : "SELL", Px(ep), issues));
}

void CheckNewPositions()
{
   if(!InpEntryAudit || !g_initialized)
      return;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES) || OrderSymbol() != Symbol())
         continue;
      int type = OrderType();
      if(type != OP_BUY && type != OP_SELL)
         continue;
      int ticket = OrderTicket();
      bool known = false;
      for(int k = 0; k < ArraySize(g_knownTickets); k++)
         if(g_knownTickets[k] == ticket) { known = true; break; }
      if(known)
         continue;
      int n = ArraySize(g_knownTickets);
      ArrayResize(g_knownTickets, n + 1);
      g_knownTickets[n] = ticket;
      // Positions already open when the indicator loaded are not audited.
      if(g_ticketsLoaded)
         AuditEntry(ticket, type == OP_BUY ? 1 : -1, OrderOpenPrice(), OrderStopLoss());
   }
   g_ticketsLoaded = true;
}

//+------------------------------------------------------------------+
//| Drawing                                                          |
//+------------------------------------------------------------------+
color ZoneColor(const Zone &z)
{
   if(z.state == ST_FRESH) return InpClrFresh;
   if(z.state == ST_RUN)   return InpClrRun;
   if(z.dir > 0) return z.state == ST_RETEST ? InpClrGlpRetest : InpClrGlp;
   return z.state == ST_RETEST ? InpClrRlpRetest : InpClrRlp;
}

color LineColor(const Zone &z)
{
   if(z.dir > 0) return InpClrLineGlp;
   if(z.dir < 0) return InpClrLineRlp;
   return InpClrLineFresh;
}

void DrawText(string name, datetime t, double price, string text, color clr, int anchor)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 7);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

void DrawLine(string name, datetime t0, datetime t1, double price, color clr, int style, int width)
{
   ObjectCreate(0, name, OBJ_TREND, 0, t0, price, t1, price);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

// Chart-timeframe LP: filled rectangle (outline only when NEW or RUN).
void DrawZoneBox(const Zone &z, datetime tEnd, string label)
{
   string name = PREFIX + ZoneKey(z);
   bool filled = (z.state == ST_BROKEN || z.state == ST_RETEST);
   ObjectCreate(0, name, OBJ_RECTANGLE, 0, z.t0, z.hi, tEnd, z.lo);
   ObjectSetInteger(0, name, OBJPROP_COLOR, ZoneColor(z));
   ObjectSetInteger(0, name, OBJPROP_BACK, filled);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, z.isMain ? 2 : 1);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   DrawText(name + "_t", tEnd, z.hi, label, clrSilver, ANCHOR_RIGHT_LOWER);
}

// Higher-timeframe LP: "H-<kind>-<tf> <date>" and "L-<kind>-<tf> <date>" lines.
void DrawZoneLines(const Zone &z, datetime tEnd, string state)
{
   string base = PREFIX + ZoneKey(z);
   string tag = ZoneKind(z) + "-" + TfName(z.tf) + " " + ZoneDate(z);
   color clr = LineColor(z);
   int style = (z.state == ST_BROKEN || z.state == ST_RETEST) ? STYLE_SOLID :
               (z.state == ST_FRESH ? STYLE_DOT : STYLE_DASH);
   int width = (z.isMain || z.tf >= 1440) ? 2 : 1;
   if(style != STYLE_SOLID)
      width = 1;   // MT4 only draws dotted/dashed lines at width 1

   DrawLine(base + "_H", z.t0, tEnd, z.hi, clr, style, width);
   DrawLine(base + "_L", z.t0, tEnd, z.lo, clr, style, width);
   DrawText(base + "_Ht", tEnd, z.hi, "H-" + tag + " " + state, clr, ANCHOR_RIGHT_LOWER);
   DrawText(base + "_Lt", tEnd, z.lo, "L-" + tag, clr, ANCHOR_RIGHT_UPPER);
}

void Draw()
{
   if(!InpDraw)
   {
      // ZO_View draws this chart; only clean up once what an earlier version may have left.
      static bool cleaned = false;
      if(!cleaned)
      {
         ObjectsDeleteAll(0, PREFIX);
         cleaned = true;
      }
      return;
   }
   ObjectsDeleteAll(0, PREFIX);
   datetime tEnd = Time[0] + PeriodSeconds() * 12;
   string panel = "ZO_LP  (" + Symbol() + ")\n";

   for(int f = 0; f < ArraySize(g_tfs); f++)
   {
      int tf = g_tfs[f];
      int color_ = ReadColor(tf, 1);
      string zosTxt = color_ == 1 ? "GREEN" : color_ == 2 ? "BLUE" : color_ == -1 ? "RED" :
                      color_ == -2 ? "PINK" : color_ == 9 ? "YELLOW" : "-";
      string trendTxt = g_tfTrend[f] > 0 ? "UP" : g_tfTrend[f] < 0 ? "DOWN" : "?";
      if(g_tfTrendTime[f] > 0)
         trendTxt += " since " + IntegerToString(TimeDay(g_tfTrendTime[f])) + "/" +
                     IntegerToString(TimeMonth(g_tfTrendTime[f]));
      panel += StringFormat("\n%s  ZOS: %s   LP trend: %s\n", TfName(tf), zosTxt, trendTxt);

      int sel[];
      int n = SelectZones(tf, sel);
      for(int i = 0; i < n; i++)
      {
         Zone z = g_zones[sel[i]];
         string state = StateName(z.state) + (z.retests > 1 ? " #" + IntegerToString(z.retests) : "");
         if(IsShield(z))
            state += " (shield)";
         if(tf == Period())
            DrawZoneBox(z, tEnd, ZoneKind(z) + "-" + TfName(tf) + " " + ZoneDate(z) + " " + state);
         else
            DrawZoneLines(z, tEnd, state);

         double d = DistancePips(z, Bid);
         panel += StringFormat("   %-5s %-6s %-18s %s-%s  %s\n", ZoneKind(z), ZoneDate(z), state,
                               Px(z.lo), Px(z.hi),
                               d == 0 ? "PRICE INSIDE" : DoubleToString(d, 1) + " pips");
      }
   }
   Comment(panel);
   ChartRedraw();
}

//+------------------------------------------------------------------+
// Diagnostics: every zone (alive or dead) and the ZOS coverage of each timeframe.
void DumpZones()
{
   int h = FileOpen("zo_lp_zones_" + Symbol() + ".csv", FILE_WRITE | FILE_CSV | FILE_ANSI, ',');
   if(h == INVALID_HANDLE)
      return;
   FileWrite(h, "# bid", Px(Bid), "time", TimeToString(TimeCurrent()));
   for(int f = 0; f < ArraySize(g_tfs); f++)
      FileWrite(h, "# tf", TfName(g_tfs[f]), "bars", iBars(Symbol(), g_tfs[f]), "valid_zos_bars", g_tfValid[f],
                "first_valid", TimeToString(g_tfFirstValid[f]), "trend", g_tfTrend[f],
                "source", g_tfs[f] == Period() ? "this chart" : g_tfShared[f] ? "shared" : "iCustom fallback");
   FileWrite(h, "tf", "t0", "t_last", "t_break", "t_dead", "lo", "hi", "kind", "state", "retests", "builds", "main");
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      FileWrite(h, TfName(z.tf), TimeToString(z.t0), TimeToString(z.tLast),
                z.tBreak > 0 ? TimeToString(z.tBreak) : "", z.tDead > 0 ? TimeToString(z.tDead) : "",
                Px(z.lo), Px(z.hi), ZoneKind(z), StateName(z.state), z.retests, z.builds, z.isMain ? 1 : 0);
   }
   FileClose(h);
}

//+------------------------------------------------------------------+
//| Sharing between charts                                           |
//+------------------------------------------------------------------+
string ShareFile(int tf)
{
   return SHARE_DIR + Symbol() + "_" + IntegerToString(tf) + ".csv";
}

string Dbl(double v)
{
   return DoubleToString(v, 8);
}

// Writes this chart's timeframe (trend, last candles, every LP) for the other charts.
void ExportShared(int f)
{
   int tf = g_tfs[f];
   string name = ShareFile(tf), tmp = name + ".tmp";
   int h = FileOpen(tmp, FILE_WRITE | FILE_CSV | FILE_COMMON | FILE_ANSI, ',');
   if(h == INVALID_HANDLE)
      return;
   FileWrite(h, "H", IntegerToString((long)iTime(Symbol(), tf, 1)), g_tfTrend[f], IntegerToString((long)g_tfTrendTime[f]),
             g_tfValid[f], IntegerToString((long)g_tfFirstValid[f]));
   for(int s = 1; s < CACHE_SIZE; s++)
   {
      double zh, zl, zo, zc;
      bool build;
      if(!ReadZos(tf, s, zh, zl, zo, zc, build))
         zh = zl = zo = zc = 0;
      FileWrite(h, "C", s, Dbl(zh), Dbl(zl), Dbl(zo), Dbl(zc), build ? 1 : 0, ReadColor(tf, s));
   }
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      Zone z = g_zones[i];
      if(z.tf != tf)
         continue;
      FileWrite(h, "Z", IntegerToString((long)z.t0), IntegerToString((long)z.tLast), IntegerToString((long)z.tBreak),
                IntegerToString((long)z.tDead), Dbl(z.lo), Dbl(z.hi), z.dir, z.state, z.retests, z.builds, z.isMain ? 1 : 0);
   }
   FileClose(h);
   FileMove(tmp, FILE_COMMON, name, FILE_COMMON | FILE_REWRITE);
}

long ReadLong(int h)  { return StringToInteger(FileReadString(h)); }
double ReadDbl(int h) { return StringToDouble(FileReadString(h)); }

// Loads a timeframe written by ZO_LP on its own chart. Rejected when missing or more than one bar old.
bool ImportShared(int f, Zone &out[], int &trend, datetime &trendTime, int &valid, datetime &firstValid)
{
   int tf = g_tfs[f];
   string name = ShareFile(tf);
   if(!FileIsExist(name, FILE_COMMON))
      return false;
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_COMMON | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
      return false;
   bool fresh = false;
   Zone zs[];
   ArrayResize(zs, 0);
   while(!FileIsEnding(h))
   {
      string type = FileReadString(h);
      if(type == "H")
      {
         datetime lastBar = (datetime)ReadLong(h);
         trend = (int)ReadLong(h);
         trendTime = (datetime)ReadLong(h);
         valid = (int)ReadLong(h);
         firstValid = (datetime)ReadLong(h);
         fresh = lastBar > 0 && lastBar >= iTime(Symbol(), tf, 2);
      }
      else if(type == "C")
      {
         int s = (int)ReadLong(h);
         double zh = ReadDbl(h), zl = ReadDbl(h), zo = ReadDbl(h), zc = ReadDbl(h), zb = ReadDbl(h);
         int col = (int)ReadLong(h);
         if(s >= 1 && s < CACHE_SIZE)
         {
            g_cH[f][s] = zh; g_cL[f][s] = zl; g_cO[f][s] = zo; g_cC[f][s] = zc; g_cB[f][s] = zb; g_cCol[f][s] = col;
         }
      }
      else if(type == "Z")
      {
         int k = ArraySize(zs);
         ArrayResize(zs, k + 1);
         zs[k].tf = tf;
         zs[k].t0 = (datetime)ReadLong(h);
         zs[k].tLast = (datetime)ReadLong(h);
         zs[k].tBreak = (datetime)ReadLong(h);
         zs[k].tDead = (datetime)ReadLong(h);
         zs[k].lo = ReadDbl(h);
         zs[k].hi = ReadDbl(h);
         zs[k].dir = (int)ReadLong(h);
         zs[k].state = (int)ReadLong(h);
         zs[k].retests = (int)ReadLong(h);
         zs[k].builds = (int)ReadLong(h);
         zs[k].isMain = ReadLong(h) != 0;
      }
      else
         while(!FileIsLineEnding(h) && !FileIsEnding(h))
            FileReadString(h);
   }
   FileClose(h);
   if(!fresh)
      return false;
   for(int i = 0; i < ArraySize(zs); i++)
   {
      int k = ArraySize(out);
      ArrayResize(out, k + 1);
      out[k] = zs[i];
   }
   return true;
}

//+------------------------------------------------------------------+
void Recalculate(bool force)
{
   bool changed = force;
   for(int f = 0; f < ArraySize(g_tfs); f++)
   {
      datetime t = iTime(Symbol(), g_tfs[f], 0);
      if(t != g_lastBarTime[f])
      {
         g_lastBarTime[f] = t;
         changed = true;
      }
      // Another chart re-exported its timeframe (e.g. its bar just closed).
      if(InpUseSharedCharts && g_tfs[f] != Period())
      {
         long mod = FileGetInteger(ShareFile(g_tfs[f]), FILE_MODIFY_DATE, true);
         if(mod != g_tfFileMod[f])
         {
            g_tfFileMod[f] = mod;
            changed = true;
         }
      }
   }
   if(!changed)
      return;

   Zone all[];
   ArrayResize(all, 0);
   for(int f = 0; f < ArraySize(g_tfs); f++)
   {
      int trend = 0;
      datetime trendTime = 0;
      g_tfShared[f] = false;
      g_tfFallback[f] = false;
      if(g_tfs[f] == Period())
         ScanTimeframe(g_tfs[f], all, trend, trendTime, g_tfValid[f], g_tfFirstValid[f]);
      else if(InpUseSharedCharts && ImportShared(f, all, trend, trendTime, g_tfValid[f], g_tfFirstValid[f]))
         g_tfShared[f] = true;
      else
      {
         ScanTimeframe(g_tfs[f], all, trend, trendTime, g_tfValid[f], g_tfFirstValid[f]);
         g_tfFallback[f] = true;
      }
      g_tfTrend[f] = trend;
      g_tfTrendTime[f] = trendTime;
   }

   ArrayResize(g_zones, ArraySize(all));
   for(int i = 0; i < ArraySize(all); i++)
      g_zones[i] = all[i];

   int self = TfIndex(Period());
   if(InpUseSharedCharts && self >= 0)
      ExportShared(self);

   if(InpDebugDump)
      DumpZones();
   AlertTransitions();
   if(!g_initialized)
   {
      // First pass after attaching: record every condition that is already true (price inside a zone,
      // close to an HTF LP, weak retest, attack) without alerting, so re-attaching never floods Telegram.
      g_initialized = true;
      g_silent = true;
      CheckMarketSignals();
      CheckTickRetest();
      g_silent = false;
   }
   else
      CheckMarketSignals();
   FlushEvents(false);
   Draw();
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   Recalculate(prev_calculated == 0);
   CheckTickRetest();
   CheckNewPositions();
   return rates_total;
}

void OnTimer()
{
   Recalculate(false);
   CheckNewPositions();
   if(InpReportOnStart && !g_reportOnStartSent && g_initialized && IsMaster())
   {
      g_reportOnStartSent = true;
      // Switching the chart timeframe re-initialises the indicator; a terminal-wide timestamp keeps
      // the test report to one message per 10 minutes.
      string gv = "ZOLP_TESTREPORT_" + Symbol();
      if(!GlobalVariableCheck(gv) || TimeLocal() - (datetime)GlobalVariableGet(gv) > 600)
      {
         GlobalVariableSet(gv, (double)TimeLocal());
         CheckMorningReport(true);
      }
   }
   CheckMorningReport(false);
   CheckDigests();
   FlushEvents(false);
   Draw();   // keep "nearest to price" selection fresh between bars
}

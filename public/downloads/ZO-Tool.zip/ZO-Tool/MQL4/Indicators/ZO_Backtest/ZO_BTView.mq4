﻿//+------------------------------------------------------------------+
//| ZO_BTView.mq4                                                    |
//| Draws what the Python backtest (backtest/bt_h4m15.py) saw, so    |
//| entries can be checked by eye on the M15 chart:                  |
//|  - every H4 LP (whole history, never hidden) as two labelled     |
//|    lines (High / Low) until an H4 ZOS body is cut by its end     |
//|    point (x marks that candle); Main H4 changes marked;          |
//|  - every M15 LP as a rectangle while alive, Mains starred;       |
//|  - the trades of the chosen rule sets (buy / sell arrows with    |
//|    kind and result, entry / SL / TP lines);                      |
//|  - candidates the FLEX / R1 / R1D rule sets rejected, with the   |
//|    reason (hover the grey dot) - to spot entries the rules miss. |
//|  - "EP" + quality where the EA would have sent a POTENTIAL EP    |
//|    (WATCH) alert: gold = no entry followed, aqua = entry followed;|
//| Click a trade (its arrow, line or result) to open a panel with   |
//| why it was taken: what supported it, what spoke against it, the  |
//| context (phase, session, news) and how it was managed.           |
//| Input file: MQL4\Files\zo_bt_overlay_<symbol>.csv, written by    |
//| every backtest run. Times are MT4 server time. Read-only.        |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_BTView - Xem lai cac lenh cua BACKTEST tren chart M15."
#property description "Ve LP H4 / M15, diem vao -> diem thoat (xanh = lai, do = lo, trang = hoa), SL / TP."
#property description "BAM vao 1 lenh de xem vi sao vao: yeu to ung ho, khong ung ho, boi canh, cach quan ly."
#property description "Chu EP + so = cho EA bao POTENTIAL EP (vang: khong vao, xanh ngoc: co vao lenh). InpShow = ten he (mac dinh ZOFLEX = he chinh)."
#property indicator_chart_window
#property indicator_buffers 0

#include <ZO/ZoCore.mqh>   // ZoUnaccent(): accents show as "?" on MT4 under Wine

input string InpFile        = "";            // Overlay file (empty = zo_bt_overlay_<symbol>.csv)
input string InpShow        = "ZOFLEX";       // System shown: ZOFLEX = the main system (the one the EA runs). Testing systems appear only when bt_lab.py wrote them
input int    InpDaysBack    = 30;            // M15 LP boxes / rejected dots of the last N days only (0 = all)
input int    InpTradeDaysBack = 0;          // Trades of the last N days only (0 = every trade in the file)
input bool   InpShowMainH4  = true;          // Mark Main H4 changes (H4 trend)
input int    InpH4Labels    = 1;             // H4 LP labels: 0 none, 1 live LPs only, 2 all (hover a line for details)
input bool   InpShowH4      = true;          // H4 LPs as lines
input bool   InpShowM15     = true;          // M15 LPs as boxes
input bool   InpShowWatch   = true;          // "EP" marks where the EA would send a POTENTIAL EP alert (click for the reasons)
input int    InpWatchMinQuality = 80;        // ... only alerts of at least this quality (the EA's InpEpMinQuality; 50 = all)
input color  InpClrWatch    = clrGold;       // alert not followed by an entry
input color  InpClrWatchEntry = clrAqua;     // alert followed by an entry
input bool   InpShowRejects = true;          // Rejected FLEX triggers (grey dots, hover for the reason)
input bool   InpRejectText  = false;         // Also print the reason next to each grey dot
input color  InpClrH4G      = clrLimeGreen;
input color  InpClrH4R      = clrTomato;
input color  InpClrH4Fresh  = clrGold;
input color  InpClrM15G     = C'0,70,35';
input color  InpClrM15R     = C'85,20,20';
input color  InpClrM15Fresh = C'70,70,20';
input color  InpClrWin      = clrLime;        // entry -> exit line: profit
input color  InpClrLoss     = clrRed;         // entry -> exit line: loss
input color  InpClrBe       = clrWhite;       // entry -> exit line: break-even
input color  InpClrBuy      = clrDodgerBlue;  // BUY arrow / label
input color  InpClrSell     = clrOrange;      // SELL arrow / label
input int    InpTradeWidth  = 2;              // Width of the entry -> exit line
input bool   InpShowSlTp    = true;           // Faint SL / TP segments
input color  InpClrSlTp     = C'90,90,90';
input int    InpNoteFontSize = 9;             // Font size of the "why this trade" panel (click a trade to open it)
input int    InpNoteCorner  = 1;             // Corner of the note panel: 0 top left, 1 top right, 2 bottom left, 3 bottom right
input color  InpNoteBack    = C'20,24,32';  // Background of the note panel

#define PFX "ZOBT_"

long g_fileMod = -2;

// "Why" notes of the trades (N rows of the overlay file) and the panel showing one after a click on a trade.
#define PANEL "ZOBTP_"
#define PANEL_ROWS 60
string g_noteKey[];     // "<code>_<unix time of the entry>"
string g_noteText[];    // lines separated by |
string g_tBase[];       // object name prefix of each drawn trade
string g_tHead[];       // one-line summary of the trade
string g_tNote[];       // its note (may be empty)
string g_shown = "";

string FileName()
{
   return InpFile != "" ? InpFile : "zo_bt_overlay_" + Symbol() + ".csv";
}

int OnInit()
{
   EventSetTimer(15);
   DrawAll();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, PFX);
   ObjectsDeleteAll(0, PANEL);
}

// A click on any object of a trade (arrow, line, result) opens the panel with why it was taken; a second click
// on the same trade, or a click on the panel, closes it.
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id != CHARTEVENT_OBJECT_CLICK)
      return;
   if(StringFind(sparam, PANEL) == 0)
   {
      HidePanel();
      return;
   }
   if(StringFind(sparam, PFX + "T") != 0)
      return;
   for(int k = 0; k < ArraySize(g_tBase); k++)
      if(StringFind(sparam, g_tBase[k]) == 0 && StringLen(sparam) == StringLen(g_tBase[k]) + 1)
      {
         if(g_shown == g_tBase[k])
            HidePanel();
         else
            ShowPanel(k);
         return;
      }
}

void HidePanel()
{
   ObjectsDeleteAll(0, PANEL);
   g_shown = "";
   ChartRedraw();
}

bool PanelRight() { return InpNoteCorner == 1 || InpNoteCorner == 3; }
bool PanelLower() { return InpNoteCorner >= 2; }
int  PanelWidth() { return 20 + (int)(64 * InpNoteFontSize * 0.85); }

ENUM_BASE_CORNER PanelCorner()
{
   if(PanelLower())
      return PanelRight() ? CORNER_RIGHT_LOWER : CORNER_LEFT_LOWER;
   return PanelRight() ? CORNER_RIGHT_UPPER : CORNER_LEFT_UPPER;
}

// Lines of the open panel; collected first so the box can be sized and the rows placed from either edge.
string g_pText[];
color  g_pClr[];

void PanelAdd(string text, color clr)
{
   int n = ArraySize(g_pText);
   if(n >= PANEL_ROWS)
      return;
   ArrayResize(g_pText, n + 1);
   ArrayResize(g_pClr, n + 1);
   g_pText[n] = text;
   g_pClr[n] = clr;
}

// Chart labels hold at most 63 characters: long lines are wrapped at a space.
void AddWrapped(string text, color clr)
{
   int width = 60;
   text = ZoUnaccent(text);
   while(StringLen(text) > 0)
   {
      if(StringLen(text) <= width)
      {
         PanelAdd(text, clr);
         break;
      }
      int cut = -1;
      for(int p = width; p > 20; p--)
         if(StringGetCharacter(text, p) == ' ')
         {
            cut = p;
            break;
         }
      if(cut < 0)
      {
         PanelAdd(StringSubstr(text, 0, width), clr);
         text = "   " + StringSubstr(text, width);
      }
      else
      {
         PanelAdd(StringSubstr(text, 0, cut), clr);
         text = "   " + StringSubstr(text, cut + 1);
      }
   }
}

// Opaque box first (so it stays under the text), then one label per line.
void PanelDraw()
{
   int n = ArraySize(g_pText), h = InpNoteFontSize + 6, w = PanelWidth();
   int margin = 6, top = 18;
   string bg = PANEL + "bg";
   ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, bg, OBJPROP_CORNER, PanelCorner());
   ObjectSetInteger(0, bg, OBJPROP_XDISTANCE, PanelRight() ? margin + w : margin);
   ObjectSetInteger(0, bg, OBJPROP_YDISTANCE, PanelLower() ? margin + n * h + 12 : top);
   ObjectSetInteger(0, bg, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, bg, OBJPROP_YSIZE, n * h + 12);
   ObjectSetInteger(0, bg, OBJPROP_BGCOLOR, InpNoteBack);
   ObjectSetInteger(0, bg, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, bg, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, bg, OBJPROP_BACK, false);
   ObjectSetInteger(0, bg, OBJPROP_SELECTABLE, false);
   for(int r = 0; r < n; r++)
   {
      string name = PANEL + IntegerToString(r);
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner());
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, PanelLower() ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelRight() ? margin + w - 8 : margin + 8);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelLower() ? margin + 6 + (n - 1 - r) * h : top + 6 + r * h);
      ObjectSetString(0, name, OBJPROP_FONT, "Consolas");
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpNoteFontSize);
      ObjectSetInteger(0, name, OBJPROP_COLOR, g_pClr[r]);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetString(0, name, OBJPROP_TEXT, g_pText[r]);
   }
}

void ShowPanel(int k)
{
   ObjectsDeleteAll(0, PANEL);
   g_shown = g_tBase[k];
   ArrayResize(g_pText, 0);
   ArrayResize(g_pClr, 0);
   AddWrapped(g_tHead[k], clrGold);
   if(g_tNote[k] == "")
      AddWrapped("(file overlay chua co chu thich - chay lai bt_lab.py)", clrSilver);
   else
   {
      string parts[];
      int n = StringSplit(g_tNote[k], '|', parts);
      for(int i = 0; i < n; i++)
      {
         color clr = StringFind(parts[i], "POTENTIAL EP") == 0 ? clrGold : StringFind(parts[i], "UNG HO:") == 0 ? clrLime : StringFind(parts[i], "KHONG UNG HO:") == 0 ? clrTomato :
                     StringFind(parts[i], "BOI CANH:") == 0 ? clrSilver : StringFind(parts[i], "QUAN LY:") == 0 ? clrLightSkyBlue : clrWhite;
         AddWrapped(parts[i], clr);
      }
   }
   PanelAdd("(bam vao bang nay hoac vao lenh do lan nua de dong)", clrGray);
   PanelDraw();
   ChartRedraw();
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   return rates_total;
}

void OnTimer()
{
   // Redraw when a new backtest run rewrites the file.
   if(FileGetInteger(FileName(), FILE_MODIFY_DATE, false) != g_fileMod)
      DrawAll();
}

//+------------------------------------------------------------------+
string TfName(int tf)
{
   return tf == 240 ? "H4" : tf == 15 ? "M15" : tf == 60 ? "H1" : IntegerToString(tf);
}

string DateText(datetime t)
{
   return IntegerToString(TimeDay(t)) + "/" + IntegerToString(TimeMonth(t));
}

bool Wanted(string code)
{
   string parts[];
   int n = StringSplit(InpShow, ',', parts);
   for(int i = 0; i < n; i++)
   {
      string p = parts[i];
      StringTrimLeft(p);
      StringTrimRight(p);
      if(p == code)
         return true;
   }
   return false;
}

datetime Oldest()
{
   return InpDaysBack > 0 ? Time[0] - InpDaysBack * 86400 : 0;
}

datetime NowEnd()
{
   return Time[0] + PeriodSeconds() * 3;
}

void Line(string name, datetime t0, datetime t1, double p, color clr, int style, int width, string tip)
{
   ObjectCreate(0, name, OBJ_TREND, 0, t0, p, t1, p);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, style == STYLE_SOLID ? width : 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, ZoUnaccent(tip));
}

void Text(string name, datetime t, double p, string txt, color clr, int anchor, int size, string tip)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, p);
   ObjectSetString(0, name, OBJPROP_TEXT, ZoUnaccent(txt));
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, ZoUnaccent(tip));
}

void Arrow(string name, datetime t, double p, int code, color clr, int anchor, int width, string tip)
{
   ObjectCreate(0, name, OBJ_ARROW, 0, t, p);
   ObjectSetInteger(0, name, OBJPROP_ARROWCODE, code);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, ZoUnaccent(tip));
}

double BarHigh(datetime t) { int s = iBarShift(Symbol(), Period(), t); return s >= 0 ? High[s] : 0; }
double BarLow(datetime t)  { int s = iBarShift(Symbol(), Period(), t); return s >= 0 ? Low[s] : 0; }

//+------------------------------------------------------------------+
//| Z,tf,t0,created,t_break,t_dead,t_clear,hi,lo,dir,main_since      |
//+------------------------------------------------------------------+
void DrawZone(string &f[], int n)
{
   if(n < 11)
      return;
   int tf = (int)StringToInteger(f[1]);
   datetime t0 = (datetime)StringToInteger(f[2]);
   datetime tBreak = (datetime)StringToInteger(f[4]);
   datetime tDead = (datetime)StringToInteger(f[5]);
   datetime tClear = (datetime)StringToInteger(f[6]);
   double hi = StringToDouble(f[7]), lo = StringToDouble(f[8]);
   int dir = (int)StringToInteger(f[9]);
   datetime tMain = (datetime)StringToInteger(f[10]);
   datetime oldest = tf == 240 ? 0 : Oldest();   // H4 LPs are always drawn in full
   datetime tEnd = tDead > 0 ? tDead : NowEnd();
   datetime tLast = tClear > tEnd ? tClear : tEnd;
   if(tLast < oldest)
      return;   // gone before the drawn period
   string kind = dir > 0 ? (tMain > 0 ? "MGLP" : "GLP") : dir < 0 ? (tMain > 0 ? "MRLP" : "RLP") : "LP";
   string tag = kind + "-" + TfName(tf) + " " + DateText(t0);
   string tip = tag + "  " + DoubleToString(lo, Digits) + "-" + DoubleToString(hi, Digits) +
                (tBreak > 0 ? "  break " + TimeToString(tBreak) : "  chua break") +
                (tDead > 0 ? (tf == 240 ? "  bi cat than " : "  chet ") + TimeToString(tDead) : "") +
                (tClear > 0 ? "  clear " + TimeToString(tClear) : "");
   string base = PFX + "Z" + IntegerToString(tf) + "_" + IntegerToString((long)t0);

   if(tf == 240)
   {
      if(!InpShowH4)
         return;
      color clr = dir > 0 ? InpClrH4G : dir < 0 ? InpClrH4R : InpClrH4Fresh;
      int width = 1;   // thin lines; Main LPs carry "MAIN" in their label
      int style = dir == 0 ? STYLE_DOT : STYLE_SOLID;
      Line(base + "H", t0, tEnd, hi, clr, style, width, "H-" + tip);
      Line(base + "L", t0, tEnd, lo, clr, style, width, "L-" + tip);
      if(tClear > tEnd && tDead > 0)
      {
         // Failed (closed through its end point) but not cleared yet.
         Line(base + "Hx", tEnd, tClear, hi, clr, STYLE_DOT, 1, "da thung, chua clear: " + tip);
         Line(base + "Lx", tEnd, tClear, lo, clr, STYLE_DOT, 1, "da thung, chua clear: " + tip);
      }
      // One short label per LP, at the start of its lines (the end of many lines falls on the same bars and
      // their labels piled up there). Dead LPs keep only the tooltip unless InpH4Labels = 2.
      bool alive = tDead == 0 || tDead > Time[0];
      if(InpH4Labels == 2 || (InpH4Labels == 1 && alive))
         Text(base + "t", t0, dir < 0 ? lo : hi, " " + tag + (tMain > 0 ? " MAIN" : ""), clr,
              dir < 0 ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER, 7, tip);
      if(tDead > 0 && dir != 0)
      {
         // The H4 candle whose ZOS body was cut by the end point (GLP: Low, RLP: High).
         double endPx = dir > 0 ? lo : hi;
         Text(base + "x", tDead - 240 * 60, endPx, "x", clr, ANCHOR_CENTER, 10, "LP H4 bi cat than tai day: " + tip);
      }
      return;
   }

   if(!InpShowM15 || tf != Period())
      return;
   color fill = dir > 0 ? InpClrM15G : dir < 0 ? InpClrM15R : InpClrM15Fresh;
   ObjectCreate(0, base, OBJ_RECTANGLE, 0, t0, hi, tEnd, lo);
   ObjectSetInteger(0, base, OBJPROP_COLOR, fill);
   ObjectSetInteger(0, base, OBJPROP_BACK, true);
   ObjectSetInteger(0, base, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, base, OBJPROP_TOOLTIP, ZoUnaccent(tip));
   if(tMain > 0 && tMain >= oldest)
      Text(base + "m", tMain, dir > 0 ? lo : hi, "MAIN " + (dir > 0 ? "G" : "R"), clrWhite,
           dir > 0 ? ANCHOR_UPPER : ANCHOR_LOWER, 8, "Main M15 tu " + TimeToString(tMain) + ": " + tip);
}

//+------------------------------------------------------------------+
//| T,code,dir,t_signal,t_fill,t_exit,ep,sl,tp,outcome,R,kind,trigger |
//+------------------------------------------------------------------+
void DrawTrade(string &f[], int n, int idx)
{
   if(n < 13 || !Wanted(f[1]))
      return;
   int dir = (int)StringToInteger(f[2]);
   datetime tSig = (datetime)StringToInteger(f[3]);
   datetime tFill = (datetime)StringToInteger(f[4]);
   datetime tExit = (datetime)StringToInteger(f[5]);
   if(InpTradeDaysBack > 0 && tSig < Time[0] - InpTradeDaysBack * 86400)
      return;
   double ep = StringToDouble(f[6]), sl = StringToDouble(f[7]), tp = StringToDouble(f[8]);
   string outcome = f[9], r = f[10], kind = f[11], trig = f[12];
   double xp = n >= 14 ? StringToDouble(f[13]) : ep;
   if(tExit <= tFill)
      tExit = tFill + PeriodSeconds();
   color res = outcome == "win" ? InpClrWin : outcome == "loss" ? InpClrLoss : InpClrBe;
   string side = dir > 0 ? "BUY" : "SELL";
   string resTxt = outcome == "win" ? "LAI" : outcome == "loss" ? "LO" : outcome == "be" ? "HOA (BE)" : "dang mo";
   string tip = f[1] + " " + side + " " + trig + "  vao " + TimeToString(tFill) + " @" + DoubleToString(ep, Digits) +
                "  SL " + DoubleToString(sl, Digits) + "  TP " + DoubleToString(tp, Digits) +
                "  | dong " + TimeToString(tExit) + " @" + DoubleToString(xp, Digits) + "  " + resTxt + " " + r + "R";
   string base = PFX + "T" + IntegerToString(idx);
   // Remember the trade for the click panel, with its "why" note when the file has one.
   int tk = ArraySize(g_tBase);
   ArrayResize(g_tBase, tk + 1);
   ArrayResize(g_tHead, tk + 1);
   ArrayResize(g_tNote, tk + 1);
   g_tBase[tk] = base;
   g_tHead[tk] = tip;
   g_tNote[tk] = "";
   string key = f[1] + "_" + f[4];
   for(int q = 0; q < ArraySize(g_noteKey); q++)
      if(g_noteKey[q] == key)
      {
         g_tNote[tk] = g_noteText[q];
         break;
      }

   // Entry -> exit: one line coloured by the result (green = profit, red = loss, white = break-even).
   ObjectCreate(0, base + "j", OBJ_TREND, 0, tFill, ep, tExit, xp);
   ObjectSetInteger(0, base + "j", OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, base + "j", OBJPROP_COLOR, res);
   ObjectSetInteger(0, base + "j", OBJPROP_WIDTH, InpTradeWidth);
   ObjectSetInteger(0, base + "j", OBJPROP_SELECTABLE, false);
   ObjectSetString(0, base + "j", OBJPROP_TOOLTIP, ZoUnaccent(tip));

   // Entry: buy / sell arrow at the fill price and a label.
   // MT4's own buy / sell sign: Wingdings glyphs show as squares under Wine.
   ObjectCreate(0, base + "a", dir > 0 ? OBJ_ARROW_BUY : OBJ_ARROW_SELL, 0, tFill, ep);
   ObjectSetInteger(0, base + "a", OBJPROP_COLOR, dir > 0 ? InpClrBuy : InpClrSell);
   ObjectSetInteger(0, base + "a", OBJPROP_WIDTH, 2);
   ObjectSetInteger(0, base + "a", OBJPROP_SELECTABLE, false);
   ObjectSetString(0, base + "a", OBJPROP_TOOLTIP, ZoUnaccent(tip));
   Text(base + "t", tFill, ep, (dir > 0 ? "B " : "S "), dir > 0 ? InpClrBuy : InpClrSell,
        dir > 0 ? ANCHOR_RIGHT_UPPER : ANCHOR_RIGHT_LOWER, 7, tip);

   // Exit: check (profit), cross (loss) or dot (break-even) and the result in R.
   Text(base + "r", tExit, xp, " " + r + "R", res, ANCHOR_LEFT, 7, tip);

   // SL / TP as short faint segments over the life of the trade.
   if(InpShowSlTp)
   {
      Line(base + "s", tFill, tExit, sl, InpClrSlTp, STYLE_DOT, 1, "SL " + tip);
      Line(base + "p", tFill, tExit, tp, InpClrSlTp, STYLE_DOT, 1, "TP " + tip);
   }
}

//+------------------------------------------------------------------+
//| X,code,dir,t,price,reason                                        |
//+------------------------------------------------------------------+
void DrawMain(string &f[], int n, int idx)
{
   if(!InpShowMainH4 || n < 3)
      return;
   datetime t = (datetime)StringToInteger(f[1]);
   int dir = (int)StringToInteger(f[2]);
   datetime tBar = t - 240 * 60;   // the H4 candle that cut the opposite LP
   int s = iBarShift(Symbol(), Period(), tBar);
   if(s < 0)
      return;
   string txt = dir > 0 ? "Main H4 TANG" : "Main H4 GIAM";
   Text(PFX + "M" + IntegerToString(idx), tBar, dir > 0 ? Low[s] : High[s], txt, dir > 0 ? InpClrH4G : InpClrH4R,
        dir > 0 ? ANCHOR_UPPER : ANCHOR_LOWER, 8, "Xu the H4 doi luc " + TimeToString(t) + ": LP H4 nguoc bi cat than, co LP " +
        (dir > 0 ? "G" : "R") + " H4 lam Main");
}

string ReasonVi(string r)
{
   string main = "";
   if(StringFind(r, "_MAIN") >= 0)
   {
      main = " (trigger Main M15)";
      StringReplace(r, "_MAIN", "");
   }
   if(r == "NO_H4_LP")        return "khong nam o LP H4 cung chieu" + main;
   if(r == "H4_TREND")        return "nguoc xu the H4" + main;
   if(r == "H4_RETESTS")      return "LP H4 da retest qua nhieu lan" + main;
   if(r == "H4_CIVIL_WAR")    return "noi chien H4" + main;
   if(r == "WRONG_HALF")      return "LP M15 o nua sai LP H4" + main;
   if(r == "NO_ENTRY_CANDLE") return "khong co nen xac nhan (gia khong retest / LP bi dong xuyen / qua 24h)" + main;
   if(r == "BAD_TIME")        return "gio xau (khuya)" + main;
   if(r == "RR_LOW")          return "RR thap hoac khong co target" + main;
   if(r == "B_OPEN_OUTSIDE_BODY") return "nen B khong mo trong than nen A";
   if(r == "H4_MAIN_TREND")   return "nguoc xu the Main H4";
   if(r == "LOC_INSIDE_OPP")  return "nam trong LP H4 nguoc (noi chien)";
   if(r == "LOC_NONE")        return "khong o moc H4 nao (bo luat chi vao o moc H4)";
   if(r == "LOC_ZONE_NEAR")   return "o nua gan cua LP H4 (bo luat chi vao o nua sau)";
   return r + main;
}

void DrawReject(string &f[], int n, int idx)
{
   if(!InpShowRejects || n < 6 || !Wanted(f[1]))
      return;
   int dir = (int)StringToInteger(f[2]);
   datetime t = (datetime)StringToInteger(f[3]);
   if(t < Oldest())
      return;
   double px = StringToDouble(f[4]);
   string why = ReasonVi(f[5]);
   string tip = f[1] + " bo qua " + (dir > 0 ? "BUY" : "SELL") + " luc " + TimeToString(t) + ": " + why;
   datetime tBar = t - PeriodSeconds();
   Text(PFX + "X" + IntegerToString(idx), tBar, px, "o", clrGray, ANCHOR_CENTER, 7, tip);
   if(InpRejectText)
      Text(PFX + "Xt" + IntegerToString(idx), tBar, px, "  " + why, clrGray, ANCHOR_LEFT, 6, tip);
}

//+------------------------------------------------------------------+
//| W,code,dir,t,price,quality,entry followed,note                   |
//+------------------------------------------------------------------+
void DrawWatch(string &f[], int n, int idx)
{
   if(!InpShowWatch || n < 8)
      return;
   int q = (int)StringToInteger(f[5]);
   datetime t = (datetime)StringToInteger(f[3]);
   if(q < InpWatchMinQuality || t < Oldest())
      return;
   int dir = (int)StringToInteger(f[2]);
   bool entry = StringToInteger(f[6]) == 1;
   datetime tBar = t - 15 * 60;   // the candle that completed the A/B pair
   double px = StringToDouble(f[4]);
   color clr = entry ? InpClrWatchEntry : InpClrWatch;
   string head = StringFormat("%s POTENTIAL EP %s, chat luong %d/100 - %s", TimeToString(t), dir > 0 ? "BUY" : "SELL", q,
                              entry ? "sau do EA VAO LENH" : "EA khong vao lenh");
   string base = PFX + "T" + IntegerToString(idx);
   int tk = ArraySize(g_tBase);
   ArrayResize(g_tBase, tk + 1);
   ArrayResize(g_tHead, tk + 1);
   ArrayResize(g_tNote, tk + 1);
   g_tBase[tk] = base;
   g_tHead[tk] = head;
   g_tNote[tk] = f[7];
   Text(base + "w", tBar, px, "EP" + IntegerToString(q), clr, dir > 0 ? ANCHOR_UPPER : ANCHOR_LOWER, 7, head + " (bam de xem)");
}

//+------------------------------------------------------------------+
void DrawAll()
{
   ObjectsDeleteAll(0, PFX);
   ObjectsDeleteAll(0, PANEL);
   g_shown = "";
   ArrayResize(g_noteKey, 0);
   ArrayResize(g_noteText, 0);
   ArrayResize(g_tBase, 0);
   ArrayResize(g_tHead, 0);
   ArrayResize(g_tNote, 0);
   string name = FileName();
   g_fileMod = FileGetInteger(name, FILE_MODIFY_DATE, false);
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
   {
      Comment("ZO_BTView: chua co file " + name + " trong MQL4\\Files - chay backtest bt_h4m15.py truoc.");
      return;
   }
   Comment("");
   int zones = 0, trades = 0, rejects = 0, idx = 0;
   while(!FileIsEnding(h))
   {
      string f[];
      int n = 0;
      ArrayResize(f, 16);
      do
      {
         string v = FileReadString(h);
         if(n < 16)
            f[n++] = v;
      }
      while(!FileIsLineEnding(h) && !FileIsEnding(h));
      if(n == 0)
         continue;
      idx++;
      if(f[0] == "N")
      {
         // N,code,t_entry,dir,why|UNG HO: ...|KHONG UNG HO: ...|BOI CANH: ...|QUAN LY: ...
         if(n >= 5 && Wanted(f[1]))
         {
            int nk = ArraySize(g_noteKey);
            ArrayResize(g_noteKey, nk + 1);
            ArrayResize(g_noteText, nk + 1);
            g_noteKey[nk] = f[1] + "_" + f[2];
            g_noteText[nk] = f[4];
         }
         continue;
      }
      if(f[0] == "Z")      { DrawZone(f, n); zones++; }
      else if(f[0] == "T") { DrawTrade(f, n, idx); trades++; }
      else if(f[0] == "X") { DrawReject(f, n, idx); rejects++; }
      else if(f[0] == "M") DrawMain(f, n, idx);
      else if(f[0] == "W") DrawWatch(f, n, idx);
   }
   FileClose(h);
   PrintFormat("ZO_BTView: %d LP, %d lenh, %d trigger bi loai trong file (ve %d ngay gan nhat, bo luat: %s)",
               zones, trades, rejects, InpDaysBack, InpShow);
   ChartRedraw();
}

﻿//+------------------------------------------------------------------+
//| ZO_Review.mq4                                                    |
//| Clean review chart for hand-marking entries (M15 chart):         |
//|  - every H4 / D1 / W1 LP of the whole history as thin High / Low |
//|    lines (H4 blue, D1 yellow, W1 red; GLP solid, RLP dashed)     |
//|    (plus a dotted 50% line: the deep half is where the ZO rules  |
//|    enter), until an H4 ZOS body is cut by its end point; labels  |
//|    follow the left edge of the screen so long lines stay named;  |
//|  - every M15 LP of the whole history as a short box (4h from its  |
//|    start, so old zones stay visible without covering the chart); |
//|  - Main H4 changes (H4 trend).                                   |
//| No system trades by default, so your marks are not biased. When  |
//| done, set InpCompare (e.g. "ZOM") to overlay the system's trades |
//| as small arrows next to your marks.                              |
//| Mark with Insert > Arrows > Buy Sign / Sell Sign / Stop Sign,    |
//| then run Scripts\ZO_ExportMarks and backtest/bt_marks.py.        |
//| Input file: MQL4\Files\zo_bt_overlay_<symbol>.csv (bt_lab.py).   |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_Review - Chart sach de TU DANH DAU diem vao (khong hien lenh cua he)."
#property description "LP H4 xanh lam, D1 vang, W1 do (dang duong High / Low); LP M15 dang hop."
#property description "Danh dau: Insert > Arrows > Arrow Up (mua) / Arrow Down (ban) / Stop Sign (khong nen vao)."
#property description "Xong chay script ZO_ExportMarks. InpCompare = ten he de hien lenh cua he ben canh."
#property indicator_chart_window
#property indicator_buffers 0

input string InpFile       = "";            // Overlay file (empty = zo_bt_overlay_<symbol>.csv)
input int    InpDaysBack   = 0;             // Draw only the last N days (0 = whole history)
input bool   InpShowH4     = true;          // H4 LPs as lines
input bool   InpShowD1     = true;          // D1 LPs as lines (needs zos_probe_<symbol>_1440_chart.csv)
input bool   InpShowW1     = true;          // W1 LPs as lines (needs zos_probe_<symbol>_10080_chart.csv)
input bool   InpShowMid    = true;          // Dotted 50% line of each LP line set (deep half boundary)
input bool   InpShowDeadH4 = true;          // Also LPs that are already dead (cut) - whole history
input int    InpH4Labels   = 2;             // LP line labels: 0 none, 1 live LPs only, 2 all
input int    InpLabelPos   = 0;             // Label position: 0 left edge of the screen (follows scrolling), 1 line end
input int    InpLabelSize  = 10;            // Label font size
input double InpLabelGapPips = 6;           // Labels closer than this (pips) are shifted sideways
input int    InpLabelShiftBars = 16;        // Sideways shift step for overlapping labels (bars)
input bool   InpShowM15    = true;          // M15 LPs as boxes
input int    InpM15BoxHours = 4;            // M15 box length in hours from the LP start (0 = until the LP dies)
input bool   InpShowMainH4 = true;          // Main H4 changes
input string InpCompare    = "";            // After marking: system trades to compare (e.g. ZOM, ZO4, HE3z); empty = none
input color  InpClrH4      = clrDodgerBlue; // H4 LP lines (GLP solid, RLP dashed, fresh dotted)
input color  InpClrD1      = clrGold;       // D1 LP lines
input color  InpClrW1      = clrRed;        // W1 LP lines
input color  InpClrUp      = clrLimeGreen;  // Main H4 up marker
input color  InpClrDown    = clrTomato;     // Main H4 down marker
input color  InpClrM15G    = C'0,120,60';
input color  InpClrM15R    = C'150,40,40';
input color  InpClrM15Fresh= C'120,120,30';
input color  InpClrCmpWin  = clrLime;
input color  InpClrCmpLoss = clrRed;
input color  InpClrCmpBe   = clrSilver;

#define PFX "ZOREV_"

long g_fileMod = -2;

// H4 LP labels, re-placed by PlaceLabels() whenever the chart is scrolled or zoomed.
string   g_lblName[];
datetime g_lblT0[];
datetime g_lblT1[];
double   g_lblPrice[];
bool     g_lblUp[];      // true: text above its line (High), false: below (Low)
bool     g_lblAlive[];
string   g_lblText[];
color    g_lblColor[];
string   g_lblTip[];
int      g_lblFirstBar = -1;
int      g_lblBars = -1;

string FileName() { return InpFile != "" ? InpFile : "zo_bt_overlay_" + Symbol() + ".csv"; }

int OnInit()
{
   EventSetTimer(15);
   DrawAll();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, PFX);
   Comment("");
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   return rates_total;
}

void OnTimer()
{
   if(FileGetInteger(FileName(), FILE_MODIFY_DATE, false) != g_fileMod)
      DrawAll();
}

//+------------------------------------------------------------------+
datetime Oldest()  { return InpDaysBack > 0 ? Time[0] - InpDaysBack * 86400 : 0; }
datetime NowEnd()  { return Time[0] + PeriodSeconds() * 3; }
string DateText(datetime t) { return IntegerToString(TimeDay(t)) + "/" + IntegerToString(TimeMonth(t)) + "/" +
                                     IntegerToString(TimeYear(t) % 100); }

bool Wanted(string code)
{
   string parts[];
   int n = StringSplit(InpCompare, ',', parts);
   for(int i = 0; i < n; i++)
   {
      string p = parts[i];
      StringTrimLeft(p);
      StringTrimRight(p);
      if(p != "" && p == code)
         return true;
   }
   return false;
}

// Vietnamese letters show as "?" in MT4 under Wine (ANSI code page), so every string shown on the chart
// (labels, tooltips, comment) goes through Unaccent(): "đây là LP H1" -> "day la LP H1".
string Unaccent(string s)
{
   string from[] = {"àáạảãâầấậẩẫăằắặẳẵ", "èéẹẻẽêềếệểễ", "ìíịỉĩ", "òóọỏõôồốộổỗơờớợởỡ", "ùúụủũưừứựửữ", "ỳýỵỷỹ", "đ",
                    "ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ", "ÈÉẸẺẼÊỀẾỆỂỄ", "ÌÍỊỈĨ", "ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ", "ÙÚỤỦŨƯỪỨỰỬỮ", "ỲÝỴỶỸ", "Đ"};
   string to[] = {"a", "e", "i", "o", "u", "y", "d", "A", "E", "I", "O", "U", "Y", "D"};
   string out = "";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
   {
      ushort c = StringGetCharacter(s, i);
      string ch = ShortToString(c);
      if(c >= 128)
      {
         for(int g = 0; g < ArraySize(from); g++)
            if(StringFind(from[g], ch) >= 0)
            {
               ch = to[g];
               break;
            }
         if(c == 0x2192)
            ch = "->";
         else if(c == 0x2013)
            ch = "-";
      }
      out += ch;
   }
   return out;
}

void SetTip(string name, string tip)
{
   ObjectSetString(0, name, OBJPROP_TOOLTIP, Unaccent(tip));
}

void Line(string name, datetime t0, datetime t1, double p0, double p1, color clr, int style, int width, string tip)
{
   ObjectCreate(0, name, OBJ_TREND, 0, t0, p0, t1, p1);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   SetTip(name, tip);
}

void Text(string name, datetime t, double p, string txt, color clr, int anchor, int size, string tip)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, p);
   ObjectSetString(0, name, OBJPROP_TEXT, Unaccent(txt));
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   SetTip(name, tip);
}

//+------------------------------------------------------------------+
//| Z,tf,t0,created,t_break,t_dead,t_clear,hi,lo,dir,main_since      |
//+------------------------------------------------------------------+
void DrawZone(string &f[], int n)
{
   if(n < 11)
      return;
   int tf = (int)StringToInteger(f[1]);
   datetime t0 = (datetime)StringToInteger(f[2]);
   datetime tDead = (datetime)StringToInteger(f[5]);
   double hi = StringToDouble(f[7]), lo = StringToDouble(f[8]);
   int dir = (int)StringToInteger(f[9]);
   datetime tMain = (datetime)StringToInteger(f[10]);
   datetime tEnd = tDead > 0 ? tDead : NowEnd();
   if(tEnd < Oldest())
      return;
   bool alive = tDead == 0 || tDead > Time[0];
   string tfTxt = tf == 240 ? "H4" : tf == 1440 ? "D1" : tf == 10080 ? "W1" : "M15";
   bool lineTf = tf == 240 || tf == 1440 || tf == 10080;
   string kind = dir > 0 ? (tMain > 0 ? "MGLP" : "GLP") : dir < 0 ? (tMain > 0 ? "MRLP" : "RLP") : "LP";
   string tag = kind + "-" + tfTxt + " " + DateText(t0);
   string tip = tag + "  " + DoubleToString(lo, Digits) + " - " + DoubleToString(hi, Digits) + "  (" +
                DoubleToString((hi - lo) / Point / 10, 1) + " pip)" +
                (tDead > 0 ? (lineTf ? "  bị cắt thân " : "  chết ") + TimeToString(tDead) : "  còn sống");
   string base = PFX + "Z" + IntegerToString(tf) + "_" + IntegerToString((long)t0) + "_" + IntegerToString(dir);

   if(lineTf)
   {
      if((tf == 240 && !InpShowH4) || (tf == 1440 && !InpShowD1) || (tf == 10080 && !InpShowW1) ||
         (!alive && !InpShowDeadH4))
         return;
      // Colour = timeframe, style = direction.
      color clr = tf == 240 ? InpClrH4 : tf == 1440 ? InpClrD1 : InpClrW1;
      int style = dir > 0 ? STYLE_SOLID : dir < 0 ? STYLE_DASH : STYLE_DOT;
      Line(base + "H", t0, tEnd, hi, hi, clr, style, 1, "High " + tip);
      Line(base + "L", t0, tEnd, lo, lo, clr, style, 1, "Low " + tip);
      if(InpShowMid && dir != 0)
      {
         double mid = (hi + lo) / 2;
         Line(base + "M", t0, tEnd, mid, mid, clr, STYLE_DOT, 1,
              "50% " + tip + (dir > 0 ? "  (nửa sâu = dưới đường này)" : "  (nửa sâu = trên đường này)"));
      }
      if(InpH4Labels == 2 || (InpH4Labels == 1 && alive))
      {
         string name2 = tag + (tMain > 0 ? " MAIN" : "");
         QueueLabel(base + "th", t0, tEnd, hi, true, alive, "High " + name2 + " " + DoubleToString(hi, Digits), clr, "High " + tip);
         QueueLabel(base + "tl", t0, tEnd, lo, false, alive, "Low " + name2 + " " + DoubleToString(lo, Digits), clr, "Low " + tip);
      }
      if(tDead > 0 && dir != 0)
         Text(base + "x", tDead - tf * 60, dir > 0 ? lo : hi, "✖", clr, ANCHOR_CENTER, InpLabelSize,
              "LP " + tfTxt + " bị cắt thân tại đây: " + tip);
      return;
   }

   if(!InpShowM15 || tf != Period())
      return;
   color fill = dir > 0 ? InpClrM15G : dir < 0 ? InpClrM15R : InpClrM15Fresh;
   datetime tBox = InpM15BoxHours > 0 ? t0 + InpM15BoxHours * 3600 : tEnd;
   if(tBox > tEnd)
      tBox = tEnd;
   if(tBox <= t0)
      tBox = t0 + PeriodSeconds();
   ObjectCreate(0, base, OBJ_RECTANGLE, 0, t0, hi, tBox, lo);
   ObjectSetInteger(0, base, OBJPROP_COLOR, fill);
   ObjectSetInteger(0, base, OBJPROP_BACK, true);
   ObjectSetInteger(0, base, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, base, OBJPROP_HIDDEN, true);
   SetTip(base, tip);
   if(tMain > 0 && tMain < tBox)
      Text(base + "m", tMain, dir > 0 ? lo : hi, "★", clrWhite, dir > 0 ? ANCHOR_UPPER : ANCHOR_LOWER, InpLabelSize,
           "Main M15 từ " + TimeToString(tMain) + ": " + tip);
}

void DrawMain(string &f[], int n, int idx)
{
   if(!InpShowMainH4 || n < 3)
      return;
   datetime t = (datetime)StringToInteger(f[1]);
   int dir = (int)StringToInteger(f[2]);
   datetime tBar = t - 240 * 60;
   if(tBar < Oldest())
      return;
   int s = iBarShift(Symbol(), Period(), tBar);
   if(s < 0)
      return;
   Text(PFX + "M" + IntegerToString(idx), tBar, dir > 0 ? Low[s] : High[s], dir > 0 ? "▲ Main H4" : "▼ Main H4",
        dir > 0 ? InpClrUp : InpClrDown, dir > 0 ? ANCHOR_UPPER : ANCHOR_LOWER, InpLabelSize,
        "Xu thế H4 đổi " + (dir > 0 ? "TĂNG" : "GIẢM") + " lúc " + TimeToString(t));
}

//+------------------------------------------------------------------+
//| T,code,dir,t_sig,t_fill,t_exit,ep,sl,tp,outcome,R,kind,trigger   |
//+------------------------------------------------------------------+
void DrawTrade(string &f[], int n, int idx)
{
   if(n < 13 || !Wanted(f[1]))
      return;
   int dir = (int)StringToInteger(f[2]);
   datetime tFill = (datetime)StringToInteger(f[4]);
   if(tFill < Oldest())
      return;
   double ep = StringToDouble(f[6]);
   string outcome = f[9];
   color clr = outcome == "win" ? InpClrCmpWin : outcome == "loss" ? InpClrCmpLoss : InpClrCmpBe;
   string tip = "Hệ " + f[1] + " " + (dir > 0 ? "BUY" : "SELL") + " " + f[12] + " lúc " + TimeToString(tFill) +
                " @" + DoubleToString(ep, Digits) + " → " + f[10] + "R";
   // Small hollow circle so it is not mistaken for your own Buy / Sell Sign.
   string name = PFX + "T" + IntegerToString(idx);
   ObjectCreate(0, name, OBJ_ARROW, 0, tFill, ep);
   ObjectSetInteger(0, name, OBJPROP_ARROWCODE, 161);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_CENTER);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 2);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   SetTip(name, tip);
   Text(name + "t", tFill, ep, (dir > 0 ? " b " : " s ") + f[10], clr, ANCHOR_LEFT, InpLabelSize, tip);
}

//+------------------------------------------------------------------+
void QueueLabel(string name, datetime t0, datetime t1, double price, bool up, bool alive, string text, color clr,
                string tip)
{
   int k = ArraySize(g_lblName);
   ArrayResize(g_lblName, k + 1);
   ArrayResize(g_lblT0, k + 1);
   ArrayResize(g_lblT1, k + 1);
   ArrayResize(g_lblPrice, k + 1);
   ArrayResize(g_lblUp, k + 1);
   ArrayResize(g_lblAlive, k + 1);
   ArrayResize(g_lblText, k + 1);
   ArrayResize(g_lblColor, k + 1);
   ArrayResize(g_lblTip, k + 1);
   g_lblName[k] = name;
   g_lblT0[k] = t0;
   g_lblT1[k] = t1;
   g_lblPrice[k] = price;
   g_lblUp[k] = up;
   g_lblAlive[k] = alive;
   g_lblText[k] = text;
   g_lblColor[k] = clr;
   g_lblTip[k] = tip;
}

void ClearLabels()
{
   for(int k = 0; k < ArraySize(g_lblName); k++)
      ObjectDelete(0, g_lblName[k]);
   ArrayResize(g_lblName, 0);
   ArrayResize(g_lblT0, 0);
   ArrayResize(g_lblT1, 0);
   ArrayResize(g_lblPrice, 0);
   ArrayResize(g_lblUp, 0);
   ArrayResize(g_lblAlive, 0);
   ArrayResize(g_lblText, 0);
   ArrayResize(g_lblColor, 0);
   ArrayResize(g_lblTip, 0);
}

// InpLabelPos 0: each line visible on screen gets its label at the left edge of its visible part (the line
// start, or the left edge of the screen when the line starts off-screen). 1: at the line end (right of the
// last bar for live LPs, ending at the cut candle for dead ones). A label closer than InpLabelGapPips in price
// and one shift step in time to a label already placed moves one step further along its line.
void PlaceLabels()
{
   int n = ArraySize(g_lblName);
   int first = WindowFirstVisibleBar();
   int bars = WindowBarsPerChart();
   g_lblFirstBar = first;
   g_lblBars = bars;
   if(first < 0 || first >= Bars)
      first = Bars - 1;
   datetime leftT = Time[first];
   int lastBar = first - bars + 1;
   datetime rightT = lastBar >= 0 ? Time[lastBar] : Time[0] - lastBar * PeriodSeconds();
   double gap = InpLabelGapPips * ((Digits == 3 || Digits == 5) ? Point * 10 : Point);
   int step = MathMax(1, InpLabelShiftBars) * PeriodSeconds();
   datetime placedT[];
   double placedP[];
   int placedS[];
   ArrayResize(placedT, n);
   ArrayResize(placedP, n);
   ArrayResize(placedS, n);
   bool placedU[];
   ArrayResize(placedU, n);
   int m = 0;
   for(int k = 0; k < n; k++)
   {
      ObjectDelete(0, g_lblName[k]);
      int side, anchor;
      datetime t;
      bool up = g_lblUp[k];
      if(InpLabelPos == 0)
      {
         if(g_lblT1[k] < leftT || g_lblT0[k] > rightT)
            continue;   // line not on screen
         t = g_lblT0[k] > leftT ? g_lblT0[k] : leftT;
         side = 1;
         anchor = up ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER;
      }
      else
      {
         bool live = g_lblAlive[k];
         t = live ? Time[0] + PeriodSeconds() * 2 : g_lblT1[k];
         side = live ? 1 : -1;
         anchor = live ? (up ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER) : (up ? ANCHOR_RIGHT_LOWER : ANCHOR_RIGHT_UPPER);
      }
      for(int tries = 0; tries < 12; tries++)
      {
         bool clash = false;
         for(int j = 0; j < m && !clash; j++)
            clash = placedS[j] == side && placedU[j] == up && MathAbs((double)(placedT[j] - t)) < step &&
                    MathAbs(placedP[j] - g_lblPrice[k]) < gap;
         if(!clash)
            break;
         t += side * step;
      }
      placedT[m] = t;
      placedP[m] = g_lblPrice[k];
      placedS[m] = side;
      placedU[m] = up;
      m++;
      Text(g_lblName[k], t, g_lblPrice[k], " " + g_lblText[k] + " ", g_lblColor[k], anchor, InpLabelSize, g_lblTip[k]);
   }
}

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   // Scrolling / zooming: keep the labels at the left edge of the screen.
   if(id == CHARTEVENT_CHART_CHANGE && InpLabelPos == 0 &&
      (WindowFirstVisibleBar() != g_lblFirstBar || WindowBarsPerChart() != g_lblBars))
   {
      PlaceLabels();
      ChartRedraw();
   }
}

//+------------------------------------------------------------------+
void DrawAll()
{
   ClearLabels();
   ObjectsDeleteAll(0, PFX);
   string name = FileName();
   g_fileMod = FileGetInteger(name, FILE_MODIFY_DATE, false);
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
   {
      Comment(Unaccent("ZO_Review: chưa có file " + name + " trong MQL4\\Files - chạy backtest/bt_lab.py trước."));
      return;
   }
   int h4 = 0, d1 = 0, w1 = 0, m15 = 0, trades = 0, idx = 0;
   while(!FileIsEnding(h))
   {
      string f[];
      int n = 0;
      ArrayResize(f, 16);
      do
      {
         string v = FileReadString(h);
         if(n < 16)
            f[n++] = v;
      }
      while(!FileIsLineEnding(h) && !FileIsEnding(h));
      if(n == 0)
         continue;
      idx++;
      if(f[0] == "Z")
      {
         DrawZone(f, n);
         if(f[1] == "240") h4++; else if(f[1] == "1440") d1++; else if(f[1] == "10080") w1++; else m15++;
      }
      else if(f[0] == "M") DrawMain(f, n, idx);
      else if(f[0] == "T" && Wanted(f[1])) { DrawTrade(f, n, idx); trades++; }
   }
   FileClose(h);
   PlaceLabels();
   Comment(Unaccent(StringFormat("ZO_Review: %d LP W1 (đỏ), %d LP D1 (vàng), %d LP H4 (xanh lam), %d LP M15 (hộp)%s\n"
                     "Đánh dấu: Insert > Arrows > Buy Sign / Sell Sign (điểm bạn sẽ vào), Stop Sign (lệnh không nên vào).\n"
                     "Nháy đúp mũi tên > Common > Description để ghi lý do. Xong chạy Scripts > ZO_ExportMarks.",
                     w1, d1, h4, m15, InpCompare == "" ? "" : StringFormat(", %d lệnh của hệ %s (vòng tròn)", trades, InpCompare))));
   ChartRedraw();
}

﻿//+------------------------------------------------------------------+
//| ZO_RunStart.mq4                                                  |
//| Marks where runs really started (hindsight) on the ZOS chart, to |
//| study what the chart looked like at those points:                |
//|  - a circle at every swing point a run of >= 30 pip started from |
//|    (size S / M / L by the length of the run), with a thin line   |
//|    to where that run ended;                                      |
//|  - optionally the swing points that looked alike but failed      |
//|    (grey dots), to compare;                                      |
//|  - CLICK a point: a panel explains it (location among the LPs,   |
//|    the leg before it, the ZOS candles at the tip, H4 context,    |
//|    what followed, the ZO reading, reasons for / against) and the |
//|    levels it sat at are drawn (LP end points, round number, old  |
//|    highs / lows, the confirm candle, the entry and stop tested). |
//|  - ENTRIES of the round-39 rule (chosen without hindsight): a   |
//|    tip whose ZOS pull wick is >= 10 pip and >= 2x the body, in   |
//|    an LP of our                                                  |
//|    side and in the cheap / dear 35% of the 5-day range, entered  |
//|    2 or 3 candles later. Arrow at the entry, line to the exit    |
//|    of the fixed 1R trade (green = won, red = lost), SL / TP.     |
//|  - next to every run start:                                     |
//|    a BUY / SELL sign at the entry proposed for that run (round   |
//|    48, hindsight): the candle just before the strongest two-     |
//|    candle advance of the 20 candles after the tip.               |
//| Input file: MQL4\Files\zo_runstart_<symbol>.csv, written by      |
//| backtest/rs_report.py. Times are MT4 server time. Read-only.     |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_RunStart - Khoanh cac diem BAT DAU DOT CHAY (nhin lai qua khu) tren chart ZOS."
#property description "Vach ngang dam = diem bat dau dot chay (xanh len, cam xuong). Dau BUY / SELL = diem vao de xuat."
#property description "BAM vao 1 diem de xem giai thich: vi tri LP, qua trinh truoc do, nen ZOS, boi canh H4, cach doc theo ZO."
#property description "InpShowEntries = true de xem them lenh cua cac luat da thu (He N, diem so, retest, mui rau)."
#property description "Doc file zo_runstart_<cap>.csv trong MQL4/Files (chay backtest/rs_report.py de tao)."
#property indicator_chart_window
#property indicator_buffers 0

input string InpFile         = "";             // Overlay file (empty = zo_runstart_<symbol>.csv)
input int    InpDaysBack     = 120;            // Points of the last N days only (0 = all, slower)
input int    InpMinRunPips   = 30;             // Smallest run shown (30 = all, 60 = M and L, 100 = L only)
input string InpTypes        = "";             // Readings shown, comma list of code prefixes (empty = all): EDGE, DEEP, FRESH, FLIP, SHS, CONT, CIVIL, WAVE_END, IN_LP, NONE
input bool   InpShowRuns     = true;           // Run starts (hindsight circles)
input bool   InpMarkBest     = true;           // Buy / sell sign = the entry proposed next to each run start (hindsight, round 48)
input color  InpClrBestBuy   = clrAqua;
input color  InpClrBestSell  = clrMagenta;
input bool   InpShowEntries  = true;           // Entry arrows of the chosen rule (no hindsight in the choice)
input bool   InpShowFillers  = true;           // System N: also the filler trades (taken only while the week has < 3 trades)
input int    InpRule         = 5;              // Rule: 5 = SCORE LEARNT FROM THE MARKED ENTRIES (round 49, from 7/2024, SL < 13 pip), 4 = SYSTEM N (round 47: ZEAR2-style core + fillers, ZEAR2 exit), 3 = SCORE of all criteria (round 43, from 7/2024), 1 = retest + H4 weak colour (round 40), 0 = wick tip (round 39), 2 = 0 and 1
input int    InpScoreTop     = 5;              // Score rule: keep the best N% of the scores: 2, 5 or 10
input bool   InpRetestWide   = false;          // Retest rule: also the 35-50% band of the 5-day range (more entries, about break-even)
input int    InpEntryAfter   = 2;              // Entry N candles after the tip: 2 or 3 (0 = both)
input bool   InpSkipOppColor = true;           // Skip entries whose entry candle is still red (buy) / green (sell) on ZOS
input bool   InpShowSlTp     = true;           // SL / TP segments of each entry
input color  InpClrWin       = clrLime;
input color  InpClrLoss      = clrRed;
input bool   InpShowFailed   = false;          // Also the swing points that failed (grey dots)
input bool   InpShowRunLine  = true;           // Thin line from the start to the end of the run
input bool   InpShowLabel    = true;           // Size and pips next to each point
input color  InpClrBuy       = clrDodgerBlue;
input color  InpClrSell      = clrOrange;
input color  InpClrFailed    = clrDimGray;
input color  InpClrLevel     = clrYellow;      // Levels of the clicked point
input int    InpNoteFontSize = 9;              // Font size of the panel
input int    InpNoteCorner   = 1;              // Panel corner: 0 top left, 1 top right, 2 bottom left, 3 bottom right
input color  InpNoteBack     = C'20,24,32';

#define PFX   "ZORS_"
#define PANEL "ZORSP_"
#define LEVEL "ZORSL_"
#define PANEL_ROWS 70

long g_fileMod = -2;
double g_sumR = 0;      // system N: sum of the results in R of the drawn trades
int    g_flat = 0;      // system N: trades closed at break-even
int  g_marks = 0;

// Points kept for the click panel.
int      g_id[];
int      g_dir[];
bool     g_run[];
bool     g_ent[];        // an entry of the rule (E row)
datetime g_tPiv[];
datetime g_tConf[];
double   g_px[];
double   g_entry[];
double   g_sl[];
string   g_head[];
string   g_note[];
// Levels of the kept points.
int      g_vId[];
string   g_vLabel[];
double   g_vPx[];
datetime g_vT[];
int      g_shown = -1;

string g_pText[];
color  g_pClr[];

string FileName()
{
   return InpFile != "" ? InpFile : "zo_runstart_" + Symbol() + ".csv";
}

int OnInit()
{
   EventSetTimer(20);
   DrawAll();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, PFX);
   ObjectsDeleteAll(0, PANEL);
   ObjectsDeleteAll(0, LEVEL);
   Comment("");
}

int OnCalculate(const int rates_total, const int prev_calculated, const datetime &time[], const double &open[],
                const double &high[], const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   return rates_total;
}

void OnTimer()
{
   if(FileGetInteger(FileName(), FILE_MODIFY_DATE, false) != g_fileMod)
      DrawAll();
}

// A click on a point opens its panel and draws its levels; a second click, or a click on the panel, closes it.
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id != CHARTEVENT_OBJECT_CLICK)
      return;
   if(StringFind(sparam, PANEL) == 0)
   {
      Hide();
      return;
   }
   if(StringFind(sparam, PFX) != 0)
      return;
   // Object names: ZORS_<kind letter><index>
   int k = (int)StringToInteger(StringSubstr(sparam, StringLen(PFX) + 1));
   if(k < 0 || k >= ArraySize(g_id))
      return;
   if(g_shown == k)
      Hide();
   else
      Show(k);
}

void Hide()
{
   ObjectsDeleteAll(0, PANEL);
   ObjectsDeleteAll(0, LEVEL);
   g_shown = -1;
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Panel                                                            |
//+------------------------------------------------------------------+
bool PanelRight() { return InpNoteCorner == 1 || InpNoteCorner == 3; }
bool PanelLower() { return InpNoteCorner >= 2; }
int  PanelWidth() { return 20 + (int)(66 * InpNoteFontSize * 0.85); }

ENUM_BASE_CORNER PanelCorner()
{
   if(PanelLower())
      return PanelRight() ? CORNER_RIGHT_LOWER : CORNER_LEFT_LOWER;
   return PanelRight() ? CORNER_RIGHT_UPPER : CORNER_LEFT_UPPER;
}

void PanelAdd(string text, color clr)
{
   int n = ArraySize(g_pText);
   if(n >= PANEL_ROWS)
      return;
   ArrayResize(g_pText, n + 1);
   ArrayResize(g_pClr, n + 1);
   g_pText[n] = text;
   g_pClr[n] = clr;
}

// Chart labels hold at most 63 characters: long lines are wrapped at a space.
void AddWrapped(string text, color clr)
{
   int width = 62;
   while(StringLen(text) > 0)
   {
      if(StringLen(text) <= width)
      {
         PanelAdd(text, clr);
         break;
      }
      int cut = -1;
      for(int p = width; p > 20; p--)
         if(StringGetCharacter(text, p) == ' ')
         {
            cut = p;
            break;
         }
      if(cut < 0)
      {
         PanelAdd(StringSubstr(text, 0, width), clr);
         text = "   " + StringSubstr(text, width);
      }
      else
      {
         PanelAdd(StringSubstr(text, 0, cut), clr);
         text = "   " + StringSubstr(text, cut + 1);
      }
   }
}

void PanelDraw()
{
   int n = ArraySize(g_pText), h = InpNoteFontSize + 6, w = PanelWidth();
   int margin = 6, top = 18;
   string bg = PANEL + "bg";
   ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, bg, OBJPROP_CORNER, PanelCorner());
   ObjectSetInteger(0, bg, OBJPROP_XDISTANCE, PanelRight() ? margin + w : margin);
   ObjectSetInteger(0, bg, OBJPROP_YDISTANCE, PanelLower() ? margin + n * h + 12 : top);
   ObjectSetInteger(0, bg, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, bg, OBJPROP_YSIZE, n * h + 12);
   ObjectSetInteger(0, bg, OBJPROP_BGCOLOR, InpNoteBack);
   ObjectSetInteger(0, bg, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, bg, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, bg, OBJPROP_BACK, false);
   ObjectSetInteger(0, bg, OBJPROP_SELECTABLE, false);
   for(int r = 0; r < n; r++)
   {
      string name = PANEL + IntegerToString(r);
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_CORNER, PanelCorner());
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, PanelLower() ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, PanelRight() ? margin + w - 8 : margin + 8);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, PanelLower() ? margin + 6 + (n - 1 - r) * h : top + 6 + r * h);
      ObjectSetString(0, name, OBJPROP_FONT, "Consolas");
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpNoteFontSize);
      ObjectSetInteger(0, name, OBJPROP_COLOR, g_pClr[r]);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetString(0, name, OBJPROP_TEXT, g_pText[r]);
   }
}

color NoteColor(string line)
{
   if(StringFind(line, "VI TRI:") == 0)        return clrGold;
   if(StringFind(line, "LUAT:") == 0)          return clrAqua;
   if(StringFind(line, "DIEM VAO DE XUAT") == 0) return clrAqua;
   if(StringFind(line, "CHUOI:") == 0)         return clrAqua;
   if(StringFind(line, "CUM NEN:") == 0)       return clrWhite;
   if(StringFind(line, "KET QUA: LAI") == 0)   return clrLime;
   if(StringFind(line, "KET QUA: LO") == 0)    return clrTomato;
   if(StringFind(line, "KET QUA: THANG") == 0) return clrLime;
   if(StringFind(line, "KET QUA: THUA") == 0)  return clrTomato;
   if(StringFind(line, "SAU DO:") == 0)        return clrLightSkyBlue;
   if(StringFind(line, "DOC THEO ZO:") == 0)   return clrKhaki;
   if(StringFind(line, "UNG HO") == 0)         return clrLime;
   if(StringFind(line, "KHONG UNG HO") == 0)   return clrTomato;
   if(StringFind(line, "BOI CANH:") == 0)      return clrSilver;
   return clrWhite;
}

void LevelLine(string name, datetime t0, datetime t1, double p, color clr, int style, string label)
{
   ObjectCreate(0, name, OBJ_TREND, 0, t0, p, t1, p);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, label + " " + DoubleToString(p, Digits));
   ObjectCreate(0, name + "t", OBJ_TEXT, 0, t1, p);
   ObjectSetString(0, name + "t", OBJPROP_TEXT, " " + label + " " + DoubleToString(p, Digits));
   ObjectSetInteger(0, name + "t", OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name + "t", OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, name + "t", OBJPROP_FONTSIZE, 7);
   ObjectSetInteger(0, name + "t", OBJPROP_SELECTABLE, false);
}

void Show(int k)
{
   ObjectsDeleteAll(0, PANEL);
   ObjectsDeleteAll(0, LEVEL);
   g_shown = k;
   ArrayResize(g_pText, 0);
   ArrayResize(g_pClr, 0);
   AddWrapped(g_head[k], g_ent[k] ? clrWhite : g_run[k] ? clrAqua : clrGray);
   string parts[];
   int n = StringSplit(g_note[k], '|', parts);
   for(int i = 0; i < n; i++)
      AddWrapped(parts[i], NoteColor(parts[i]));
   PanelAdd("(vach vang = cac moc tai diem nay; bam lai de dong)", clrGray);
   PanelDraw();

   // The levels the point sat at, from 2 days before it to 1 day after.
   datetime t0 = g_tPiv[k] - 2 * 86400, t1 = g_tPiv[k] + 86400;
   int c = 0;
   for(int v = 0; v < ArraySize(g_vId); v++)
   {
      if(g_vId[v] != g_id[k])
         continue;
      datetime from = g_vT[v] > 0 && g_vT[v] < t0 ? g_vT[v] : t0;
      LevelLine(LEVEL + IntegerToString(c++), from, t1, g_vPx[v], InpClrLevel, STYLE_DOT, g_vLabel[v]);
   }
   // The confirm candle (what was known when the point could first be traded), the entry and the stop tested.
   string vl = LEVEL + "conf";
   ObjectCreate(0, vl, OBJ_VLINE, 0, g_tConf[k] - PeriodSeconds(PERIOD_M15), 0);
   ObjectSetInteger(0, vl, OBJPROP_COLOR, clrDimGray);
   ObjectSetInteger(0, vl, OBJPROP_STYLE, STYLE_DOT);
   ObjectSetInteger(0, vl, OBJPROP_BACK, true);
   ObjectSetInteger(0, vl, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, vl, OBJPROP_TOOLTIP, "Nen xac nhan: tu day moi biet day la diem xoay");
   if(!g_ent[k])
   {
      LevelLine(LEVEL + "ep", g_tConf[k], g_tConf[k] + 6 * 3600, g_entry[k], clrWhite, STYLE_SOLID, "vao thu");
      LevelLine(LEVEL + "sl", g_tConf[k], g_tConf[k] + 6 * 3600, g_sl[k], clrRed, STYLE_SOLID, "SL thu");
   }
   else
   {
      // The tip (wick candle) the entry was taken from.
      LevelLine(LEVEL + "tip", g_tPiv[k] - PeriodSeconds(PERIOD_M15), g_tPiv[k] + 2 * PeriodSeconds(PERIOD_M15), g_px[k], InpClrLevel, STYLE_SOLID, "mui");
   }
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Drawing                                                          |
//+------------------------------------------------------------------+
bool TypeWanted(string code)
{
   if(InpTypes == "")
      return true;
   string parts[];
   int n = StringSplit(InpTypes, ',', parts);
   for(int i = 0; i < n; i++)
   {
      string p = parts[i];
      StringTrimLeft(p);
      StringTrimRight(p);
      if(p != "" && StringFind(code, p) == 0)
         return true;
   }
   return false;
}

void DrawAll()
{
   ObjectsDeleteAll(0, PFX);
   ObjectsDeleteAll(0, PANEL);
   ObjectsDeleteAll(0, LEVEL);
   g_shown = -1;
   g_marks = 0;
   g_sumR = 0;
   g_flat = 0;
   ArrayResize(g_id, 0);     ArrayResize(g_dir, 0);   ArrayResize(g_run, 0);  ArrayResize(g_tPiv, 0);
   ArrayResize(g_ent, 0);
   ArrayResize(g_tConf, 0);  ArrayResize(g_px, 0);    ArrayResize(g_entry, 0); ArrayResize(g_sl, 0);
   ArrayResize(g_head, 0);   ArrayResize(g_note, 0);
   ArrayResize(g_vId, 0);    ArrayResize(g_vLabel, 0); ArrayResize(g_vPx, 0);  ArrayResize(g_vT, 0);
   string name = FileName();
   g_fileMod = FileGetInteger(name, FILE_MODIFY_DATE, false);
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, '\t');
   if(h == INVALID_HANDLE)
   {
      Comment("ZO_RunStart: chua co file " + name + " trong MQL4\\Files - chay backtest/rs_report.py truoc.");
      return;
   }
   datetime oldest = InpDaysBack > 0 ? Time[0] - InpDaysBack * 86400 : 0;
   int nRun = 0, nFail = 0, nS = 0, nM = 0, nL = 0, nWin = 0, nLoss = 0, nOpen = 0;
   int keptId = -1;
   while(!FileIsEnding(h))
   {
      string f[];
      ArrayResize(f, 18);
      int n = 0;
      do
      {
         string v = FileReadString(h);
         if(n < 18)
            f[n++] = v;
      }
      while(!FileIsLineEnding(h) && !FileIsEnding(h));
      if(n < 5)
         continue;
      if(f[0] == "M")
      {
         // M  id  number  time  price  label  flag: points 2 / 3 of the run start just kept
         if(!InpMarkBest || (int)StringToInteger(f[1]) != keptId || ArraySize(g_id) == 0 || (int)StringToInteger(f[2]) != 6)
            continue;
         int pk = ArraySize(g_id) - 1;
         if(!g_run[pk] || g_ent[pk])
            continue;
         datetime mt = (datetime)StringToInteger(f[3]);
         double mp = StringToDouble(f[4]);
         g_marks++;
         // MT4's own buy / sell signs (not a font glyph). The name carries the index of the run: a click opens its panel.
         string mn = PFX + "m" + IntegerToString(pk) + "_" + IntegerToString(g_marks);
         ObjectCreate(0, mn, g_dir[pk] > 0 ? OBJ_ARROW_BUY : OBJ_ARROW_SELL, 0, mt, mp);
         ObjectSetInteger(0, mn, OBJPROP_COLOR, g_dir[pk] > 0 ? InpClrBestBuy : InpClrBestSell);
         ObjectSetInteger(0, mn, OBJPROP_WIDTH, 2);
         ObjectSetInteger(0, mn, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, mn, OBJPROP_TOOLTIP, StringFormat("%s %s (dot chay bat dau %s) - bam de xem", g_dir[pk] > 0 ? "BUY" : "SELL", f[5],
                                                              TimeToString(g_tPiv[pk])));
         continue;
      }
      if(f[0] == "V")
      {
         // V  id  label  price  t0
         if((int)StringToInteger(f[1]) != keptId)
            continue;
         int vk = ArraySize(g_vId);
         ArrayResize(g_vId, vk + 1, 512);  ArrayResize(g_vLabel, vk + 1, 512);
         ArrayResize(g_vPx, vk + 1, 512);  ArrayResize(g_vT, vk + 1, 512);
         g_vId[vk] = keptId;
         g_vLabel[vk] = f[2];
         g_vPx[vk] = StringToDouble(f[3]);
         g_vT[vk] = (datetime)StringToInteger(f[4]);
         continue;
      }
      // P / X  id  dir  t_piv  price  t_conf  tier  pips  t_end  end_px  code  name  n_pro  n_con  entry  sl  note
      if(n < 17)
         continue;
      keptId = -1;
      bool run = f[0] == "P";
      bool ent = f[0] == "E";
      bool rt = ent && StringSubstr(f[6], 0, 1) == "R";      // retest rule (round 40)
      bool sc = ent && StringSubstr(f[6], 0, 1) == "S";      // score rule (round 43)
      if(ent && !InpShowEntries)
         continue;
      bool q5 = ent && StringSubstr(f[6], 0, 1) == "Q";      // round-49 score: drawn like system N (result in R)
      bool nw = ent && (q5 || StringSubstr(f[6], 0, 1) == "N");   // system N (round 47)
      if(ent && nw && (q5 ? InpRule != 5 : InpRule != 4))
         continue;
      if(ent && !nw && (InpRule == 4 || InpRule == 5))
         continue;
      if(nw && !InpShowFillers && StringFind(f[6], "F") >= 0)
         continue;
      if(ent && !nw && (sc != (InpRule == 3)))
         continue;
      if(sc)
      {
         string tier = StringSubstr(f[6], 2, 1);
         if((InpScoreTop <= 2 && tier != "a") || (InpScoreTop > 2 && InpScoreTop <= 5 && tier == "c"))
            continue;
      }
      if(rt && (InpRule == 0 || (!InpRetestWide && StringFind(f[6], "B") >= 0)))
         continue;
      if(ent && !rt && !sc && !nw && (InpRule == 1 || (InpEntryAfter != 0 && (int)StringToInteger(StringSubstr(f[6], 0, 1)) != InpEntryAfter)))
         continue;
      if(ent && !rt && !sc && !nw && InpSkipOppColor && StringFind(f[6], "C") >= 0)
         continue;
      if(run && !InpShowRuns)
         continue;
      if(!run && !ent && !InpShowFailed)
         continue;
      datetime tPiv = (datetime)StringToInteger(f[3]);
      if(tPiv < oldest)
         continue;
      int pips = (int)StringToInteger(f[7]);
      if(run && pips < InpMinRunPips)
         continue;
      if(!TypeWanted(f[10]))
         continue;
      int dir = (int)StringToInteger(f[2]);
      double px = StringToDouble(f[4]);
      int k = ArraySize(g_id);
      int rsv = 1024;
      ArrayResize(g_id, k + 1, rsv);    ArrayResize(g_dir, k + 1, rsv);   ArrayResize(g_run, k + 1, rsv);
      ArrayResize(g_tPiv, k + 1, rsv);  ArrayResize(g_tConf, k + 1, rsv); ArrayResize(g_px, k + 1, rsv);
      ArrayResize(g_entry, k + 1, rsv); ArrayResize(g_sl, k + 1, rsv);    ArrayResize(g_head, k + 1, rsv);
      ArrayResize(g_note, k + 1, rsv);
      ArrayResize(g_ent, k + 1, rsv);
      g_ent[k] = ent;
      keptId = (int)StringToInteger(f[1]);
      g_id[k] = keptId;
      g_dir[k] = dir;
      g_run[k] = run;
      g_tPiv[k] = tPiv;
      g_tConf[k] = (datetime)StringToInteger(f[5]);
      g_px[k] = px;
      g_entry[k] = StringToDouble(f[14]);
      g_sl[k] = StringToDouble(f[15]);
      g_note[k] = f[16];
      string side = dir > 0 ? "LEN" : "XUONG";
      g_head[k] = run ? StringFormat("%s %s  DOT CHAY %s co %s (%d pip) - %s  [ung ho %s / canh bao %s]", TimeToString(tPiv), DoubleToString(px, Digits),
                                     side, f[6], pips, f[11], f[12], f[13])
                      : StringFormat("%s %s  DIEM XOAY HONG (%s, di duoc %d pip) - %s  [ung ho %s / canh bao %s]", TimeToString(tPiv),
                                     DoubleToString(px, Digits), side, pips, f[11], f[12], f[13]);
      string base = IntegerToString(k);
      if(ent)
      {
         // E  id  dir  t_tip  tip  t_entry  <N candles><W|L|O>  risk pips  t_exit  exit price  code  name  pro  con  entry  sl  note
         string res = StringSubstr(f[6], 1, 1);
         datetime tIn = g_tConf[k], tOut = (datetime)StringToInteger(f[8]);
         double ep = g_entry[k], xp = StringToDouble(f[9]);
         if(tOut <= tIn)
            tOut = tIn + PeriodSeconds(PERIOD_M15);
         color rc = res == "W" ? InpClrWin : res == "L" ? InpClrLoss : clrWhite;
         string resTxt = res == "W" ? "THANG +1R" : res == "L" ? "THUA -1R" : res == "T" ? "dong sau 5 ngay" : "chua xong";
         if(nw)
         {
            // N<W|L|B>[F]:<R> - result of the ZEAR2-style exit in R
            int cp = StringFind(f[6], ":");
            double rr = cp > 0 ? StringToDouble(StringSubstr(f[6], cp + 1)) : 0;
            g_sumR += rr;
            resTxt = (res == "W" ? "LAI " : res == "L" ? "LO " : "HOA ") + (cp > 0 ? StringSubstr(f[6], cp + 1) : "") + "R";
            if(res == "B")
            {
               rc = clrWhite;
               g_flat++;
            }
         }
         if(res == "W") nWin++; else if(res == "L") nLoss++; else if(!(nw && res == "B")) nOpen++;
         string how = q5 ? "DIEM SO lan 49" : nw ? (StringFind(f[6], "F") >= 0 ? "HE N lenh phu" : "HE N lenh loi") : sc ? "DIEM SO" : rt ? "RETEST mui rau" : "vao sau " + StringSubstr(f[6], 0, 1) + " nen";
         g_head[k] = StringFormat("%s %s @%s  %s, SL %d pip%s -> %s  [%s]", TimeToString(tIn), dir > 0 ? "BUY" : "SELL",
                                  DoubleToString(ep, Digits), how, pips, nw ? "" : ", RR 1:1", resTxt, f[11]);
         string etip = StringFormat("%s %s: %s (bam de xem)", dir > 0 ? "BUY" : "SELL", how, resTxt);
         string ea = PFX + "e" + base;
         ObjectCreate(0, ea, dir > 0 ? OBJ_ARROW_BUY : OBJ_ARROW_SELL, 0, tIn, ep);
         ObjectSetInteger(0, ea, OBJPROP_COLOR, dir > 0 ? InpClrBuy : InpClrSell);
         ObjectSetInteger(0, ea, OBJPROP_WIDTH, 2);
         ObjectSetInteger(0, ea, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, ea, OBJPROP_TOOLTIP, etip);
         string ej = PFX + "j" + base;
         ObjectCreate(0, ej, OBJ_TREND, 0, tIn, ep, tOut, xp);
         ObjectSetInteger(0, ej, OBJPROP_RAY_RIGHT, false);
         ObjectSetInteger(0, ej, OBJPROP_COLOR, rc);
         ObjectSetInteger(0, ej, OBJPROP_WIDTH, 2);
         ObjectSetInteger(0, ej, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, ej, OBJPROP_TOOLTIP, etip);
         if(InpShowSlTp)
         {
            string names[2] = {"s", "p"};
            double lv[2];
            lv[0] = g_sl[k];
            lv[1] = ep + (ep - g_sl[k]);
            for(int q = 0; q < (nw ? 1 : 2); q++)       // system N has several targets: only the stop is drawn
            {
               string sn = PFX + names[q] + base;
               ObjectCreate(0, sn, OBJ_TREND, 0, tIn, lv[q], tOut, lv[q]);
               ObjectSetInteger(0, sn, OBJPROP_RAY_RIGHT, false);
               ObjectSetInteger(0, sn, OBJPROP_COLOR, C'110,110,110');
               ObjectSetInteger(0, sn, OBJPROP_STYLE, STYLE_DOT);
               ObjectSetInteger(0, sn, OBJPROP_BACK, true);
               ObjectSetInteger(0, sn, OBJPROP_SELECTABLE, false);
               ObjectSetString(0, sn, OBJPROP_TOOLTIP, (q == 0 ? "SL " : "TP 1R ") + etip);
            }
         }
         continue;
      }
      string tip = (run ? StringFormat("Bat dau dot chay %s %d pip: ", side, pips) : "Diem xoay hong: ") + f[11] + " (bam de xem)";
      color clr = run ? (dir > 0 ? InpClrBuy : InpClrSell) : InpClrFailed;

      // The point: a short thick line under / over the tip (thicker = longer run), thin and grey for a failed swing.
      // No font glyphs: Wingdings shows as squares on MT4 under Wine.
      string a = PFX + "a" + base;
      ObjectCreate(0, a, OBJ_TREND, 0, tPiv - PeriodSeconds(PERIOD_M15), px, tPiv + 2 * PeriodSeconds(PERIOD_M15), px);
      ObjectSetInteger(0, a, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, a, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, a, OBJPROP_WIDTH, !run ? 1 : f[6] == "L" ? 5 : f[6] == "M" ? 4 : 3);
      ObjectSetInteger(0, a, OBJPROP_SELECTABLE, false);
      ObjectSetString(0, a, OBJPROP_TOOLTIP, tip);
      if(!run)
      {
         nFail++;
         continue;
      }
      nRun++;
      if(f[6] == "L") nL++; else if(f[6] == "M") nM++; else nS++;
      if(InpShowRunLine)
      {
         string l = PFX + "l" + base;
         ObjectCreate(0, l, OBJ_TREND, 0, tPiv, px, (datetime)StringToInteger(f[8]), StringToDouble(f[9]));
         ObjectSetInteger(0, l, OBJPROP_RAY_RIGHT, false);
         ObjectSetInteger(0, l, OBJPROP_COLOR, clr);
         ObjectSetInteger(0, l, OBJPROP_STYLE, STYLE_DOT);
         ObjectSetInteger(0, l, OBJPROP_WIDTH, 1);
         ObjectSetInteger(0, l, OBJPROP_BACK, true);
         ObjectSetInteger(0, l, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, l, OBJPROP_TOOLTIP, tip);
      }
      if(InpShowLabel)
      {
         string t = PFX + "t" + base;
         ObjectCreate(0, t, OBJ_TEXT, 0, tPiv, px);
         ObjectSetString(0, t, OBJPROP_TEXT, StringFormat("   %s %d", f[6], pips));
         ObjectSetInteger(0, t, OBJPROP_COLOR, clr);
         ObjectSetInteger(0, t, OBJPROP_ANCHOR, dir > 0 ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER);
         ObjectSetInteger(0, t, OBJPROP_FONTSIZE, 7);
         ObjectSetInteger(0, t, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, t, OBJPROP_TOOLTIP, tip);
      }
   }
   FileClose(h);
   string entTxt = "";
   if(InpShowEntries)
      if(InpRule == 5)
         entTxt = StringFormat("\nDIEM SO lan 49 (hoc tu diem vao da danh dau, SL < 13 pip, tu 7/2024), thoat theo LP H4 + giu lenh: %d lenh, lai %d, hoa %d, lo %d, tong %+.1fR",
                               nWin + nLoss + g_flat + nOpen, nWin, g_flat, nLoss, g_sumR);
      else if(InpRule == 4)
         entTxt = StringFormat("\n%s%s, thoat theo LP H4 + giu lenh: %d lenh, lai %d, hoa %d, lo %d, tong %+.1fR", "HE N (lan 47: loi ke thua ZEAR2)",
                               InpShowFillers ? " + lenh phu" : "", nWin + nLoss + g_flat + nOpen, nWin, g_flat, nLoss, g_sumR);
      else
         entTxt = StringFormat("\nLuat %s, RR 1:1, SL >= 7 pip: %d lenh, thang %d, thua %d%s = %.0f%% thang",
                            InpRule == 3 ? "DIEM SO top " + IntegerToString(InpScoreTop) + "% (lan 43, tu 7/2024)" : InpRule == 1 ? "RETEST mui rau + H4 mau yeu phe nguoc + " + (InpRetestWide ? "50%" : "35%") + " bien do (lan 40)"
                            : InpRule == 0 ? "mui rau lan 39" : "lan 39 + lan 40", nWin + nLoss + nOpen, nWin, nLoss,
                            nOpen > 0 ? StringFormat(", chua xong %d", nOpen) : "", nWin + nLoss > 0 ? 100.0 * nWin / (nWin + nLoss) : 0);
   Comment(StringFormat("ZO_RunStart: %d diem bat dau dot chay (S %d, M %d, L %d)%s trong %s - bam vao 1 diem de xem giai thich",
                        nRun, nS, nM, nL, InpShowFailed ? StringFormat(", %d diem hong", nFail) : "",
                        InpDaysBack > 0 ? IntegerToString(InpDaysBack) + " ngay gan nhat" : "toan bo du lieu") + entTxt);
   ChartRedraw();
}

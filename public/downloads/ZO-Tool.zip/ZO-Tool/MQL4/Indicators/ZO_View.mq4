﻿//+------------------------------------------------------------------+
//| ZO_View.mq4                                                      |
//| Chart view for ZOS:                                              |
//|  - LPs of the chart's timeframe as rectangles (GLP green, RLP    |
//|    red, not broken = gold outline, already run = grey outline),  |
//|    Main thicker and labelled, Shields labelled; redrawn whenever |
//|    the chart timeframe changes.                                  |
//|  - Notable candles: break (arrow), clear / fail of an LP (x),    |
//|    Main confirmation (star), standalone one-wick Build (dot:     |
//|    candidate end of a wave), shrinking two-wick candles at an LP |
//|    ("thu nến").                                                  |
//|  - Panel (chart labels, not Comment(), so ZOS cannot overwrite   |
//|    it) with the reading of W1 / D1 / H4 / H1 / M15 and the bias  |
//|    of both trading frames; refreshed every InpPanelMinutes and   |
//|    on every new bar of the chart.                                |
//| Objects are rebuilt only on a new bar, never on every tick, so   |
//| nothing flickers. Other timeframes come from ZO_LP's shared      |
//| files (ZO_LP running on each timeframe's chart).                 |
//+------------------------------------------------------------------+
#property strict
#property indicator_chart_window
#property indicator_buffers 0

#include <ZO/ZoCore.mqh>

input string InpZosName       = "ZOS";                  // ZOS indicator file name
input int    InpLookback      = 500;                    // Bars scanned on the chart timeframe
input int    InpPerSide       = 3;                      // LP boxes above and below price (Mains always drawn)
input bool   InpShowFresh     = true;                   // Boxes for LPs not broken yet
input bool   InpShowRun       = true;                   // Boxes for LPs already retested and left
input int    InpMarkBars      = 300;                    // Candles marked back from the last bar
input bool   InpMarkBreak     = true;                   // Arrow on the candle that broke an LP
input bool   InpMarkDeath     = true;                   // Mark on the candle that cleared / failed an LP
input bool   InpMarkMain      = true;                   // Star on the candle that made an LP Main
input bool   InpMarkBuild1    = true;                   // Dot on standalone one-wick Build candles
input bool   InpMarkShrink    = true;                   // "thu nến" where 3 of 5 candles are two-wick at an LP
input bool   InpPanel         = true;                   // Analysis panel
input string InpPanelTfs      = "10080,1440,240,60,15"; // Panel timeframes
input int    InpPanelMinutes  = 60;                     // Panel refresh (minutes; also on each new bar)
input bool   InpEstimate      = true;                   // Estimate timeframes without a ZO_LP file (iCustom)
input string InpLongCtx       = "10080,1440";           // Long frame context (W1, D1)
input string InpShortCtx      = "240,60";               // Short frame context (H4, H1)
input int    InpPanelCorner   = 0;                      // 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right
input int    InpPanelX        = 8;
input int    InpPanelY        = 18;
input string InpPanelFont     = "Consolas";
input int    InpPanelFontSize = 8;
input color  InpPanelText     = clrWhiteSmoke;
input color  InpPanelBg       = C'20,20,28';
input color  InpClrGlp        = C'0,95,0';
input color  InpClrGlpRetest  = C'0,150,0';
input color  InpClrRlp        = C'110,0,0';
input color  InpClrRlpRetest  = C'175,0,0';
input color  InpClrFresh      = clrGold;
input color  InpClrRun        = C'100,100,100';
input color  InpClrMark       = clrOrange;

#define VIEW_PREFIX  "ZOVIEW_"
#define PANEL_PREFIX "ZOVIEWP_"
#define PANEL_LINES  24

ZoZone   g_all[];
ZoTf     g_d[];
int      g_tfs[];
datetime g_lastBar = 0;
datetime g_panelTime = 0;
int      g_panelRows = 0;

//+------------------------------------------------------------------+
int OnInit()
{
   g_zoName = InpZosName;
   g_zoLookback = InpLookback;
   ArrayResize(g_tfs, 0);
   string parts[];
   int n = StringSplit(InpPanelTfs, ',', parts);
   for(int i = 0; i < n; i++)
      AddTf((int)StringToInteger(parts[i]));
   AddTf(Period());
   ArrayResize(g_d, ArraySize(g_tfs));
   g_lastBar = 0;
   g_panelTime = 0;
   EventSetTimer(30);
   return INIT_SUCCEEDED;
}

void AddTf(int tf)
{
   if(tf <= 0)
      return;
   for(int i = 0; i < ArraySize(g_tfs); i++)
      if(g_tfs[i] == tf)
         return;
   int k = ArraySize(g_tfs);
   ArrayResize(g_tfs, k + 1);
   g_tfs[k] = tf;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectsDeleteAll(0, VIEW_PREFIX);
   ObjectsDeleteAll(0, PANEL_PREFIX);
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   if(Time[0] != g_lastBar)
   {
      g_lastBar = Time[0];
      LoadAll();
      DrawZones();
      DrawMarks();
      if(InpPanel)
         DrawPanel();
      ChartRedraw();
   }
   return rates_total;
}

void OnTimer()
{
   if(!InpPanel || TimeCurrent() - g_panelTime < InpPanelMinutes * 60)
      return;
   LoadAll();
   DrawPanel();
   ChartRedraw();
}

//+------------------------------------------------------------------+
void LoadAll()
{
   ArrayResize(g_all, 0);
   for(int i = 0; i < ArraySize(g_tfs); i++)
      ZoLoadTf(g_tfs[i], g_all, g_d[i], InpEstimate || g_tfs[i] == Period());
}

int DataIndex(int tf)
{
   for(int i = 0; i < ArraySize(g_tfs); i++)
      if(g_tfs[i] == tf)
         return i;
   return -1;
}

//+------------------------------------------------------------------+
//| LP boxes                                                         |
//+------------------------------------------------------------------+
color BoxColor(const ZoZone &z)
{
   if(z.state == ZO_ST_FRESH) return InpClrFresh;
   if(z.state == ZO_ST_RUN)   return InpClrRun;
   if(z.dir > 0) return z.state == ZO_ST_RETEST ? InpClrGlpRetest : InpClrGlp;
   return z.state == ZO_ST_RETEST ? InpClrRlpRetest : InpClrRlp;
}

void DrawZones()
{
   ObjectsDeleteAll(0, VIEW_PREFIX + "Z");
   int sel[];
   int n = ZoSelect(g_all, Period(), Bid, InpPerSide, InpShowFresh, sel);
   datetime tEnd = Time[0] + PeriodSeconds() * 10;
   for(int i = 0; i < n; i++)
   {
      ZoZone z = g_all[sel[i]];
      if(z.state == ZO_ST_RUN && !InpShowRun && !z.isMain)
         continue;
      string name = VIEW_PREFIX + "Z" + IntegerToString((long)z.t0);
      bool filled = (z.state == ZO_ST_BROKEN || z.state == ZO_ST_RETEST);
      ObjectCreate(0, name, OBJ_RECTANGLE, 0, z.t0, z.hi, tEnd, z.lo);
      ObjectSetInteger(0, name, OBJPROP_COLOR, BoxColor(z));
      ObjectSetInteger(0, name, OBJPROP_BACK, filled);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, z.isMain ? 3 : 1);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);

      string label = ZoKind(z) + "-" + ZoTfName(z.tf) + " " + ZoDate(z.t0) + "  " + ZoStateVi(z.state);
      if(z.retests > 1)             label += " #" + IntegerToString(z.retests);
      if(z.isMain)                  label = "MAIN  " + label;
      if(ZoIsShield(g_all, sel[i])) label += "  shield";
      string t = name + "_t";
      ObjectCreate(0, t, OBJ_TEXT, 0, tEnd, z.hi);
      ObjectSetString(0, t, OBJPROP_TEXT, label);
      ObjectSetInteger(0, t, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);
      ObjectSetInteger(0, t, OBJPROP_COLOR, z.isMain ? clrWhite : clrSilver);
      ObjectSetInteger(0, t, OBJPROP_FONTSIZE, 7);
      ObjectSetInteger(0, t, OBJPROP_SELECTABLE, false);
   }
}

//+------------------------------------------------------------------+
//| Notable candles                                                  |
//+------------------------------------------------------------------+
void Arrow(string name, datetime t, double price, int code, color clr, int anchor, string tip)
{
   ObjectCreate(0, name, OBJ_ARROW, 0, t, price);
   ObjectSetInteger(0, name, OBJPROP_ARROWCODE, code);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, tip);
}

void Label(string name, datetime t, double price, string text, color clr, int anchor, int size)
{
   ObjectCreate(0, name, OBJ_TEXT, 0, t, price);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, size);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

double BarHigh(datetime t) { int s = iBarShift(Symbol(), Period(), t); return s >= 0 ? High[s] : 0; }
double BarLow(datetime t)  { int s = iBarShift(Symbol(), Period(), t); return s >= 0 ? Low[s] : 0; }

bool InsideAnyZone(double h, double l)
{
   for(int i = 0; i < ArraySize(g_all); i++)
      if(g_all[i].tf == Period() && g_all[i].dir != 0 && ZoIsAlive(g_all[i]) && h >= g_all[i].lo && l <= g_all[i].hi)
         return true;
   return false;
}

void DrawMarks()
{
   ObjectsDeleteAll(0, VIEW_PREFIX + "M");
   datetime oldest = Time[MathMin(InpMarkBars, Bars - 1)];
   double off = 3 * ZoPip();

   for(int i = 0; i < ArraySize(g_all); i++)
   {
      ZoZone z = g_all[i];
      if(z.tf != Period())
         continue;
      string base = VIEW_PREFIX + "M" + IntegerToString((long)z.t0);
      if(InpMarkBreak && z.tBreak >= oldest && z.dir != 0)
      {
         if(z.dir > 0)
            Arrow(base + "_b", z.tBreak, BarLow(z.tBreak) - off, 233, clrLimeGreen, ANCHOR_TOP,
                  "Break lên: " + ZoShortName(z) + " thành GLP");
         else
            Arrow(base + "_b", z.tBreak, BarHigh(z.tBreak) + off, 234, clrTomato, ANCHOR_BOTTOM,
                  "Break xuống: " + ZoShortName(z) + " thành RLP");
      }
      if(InpMarkDeath && z.tDead >= oldest && z.dir != 0)
      {
         // Buyers kill an RLP from below -> mark above the candle, and vice versa.
         bool above = z.dir < 0;
         double y = above ? BarHigh(z.tDead) + 2 * off : BarLow(z.tDead) - 2 * off;
         string what = (z.state == ZO_ST_CLEARED ? "clear " : "thủng ") + (z.dir > 0 ? "G " : "R ") + ZoDate(z.t0);
         Label(base + "_d", z.tDead, y, "✖ " + what, InpClrMark, above ? ANCHOR_LOWER : ANCHOR_UPPER, 7);
      }
      if(InpMarkMain && z.isMain && z.tMain >= oldest)
      {
         bool above = z.dir < 0;
         double y = above ? BarHigh(z.tMain) + 5 * off : BarLow(z.tMain) - 5 * off;
         Label(base + "_m", z.tMain, y, "★ MAIN " + (z.dir > 0 ? "G " : "R ") + ZoDate(z.t0), clrWhite,
               above ? ANCHOR_LOWER : ANCHOR_UPPER, 8);
      }
   }

   int last = MathMin(InpMarkBars, Bars - 3);
   int lastShrink = 1000000;   // shift of the last "thu nến" mark (marks at least 5 bars apart)
   for(int s = last; s >= 1; s--)
   {
      double h, l, o, c;
      bool build;
      if(!ZoReadChart(Period(), s, h, l, o, c, build))
         continue;
      bool upWick = h - MathMax(o, c) >= g_zoMinWickPts * Point;
      bool dnWick = MathMin(o, c) - l >= g_zoMinWickPts * Point;

      // Standalone one-wick Build (neither neighbour is a Build): often the candle that ends a wave.
      if(InpMarkBuild1 && build && (upWick != dnWick))
      {
         double h2, l2, o2, c2;
         bool bPrev = false, bNext = false;
         ZoReadChart(Period(), s + 1, h2, l2, o2, c2, bPrev);
         if(s > 1)
            ZoReadChart(Period(), s - 1, h2, l2, o2, c2, bNext);
         if(!bPrev && !bNext)
         {
            bool top = upWick;   // wick on top: marks a possible High
            Arrow(VIEW_PREFIX + "Mb" + IntegerToString((long)Time[s]), Time[s], top ? High[s] + off : Low[s] - off,
                  159, clrYellow, top ? ANCHOR_BOTTOM : ANCHOR_TOP,
                  "Build 1 đầu: " + (top ? "có thể là đỉnh sóng" : "có thể là đáy sóng"));
         }
      }

      // "Thu nến": 3 of 5 two-wick small-body candles while price sits at a live LP of this timeframe.
      if(InpMarkShrink && lastShrink - s > 4)
      {
         int cnt = 0;
         for(int k = s; k < s + 5; k++)
         {
            double hh, ll, oo, cc;
            bool bb;
            if(!ZoReadChart(Period(), k, hh, ll, oo, cc, bb))
               continue;
            if(hh > MathMax(oo, cc) && ll < MathMin(oo, cc) && MathAbs(cc - oo) <= (hh - ll) * 0.4)
               cnt++;
         }
         if(cnt >= 3 && InsideAnyZone(High[s], Low[s]))
         {
            Label(VIEW_PREFIX + "Ms" + IntegerToString((long)Time[s]), Time[s], Low[s] - off, "thu nến",
                  clrSilver, ANCHOR_UPPER, 7);
            lastShrink = s;
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Panel                                                            |
//+------------------------------------------------------------------+
string g_lines[];

void Add(string s)
{
   int k = ArraySize(g_lines);
   ArrayResize(g_lines, k + 1);
   g_lines[k] = s;
}

string PadRight(string s, int n)
{
   while(StringLen(s) < n)
      s += " ";
   return s;
}

void TfBlock(int tf)
{
   int di = DataIndex(tf);
   if(di < 0)
      return;
   ZoTf d = g_d[di];
   if(d.source == ZO_SRC_NONE)
   {
      Add(PadRight(ZoTfName(tf), 4) + "không có dữ liệu - chạy ZO_LP trên chart " + ZoTfName(tf));
      return;
   }
   int code;
   int run = ZoColorRun(d, code);
   string s = PadRight(ZoTfName(tf), 4) + "ZOS " + ZoColorShort(code) + " x" + IntegerToString(run) +
              " | xu thế " + ZoTrendText(d.trend);
   if(d.trendTime > 0)
      s += " (" + ZoDate(d.trendTime) + ")";
   if(ZoTwoWickCount(d, 5) >= 3)
      s += " | thu nến";
   s += ZoSourceNote(d);
   Add(s);

   string s2 = "    ";
   int at = ZoZoneAt(g_all, tf, Bid);
   if(at >= 0)
   {
      ZoZone z = g_all[at];
      s2 += StringFormat("TRONG %s %s %.0f%% | ", ZoKind(z), ZoDate(z.t0),
                         (Bid - z.lo) / MathMax(z.hi - z.lo, Point) * 100);
   }
   int up = ZoNeighbour(g_all, tf, Bid, true), dn = ZoNeighbour(g_all, tf, Bid, false);
   s2 += "↑ " + (up >= 0 ? StringFormat("%s %s +%.0fp", ZoKind(g_all[up]), ZoDate(g_all[up].t0), ZoDist(g_all[up], Bid)) : "trống");
   s2 += "  ↓ " + (dn >= 0 ? StringFormat("%s %s -%.0fp", ZoKind(g_all[dn]), ZoDate(g_all[dn].t0), ZoDist(g_all[dn], Bid)) : "trống");
   Add(s2);

   int mg = ZoMainOf(g_all, tf, 1), mr = ZoMainOf(g_all, tf, -1);
   if(mg >= 0 || mr >= 0)
   {
      string s3 = "    Main:";
      if(mg >= 0) s3 += " mua " + ZoPx(g_all[mg].lo) + "-" + ZoPx(g_all[mg].hi) + " (" + ZoDate(g_all[mg].t0) + ")";
      if(mr >= 0) s3 += " bán " + ZoPx(g_all[mr].lo) + "-" + ZoPx(g_all[mr].hi) + " (" + ZoDate(g_all[mr].t0) + ")";
      Add(s3);
   }
}

int TrendOf(int tf)
{
   int di = DataIndex(tf);
   return di >= 0 ? g_d[di].trend : 0;
}

string FrameLine(string title, string ctx)
{
   string parts[];
   int n = StringSplit(ctx, ',', parts);
   if(n < 2)
      return "";
   int a = (int)StringToInteger(parts[0]), b = (int)StringToInteger(parts[1]);
   int ta = TrendOf(a), tb = TrendOf(b);
   string bias = (ta > 0 && tb > 0) ? "ƯU TIÊN MUA" : (ta < 0 && tb < 0) ? "ƯU TIÊN BÁN" : "ĐỨNG NGOÀI / scalp theo " + ZoTfName(a);
   return title + ": " + bias + "  (" + ZoTfName(a) + " " + ZoTrendText(ta) + ", " + ZoTfName(b) + " " + ZoTrendText(tb) + ")";
}

void DrawPanel()
{
   ArrayResize(g_lines, 0);
   datetime hn = ZoHanoiNow();
   Add("ZO_View " + Symbol() + "  " + StringFormat("%02d:%02d %d/%d (HN)", TimeHour(hn), TimeMinute(hn), TimeDay(hn), TimeMonth(hn)) +
       "  giá " + ZoPx(Bid));
   for(int i = 0; i < ArraySize(g_tfs); i++)
   {
      string parts[];
      int n = StringSplit(InpPanelTfs, ',', parts);
      bool listed = false;
      for(int p = 0; p < n; p++)
         if((int)StringToInteger(parts[p]) == g_tfs[i])
            listed = true;
      if(listed)
         TfBlock(g_tfs[i]);
   }
   Add(FrameLine("Bộ dài ", InpLongCtx));
   Add(FrameLine("Bộ ngắn", InpShortCtx));

   int corner = InpPanelCorner;
   bool bottom = (corner == 2 || corner == 3);
   int lh = InpPanelFontSize + 6;
   int rows = MathMin(ArraySize(g_lines), PANEL_LINES);

   string bg = PANEL_PREFIX + "bg";
   if(ObjectFind(0, bg) < 0)
   {
      ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, bg, OBJPROP_BGCOLOR, InpPanelBg);
      ObjectSetInteger(0, bg, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, bg, OBJPROP_COLOR, InpPanelBg);
      ObjectSetInteger(0, bg, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, bg, OBJPROP_BACK, false);
   }
   ObjectSetInteger(0, bg, OBJPROP_CORNER, corner);
   int width = InpPanelFontSize * 85;
   // Rectangle labels are positioned by their top-left point, also in the right-hand corners.
   ObjectSetInteger(0, bg, OBJPROP_XDISTANCE, (corner == 1 || corner == 3) ? InpPanelX - 4 + width : InpPanelX - 4);
   ObjectSetInteger(0, bg, OBJPROP_YDISTANCE, bottom ? InpPanelY + rows * lh + 2 : InpPanelY - 4);
   ObjectSetInteger(0, bg, OBJPROP_XSIZE, width);
   ObjectSetInteger(0, bg, OBJPROP_YSIZE, rows * lh + 6);

   for(int r = 0; r < PANEL_LINES; r++)
   {
      string name = PANEL_PREFIX + IntegerToString(r);
      if(r >= rows)
      {
         if(ObjectFind(0, name) >= 0)
            ObjectDelete(0, name);
         continue;
      }
      if(ObjectFind(0, name) < 0)
      {
         ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
         ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      }
      ObjectSetInteger(0, name, OBJPROP_CORNER, corner);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, corner == 1 || corner == 3 ? ANCHOR_RIGHT_UPPER : ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, InpPanelX);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, bottom ? InpPanelY + (rows - r) * lh : InpPanelY + r * lh);
      ObjectSetString(0, name, OBJPROP_FONT, InpPanelFont);
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, InpPanelFontSize);
      ObjectSetInteger(0, name, OBJPROP_COLOR, r == 0 ? clrGold : InpPanelText);
      ObjectSetString(0, name, OBJPROP_TEXT, g_lines[r]);
   }
   g_panelRows = rows;
   g_panelTime = TimeCurrent();
}

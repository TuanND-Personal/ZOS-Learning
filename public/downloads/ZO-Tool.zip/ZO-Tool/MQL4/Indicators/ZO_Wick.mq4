﻿//+------------------------------------------------------------------+
//| ZO_Wick.mq4                                                      |
//| Marks, on the chart's own timeframe, the ZOS candles that match  |
//| the "long one-sided wick" entry idea, so the detection can be    |
//| checked by eye (wicks and bodies are those of the ZOS candle,    |
//| not of the price candle):                                        |
//|  - candle A: a wick on one side at least InpMinWickPips long     |
//|    (and InpBodyMult x its body when > 0), longer than the        |
//|    opposite wick. EVERY candle with such a wick gets a dot at    |
//|    the wick tip, entry or not (yellow when the wick pokes into a |
//|    sensitive point: High / Low of an H4 / D1 / W1 LP or a round  |
//|    number, white otherwise);                                     |
//|  - entry candle: the FIRST candle, up to InpBack candles after   |
//|    A, whose wick on A's side is gone (<= InpGone x A's wick) or  |
//|    that is a two-wick candle; the candles in between may still   |
//|    carry a shorter wick (the pull fades). Arrow: up = buy after  |
//|    a long lower wick, down = sell after a long upper wick;       |
//|    bright when A was at a sensitive point. InpDelay = 1 marks    |
//|    the candle after it instead (it must have no wick either).    |
//|  - optional: the pull-gone rule the ZOU system uses (U1w), as    |
//|    small circles, to compare both definitions.                   |
//| LP levels come from MQL4\Files\zo_bt_overlay_<symbol>.csv        |
//| (written by backtest/bt_lab.py). Read-only, places no orders.    |
//+------------------------------------------------------------------+
#property strict
#property description "ZO_Wick - Kiem tra dinh nghia 'nen rau dai' tren nen ZOS (gan len chart M15 co ZOS)."
#property description "Cham = moi nen ZOS co rau >= InpMinWickPips (vang: choc vao High/Low LP hoac so tron)."
#property description "Mui ten = nen dau tien het rau sau do (diem vao theo luat rau dai)."
#property description "Vong tim = cho luat U1w cua he ZOU bat. Di chuot vao de xem so do rau / than."
#property indicator_chart_window
#property indicator_buffers 0

#include <ZO/ZoCore.mqh>

input string InpZosName     = "ZOS";       // ZOS indicator file name
input int    InpLookback    = 3000;        // Candles scanned back from the last bar
input double InpMinWickPips = 10;          // Candle A: wick at least this long (pips)
input double InpBodyMult    = 0;           // Candle A: wick >= this x body (0 = not checked)
input double InpGone        = 0.1;         // Entry candle: wick on A's side <= this x A's wick
input bool   InpTwoWick     = true;        // ... or a two-wick candle also counts
input int    InpBack        = 5;           // Entry candle at most this many candles after A
input int    InpDelay       = 0;           // 0 = first candle without the wick, 1 = the candle after it
input double InpTouchPips   = 2;           // Wick tip may stop this far before the sensitive point
input bool   InpOnlyAtLevel = false;       // Draw only the candles A that poke into a sensitive point
input bool   InpShowA       = true;        // Dot on EVERY candle with a wick >= InpMinWickPips (entry or not)
input bool   InpShowU1w     = true;        // Circles where the ZOU pull-gone rule (U1w) fires
input string InpFile        = "";          // LP file (empty = zo_bt_overlay_<symbol>.csv)
input color  InpClrBuy      = clrDodgerBlue;
input color  InpClrSell     = clrOrange;
input color  InpClrDim      = clrDimGray;  // entries whose candle A is not at a sensitive point
input color  InpClrA        = clrGold;     // long wick poking into a sensitive point
input color  InpClrWick     = clrWhite;    // long wick elsewhere
input color  InpClrU1w      = clrMediumOrchid;

#define PFX "ZOWICK_"

datetime g_lastBar = 0;
// High / Low of the H4 / D1 / W1 LPs with their lifetime.
double   g_lvHi[];
double   g_lvLo[];
datetime g_lvFrom[];
datetime g_lvTo[];

int OnInit()
{
   g_zoName = InpZosName;
   g_lastBar = 0;
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   ObjectsDeleteAll(0, PFX);
   Comment("");
}

int OnCalculate(const int rates_total, const int prev_calculated,
                const datetime &time[], const double &open[], const double &high[],
                const double &low[], const double &close[], const long &tick_volume[],
                const long &volume[], const int &spread[])
{
   if(Time[0] != g_lastBar)
   {
      g_lastBar = Time[0];
      LoadLevels();
      DrawAll();
   }
   return rates_total;
}

//+------------------------------------------------------------------+
void LoadLevels()
{
   ArrayResize(g_lvHi, 0);
   ArrayResize(g_lvLo, 0);
   ArrayResize(g_lvFrom, 0);
   ArrayResize(g_lvTo, 0);
   string name = InpFile != "" ? InpFile : "zo_bt_overlay_" + Symbol() + ".csv";
   int h = FileOpen(name, FILE_READ | FILE_CSV | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE, ',');
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
   {
      string f[];
      int n = 0;
      ArrayResize(f, 16);
      do
      {
         string v = FileReadString(h);
         if(n < 16)
            f[n++] = v;
      }
      while(!FileIsLineEnding(h) && !FileIsEnding(h));
      // Z,tf,t0,created,t_break,t_dead,t_clear,hi,lo,dir,main_since
      if(n < 10 || f[0] != "Z" || StringToInteger(f[1]) < 240)
         continue;
      int k = ArraySize(g_lvHi);
      ArrayResize(g_lvHi, k + 1);
      ArrayResize(g_lvLo, k + 1);
      ArrayResize(g_lvFrom, k + 1);
      ArrayResize(g_lvTo, k + 1);
      g_lvHi[k] = StringToDouble(f[7]);
      g_lvLo[k] = StringToDouble(f[8]);
      g_lvFrom[k] = (datetime)StringToInteger(f[3]);
      g_lvTo[k] = (datetime)StringToInteger(f[5]);
   }
   FileClose(h);
}

// Sensitive point between lo and hi at time t: "" none, else its name.
string LevelIn(double lo, double hi, datetime t)
{
   double rn = MathCeil(lo / ZO_RN_STEP - 1e-9) * ZO_RN_STEP;
   if(rn <= hi + 1e-9)
      return "so tron " + DoubleToString(rn, Digits);
   for(int k = 0; k < ArraySize(g_lvHi); k++)
   {
      if(g_lvFrom[k] > t || (g_lvTo[k] > 0 && g_lvTo[k] <= t))
         continue;
      if(g_lvHi[k] >= lo && g_lvHi[k] <= hi)
         return "High LP " + DoubleToString(g_lvHi[k], Digits);
      if(g_lvLo[k] >= lo && g_lvLo[k] <= hi)
         return "Low LP " + DoubleToString(g_lvLo[k], Digits);
   }
   return "";
}

double Against(double h, double l, double o, double c, int d)
{
   double ag, tw;
   ZoPull(h, l, o, c, d, ag, tw);
   return ag;
}

// The wick on A's side is gone (<= InpGone x A's wick) or the candle is a two-wick candle.
bool Gone(double h, double l, double o, double c, int d, double aWick)
{
   double ag, tw;
   ZoPull(h, l, o, c, d, ag, tw);
   if(ag <= InpGone * aWick)
      return true;
   return InpTwoWick && ag > 0 && tw > 0 && tw >= ag;
}

void Mark(string name, datetime t, double p, int code, color clr, int anchor, int width, string tip)
{
   ObjectCreate(0, name, OBJ_ARROW, 0, t, p);
   ObjectSetInteger(0, name, OBJPROP_ARROWCODE, code);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, ZoUnaccent(tip));
}

//+------------------------------------------------------------------+
void DrawAll()
{
   ObjectsDeleteAll(0, PFX);
   int bars = MathMin(InpLookback, Bars - 5);
   if(bars < 10)
      return;
   // ZOS candles of the chart timeframe, index = shift.
   double zh[], zl[], zo[], zc[];
   bool ok[];
   ArrayResize(zh, bars + 1);
   ArrayResize(zl, bars + 1);
   ArrayResize(zo, bars + 1);
   ArrayResize(zc, bars + 1);
   ArrayResize(ok, bars + 1);
   for(int s = 1; s <= bars; s++)
   {
      bool build;
      ok[s] = ZoReadChart(Period(), s, zh[s], zl[s], zo[s], zc[s], build);
   }
   double pip = ZoPip();
   int nA = 0, nEntry = 0, nAtLevel = 0, nU = 0;
   // Every candle with a long wick gets a dot at the wick tip, whether an entry follows or not.
   if(InpShowA)
      for(int s = bars; s >= 1; s--)
      {
         if(!ok[s])
            continue;
         for(int d = 1; d >= -1; d -= 2)
         {
            double ag, tw;
            ZoPull(zh[s], zl[s], zo[s], zc[s], d, ag, tw);
            double body = MathAbs(zc[s] - zo[s]);
            if(ag < MathMax(InpBodyMult * body, InpMinWickPips * pip))
               continue;
            double lo = d > 0 ? zl[s] - InpTouchPips * pip : MathMax(zo[s], zc[s]);
            double hi = d > 0 ? MathMin(zo[s], zc[s]) : zh[s] + InpTouchPips * pip;
            string lvl = LevelIn(lo, hi, Time[s]);
            if(lvl == "" && InpOnlyAtLevel)
               continue;
            nA++;
            Mark(PFX + "A" + IntegerToString((long)Time[s]) + (d > 0 ? "b" : "s"), Time[s], d > 0 ? zl[s] : zh[s], 159,
                 lvl != "" ? InpClrA : InpClrWick, d > 0 ? ANCHOR_TOP : ANCHOR_BOTTOM, 2,
                 StringFormat("Rau %s %.1f pip (ZOS %s -> %s), than %.1f pip, rau kia %.1f pip%s%s", d > 0 ? "duoi" : "tren", ag / pip,
                              DoubleToString(d > 0 ? MathMin(zo[s], zc[s]) : MathMax(zo[s], zc[s]), Digits),
                              DoubleToString(d > 0 ? zl[s] : zh[s], Digits), body / pip, tw / pip,
                              ag <= tw ? " | rau kia dai hon -> khong tinh la nen A" : "",
                              lvl != "" ? " | choc vao " + lvl : ""));
         }
      }
   for(int s = bars - InpBack - 3; s >= 1; s--)
   {
      if(!ok[s])
         continue;
      datetime t = Time[s];
      for(int d = 1; d >= -1; d -= 2)
      {
         // s = entry candle; e = first candle without the pull (s + InpDelay); A = up to InpBack candles before e.
         int e = s + InpDelay;
         for(int back = 1; back <= InpBack && e + back <= bars; back++)
         {
            int a = e + back;
            if(!ok[a])
               continue;
            double ag, tw;
            ZoPull(zh[a], zl[a], zo[a], zc[a], d, ag, tw);
            double body = MathAbs(zc[a] - zo[a]);
            if(ag < MathMax(InpBodyMult * body, InpMinWickPips * pip) || ag <= tw)
               continue;
            // Between A and e: no longer pull (that candle would be the real A) and the pull not gone earlier.
            bool valid = true;
            for(int x = a - 1; x > e && valid; x--)
               valid = ok[x] && Against(zh[x], zl[x], zo[x], zc[x], d) < ag && !Gone(zh[x], zl[x], zo[x], zc[x], d, ag);
            for(int x = e; x >= s && valid; x--)
               valid = ok[x] && Gone(zh[x], zl[x], zo[x], zc[x], d, ag);
            if(!valid)
               break;
            double lo = d > 0 ? zl[a] - InpTouchPips * pip : MathMax(zo[a], zc[a]);
            double hi = d > 0 ? MathMin(zo[a], zc[a]) : zh[a] + InpTouchPips * pip;
            string lvl = LevelIn(lo, hi, Time[a]);
            if(lvl == "" && InpOnlyAtLevel)
               break;
            nEntry++;
            if(lvl != "")
               nAtLevel++;
            color clr = lvl != "" ? (d > 0 ? InpClrBuy : InpClrSell) : InpClrDim;
            Mark(PFX + "E" + IntegerToString((long)t) + (d > 0 ? "b" : "s"), t, d > 0 ? Low[s] : High[s], d > 0 ? 233 : 234, clr,
                 d > 0 ? ANCHOR_TOP : ANCHOR_BOTTOM, lvl != "" ? 2 : 1,
                 StringFormat("EP %s: nen A cach %d nen, rau %.1f pip; rau phia do da het%s", d > 0 ? "BUY" : "SELL", a - s, ag / pip,
                              lvl != "" ? " | A choc vao " + lvl : ""));
            break;
         }
      }
      // The pull-gone rule of the ZOU system at shift s (U1w, without its location / trend filters).
      if(InpShowU1w && s + 3 <= bars)
         for(int d = 1; d >= -1; d -= 2)
         {
            double ag, tw;
            ZoPull(zh[s], zl[s], zo[s], zc[s], d, ag, tw);
            bool ourBody = d > 0 ? zc[s] > zo[s] : zc[s] < zo[s];
            if(ag > MathMax(0.5 * pip, 0.1 * (zh[s] - zl[s])) || !ourBody)
               continue;
            bool pulled = false;
            for(int x = s + 1; x <= s + 3 && !pulled; x++)
            {
               if(!ok[x])
                  continue;
               double a2, t2;
               ZoPull(zh[x], zl[x], zo[x], zc[x], d, a2, t2);
               pulled = a2 >= MathMax(5 * pip, (zh[x] - zl[x]) / 3);
            }
            if(!pulled)
               continue;
            nU++;
            Mark(PFX + "U" + IntegerToString(s) + (d > 0 ? "b" : "s"), t, d > 0 ? Low[s] - 2 * pip : High[s] + 2 * pip, 161, InpClrU1w,
                 d > 0 ? ANCHOR_TOP : ANCHOR_BOTTOM, 1,
                 StringFormat("ZOU (U1w) %s: 1 trong 3 nen truoc co rau keo >= 5 pip va >= 1/3 bien do, nen nay het rau keo, than theo huong lenh",
                              d > 0 ? "BUY" : "SELL"));
         }
   }
   Comment(ZoUnaccent(StringFormat("ZO_Wick: %d râu dài (≥ %.0f pip) | %d điểm EP (nến đầu tiên hết râu sau nến A), trong đó %d ở điểm nhạy cảm (mũi tên màu)%s\n"
                                   "Chấm = MỌI nến có râu ≥ ngưỡng (vàng: chọc vào High / Low LP H4-D1-W1 hoặc số tròn; trắng: chỗ khác). Mũi tên = nến đầu tiên hết râu sau đó. Di chuột vào để xem số đo.",
                                   nA, InpMinWickPips, nEntry, nAtLevel,
                                   InpShowU1w ? StringFormat(" | %d vòng tím = luật U1w của hệ ZOU", nU) : "")));
   ChartRedraw();
}
